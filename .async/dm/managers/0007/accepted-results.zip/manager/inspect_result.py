"""Read-only review of r04's submitted source and preserved execution evidence."""
import ast
import hashlib
import json
import sys
from pathlib import Path

REPO = Path('C:/math')
RECORDS = REPO / '.async/dm'
HERE = RECORDS / 'managers/0007'
TASK = RECORDS / 'tasks/r04'
sys.path.insert(0, str(REPO / 'services/async-development'))
import workspaces

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

home, changes = workspaces.changes(RECORDS, 'r04')
report = read(TASK / 'report.json')
assert sorted(changes) == sorted(report['changes'])
verification = read(TASK / 'evidence/verification.json')
result = {'task': 'r04', 'changes': {}, 'runs': [], 'source_map': {}, 'historical': []}
for rel, (old, new) in sorted(changes.items()):
    assert sha(TASK / 'base' / rel) == old
    assert sha(REPO / rel) == old
    assert sha(TASK / 'workspace' / rel) == new
    assert verification['changed_hashes'][rel] == {'base': old, 'submitted': new}
    result['changes'][rel] = {'base': old, 'submitted': new, 'canonical_before': old}

for observed in verification['runs']:
    path = TASK / 'evidence' / observed['report']
    assert sha(path) == observed['report_sha256']
    raw = read(path)
    rows = [r for group in raw['reports'] for r in group['rows']]
    assert set(raw['selected']) == {r['id'] for r in rows}
    assert len(rows) == len({r['id'] for r in rows})
    for group in raw['reports']:
        child = read(path.parent / group['group'] / 'result.json')
        assert child['rows'] == group['rows']
    entry = {k: raw[k] for k in ['complete', 'successful', 'counts', 'fixture_counts', 'changed_during_run', 'total_seconds']}
    entry.update(edition=observed['edition'], report_sha256=sha(path), selected=raw['selected'],
                 rows=[{k:r[k] for k in ['id','outcome','seconds']} for r in rows],
                 task_observed_exit_code=observed['observed_exit_code'])
    if observed['edition'] == 'final':
        assert raw['complete'] and raw['successful'] and raw['counts'] == {'passed': 6}
        assert not raw['fixture_counts'] and not raw['changed_during_run']
        scripts = TASK / 'workspace/.claude/skills/do-math/scripts'
        mismatches = [p for p,h in raw['source_sha256'].items() if sha(scripts/p) != h]
        assert not mismatches
        entry['submitted_python_hashes'] = len(raw['source_sha256'])
        entry['mismatches'] = mismatches
    result['runs'].append(entry)

for rel, detail in read(TASK/'evidence/source-map.json').items():
    assert sha(TASK/'workspace'/rel) == detail['sha256']
    result['source_map'][rel] = {'submitted': detail['sha256'], 'canonical_before': sha(REPO/rel)}
    if rel not in changes:
        assert sha(REPO/rel) == detail['sha256']

for rel, names in verification['preserved_source_sections'].items():
    def segments(root):
        source = (root/rel).read_text(encoding='utf-8-sig')
        return {n.name:ast.get_source_segment(source,n) for n in ast.walk(ast.parse(source))
                if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    before, after = segments(TASK/'base'), segments(TASK/'workspace')
    assert all(before[n] == after[n] for n in names)
result['preserved_source_sections'] = verification['preserved_source_sections']
result['mirrors'] = []
for rel in changes:
    if rel.startswith('.claude/'):
        other = rel.replace('.claude/', '.agents/', 1)
        assert (TASK/'workspace'/rel).read_bytes() == (TASK/'workspace'/other).read_bytes()
        result['mirrors'].append([rel,other])
for target in ['claude','agents']:
    rel = f'.{target}/skills/do-math/scripts/tests/.timings.json'
    assert (TASK/'workspace'/rel).read_bytes() == (TASK/'base'/rel).read_bytes()
result['timings_restored'] = True

for observed in read(TASK/'evidence/inherited-evidence.json')['B85']:
    path = Path(observed['path'])
    assert sha(path) == observed['recorded_sha256']
    raw = read(path)
    rows = {r['id']:r for g in raw['reports'] for r in g['rows']}
    for row in observed['relevant_rows']:
        assert rows[row['id']] == row and row['outcome'] == 'passed'
    result['historical'].append({'path':str(path), 'sha256':sha(path), 'rows':observed['relevant_rows']})

result['decision'] = 'Accept bounded R04/1-A result after integration; receipt-content test gap repaired; condition/limit assertions retained.'
result['limits'] = ['No new manager product tests.', 'Task reports final exit 0; red exit remains unrecorded.',
    'Artifact path checks serializer output, not the entire engine workflow; operator path reads the published file.',
    'No full/fresh T3/mutation/real boundary gate; other 1-A families and R06 remain open.']
(HERE/'source-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'changes':len(changes),'final_rows':6,'python_hashes':875,'source_files':len(result['source_map']),
                  'historical_reports':len(result['historical']),'decision':'ready to integrate'},ensure_ascii=False))
