import json
from pathlib import Path

repo = Path('C:/math')
root = repo / '.async/dm'
queue = json.loads((root/'queue.json').read_text(encoding='utf-8-sig'))
assert 'r04' not in queue['accepted'] and not any(t['id']=='r03' for t in queue['tasks'])
old = next(t for t in queue['tasks'] if t['id']=='r05')
common = old['inputs'][:old['inputs'].index('C:/math/.async/dm/managers/0006/review.md')]
suffixes = ['tests/contracts/pairs.py','tests/contracts/test_pairs.py','tests/unit/test_toolchain_records.py',
    'tests/unit/test_trust_environment.py','tests/sim/test_toolchain_tools.py','tests/sim/test_public_record_storage.py',
    'tests/unit/test_observation_tracker.py','tests/support/trust_inputs.py','tests/support/observation_inputs.py',
    'tests/.timings.json']
writes = [f'.{target}/skills/do-math/scripts/{s}' for target in ['claude','agents'] for s in suffixes]
inputs = common + ['C:/math/.async/dm/managers/0007/review.md','C:/math/.async/dm/managers/0007/source-review.json',
    'C:/math/.async/dm/tasks/r04/report.json','C:/math/.async/dm/tasks/r04/evidence/verification.json',
    'C:/math/.async/dm/tasks/r04/evidence/result-assertion-map.json']
inputs += [f'.claude/skills/do-math/scripts/{s}' for s in suffixes if s!='tests/.timings.json']
inputs += [f'.claude/skills/do-math/scripts/{s}' for s in ['setup_lean.py','do_math/trust_inventory.py',
    'do_math/trust_validation.py','do_math/formal_engine.py','do_math/observations.py','do_math/observation_transport.py',
    'do_math/state_contract.py','do_math/record_schemas/schemas.py','tests/flows/test_storage_installation_costs.py',
    'tests/flows/test_observation_application.py']]
assert all((repo/p).exists() for p in inputs)
queue['tasks'].append({'id':'r03','kind':'work','depends_on':['r04'],'writes':writes,'inputs':inputs,
                      'model':'gpt-6.1-sol','effort':'high'})
queue['accepted'].append('r04')
queue['status'] = 'active'
for task_id in ['r05','r11']:
    active = next(t for t in queue['tasks'] if t['id']==task_id)
    assert not (set(active['writes']) & set(writes)) - {p for p in writes if p.endswith('/.timings.json')}
(root/'managers/0007/queue.pending.json').write_text(json.dumps(queue,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print({'tasks':len(queue['tasks']),'accepted':queue['accepted'],'new':'r03'})
