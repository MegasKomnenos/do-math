# 공용 인터페이스와 작업 사본의 경계

제품의 정본은 각 workspace 안 `.claude/skills/do-math/scripts/do_math/`의 실제 정의와 `.claude/skills/do-math/scripts/tests/contracts/`, `.claude/skills/do-math/scripts/이음새-정본.md`다. 기존 상세 연결과 변경 이유는 sources/legacy/seams.md에 보존했다. 그 원문 속 run: 경로는 이전 실행 기록 루트 기준이다. 초기 세 읽기 작업 사이에 새 제공/소비 API는 없다.

- R02는 현재 역할 요청 생산자와 worker/정본 schema 수신자를, R07은 test_schema_builders의 실제 반환 경로와 소유 모집단을, R18은 현재 adapter/real port 호출과 실제 배선을 기존030 objective의 정확한 심볼로 연결한다. 서로의 미완성 결과를 소비하지 않는다.
- 새로운 인터페이스가 필요한 작업에서는 실제 정의의 파일·심볼, 입력·출력·실패·부수 효과와 소비 책임을 먼저 적는다. 기존 정의를 별도 문서 schema로 재발명하지 않는다.
- source_repo는 C:/math이고 manager가 통합하는 공용 판본이다. task는 workspace만 수정한다. task의 시작 inputs/base/baseline이 수행 중 고정되고, manager의 다른 결과 통합은 이미 실행 중인 workspace를 바꾸지 않는다.
- manager는 workspaces.py integrate의 충돌 결과를 존중한다. 같은 파일이 양쪽에서 달라졌다면 원본을 덮거나 workspace를 공용 소스에 통째로 복사하지 않고 필요한 조정 작업을 배정한다. 승인한 무변경 조사도 integrate의 변경 없음 기록 뒤 accepted에 넣는다.
- 정본 스킬과 대응 미러는 같은 task의 쓰기 범위에 함께 둔다. 공식 생성기가 자기 workspace에서 예상한 범위만 바꾸는지 확인한다. 공용 판본의 snapshot과 integration을 serialize하는 source.lock은 서비스가 관리하며 세션이 삭제하지 않는다.
- 실제 외부 자원·최종 전체 관문의 공유 경계는 manager가 충돌 없이 배정한다. 독립 workspace의 소규모 검증은 각jobs1로 수행할 수 있고 총시험worker3 이하를 유지한다. 제품 의미·판정·원자료 무결성을 줄여 속도를 맞추지 않는다.

## 이번 세 읽기의 실제 연결과 보고 경계

- r02: `do_math/model_runner.py:ModelRunner` 및 현재 adapter의 요청 조립, `worker_request.py`의 `check_codex_request`/`check_claude_request`, `codex_worker.py`/`claude_worker.py`의 load 경계가 대상이다. `tests/contracts/pairs.py:_worker_request_samples`와 `test_pairs.py`의 required/optional 역방향 단언이 실제 저장·수신까지 무엇을 입증하는지 구별한다. 이 문서는 새 요청 schema를 정의하지 않는다.
- r07: `tests/structure/test_schema_builders.py`의 `_calls`, `_composition_calls`, `_constant_object_calls`, `TRANSFORMERS`, `DELEGATED_SCHEMA_METHODS`가 현 등록이다. 실제 contracts/control/record schema와 engine·review_cycle·knowledge_io·planning 반환의 소유 계약에 대응한다. caller 입력을 빌리는 transformer나 read-only borrowed row를 임의 copy 의무로 바꾸지 않는다.
- r18: `tests/structure/test_boundary_invariants.py`의 `PROCESS_STARTS`, `INJECTED_STARTS`, `JOB_RUN_STARTS`, `INTERPRETER_USES`, `EXECUTABLE_IDENTITY` 및 발견 함수와 `file_io.py`의 소유 규칙을 실제 windows_job/git_process/cli_worker/formal/scheduler 및 최상위 도구 호출에 연결한다. 현재 누락과 장래 가상 우회 가능성을 구별한다.
- 세 task의 제품 경로는 자기 workspace 상대 경로다. `C:/math/docs/...`와 `C:/math/.async/dm/...` 입력은 읽기 전용 원자료다. 과거 문서 안 `run:`은 legacy 실행 루트, 과거 `repo:docs/...`는 공용소스의 원자료를 뜻한다. workspace에 없는 대형 기록을 제품 누락으로 판정하지 않는다.
- source 판본 비교는 task의 `baseline.json`과 자기 workspace를 기준으로 하고, 이관 기준은 `managers/0001/source-inspected.json`의 스킬2675파일과 교집합에서 대조한다. 실제 차이가 있으면 명시한다. 이후 manager가 공용소스에 다른 결과를 반영해도 이미 실행 중인 task는 자기 고정판으로 완료한다.
- 보고는 async protocol의 `status`, `summary`, 문자열 목록 `changes`/`findings`, `verification`을 사용한다. 제품 무변경 조사는 changes=[]이다. 각 finding 문자열에는 해당 요구·증거 파일/심볼·영향과 다음 행동을 함께 적고 자세한 표는 자기 evidence를 참조한다.

## r02-fix 수용 후 요청 시험의 실제 계약

새 제품 API는 없다. `ModelRunner.run` (`do_math/model_runner.py`)은 `model_call.runner_assignment`가 검사한 배정으로 `worker_request_fields`의 결과를 evidence/request.json에 쓴다. `codex_adapter.LocalCLIAdapter.start`는 공급자별 `load_request`로 이를 검사하고 prompt/schema를 사유 snapshot 경로로 옮긴다. `codex_worker.run` 또는 `claude_worker.run`은 snapshot 요청을 다시 읽어 CLI argv를 만든다. 수용된 r02-fix의 worker_request_run은 이 경로의 실제 저장값을 시험 표본으로 사용한다.

- pinned 입력은 execution_id와 AI profile, 해당 profile SHA의 dispatched ticket, 정확 prompt_seal을 함께 준다. model/effort가 profile.ai와 다르거나 seal이 입력과 다르면 runner가 거부한다. host limits가 있는 profile은 일치하는 host와 resume 전 `on_started` publication도 필요하다.
- pinned scholarly/model-lock 설정은 profile.ai에서만 온다. 같은 설정을 별도 caller override로 주면 거부된다. unpinned 호출은 identity/ref/limits/control 없이 caller 설정을 사용한다. control binding은 해당 execution과 workspace를 가리키며 control이 있으면 CLI output schema를 전달하지 않는다. unbound일 때 Codex는 전송 schema, Claude는 의미 schema를 받는다.
- 수신 필드 정본은 `worker_request.py`의 COMMON/CODEX/CLAUDE REQUIRED·OPTIONAL과 `check_codex_request`/`check_claude_request`다. `validate_execution_binding`은 profile_ref의 형식과 identity·limits·control 관계를 검사한다. 프로필 registry의 AI 의미까지 재검사하는 경계가 아니다.
- `tests/support/provider_runs.py:ProviderJobs`는 실제 worker를 실행하고 `ScriptedCLI`는 worker.spawn만 대체한다. `dispatched`와 `model_runner`도 기존 fixture다. 새 fake runner/adapter/collector를 만들거나 저장 요청을 다시 조립해 관찰값으로 대체하지 않는다.
- `tests/contracts/pairs.py:Pair.samples`는 `(branch, value)` 목록을, `receive`는 수신 검사/ValueError 반려를 제공한다. `fields`의 필수+선택 역방향과 현재 lock 두 값의 성질을 유지한다. 실제 profile의 lock/tool 설정 변경은 profile_ref를 바꿀 수 있으므로 각 요청 참조를 자기 profile에 대조한다. 서로 다른 실행의 경로·참조 차이와 CLI lock 효과를 구별하고 정규화로 binding 검사를 지우지 않는다.

공급자별 기존 유효20조합과 필드35행의 정의·한계는 tasks/r02/evidence/branch-field-map.json이다. scholarly args의 0/1/여럿은 목록 축이며 identity/control 객체를 여러 개 만드는 요구가 아니다. r02-fix는 이 조합과 정확 값 전달을 관련6개 공식 시험에서 확인했다. worker_request_runs가 실제20입력을 공급자별로 실행하며 request/staged와 fixture 기대 입력을 함께 돌려준다. 파일이 살아 있는 동안 assert_worker_run이 정확 profile_ref·limits·control·prompt/schema·CLI·collector를 확인한다. 최종 G4~G8의 전체 판본 실행은 별도 배정까지 남긴다.

## r07 수용 후 반환 소유권 수리의 연결

새 API는 없다. `do_math/provider_final.py:output_contract(provider, schema)`는 caller의 JSON schema dict를 받아 공급자 CLI의 전송 schema dict를 반환한다. Codex는 필수 문자열 output_json 하나를 갖는 닫힌 객체를 만들고 원 schema를 description에 JSON으로 담는다. Claude는 같은 의미 schema를 복사하며 미지원 provider는 ValueError다. 현재 Claude 구현의 deepcopy는 입력/다른 반환은 분리하지만 같은 반환 내부의 반복 노드를 보존한다. 정본 `scripts/이음새-정본.md` 5절은 이 내부 공유도 금지한다. r07-fix는 이 분기에 기존 `values.py:json_copy`를 적용한다.

`ModelRunner.run`은 unbound Codex에만 output_contract를 호출해 transport.schema.json에 저장한다. Claude는 output.schema.json에 원 schema를 바로 직렬화한다. `provider_final.semantic_output`도 Codex 봉투 검증에 이 함수를 사용한다. 반환 소유권 수리를 Claude 실제 전송 실패로 해석하지 않는다.

`tests/structure/test_schema_builders.py:_composition_calls`는 이름에 schema가 없는 생성자의 실제 호출 변형을 제공하고 `_isolation_problems`는 각 변형을 두 번 호출해 결과를 유지한 채 dict/list ID의 전역·다른 반환·결과 내부 공유를 판정한다. r07-fix는 두 공급자와 shared-leaf schema를 여기에 연결한다. 값 보존과 caller 입력 격리는 해당 명시 입력과 실제 반환으로 확인한다. 기존 transformer·borrowed lookup의 소유 계약은 유지한다.

r07-fix의 쓰기 경계는 provider_final·해당 구조 시험·관련 정본 설명 및 각 미러다. r02-fix가 쓰는 pairs/provider_runs/pinned_runner는 읽기 전용이다. 공식 실행으로 생성된 r07-fix의 두 비용 캐시는 evidence 보존 후 자기 base로 복원해 최종 통합 delta에 포함하지 않는다. 공유 캐시 때문에 새 선행 의존성을 만들지 않는다.

## r18 수용 후 파일 교체 소유권 검사 연결

새 제품 API는 없다. `do_math/file_io.py:_windows_files`는 Windows API의 create·close·invalid handle·rename 네 값을 반환한다. rename은 `kernel.SetFileInformationByHandle`의 binding이다. `_replace_once(source, destination)`는 이 tuple을 받아 rename(handle, 22, buffer, size)으로 현재 Windows 교체를 수행하고 finally에서 handle을 닫는다. 비Windows 분기는 os.replace를 쓴다. `atomic_replace`는 공유 위반 5/32/33에만 같은 교체를 재시도하며 다른 오류는 그대로 전달한다. 이 runtime의 변경은 r18-fix 범위에 없다.

`tests/structure/test_boundary_invariants.py:_sites`는 `_product_files`의 실제 AST에서 상대 경로·소유 함수·노드를 제공한다. 기존 `test_only_file_io_replaces_files`는 os.replace/shutil.move Call만 발견하여 native binding과 별칭 소비를 빠뜨린다. r18-fix는 현재 native 경로를 발견 결과에 연결하고 소유자가 file_io인지 검사한다. 현재 source의 binding·소비가 모두 관찰돼야 하며, 같은 native 코드를 다른 모듈로 옮긴 AST source는 반려돼야 한다. 시험용 fixture도 실제 검사에 쓰는 탐색 함수를 사용한다. 범용 Python 별칭 분석기나 WinAPI 실호출을 새로 만들 필요는 없다.

기존 `boundary/test_storage_atomic_replace.py:MetadataPublicationTests`의 실제 파일 버전·같은 rename 재시도·영구/부재 오류·Unicode/긴 경로/길이 변경 성질은 보존 018 원보고의 4행 범위로 유지한다. 구조 검사 수리의 통과를 새 Windows 실행 증거로 세지 않는다. r18-fix는 해당 structure 모듈·미러와 필요한 최소 반례를 확인하며 비용 캐시는 자기 evidence 보존 후 base로 복원한다. r07-fix가 쓰는 제품 정본 문서와 다른 수리의 파일은 수정하지 않는다.

## r04가 소비하는 조건·한도·결과 계약

새 API는 없다. contracts/pairs.py의 enumerated_pointers는 planning.EXPOSED_FIELDS·RECORD_FAMILIES와 StateContract의 노출 필드 enum을 연결한다. _condition_pairs는 저장 enum과 lifecycle 후보를 validate_condition에 보내 실제 수용값이 저장 enum 안인지, 역방향으로 필요한 값이 생산되는지 검사한다. enum 값과 객체 필드의 모집단은 구분한다.

task_contracts.REPEAT_LINEAGES는 현재 import_rework·selection_failure·exhaustion_empty·proposal_version·contract_revision이다. revisions.record_repetition은 instance.config의 lineage + '_limit'를 읽는다. test_storage_fields의 이름 사용/읽기 연결은 구조 성질이며 test_repetition_hold_contract의 실제 count·임계 hold·정확 사용자 계속·중복 불변이 행동 성질을 맡는다. r04는 이 좁은 연결의 충분성만 판단하고 반복/대기 전체 요구로 확대하지 않는다.

_runner_result_samples는 실제 runner/worker/collector의 두 공급자 × collected/bound/incomplete/stopped 여덟 결과다. _receive_stored_result는 call_engine·scheduler가 쓰는 canonical_json(payloads.json_safe(result))를, _receive_operator_record는 scheduled_operator._json의 실제 파일 출력을 사용한다. json_safe는 bytes를 증거 객체로, Path와 안전 정수 범위 밖 값을 문자열로, float를 reported_decimal 객체로 투영한다. _json은 bytes/Path를 변환하고 allow_nan=False의 JSON 파일을 원자 게시한다. 두 표현의 차이를 무조건 같은 값으로 정규화하지 않는다. r04는 계약에 따른 실제 내용 보존과 단순 무예외 직렬화를 구별한다.

r04는 수용된 요청 시험을 보존하고 기존 pair/외부 대역을 재사용한다. 쓰기는 관련 시험4파일과 각 미러이며 runtime·r07 정본 설명·r18 구조 검사는 읽기 전용이다. 확인된 runtime 결함은 정확 반례와 함께 후속으로 보고한다. 비용 캐시는 자기 evidence에 보존한 뒤 base로 복원한다.
