"""Capture actual deltas, final source match, and the bounded task report."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

TASK = Path(__file__).resolve().parents[1]
W = TASK / 'workspace'
SCRIPTS = W / '.claude/skills/do-math/scripts'
E = TASK / 'evidence'

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

baseline = load(TASK / 'baseline.json')
current = {path.relative_to(W).as_posix(): sha(path) for path in W.rglob('*') if path.is_file()}
changes = sorted(key for key in baseline.keys() | current.keys() if baseline.get(key) != current.get(key))
assignment = load(TASK / 'task.json')
assert set(changes) <= set(assignment['writes']), changes
assert len(changes) == 4, changes
diffs = []
for key in changes:
    if key.startswith('.claude/'):
        diffs.extend(difflib.unified_diff((TASK / 'base' / key).read_text(encoding='utf-8').splitlines(True),
                                        (W / key).read_text(encoding='utf-8').splitlines(True),
                                        fromfile='base/' + key, tofile='workspace/' + key))
(E / 'source.diff').write_text(''.join(diffs), encoding='utf-8')

def sections(path):
    source = path.read_text(encoding='utf-8')
    return {node.name: ast.get_source_segment(source, node) for node in ast.walk(ast.parse(source))
            if isinstance(node, ast.FunctionDef)}

preserved = {}
targets = {
    'contracts/pairs.py': ['worker_request_run', 'worker_request_runs', '_worker_request_samples',
        '_worker_request_fields', '_receive_worker_request', 'accepted_condition', 'enumerated_pointers',
        '_condition_pairs', '_runner_result_samples'],
    'contracts/test_pairs.py': ['test_every_producer_branch_is_received_and_every_named_field_is_produced',
        'test_worker_samples_preserve_both_assigned_model_flags_for_each_legal_assignment',
        'request_without_run_paths', 'assert_worker_run', 'test_scholarly_args_zero_one_and_many_reach_both_worker_commands',
        'test_every_rule_id_the_tracker_accepts_is_storable',
        'test_the_condition_grammar_rejects_values_outside_every_stored_enumeration'],
}
for relative, names in targets.items():
    key = '.claude/skills/do-math/scripts/tests/' + relative
    before, after = sections(TASK / 'base' / key), sections(W / key)
    preserved[key] = {name: before[name] == after[name] for name in names}
    assert all(preserved[key].values())

mirrors = []
for relative in ('contracts/pairs.py', 'contracts/test_pairs.py', 'structure/test_storage_fields.py',
                 'unit/test_repetition_hold_contract.py', '.timings.json'):
    a, b = (W / ('.' + runtime) / 'skills/do-math/scripts/tests' / relative for runtime in ('claude', 'agents'))
    mirrors.append({'relative_test_path': relative, 'equal': a.read_bytes() == b.read_bytes(), 'sha256': sha(a)})
    assert mirrors[-1]['equal']

final = load(E / 'final/report.json')
source_match = {'count': len(final['source_sha256']),
                'mismatches': [key for key, digest in final['source_sha256'].items() if sha(SCRIPTS / key) != digest]}
assert not source_match['mismatches']
rows = [row for group in final['reports'] for row in group['rows']]
assert len(rows) == len(final['selected']) == len({row['id'] for row in rows}) == 6
assert {row['id'] for row in rows} == set(final['selected'])
assert all(row['outcome'] == 'passed' for row in rows)
assert final['complete'] and final['successful'] and not final['changed_during_run'] and not final['fixture_counts']

runs = []
for edition, code, reason in (
    ('red', None, 'Old receive helpers discard decoded content: sixteen subtest errors (NoneType). Tool exit was not retained; report is complete/unsuccessful.'),
    ('green', 1, 'First observation run exposed an incorrect test expectation: termination_barrier.process_ids tuple serializes to []. Corrected the test; no runtime change.'),
    ('green2', 0, 'Small corrected content check: eight actual results through both JSON consumers.'),
    ('final', 0, 'Complete related module handoff; all existing six IDs retained.')):
    data = load(E / edition / 'report.json')
    runs.append({'edition': edition, 'report': edition + '/report.json', 'report_sha256': sha(E / edition / 'report.json'),
                 'observed_exit_code': code, 'reason': reason, 'selected': data['selected'],
                 'complete': data['complete'], 'successful': data['successful'], 'counts': data['counts'],
                 'fixture_counts': data['fixture_counts'], 'changed_during_run': data['changed_during_run'],
                 'total_seconds': data['total_seconds'],
                 'rows': [{k: r[k] for k in ('id', 'outcome', 'seconds')}
                          for g in data['reports'] for r in g['rows']]})

save(E / 'verification.json', {
    'runs': runs, 'changes': changes,
    'changed_hashes': {key: {'base': baseline.get(key), 'submitted': current.get(key)} for key in changes},
    'preserved_source_sections': preserved,
    'unchanged_structure_and_unit': {relative: sha(W / relative) == baseline[relative] for relative in (
        '.claude/skills/do-math/scripts/tests/structure/test_storage_fields.py',
        '.claude/skills/do-math/scripts/tests/unit/test_repetition_hold_contract.py')},
    'final_python_source_match': source_match, 'mirrors': mirrors,
    'timings': {'preserved': ['timings/claude.json', 'timings/agents.json'],
                'restored_to_own_base': {runtime: sha(W / ('.' + runtime) / 'skills/do-math/scripts/tests/.timings.json') ==
                                        baseline['.' + runtime + '/skills/do-math/scripts/tests/.timings.json']
                                        for runtime in ('claude', 'agents')}},
    'mirror_generator': {'final_build_exit_code': 0, 'final_build_result': '0 created, 0 updated, 0 deleted; first build had already generated the matching mirrors',
                         'check_exit_code': 0, 'check_result': 'no drift (1336 files)'},
    'budget': final['budget'],
    'limits': ['Jobs and CLI spawn are the existing external doubles; runner/adapter/workers/collector and serializers are real.',
               'Six official rows contain the request 40-input matrix, args6 and result8/JSON16 checks; these are not separate official test rows.',
               'Artifact receiver decodes canonical artifact bytes used by call_engine/scheduler; operator receiver reads the file actually written by _json. Does not run full engine/scheduler/operator workflows.',
               'Unchanged repetition/structure modules were statically reviewed, with bounded original B85 rows; no fresh r04 execution of those modules.',
               'No real remote model, installation, Job, Lean, scheduler or scholarly call; no G4-G8/full T3/mutation/T4/T5 gate execution.']
})

save(E / 'result-assertion-map.json', {
    'test_id': 'contracts.test_pairs.ContractPairTests.test_runner_samples_cover_success_bound_incomplete_and_stopped',
    'producer': 'contracts/pairs.py:_runner_result_samples -> ModelRunner.run -> provider adapter -> actual worker.run -> actual collect -> model_call.classify_run',
    'consumer_paths': {
        'runner result (stored artifact)': 'call_engine.py:_publish_provider_result/canonical_json(json_safe(result)); scheduler.py same encoding; _receive_stored_result returns json.loads of those bytes',
        'runner result (operator file)': 'scheduled_operator.py:_json(path,result); _receive_operator_record reads the actually published file via read_bytes_shared and json.loads',
    },
    'rows': [{'provider': provider, 'branch': branch, 'json_consumers': 2,
              'status': status, 'output': output, 'collection_present': branch == 'collected, bound',
              'error_kind_present': branch in ('incomplete','stopped'), 'bound_identity': branch == 'collected, bound'}
             for provider in ('codex','claude') for branch, status, output in (
                 ('collected','completed',{}), ('collected, bound','completed',None),
                 ('incomplete','failed',None), ('stopped','stopped',None))],
    'assertions': [
        'Original runner status/output/collection/error_kind/collect result, reasons, error, confirmed barrier, byte lengths/SHA and bound request/final remain in the same method.',
        'Both decoded results preserve top/execution/collect key populations; collection and error_kind presence is branch-specific; explicit null output/error/execution_id/profile_ref/host_resources/schema_sha256 is checked separately from missing status identity.',
        'Exact started receipt, worker_status/process_identity/stop_receipts/provider_observation and binding/profile references are compared to the already checked actual producer values; terminal barrier is explicitly (0,[],True,True).',
        'All five collected raw artifacts (request,prompt,stdout,stderr,final) retain exact length, digest, lossy text and reversible base64. Expected digest/base64 derive directly from raw bytes, never bytes_evidence or a receiving serializer.',
        'Codex usage=(1,1), Claude usage=(7,3), model usage and ordered usage segment derive from ScriptedCLI fixture inputs; parsed result and selected-result nulls retain actual receipt content.',
        'Fixture decimal 0.0123 must be {reported_decimal:0.0123-text} in stored artifact and numeric 0.0123 in operator file. Only that expected parsed leaf differs; no normalization equates the two consumers.'
    ],
    'decision': 'Bounded receipt-content gap repaired. No runtime defect observed in these eight results; all broader value/null/family and final-edition gates remain outside this task.'
})

save(TASK / 'report.json', {
    'status': 'complete',
    'summary': 'R04/1-A의 조건 enum·반복 한도 다섯 키·러너 영수증 JSON 전달 질문을 완료했다. 현재 노출36포인터 중 enum17포인터/57값은 저장 정의와 pair가 일치하고 lifecycle 후보 차이·누락이 없어 기존 순방향/값 역방향/반려 단언을 유지했다. 다섯 계보의 실제 config 읽기와 한도2 직전/도달·정확 사용자 계속·중복 불변 단언은 좁은 소비 질문에 충분해 유지했다. 결과 수신 helper가 직렬화 결과를 버리던 시험 공백은 실제 canonical artifact bytes 및 operator 게시 파일의 JSON을 반환하게 고치고, 기존 실제8결과를 두 경로에 연결해 중첩 영수증·bytes/hash/base64·null/부재·Claude decimal 차이를 단언했다. 정본 시험2파일과 미러2파일만 변경했으며 runtime과 요청40조합/args/lock 단언은 보존했다.',
    'changes': changes,
    'verification': '정적 모집단 대응은 evidence/condition-population.json(36노출/17enum/57값, 누락0·lifecycle차이0), repetition-map.json, source-map.json에 기록했다. 보존 B85 원보고3개는 실제 해시·해당 storage/repetition row를 확인했으며 현재 실행으로 합산하지 않았다. 수리 단언을 먼저 추가한 red는 구 수신 helper의 None 반환에서16 subtest 오류가 난 complete/unsuccessful 공식1row다(exit 미보존). 첫 관찰 실행 green의 tuple→JSON배열 기대 오류를 시험에서 수정한 뒤 green2는1passed/exit0. 최종 contracts.test_pairs --jobs 1은 기존6ID/고유6row 전부passed, exit0, 7.7초, fixture오류·미실행·실행 중 정본소스 변경 없음이다. Python875개 SHA가 제출판과 전부 일치한다. 요청40입력/args6와 실제 결과8→JSON16은 공식6row 안의 단언이며 독립 시험 counts로 세지 않는다. 공식 미러 생성 및 --check --target .agents exit0, 1336파일 드리프트 없음, 관련5쌍 바이트 일치. 비용캐시2개는 evidence/timings에 보존한 뒤 own base로 복원했으며 baseline 대비 실제 변경4개가 writes 안이다. 결과 단언/소비 경로는 evidence/result-assertion-map.json, 실제선택·row·exit·판본·비용·변경과 보존은 verification.json/source.diff에 있다. 변경하지 않은 storage/repetition 시험은 정적 검토로 끝내고 다시 실행하지 않았다. 전체/실경계 관문은 실행하지 않았다.',
    'findings': [
        'R04 조건 slice 유지 | planning.EXPOSED_FIELDS/RECORD_FAMILIES/lifecycle_values/validate_condition과 StateContract의 현재17enum/57값을 연결했다(condition-population.json). 36노출 중 나머지는 비enum/계산 필드이고 instance의 governance 판본은 instance_record로 투영되므로 enum 모집단으로 확대하지 않았다. Pair.fields/written의 역방향은 enum 값 모집단이며 worker 객체의 필수+선택 필드35행과 구별한다. 최종 generic/rejection row가 통과했으며 새 조건 시험·runtime 수정은 없다.',
        'R04 반복 한도 slice 유지 | REPEAT_LINEAGES의 import_rework/selection_failure/exhaustion_empty/proposal_version/contract_revision 각각의 _limit는 revisions.record_repetition의 실제 가변 config 읽기로 hold를 만든다. storage_fields는 AST 읽기/이름 사용만, repetition_hold_contract는 count1/2·hold(2,2,user)·정확 scope/hold 계속·중복 전체불변·해소를 단언한다(repetition-map.json). 충분한 기존 구조와 행동을 유지하고 전체 반복/대기 요구·임의 한도 공간을 새로 종결하지 않는다. B85 원보고3개의 해당4row와 해시만 한정 확인했다.',
        'F1 수리 완료 | R04/1-A·G1/G3·PR18 계약쌍 slice: _receive_stored_result/_receive_operator_record가 실제 수신 표현을 관찰 가능하게 반환하며 기존8 actual runner result에 각각2 JSON 경로의 내용 단언을 적용했다. expected는 fixture/원바이트/명시 계약에서 얻고 json_safe·bytes_evidence·_json으로 재계산하지 않는다. bytes영수증의 length/SHA/text/base64, started/worker/barrier/stop receipts, 정확 null/부재 및 Claude 비용의 artifact 객체/operator 숫자 차이를 보존했다(result-assertion-map.json). 해당 runtime 결함은 관측하지 않았고 후속 runtime 쓰기는 필요하지 않다.',
        'R02 수리 및 PR18 한정 보존 | 시작 base의 수용 r02-fix6경로 SHA가 manager0005 제출SHA와 같다. worker_request_run/runs·40조합·정확profile_ref/binding·lock·args0/1/여럿과 enum/helper·generic 역방향·결과 생산자는 소스구간 그대로 유지했다(verification.json). 최종 기존6ID를 모두 다시 확인했다. 공유규칙/작은 유한 공간의 계약쌍 성질만 판단했으며 PR18 B70~B73의 다른 권한/바이트예산/환경 분류·K/P2 전체를 새로 수용하지 않는다.',
        '비용·범위 | 최종7.7초 중 네 공식ID는0.2초 소프트 기준을 넘었다(4.375/0.469/0.437/2.422초). 실제파일·worker·collector와 내용 보존 경로 확인 비용이며 단언/입력을 줄이지 않았다. Jobs/CLI spawn만 기존 외부대역이고 원격모델·실Job·설치·Lean·예약·학술 호출은 없다. 캐시는 근거 보존 후 base복원해 delta에서 제외했다.',
        '최종 판본 대기 유지 | R04 배정의 좁은 질문은 종료했지만 이번6row는 G4~G8 전체·fresh T3·전체변이·T4/T5를 대체하지 않는다. 다른1-A 가족·R05/R06 전체 외부값/null·PR18/K/P2 미결, 029설치/prompt판본 한계, L01 Q1/Q2·UTF-8 byte 미충족, Windows1314 symlink실반려 미검사는 그대로 남는다. 공용소스·다른task·engine·inputs/base·Git index·graphify는 수정하지 않았으며 manager의 통합/수용은 다음 단계다.'
    ]
})
print(json.dumps({'changes': changes, 'source_match': source_match,
                  'final': final['counts'], 'selected_rows': len(rows)}, ensure_ascii=False))
