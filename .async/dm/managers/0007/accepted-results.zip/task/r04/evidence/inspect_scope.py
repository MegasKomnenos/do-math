"""Read-only source/population and inherited-evidence capture for r04."""
import ast
import hashlib
import json
from pathlib import Path
import sys

TASK = Path(__file__).resolve().parents[1]
WORKSPACE = TASK / 'workspace'
SCRIPTS = WORKSPACE / '.claude/skills/do-math/scripts'
RUN = Path('C:/math/docs/do-math/continuous-development-2026-10-13')
BOARD = Path('C:/math/docs/do-math/시험-재편-2026-09-29/단계-전환표-2026-10-03.json')
sys.path[:0] = [str(SCRIPTS), str(SCRIPTS / 'tests')]
from do_math import planning, task_contracts
from do_math.state_contract import default_state_contract
from contracts.pairs import enumerated_pointers

def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (TASK / 'evidence' / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

closure = RUN / 'phases/001/tasks/closure-map/evidence'
board = load(BOARD)
catalog = load(closure / 'evidence-catalog.json')
save('original-slices.json', {
    'requirement_index_1_A': [r for r in load(RUN / 'sources/requirements-index.json')['rows'] if r['id'] == '1-A'],
    'requirement_state_1_A': [r for r in load(closure / 'requirement-state.json')['rows'] if r['id'] == '1-A'],
    'tracking_R04': [r for values in load(closure / 'tracking-state.json').values() if isinstance(values, list)
                     for r in values if isinstance(r, dict) and r.get('id') == 'R04'],
    'prior_PR18': [r for r in load(closure / 'prior-review-state.json')['review_units'] if r['id'] == 'PR18'],
    'board_1_A': [r for r in board['obligations'] if r['id'] == '1-A'],
    'boundary_storage_guard_correction': board['current_work']['boundary_storage_guard_correction'],
    'catalog_boundary_storage_guard_correction': catalog['integrations']['current_work.boundary_storage_guard_correction'],
})

contract = default_state_contract()
found = {(f, s, p): list(values) for f, s, p, values in enumerated_pointers()}
exposed = []
for family, pointers in sorted(planning.EXPOSED_FIELDS.items()):
    space, key = planning.RECORD_FAMILIES[family]
    for pointer in sorted(pointers):
        name = pointer[1:]
        scalar = contract.family(space, name) if key is None else None
        schema = ((scalar.schema if scalar is not None else {}) if key is None else
                  contract.family(space, key).schema['properties'].get(name, {}))
        enumeration = schema.get('enum')
        lifecycle = sorted(planning.lifecycle_values().get(family, ())) if pointer in ('/status', '/lifecycle') else []
        exposed.append({'family': family, 'space': space, 'storage_family': key if key is not None else name,
                        'pointer': pointer, 'stored_enum': enumeration, 'stored_type': schema.get('type'),
                        'lifecycle_candidates': lifecycle, 'pair_enumeration': found.get((family, space, pointer)),
                        'lifecycle_only': sorted(set(lifecycle) - set(enumeration or ())),
                        'stored_only': sorted(set(enumeration or ()) - set(lifecycle)) if lifecycle else [],
                        'pair_registered': (family, space, pointer) in found})
save('condition-population.json', {
    'kind': 'Current definition census; execution is the final generic pair and rejection test rows.',
    'exposed_pointer_count': len(exposed), 'enum_pointer_count': len(found),
    'stored_enum_value_count': sum(len(row['stored_enum'] or []) for row in exposed),
    'rows': exposed,
    'missing_or_different': [row for row in exposed if row['stored_enum'] != row['pair_enumeration']],
    'assertions': {
        'forward': 'contracts.test_pairs.ContractPairTests.test_every_producer_branch_is_received_and_every_named_field_is_produced: accepted stored/lifecycle candidates pass Pair.receive membership check',
        'reverse': 'same ID: Pair.fields is the stored VALUE enumeration; pair.written extracts value, not object keys',
        'rejection': 'contracts.test_pairs.KnownPairDefectTests.test_the_condition_grammar_rejects_values_outside_every_stored_enumeration: non-enum sentinel rejected for each actual pointer',
        'instance': 'goal_status is a scalar TEXT family; goal_revision/policy_revision are derived by planning.instance_record/governance_revisions, not registered scalar fields (condition schema lookup uses {}). Knowledge usable_as_k is also computed by evaluate_condition/assess_use. No current enum is skipped by key=None. This is an enum census, not certification of all non-enum exposed pointers.',
    },
})

reports = []
for label, spec in board['current_work']['boundary_storage_guard_correction']['reports'].items():
    path = Path('C:/math') / spec['path']
    entry = {'label': label, 'path': str(path), 'exists': path.exists(), 'recorded_sha256': spec['sha256']}
    if path.exists():
        data = load(path)
        entry.update(sha256=sha(path), matches_recorded_hash=sha(path) == spec['sha256'],
                     complete=data.get('complete'), successful=data.get('successful'),
                     changed_during_run=data.get('changed_during_run'),
                     relevant_rows=[row for group in data.get('reports', []) for row in group.get('rows', [])
                                    if 'test_storage_fields' in row['id'] or 'test_pairs' in row['id']
                                    or 'test_repetition_hold_contract' in row['id']])
    reports.append(entry)
save('inherited-evidence.json', {
    'B85': reports,
    'r02_fix': {
        'report': load(Path('C:/math/.async/dm/tasks/r02-fix/report.json')),
        'verification': load(Path('C:/math/.async/dm/tasks/r02-fix/evidence/verification.json')),
        'final_rows': [row for group in load(Path('C:/math/.async/dm/tasks/r02-fix/evidence/final/report.json'))['reports']
                       for row in group['rows']],
        'base_matches_accepted': {item['path']: sha(TASK / 'base' / item['path']) == item['submitted']
                                  for item in load(Path('C:/math/.async/dm/managers/0005/source-review.json'))['changes']},
    },
    'limits': 'Historical rows are not current full-edition runs. Only inspected relevant rows receive credit. No absent report counts are added.',
})

sources = ['planning.py', 'task_contracts.py', 'revisions.py', 'state_contract.py', 'record_schemas/schemas.py',
           'payloads.py', 'canonical.py', 'call_engine.py', 'scheduler.py', 'scheduled_operator.py',
           'model_runner.py', 'model_call.py', 'values.py', 'codex_adapter.py', 'claude_stream.py', 'codex_stream.py']
tests = ['contracts/pairs.py', 'contracts/test_pairs.py', 'structure/test_storage_fields.py',
         'unit/test_repetition_hold_contract.py', 'support/provider_runs.py']
provenance = {}
for directory, paths in ((SCRIPTS / 'do_math', sources), (SCRIPTS / 'tests', tests)):
    for relative in paths:
        path = directory / relative
        tree = ast.parse(path.read_text(encoding='utf-8'))
        provenance[path.relative_to(WORKSPACE).as_posix()] = {
            'sha256': sha(path),
            'symbols': {node.name: {'line': node.lineno, 'end_line': node.end_lineno}
                        for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.ClassDef))},
        }
save('source-map.json', provenance)
save('repetition-map.json', {
    'kind': 'Static correspondence; these unchanged tests were not rerun by r04.',
    'lineages': [{'lineage': name, 'config_key': name + '_limit'} for name in task_contracts.REPEAT_LINEAGES],
    'reader': 'do_math/revisions.py:record_repetition reads instance.config[lineage + _limit], computes actual count and appends a hold with the adopted limit only at count >= limit.',
    'structure_assertion': 'structure.test_storage_fields.StorageFieldTests.test_every_field_of_a_closed_family_is_named_by_the_product: exact AST read then expand names from REPEAT_LINEAGES; only field-name usage.',
    'behavior_assertion': 'unit.test_repetition_hold_contract.RepetitionHoldContractTests.test_every_lineage_keeps_its_hold_until_the_exact_user_continuation',
    'behavior': ['All current lineages with the corresponding config key set to 2', 'count1 -> no waits; count2 -> one wait; hold(count,limit,next_owner)=(2,2,user)',
                 'same event receipt leaves entire runtime unchanged', 'wrong hold/scope are rejected without changing instance/runtime',
                 'governance.apply_decision exact continuation -> hold None, count0, waits[], exact affected refs/action scope, no open question links'],
    'decision': 'Existing structure and behavioral assertions plus actual variable limit read sufficiently answer this narrow consumption question; no new tests or runtime edits.',
    'limits': 'Does not close all repetition/wait requirements or prove arbitrary limits/missing/invalid config inputs.',
})
print(json.dumps({'pointers': len(exposed), 'enum_pointers': len(found), 'enum_values': sum(len(v) for v in found.values()),
                  'missing': len([r for r in exposed if r['stored_enum'] != r['pair_enumeration']]),
                  'lifecycle_differences': [r for r in exposed if r['lifecycle_only'] or r['stored_only']],
                  'B85': [{k: r[k] for k in ('label','exists','relevant_rows') if k in r} for r in reports]}, ensure_ascii=False))
