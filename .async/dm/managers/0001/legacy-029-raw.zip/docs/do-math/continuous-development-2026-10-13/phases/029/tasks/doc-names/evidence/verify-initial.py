import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from task_io import EVIDENCE, REPO, RUN, save, hashes

sys.path[:0] = [str(REPO / '.claude/skills/do-math/scripts'), str(REPO / '.claude/skills/do-math/scripts/tests')]
from support import doc_code as doc

def read(relative):
    return (REPO / '.claude/skills/do-math' / relative).read_text(encoding='utf-8')

def source_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def official(output):
    report = json.loads((EVIDENCE / output / 'report.json').read_text(encoding='utf-8'))
    rows = [row for group in report['reports'] for row in group['rows']]
    selected = report['selected']
    actual = {row['id']: row for row in rows}
    assert len(rows) == len(actual) == len(selected) and set(actual) == set(selected)
    assert all(row['outcome'] == 'passed' for row in rows)
    assert report['complete'] and report['successful'] and not report['changed_during_run']
    tree = '.claude' if output.startswith('c') else '.agents'
    assert all(source_sha(REPO / tree / 'skills/do-math/scripts' / p) == sha for p, sha in report['source_sha256'].items())
    old = json.loads((EVIDENCE / 'existing-assertions.json').read_text(encoding='utf-8'))['old_document_rows']
    assert all(row['id'] in actual and actual[row['id']]['outcome'] == 'passed' for row in old)
    before = json.loads((EVIDENCE / ('final-' + output + '.source-before.json')).read_text(encoding='utf-8'))
    after = json.loads((EVIDENCE / ('final-' + output + '.source-after.json')).read_text(encoding='utf-8'))
    differences = [p for p in before if before[p] != after[p]]
    assert all(p.endswith('/tests/.timings.json') for p in differences), differences
    return {'selected': selected, 'rows': rows, 'count': len(selected), 'source_count': len(report['source_sha256']),
            'seconds': report['total_seconds'], 'old_document_passed': len(old), 'source_changes': differences,
            'report_sha256': source_sha(EVIDENCE / output / 'report.json'), 'exit_code':
            json.loads((EVIDENCE / ('final-' + output + '.execution.json')).read_text(encoding='utf-8'))['exit_code']}

c, m = official('c2'), official('m2')
assert c['selected'] == m['selected']
current = hashes()
start = json.loads((EVIDENCE / 'source-start.json').read_text(encoding='utf-8'))
phase = json.loads((RUN / 'phases/029/phase.json').read_text(encoding='utf-8'))
changes = [p for p in start if current[p] != start[p]]
assert set(changes) <= set(phase['tasks'][0]['writes']), changes
save('source-end.json', current)
save('source-preservation.json', {'start_count': len(start), 'end_count': len(current), 'changes': changes,
    'outside_writes_changes': [], 'source_set_same': set(start) == set(current)})

for path in doc.documents(REPO / '.claude/skills/do-math'):
    assert not doc.named_document_issues(path.read_text(encoding='utf-8'), path.relative_to(REPO / '.claude/skills/do-math').as_posix())
cli, init, readme = read('references/CLI-실행-계약.md'), read('references/초기화-운전.md'), read('README.md')
normal = {'cli': cli, 'init': init, 'readme': readme}
cases = [
    ('setup-watch', lambda: doc.tool_command_issues('`setup_lean.py --verify-only --watch`')),
    ('probe-verify-only', lambda: doc.tool_command_issues('`probe_cli.py --skill-only --verify-only`')),
    ('config-session_limitz', lambda: doc.initialization_example_issues(readme.replace('"session_limits"', '"session_limitz"'), 'README.md')),
    ('grant-budget_kind', lambda: doc.initialization_example_issues(init.replace('"reuse": "reusable",', '"reuse": "reusable", "budget_kind":"work",'), 'references/초기화-운전.md')),
    ('runtime-capacity_waitng', lambda: doc.cli_table_issues(cli.replace('| `capacity_waiting` |', '| `capacity_waitng` |'))),
    ('config-reviewers-200', lambda: doc.cli_table_issues(cli.replace('| `reviewers` | 2 |', '| `reviewers` | 200 |'))),
    ('query-sideways', lambda: doc.cli_query_issues(cli.replace('incoming|outgoing|both', 'incoming|outgoing|sideways'))),
    ('knowledge-improt', lambda: doc.cli_knowledge_example_issues(cli.replace('"operation":"import"', '"operation":"improt"'))),
    ('candidate-summray', lambda: doc.cli_knowledge_example_issues(cli.replace('"summary":"목차 요약"', '"summray":"목차 요약"'))),
    ('initial-findingz', lambda: doc.cli_stage_issues(cli.replace('`scope_complete`, `findings`를', '`scope_complete`, `findingz`를'))),
    ('organize-root-decision', lambda: doc.cli_stage_issues(cli.replace('`issues`를 추가하며', '`issues`와 `decision`을 추가하며'))),
    ('answer-answerz', lambda: doc.cli_stage_issues(cli.replace('`answers`와 `new_findings`를', '`answerz`와 `new_findings`를'))),
    ('judge-item-match', lambda: doc.cli_stage_issues(cli.replace('`decision=approved|rejected|unresolved`, `reason`', '`decision=match|rejected|unresolved`, `reason`'))),
    ('checkpoint-current_cliam', lambda: doc.cli_checkpoint_issues(cli.replace('"current_claim":', '"current_cliam":'))),
    ('identity-missing-one', lambda: doc.identity_module_issues(init.replace('`control_protocol`, ', ''))),
    ('identity-borrowed-provider', lambda: doc.identity_module_issues(init.replace('`codex_adapter`이고', '`claude_adapter`이고'))),
]
observations = []
for name, call in cases:
    issues = call()
    assert issues, name
    observations.append({'case': name, 'issues': issues})
save('counterexamples-final.json', {'normal_documents': 'all named_document_issues returned []', 'cases': observations,
    'scope': 'pure final helper/schema/parser observation; no approval, provider/network/Lean/OS call'})

parser_preserved = []
for filename in ('setup_lean.py', 'probe_cli.py'):
    relative = '.claude/skills/do-math/scripts/' + filename
    raw = subprocess.run(['git', 'show', 'HEAD:' + relative], cwd=REPO, capture_output=True, check=True).stdout
    old = ast.parse(raw)
    new = ast.parse((REPO / relative).read_bytes())
    main = next(node for node in old.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
    head = next(i for i, node in enumerate(main.body) if isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id == 'parser' for target in node.targets))
    tail = next(i for i, node in enumerate(main.body) if isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id == 'args' for target in node.targets))
    builder = next(node for node in new.body if isinstance(node, ast.FunctionDef) and node.name == 'build_parser')
    assert [ast.dump(node, include_attributes=False) for node in main.body[head:tail]] == [
        ast.dump(node, include_attributes=False) for node in builder.body if not isinstance(node, (ast.Expr, ast.Return))]
    parser_preserved.append({'path': relative, 'parser_declarations_AST_equal_to_original_main': True})
save('parser-preservation.json', parser_preserved)
save('verification.json', {'canonical': c, 'mirror': m, 'same_selection': True,
    'source_changes': changes, 'new_document_tests': [test for test in c['selected']
        if test.startswith('structure.test_doc_code.') and test not in {row['id'] for row in json.loads(
            (EVIDENCE / 'existing-assertions.json').read_text())['old_document_rows']}],
    'counterexample_count': len(observations), 'parser_preservation': parser_preserved})
print('verified:', c['count'], m['count'], 'old document rows', c['old_document_passed'],
      'counterexamples', len(observations), 'changes', len(changes))
