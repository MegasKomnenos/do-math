from task_io import execute, PYTHON, save, hashes

SELECTION = ['structure.test_doc_code', 'unit.test_configuration', 'unit.test_engine_cli_contract',
    'sim.test_toolchain_tools', 'sim.test_operator_probe_contract', 'sim.test_provider_collection.IdentityTests',
    'sim.test_knowledge_import_control', 'unit.test_knowledge_io_contracts',
    'unit.test_academic_external_operations', 'unit.test_academic_external_sends',
    'unit.test_submission_extension_semantics', 'unit.test_submission_contracts',
    'unit.test_review_cycle_stages', 'unit.test_observation_checkpoint']
ROOT = 'docs/do-math/continuous-development-2026-10-13/phases/029/tasks/doc-names/evidence/'
assert execute('mirror-build2', [PYTHON, '-B', '.claude/skills/writing-skills/scripts/build_skill_mirrors.py']) == 0
save('final-fixed-source.json', hashes())
for tree, output in (('.claude', 'c2'), ('.agents', 'm2')):
    assert execute('final-' + output, [PYTHON, '-u', '-B', tree + '/skills/do-math/scripts/run_tests.py',
        *SELECTION, '--jobs', '1', '--output', ROOT + output]) == 0
# The generator also owns the timing cache mirror; only those allowed bytes
# may differ after the two independent official runs.
before = hashes()
assert execute('mirror-cache', [PYTHON, '-B', '.claude/skills/writing-skills/scripts/build_skill_mirrors.py']) == 0
after = hashes()
changed = [p for p in before if before[p] != after[p]]
assert set(changed) <= {'.agents/skills/do-math/scripts/tests/.timings.json'}
save('mirror-cache-changes.json', changed)
assert execute('mirror-check', [PYTHON, '-B', '.claude/skills/writing-skills/scripts/build_skill_mirrors.py', '--check']) == 0
for tree, name in (('.claude', 'skill-c'), ('.agents', 'skill-m')):
    assert execute(name, [PYTHON, '-B', tree + '/skills/do-math/scripts/probe_cli.py', '--skill-only']) == 0
print('final related runs, official mirror and both skill-only complete', flush=True)
