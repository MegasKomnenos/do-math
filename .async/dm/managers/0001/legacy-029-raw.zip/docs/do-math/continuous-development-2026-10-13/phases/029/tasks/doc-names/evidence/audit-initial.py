import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
from task_io import REPO, RUN, EVIDENCE, save, hashes

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def rows(value):
    if isinstance(value, dict):
        if {'id', 'outcome'} <= value.keys():
            yield value
        else:
            for part in value.values():
                yield from rows(part)
    elif isinstance(value, list):
        for part in value:
            yield from rows(part)

def methods(raw):
    tree = ast.parse(raw)
    return {cls.name + '.' + node.name: ast.dump(node, include_attributes=False)
            for cls in tree.body if isinstance(cls, ast.ClassDef)
            for node in cls.body if isinstance(node, ast.FunctionDef)}

phase = json.loads((RUN / 'phases/029/phase.json').read_text(encoding='utf-8'))
assigned = phase['tasks'][0]
start = json.loads((EVIDENCE / 'source-start.json').read_text(encoding='utf-8'))
current = hashes()
profiles = []
for reference in assigned['inputs']:
    prefix, relative = reference.split(':', 1)
    path = (RUN if prefix == 'run' else REPO) / relative
    raw = path.read_bytes()
    profile = {'reference': reference, 'sha256': digest(raw), 'bytes': len(raw)}
    if path.suffix == '.json':
        value = json.loads(raw)
        if path.name == 'report.json' and 'narrative' in value:
            profile.update(status=value['status'], narrative=value['narrative'], findings=value['findings'])
        elif path.name in ('test-bindings.json', 'check-bindings.json'):
            profile['bindings'] = [{k: row[k] for k in ('boundary', 'path', 'judgment', 'test', 'tests', 'methods') if k in row}
                                   for row in (value if isinstance(value, list) else [])]
            for binding in profile['bindings']:
                if 'methods' in binding:
                    binding['methods'] = [{k: v for k, v in method.items() if k != 'source'} for method in binding['methods']]
    profiles.append(profile)
save('input-profiles.json', profiles)

old_report = json.loads((RUN / 'phases/027/tasks/doc-policy/evidence/c3/report.json').read_text(encoding='utf-8'))
old_rows = {row['id']: row for row in rows(old_report) if row['id'].startswith('structure.test_doc_code.')}
assert len(old_rows) == 38 and all(row['outcome'] == 'passed' for row in old_rows.values())
preserved = []
for relative in ('.claude/skills/do-math/scripts/tests/structure/test_doc_code.py',
                 '.claude/skills/do-math/scripts/tests/support/doc_code.py',
                 '.claude/skills/do-math/scripts/tests/unit/test_engine_cli_contract.py',
                 '.claude/skills/do-math/scripts/tests/sim/test_toolchain_tools.py',
                 '.claude/skills/do-math/scripts/tests/sim/test_operator_probe_contract.py'):
    old = subprocess.run(['git', 'show', 'HEAD:' + relative], cwd=REPO, capture_output=True, check=True).stdout
    assert digest(old) == start[relative], relative
    before, after = methods(old), methods((REPO / relative).read_bytes())
    assert all(after.get(name) == source for name, source in before.items()), relative
    preserved.append({'path': relative, 'old_methods': len(before), 'unchanged_methods': len(before),
                      'new_methods': sorted(set(after) - set(before))})
save('existing-assertions.json', {'old_document_rows': list(old_rows.values()), 'methods': preserved,
    'reuse_limit': '027 rows are historical, not a new run. Existing method ASTs are unchanged; final runs must execute all 38 again.'})

operator = json.loads((RUN / 'phases/028/tasks/operator-names/evidence/minimal-counterexamples.json').read_text(encoding='utf-8'))
cli = json.loads((RUN / 'phases/028/tasks/cli-control-names/evidence/pure-observations.json').read_text(encoding='utf-8'))
role = json.loads((RUN / 'phases/028/tasks/role-glossary-names/evidence/schema-observations.json').read_text(encoding='utf-8'))
save('red-reuse.json', {'kind': 'reuse of pure observations on SHA-identical starting sources; not new execution',
    'operator_cases': operator, 'cli_cases': cli['cases'][:5], 'role_observations': role,
    'references': ['run:phases/028/tasks/operator-names/evidence/minimal-counterexamples.json',
                   'run:phases/028/tasks/cli-control-names/evidence/pure-observations.json',
                   'run:phases/028/tasks/role-glossary-names/evidence/schema-observations.json'],
    'count': 14, 'source_comparison': 'run:phases/029/tasks/doc-names/evidence/start-comparison.json'})

spec = importlib.util.spec_from_file_location('mirror_builder', REPO / '.claude/skills/writing-skills/scripts/build_skill_mirrors.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
rules = builder.load_rules(REPO / '.agents/diff')
base = builder.iter_files(REPO / '.claude/skills')
overlays = {p: path for p, path in builder.iter_files(REPO / '.agents/diff').items() if p not in builder.RESERVED}
outputs = {p: builder.transform(p, path.read_bytes(), rules) for p, path in base.items()}
outputs.update({p: path.read_bytes() for p, path in overlays.items()})
existing = builder.iter_files(REPO / '.agents/skills')
changes = [('.agents/skills/' + p) for p in outputs if p not in existing or outputs[p] != existing[p].read_bytes()]
deleted = [('.agents/skills/' + p) for p in existing if p not in outputs]
assert not deleted
assert set(changes) <= set(assigned['writes']), changes
manifest = json.loads((REPO / '.agents/diff/_manifest.json').read_text(encoding='utf-8'))
expected_manifest = {'overlays': {p: builder.sha1(base[p].read_bytes()) for p in sorted(overlays) if p in base}}
assert manifest == expected_manifest
assert (REPO / '.agents/diff/_manifest.json').read_bytes() == (json.dumps(expected_manifest, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode('utf-8')
save('mirror-plan.json', {'changes': changes, 'deleted': deleted, 'outputs': len(outputs), 'manifest_bytes_unchanged': True})
temp = Path('C:/Temp/dm029').resolve()
temp.mkdir(parents=True, exist_ok=True)
git = subprocess.run(['git', '-C', str(temp), 'rev-parse', '--show-toplevel'], capture_output=True)
assert git.returncode != 0
save('temp-environment.json', {'path': str(temp), 'git_exit_code': git.returncode,
    'stdout': git.stdout.decode('utf-8', errors='replace'), 'stderr': git.stderr.decode('utf-8', errors='replace')})
print('old doc rows', len(old_rows), 'method preservation', [(r['old_methods'], len(r['new_methods'])) for r in preserved],
      'mirror changes', len(changes), 'temp', temp)
for profile in profiles:
    if 'bindings' in profile:
        print(profile['reference'], json.dumps(profile['bindings'], ensure_ascii=False))
