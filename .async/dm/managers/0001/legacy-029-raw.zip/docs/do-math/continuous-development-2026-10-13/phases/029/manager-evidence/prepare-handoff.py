"""Publish the manager's reviewed current context and bounded next assignments."""
import difflib
import json
from pathlib import Path
import re

R = Path('C:/math')
RUN = R / 'docs/do-math/continuous-development-2026-10-13'
O = Path(__file__).resolve().parent
P = RUN / 'phases/030'

def save(p, data):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def write(p, text):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + '\n', encoding='utf-8')

def append_section(text, heading, paragraph):
    start = text.index('## ' + heading)
    end = text.find('\n## ', start + 3)
    if end < 0: end = len(text)
    return text[:end].rstrip() + '\n\n' + paragraph + '\n\n' + text[end:].lstrip()

base = 'run:phases/029/manager-evidence/'
common_inputs = [
    'run:sources/user-decisions.md', 'run:sources/model-policy-2026-10-14.md',
    'run:sources/document-batching-2026-10-14.md',
    base + 'source-inspected.json', base + 'verification.json', base + 'review.md',
    'run:phases/001/tasks/closure-map/evidence/requirement-state.json',
    'run:phases/001/tasks/closure-map/evidence/tracking-state.json',
    'run:phases/001/tasks/closure-map/evidence/prior-review-state.json',
    'run:phases/001/tasks/closure-map/evidence/evidence-catalog.json',
    'run:sources/requirements-index.json',
    'repo:docs/do-math/시험-재편-2026-09-29/설계.md',
    'repo:docs/do-math/시험-재편-2026-09-29/조사/결함-범주.md',
    'repo:docs/do-math/시험-재편-2026-09-29/단계-전환표-2026-10-03.json',
    'repo:.claude/skills/do-math/AGENTS.md',
    'repo:.claude/skills/do-math/scripts/tests/시험-지침.md',
    'repo:.claude/skills/do-math/scripts/이음새-정본.md',
]
specs = [
    ('request-producers', 'R02 작업자 요청의 실제 생산·수신과 역방향 필드 대응', [
        'tests/contracts/pairs.py', 'tests/contracts/test_pairs.py', 'do_math/model_call.py',
        'do_math/model_runner.py', 'do_math/worker_request.py', 'do_math/codex_worker.py',
        'do_math/claude_worker.py', 'do_math/codex_adapter.py', 'do_math/claude_adapter.py',
        'tests/unit/test_provider_close_requests.py', 'tests/sim/test_provider_close_worker_rejections.py'],
     ['run:phases/006/manager-evidence/review.md', 'run:phases/007/manager-evidence/review.md',
      'run:phases/007/tasks/provider-consumers/report.json'],
     '''원래 1-A의 여섯 가족 중 작업자 요청 가족만 맡는다. tracking-state R02와 requirement-state 1-A의 해당 질문, 설계3.3/A20의 필수+선택 필드 역방향이 기준이다. 현재 ModelRunner 및 실제 남아 있는 runner/adapters가 만든 요청과 check_codex_request/check_claude_request·worker load 경계를 연결한다. 역사 CodexModelRunner 이름이 현재 다른 정의로 이동했으면 현재 호출부로 설명하고 구판 경로를 복원하지 않는다. 006/007에서 이미 검수한 전송/collector/pair 결과는 재사용하며 공급자 전체나 저장·trust·조건/영수증 가족을 다시 조사하지 않는다.''',
     '''현재 공급자 전건, execution identity/profile_ref의 유무, resource_limits, control_binding, scholarly_server, claude_only_assigned_model의 허용 조합, schema 경로, adapter 고유 필드의 생산/소비를 branch-field-map.json에 연결한다. 원문에 적힌 0/1/여럿·선택 필드 축이 이 요청 가족의 어느 값에 적용되는지 실제 코드로 판정하고 적용 불가이면 이유를 적는다. _worker_request_samples의 5불리언 곱과 제외 조합이 실제 runner 전제와 같은지, 각 수신자의 required/optional 전부에 실제 생산 분기와 단언이 있는지 비교한다. 필드명 합집합의 성공을 중첩 값·의미나 실제 ModelRunner 저장 연결 성공으로 바꾸지 않는다. helper 직접 호출, runner가 저장한 request, 실제 worker 수신 검증을 구별한다. 007의 성공/결박/불완전/정지8표본은 실행 결과 가족의 근거로 유지하며 요청의 모든 분기를 대신하지 않는다.''',
     '''PR18의 계약 쌍 slice와 current_work.provider_population_integration(B49/1c80d145), 006/007 검수 처분을 읽는다. 현재 요청 조립/수신/직접 시험에 실제로 닿는 도입 hunk와 존재 원보고만 대조한다. B70~B73의 별도 평가자 전수나 PR15/PR18 전체는 확장하지 않는다. 예전 Codex only=True 누락 주장은 현 pair에서 해소됐으므로 되살리지 않는다. 요청 분기별 기존 검사와 원보고가 충분하면 최종 판본 실행 대기로 판정하고, 누락이면 최소 입력·기대/현재·정확 후속 시험/수리 파일을 지정한다.'''),
    ('schema-ownership', 'R07 스키마·상수 반환 소유권의 남은 모집단 대응', [
        'tests/structure/test_schema_builders.py', 'do_math/contracts.py', 'do_math/control_contracts.py',
        'do_math/record_schemas/schemas.py', 'do_math/core_engine.py', 'do_math/governance_engine.py',
        'do_math/review_engine.py', 'do_math/review_cycle.py', 'do_math/knowledge_io.py', 'do_math/planning.py'], [],
     '''원래1-E와 tracking-state R07의 남은 질문인 현재 선언 모집단과 원문 전체의 대응만 판정한다. 이미 승인된 B22 및 G4/G5 반환소유권, named/unnamed builder·클래스4메서드·상수6개 성질을 재구현하거나 처음부터 전수 재감사하지 않는다. 현재 test_schema_builders의 _calls/_composition_calls/_constant_object_calls, TRANSFORMERS, DELEGATED_SCHEMA_METHODS와 실제 반환 경로를 기준으로 명시적인 미종결 경계만 닫는다.''',
     '''ownership-map.json에서 기존 선언과 원문이 요구하는 owned builder의 현재 집합을 대응시킨다. 함수명 schema 검색 밖의 반환 builder를 기존 G4/G5 후보·상수소유자 목록에서 따라가고, 그 검토 후 해당 파일의 실제 diff에 새 후보가 생겼는지 확인한다. public builder, caller 입력을 빌리는 transformer, 내부 lookup의 소유 계약을 구별한다. repetition_outcome/recovery_outcome의 읽기 전용 borrowed row를 새 copy 요구로 바꾸지 않는다. 최종 _response_schema 등의 조립 뒤 결과가 전역·다른 반환값과 가변 노드를 공유하는지에 대한 기존 독립 단언과 위임 경로를 연결한다. 유한 인자 변형에서 역할·stage·preparation·review_cycle·filtering에 따라 shape가 바뀌는 축이 현재 선언에 포함되는지 판정한다. 이름 기반 등록이 전체 모집단을 보증한다고 주장하지 않는다.''',
     '''PR06 중 B22 schema_isolation_integration와 current_work.builder_population_and_windowless_boundary의 schema_registration 및 그 근거 return_ownership_review(G4/G5)를 JSON 키 선택으로 찾아 읽는다. 그 검토·등록 이후의 실제 관련 diff와 기존 원보고 SHA/testID를 대조한다. PR06의 저장/null/형식 동등성이나 windowless 실호출은 이 task의 재감사 범위가 아니다. 이미 판정된 후보는 같은 코드/소유 계약이면 재사용하고, 새 누락만 정확한 함수/인자/공유노드 반례와 수리 경로로 반환한다.'''),
    ('boundary-census', 'R18 외부 경계의 현재 호출 모집단과 공유 규칙 소비', [
        'tests/structure/test_boundary_invariants.py', 'do_math/file_io.py', 'do_math/windows_job.py',
        'do_math/git_process.py', 'do_math/cli_worker.py', 'do_math/formal.py',
        'do_math/powershell_scheduler.py', 'do_math/scheduled_operator.py', 'setup_lean.py', 'probe_cli.py'],
     ['run:phases/010/manager-evidence/review.md', 'run:phases/011/manager-evidence/review.md',
      'run:phases/012/manager-evidence/review.md', 'run:phases/013/manager-evidence/review.md',
      'run:phases/018/manager-evidence/review.md'],
     '''원래9-A 중 tracking-state R18의 남은 현재 호출 누락 여부를 판정한다. R17의 지급 console_python/실제 pythonw와010~018의 Job/Lean/held예약 실경계 승인 성질은 조건부 재사용한다. 지금의 구조 검사가 선언하는 직접 subprocess·주입 starter·native CreateProcess·_job_run·sys.executable·실행파일 정규화·파일 교체·stdlib 충돌의 대상 파일/호출 집합과 실제 코드를 비교한다. Windows 실경계를 새로 실행하거나 전체 OS 안전성 감사로 넓히지 않는다.''',
     '''boundary-map.json에 실제 경계 호출과 PROCESS_STARTS/INJECTED_STARTS/JOB_RUN_STARTS/INTERPRETER_USES/EXECUTABLE_IDENTITY 및 file_io 소유 규칙을 연결한다. 현 _product_files/_sites/_process_start_sites가 실제 별칭·wrapper·주입 호출을 놓치는지 기존 소스와 독립 rg/AST 읽기 결과로 대조한다. 각 남김은 실제 현재 누락 또는 새 호출 형태에 대한 구조 검사 공백으로 구분한다. 실제 CREATE_NO_WINDOW 값·native suspended 비트·Job 소유와 정리·단일 정규화/원자교체의 기존 검사와 호출 근거를 연결한다. 원문 밖의 상상 가능한 모든 Python 우회 형태를 새 완료 조건으로 만들지 않는다. runner2개 제외와 scripts/do_math 및 최상위 도구 범위가 원래 의무에 타당한지도 명시한다.''',
     '''PR02의 B13/B14/B62/B85 중 실행파일·창억제·현재 호출 등록 slice를 현재 코드/도입 hunk/존재 원보고에 대조한다. B12 잠금·B38 Git의 다른 성질과 PR02 전체는 닫지 않는다. 010~018의 검수된 실제 호출/Job 종료/예약은 후속 변경된 함수에 영향이 없는 성질만 재사용한다. 029 setup/probe parser 추출은 인자 처리 위치 변화이므로 새 OS 호출 추가/실행 경로 영향 유무를 정확 diff로 확인한다. 누락이면 해당 호출·현재 검사에서 빠지는 이유·기존 회귀/새 최소 반례·후속 책임을 지정한다.'''),
]

tasks = []
for task_id, title, seeds, extras, purpose, population, history in specs:
    refs = ['repo:.claude/skills/do-math/scripts/' + seed for seed in seeds]
    for ref in refs:
        assert (R / ref.split(':', 1)[1]).is_file(), ref
    tasks.append(dict(id=task_id, model='gpt-6.1-sol', effort='high', inputs=common_inputs + extras + refs,
                      writes=[], provides=[], uses=[]))
    objective = f'''## 목적과 역할

{title}를 고정된029 검수판에서 판정한다. {purpose}

이 작업은 유한한 남김의 판단 자료를 만드는 work다. G1/G2/G3의 지정 질문을 닫거나 정확 수리로 바꾸며 최종 review가 아니다. 같은030의 다른 task 결과를 기다리거나 소비하지 않는다.

## 완료 조건

### A1 원문·현재판·승인 범위 고정

029 manager source-inspected와 현재 소스의 파일 집합/SHA를 대조하고 자기 시작/종료 해시를 보존한다. requirement-state/tracking-state의 위 ID와 해당 원문·설계 조건을 읽으며 103행 전체를 다시 출력하거나 재분류하지 않는다. 기존 승인 범위·당시 한계·현재 변경 영향을 구분한다. 사용한 실제 정의와 시험 좌표 및 판본을 자기 evidence에 남긴다.

### A2 남은 모집단과 실제 단언 대응

{population}

각 행에는 실제 정의/소비 위치·입력축·정확 시험 ID와 단언·원보고 판본·판정 근거를 둔다. 판정은 기존 근거 유지, 최종 판본 실행 대기, 확인된 수리, 정확 미결을 구별한다. 표의 존재/형식 통과나 test name을 의미 충족으로 세지 않는다. 읽기만으로 충분한 질문과 실제 연결 실행이 남은 질문을 구별한다.

### A3 관련 과거 변경과 최소 후속 처분

{history}

해당 요구에 직접 연결된 보존 K/P2 ID는 requirements-index와 원문 연결을 따라 판정표에 기록한다. 관련 없는 61/12 전수 감사로 확장하지 않는다. 없는 역사 raw는 실제 부재로 남기며 counts를 성공으로 합산하지 않는다. conclusion.md에 닫힌 질문·확인된 공백·후속 구현/검증의 정확 파일·입력·기대결과를 적는다. 결함이 없어도 읽기판정이 완료되면 complete이며, 제품 전체 합격을 뜻하지 않는다.

### A4 독립성·원자료 보존·인계

자기 report/evidence 밖의 변경이 없고 시작/종료 소스가 같음을 확인한다. 새 코드 실행/공식 시험과 재사용된 과거 출력은 분리한다. 모든 finding은 근거·영향 G/원문 ID·다음 행동을 갖고 report 형식 검사에 통과한다. L01 Q1/Q2와 원문UTF-8 byte 미충족, Windows1314 symlink 실제 반려 미검사, G4~G8 최종 관문과 다른 의미 질문을 유지한다.

## 판단과 경계

제품·시험·미러·공용 문서·기존 task·engine·graphify·Git index를 쓰지 않는다. 새 공식 run_tests/pytest/unittest·실제 모델/Job/Lean/예약/네트워크 호출은 실행하지 않는다. 이 phase의 독립성은 고정 소스를 읽고 자기 evidence만 쓰는 데서 나온다. 순수 정적 파싱·해시·Git read와 기존 보고/원자료 대조는 허용한다. 관찰용 순수 계산이 필요하면 제품 부수효과/공유 캐시가 없는 경우만 허용하고 새 통합 실행으로 보고하지 않는다. 시간·원보고 부재 때문에 기대값·모집단을 축소하지 않는다.

이름·필드·함수 수나 원래17분할을 완료율로 만들지 않는다. 기존 충분한 범위를 반복 탐색하지 않고 원문 종료 질문에 답하면 반환한다. 런타임/검사 수리나 공식 실행이 필요하면 이번 task에서 쓰기 범위를 넓히지 않고 정확 반례와 다음 책임을 남긴다. manager가 공통 수리·미러·실제 연결 검증을 후속 단일 소유 또는 순차 작업으로 배정한다.

## 검증 방법

cwd C:/math, Python C:/Users/wogud/AppData/Local/Programs/Python/Python312/python.exe. 원문/JSON은 지정 키와 문장 단위로 읽고 실제 코드·단언까지 확인한다. rg/AST의 발견 목록은 후보이며 실제 호출/반환 의미로 판정한다. Git diff/show/log는 읽기만 한다. 이전 실행을 재사용하려면 소스/입력/단언의 동일 성질과 변경 영향을 기록한다. 부모030의 다른 task 파일을 입력으로 쓰지 않는다.

마지막 `python services/continuous-development/check.py report C:/math C:/math/docs/do-math/continuous-development-2026-10-13 030 {task_id}`를 지정 Python으로 실행한다. raw stdout/stderr/exit와 source-start/source-end, 판정표·conclusion을 자기 evidence에 보존한다. 공식 새 실행은 후속 통합 검증 책임으로 명시한다.
'''
    write(P / 'tasks' / task_id / 'objective.md', objective)
    (P / 'tasks' / task_id / 'evidence').mkdir(parents=True, exist_ok=True)
(P / 'logs').mkdir(parents=True, exist_ok=True)
save(P / 'phase.json', dict(kind='work', purpose='029 문서 수리를 검수한 고정판에서 R02 요청 생산·수신, R07 반환 소유권 모집단, R18 외부 경계 호출의 미종결 질문을 독립 판정해 정확 후속 수리와 최종 판본 연결을 구분한다.', tasks=tasks))

summary = 'phase 029 doc-names의 A1~A5 complete를 검수했다. report 형식 검사 후028·시작2675소스 동일, 종료/현재 파일 집합과 SHA 전건 일치 및 허용22변경(정본10·미러10·비용캐시2)을 확인했다. 최종 c2/m2의 같은183선택/고유row는 전부passed·실제exit0이며 각875Python과 실행 전후 비캐시 불변을 대조했다. 기존38문서ID와 기존 시험메서드 AST·두 parser 선언을 보존했고 여덟 원finding의 정확passed ID/16반례를 확인했다. 초기 집중2실패와 보조관찰자 오류는 역사 실패로 유지한다. 원task129파일은 불변이다. 근거는 run:phases/029/manager-evidence/verification.json·review.md다. 지정 범위 완료이며 전체G 완료가 아니다.'
context = (O / 'context.md.before').read_text(encoding='utf-8-sig')
context = append_section(context, 'C2 시작 당시 실제 상태와 증거의 한계', summary)
old = 'phase 028의 세 독립 읽기 task는 모두 종료됐고288절의 정확 합집합을 검수했다.029 doc-names는 여덟 issue의 문구·doc_code/test_doc_code·두 도구 parser 연결·공식 미러/관련 회귀를 한 담당자에게 배정한다. 공유 helper와 미러/캐시가 겹치므로 병렬 구현은 하지 않는다. 이미 끝난 이름 조사를 반복하지 않고 정확 문장·14최소 helper 반례·모듈 집합과 부재 검사를 통합한다. 실제 parser 정의가 main과 문서 검사에 함께 쓰이게 하는 작은 추출만 제품 코드 쓰기 범위에 포함한다. 공식 검사는 jobs1·전체worker3 이하·한 묶음씩·소스 고정을 유지한다.'
new = '029의 공통 문구/helper/parser·미러/관련 회귀 수리를 검수했다.030은 R02 작업자 요청 생산·수신, R07 반환 소유권 모집단, R18 외부 경계 현재 호출을 세 독립 읽기 task로 배정한다. 모두 같은029 고정판을 읽고 자기 evidence만 쓰며 다른 task 결과·공유 캐시·공식 시험·실경계를 사용하지 않는다. 끝난 문서 이름 조사나 전체 과거PR을 반복하지 않는다. 현재 선언과 원문 종료 질문의 차이를 판정해 충분한 부분은 최종판 실행 대기로, 실제 공백은 정확 후속 수리로 넘긴다. 공유 제품/helper·미러·실제 연결 검증은 결과 검수 뒤 한 담당자 또는 순차 작업에 배정하며 공식 검사 jobs1·전체worker3 이하·한 묶음씩 규칙을 유지한다.'
assert old in context
context = context.replace(old, new)
context = append_section(context, 'C8 모델과 현재 준비의 범위', '029의 gpt-6.1-sol/high 수행을 검수했다.030 세 독립 판정에도 같은 model/effort를 명시하며 manager와 제품 공급자 호출 설정은 변경하지 않는다.')
context = append_section(context, 'C9 요구별 상태와 과거 검토의 재사용 범위', '029는 기존 시험메서드와 parser 선언을 보존하고 여덟028 발견의 지정 수리를 검수했다. 다음030은 requirement-state의 R02(1-A 요청 가족), R07(1-E의 최종 모집단 대응), R18(9-A의 현재 호출 누락)만 판정한다. PR18 계약쌍·PR06/B22 및 builder 등록·PR02 실행파일/창억제/호출등록의 관련 slice를 기존 검수와 결합하며 전체PR을 완료로 바꾸지 않는다. R01/R03~R06과 나머지 의미 질문·보존ID는 그대로 남는다. 근거는029 review.md와030 세 objective다.')
context = append_section(context, 'C10 문서 결속에서 남은 고정 범위', '029 F1의 여덟 issue를 지정 범위에서 종결한다. 모듈 목록·knowledge·external·kind 문구를 실제 정의/소비에 맞췄고, setup/probe의 main과 문서 검사는 같은 parser/입력 관계 검사를 쓴다. config/grant·runtime/config표·query·knowledge 완전객체·네stage/checkpoint를 정확 문서 좌표와 실제 정의에 연결했으며 오타/차용/부재와 모듈 반례를 확인했다. 기존38문서시험과 P/PURE/027 단언을 보존했다. N01 이름/조합의 지정 남김은 닫지만 모델 독해·준수나 모든 자연어 의미의 인증으로 확대하지 않는다. 명시 소비 없는 instance 제거 가능성과 L01 Q1/Q2·원문 UTF-8 byte 미충족은 남는다. 근거는029 manager verification.json·review.md 및 원finding-closure.json이다.')
context = append_section(context, 'C11 최종 관문을 막는 도구·실경계 공백', '029 양쪽183passed는 지정 관련 실행이다. symlink 시험은 선택에 없고 Windows1314 실제 탈출 반려 미검사는 유지한다. setup/probe parser와 문서 변경 이후 과거 전체 설치/T4의 판본 동등성을 주장하지 않는다. G4 기본전체·G5 freshT3·G6 전수변이·G7 최종판 연결·G8 review 및 L01 외부 결정은 남으며030의 읽기 판정으로 대체하지 않는다.')
context = append_section(context, 'C12 공급자 부분 성공과 원바이트 인도', '029 F2의 재사용은 변경 영향을 반영해 한정 승인한다. 두 도구 parser 추출과 문서 변경은 향후 설치/prompt hash를 바꾸므로 과거 전체판본 실호출이나 모델 독해를 재인증하지 않는다. 그 밖의 소스는028과 동일해 불변 하위경계의 승인 성질만 유지하며 영향받는 main 소비는 새 관련 회귀로 확인했다. 검수한20비캐시 제품/시험/문서/미러 경로를 이번 관리 커밋으로 마감하고 비용캐시2는 제외한다. 원task129파일과20제품 원바이트는 manager-evidence/raw-evidence.zip에 보존하고 선별 원경로·전건SHA는 preservation.json에 둔다. 압축만 추적하는 중복 snapshot 원경로와 진행 로그·stage/commit 행정 수신은 로컬 보관으로 정리 시 사라질 수 있다. 압축은 복원 지시가 아니다.030 배정·관리/기억 추가는 검수한 제품판본을 바꾸지 않는다.')
write(RUN / 'context.md', context)

plan = (O / 'plan.md.before').read_text(encoding='utf-8-sig')
plan = plan.replace('## phase 001~028의 결과와 현재 상태', '## phase 001~029의 결과와 현재 상태')
start = plan.index('## 다음 phase: 029')
end = plan.index('## 가까운 후속 배정과 선행 관계', start)
next_text = '''## 다음 phase: 030

029 문서 수리의 여덟 발견과 A1~A5를 검수했다. 다음은 고정된 제품에서 세 가지 기존 종료 질문을 병렬 판정하는 work다. request-producers는 R02/1-A의 실제 요청 조립·worker 수신과 필수+선택 필드 역방향, schema-ownership은 R07/1-E의 이미 검토된 builder와 남은 현재 모집단 대응, boundary-census는 R18/9-A의 실제 경계 호출과 현 검사 등록의 누락 여부를 맡는다. 세 task 모두 gpt-6.1-sol/high이며 writes/provides/uses는 빈 목록이다.

현재 제품·시험·미러를 고정하고 각 task가 자기 evidence만 쓴다. 공식 시험·실호출·공유 캐시를 건드리지 않아 실행 환경 충돌이 없고 서로의 결과를 기다리지 않는다. 끝난 문서 조사·기존 충분한 후보를 재감사하지 않으며 각 원문 질문과 실제 정의/단언/원보고의 차이에만 답한다. 새 수리가 필요하면 정확 반례·쓰기 파일·관련 검증을 반환한다. 실제 연결 실행은 결과 검수 뒤 공통 수정 경계에 따라 통합 또는 순차 배정한다. 최종 G관문 착수나 전체 review로 취급하지 않는다.

'''
plan = plan[:start] + summary + '\n\n' + next_text + plan[end:]
old_start = plan.index('**028 manager의 묶음 결정:**')
old_end = plan.index('\n\n', old_start)
plan = plan[:old_start] + '**029 manager의 묶음 결정:** 문서 여덟 수리는 공유 helper/parser/미러/관련 회귀를 한 번에 검수해 닫았다. 다음 세 과제는 기존 requirement-state의 한정된 종료 질문이고 같은029 판본의 독립 읽기로 끝낼 수 있다. 소스 변경이나 공식 실행은 없으므로 병렬 가능하다. 결과가 확인한 수리만 후속 공통 파일/검사 경계로 묶으며 이미 승인된 문서 범위를 다시 조사하지 않는다.' + plan[old_end:]
plan = plan.replace('028에서 N01 판정을 마쳤으며 여덟 문구/검사 issue는029의 한 통합 작업이 맡는다.', '028에서 N01 판정을 마쳤고 여덟 문구/검사 issue는029의 통합 수리와 검수로 종결했다.')
plan = plan.replace('requirement-state의 해당 생산자/소비자/입력/단언 질문과 관련 PR slice만 배정한다.', '030은 R02 요청 가족·R07 반환소유권 모집단·R18 현재 경계호출과 관련 PR slice만 판정한다. 나머지 requirement-state의 생산자/소비자/입력/단언 질문은 현재 남김으로 유지한다.')
write(RUN / 'plan.md', plan)
seams = (O / 'seams.md.before').read_text(encoding='utf-8-sig')
seams += '\n029의 동일 parser/입력 검사 소비와 문서 수리를 검수했다.030은 고정된 기존 요청·반환소유권·외부호출 정의를 읽는 독립 판정이며 새 인터페이스를 제공/소비하지 않는다. 세 task의 provides/uses는 비어 있고 S항목은 개정하지 않는다. 조사표는 제품 schema를 대신하지 않으며 실제 수리·연결검증은 후속 work에 배정한다.\n'
write(RUN / 'seams.md', seams)

review = '''# 029 manager 검수

doc-names report를 전문으로 읽고 report 검사를 통과한 뒤 실제 소스·원보고·diff를 대조했다. A1~A5의 지정 완료를 승인한다. 판정의 기계적 근거는 verification.json과 verify.py이며 새 제품 시험은 실행하지 않았다.

2675개 소스의 경로 집합과 SHA를 새로 열거해028/작업시작·작업종료/현재를 비교했다. 변경22개는 report/writes와 같고 정본10·미러10·비용캐시2다. 최종 c2/m2의 선택183·고유row183·전건passed·실제exit0와 각각875Python SHA, 실행 전후 비캐시 불변을 대조했다. 원task129파일은 검산 전후 불변이다. 027의 문서38ID는 양쪽 최종passed에 모두 존재하며 기존 시험메서드는 AST 동일하다.

두 main의 argparse 선언은 새 build_parser와 AST 동일하다. parse_arguments의 기존 교차 인자 반려를 유지하고 main이 먼저 호출하는 실제 코드와 새 invalid-before-host/inspect 입력 소비 단언을 읽었다. 문서 helper는 동일 parser를 사용하며 shell pipeline 뒤를 도구 argv로 넘기지 않는다. barefilename은 파일 참조로 구분한다. 이는 현재 예제 범위의 판단이며 임의 shell 문법 전체의 실행 인증이 아니다.

모듈 열거는 실제 adapter 클래스 속성과 비교하며 목록을 복제하지 않는다. config/grant는 실제 config/control 정의를, runtime 표는 해당 저장 enum을, query는 해당 parser 선택지를 소비한다. knowledge의 control shape와 candidate 의미 검사를 나누고 부분 relation_claim은 완전 요청으로 검사하지 않는다. 네 검토단계의 root/item/enum과 checkpoint 파일도 실제 stage/schema/value 소비에 연결돼 있다. 필요한 절·fence·선언 부재를 반려하는 단언을 확인했다. 028의14최소 반례와 모듈2반례는 원진단과 정확 최종 시험에 연결된다. 문구상 기존ID import·formal재사용·withdrawn재등록·HTTP 효과불명·kind의TEXT/같은묶음 권한은 현재 직접 소비 단언과 함께 읽었다. finding-closure의 여덟 finding을 모두 승인한다.

집중 실행 f의48passed/2failed는 문구의 무소유 dotted 표기와 barefilename/pipeline 추출 문제이며 f2의52passed 및 최종 정확ID에서 해소됐다. 첫 c/m183passed 뒤 문구를 바꿨으므로 c2/m2만 최종 인도 근거로 채택한다. 보조 AST 관찰자의 Expr 제거 오류와 Git/manifest 개행 관찰 오류는 task 원실패로 남고 제품 성공에 합산하지 않는다. manager의 초기 보조파일 조회 한 경로 부재는 제품 검증 실패나 원자료 소실로 해석하지 않았고 기존028 finalize를 참조했다.

F1은 지정 수리 완료로 resolve한다. F2는 C11/C12와 plan에 carry한다. parser/문구가 새 설치·prompt hash를 바꾸므로 과거 전체 설치/T4 판본 동등성이나 모델 독해를 주장하지 않는다. 불변 하위경계의 기존 승인 성질과 새 직접 소비 회귀만 유지한다. L01 외부 프로필/byte 결정·symlink 실반려 미검사·최종 G4~G8은 남는다.

030은 R02 요청생산/수신, R07 반환소유권 모집단, R18 외부경계 현재호출을 세 독립 읽기로 배정한다. 각 기존 질문/관련 PR slice와 기존 승인 한계를 지정해 중복 문서 조사·전체 과거 감사로 확장하지 않는다. 공식 시험/외부호출과 제품쓰기를 금지하므로 캐시·DB·포트 충돌이나 미완성 결과 의존이 없다. 결과에 따라 필요한 수리·미러·실제 연결검증을 후속에 통합한다.

공용 문서는 C2 검수사실, C5 다음 독립성, C8 같은 모델, C9 지정 요구/과거slice, C10 여덟종결, C11 관문 한계, C12 보존/인도를 갱신했다. C1의G 전부·기존 외부결정·역사 실패와 유효 근거는 보존했다. 현재 배정 문단만 교체했고 다른 과거 문장은 삭제하지 않았다. common-docs.diff가 전후 의미 대조 근거다. S계약 개정은 없다.
'''
write(O / 'review.md', review)

version = int(re.search(r'^convention_version: (\d+)$', (R / '기억/세칙.md').read_text(encoding='utf-8'), re.M).group(1))
node = R / '기억/layer1/M-0579.md'
assert not node.exists()
assert max(p.name for p in node.parent.glob('M-*.md')) == 'M-0578.md'
write(node, f'''---
id: M-0579
layer: 1
title: 문서 수리 여덟 건을 검수하고 남은 요청·소유권·경계 질문을 독립 배정함
convention_version: {version}
---

## 맥락

029는028에서 찾은 문구 네 묶음과 검사 공백을 공유 helper·실제 parser·미러·관련 회귀에 통합한 작업이었다. manager는 원task129파일,2675소스와 최종 양쪽183passed의 선택·고유row·판본·실제exit를 대조했다. 두 main의 옵션 선언과 기존38문서시험을 보존한 채 필요한 실제 정의를 공유했으므로 지정 여덟 발견을 닫았다. 전체G 완료와는 구별한다.

## 다음 배정의 판단

문서 수리를 끝낸 다음 같은 이름 조사를 반복하지 않았다. 기존 요구표의 R02 요청 생산·수신/역방향 필드, R07 이미 검토한 반환 builder의 최종 모집단 대응, R18 현재 외부경계 호출 누락을 각각 독립 판정하도록030을 구성했다. 공유 소스를 읽기만 하고 공식 시험·캐시·외부 호출을 쓰지 않으므로 같은 판본에서 병렬 가능하다. 실제 수리와 연결 검증은 결과가 확인한 공백만 후속 작업으로 묶는다. 원래 큰 제목을 그대로 재파견하지 않도록 각 objective에 제외 범위와 기존 승인 재사용 조건을 썼다.

## 판본과 보존의 경계

첫 양쪽183passed 뒤 문구가 바뀌었으므로 최종 c2/m2를 인도 근거로 삼았다. parser 추출은 동작을 보존해도 설치 hash를 바꾸며 문구는 향후 prompt에 영향을 준다. 과거 전체 설치·실호출 판본 동등성이나 모델 독해를 새 회귀로 인증할 수는 없다. 불변 하위 성질만 유지하고 L01 외부결정·byte 요구와 symlink 미검사·최종 관문은 남겼다.

추적 진입점은 docs/do-math/continuous-development-2026-10-13/phases/029/manager.json, manager-evidence/verification.json·review.md·common-docs.diff·preservation.json 및030 objectives다. task 원자료와20제품 원바이트는 raw-evidence.zip에도 보존한다. 압축만 추적하는 중복 snapshot 원경로와 진행 로그·stage/commit 행정 수신은 로컬 보관으로 정리 시 사라질 수 있다. 기존 dirty/untracked와 비용캐시는 이 관리 커밋에 넣지 않는다.
''')
index = R / '기억/색인.md'
text = index.read_text(encoding='utf-8')
assert 'M-0579' not in text
write(index, text.replace('## layer-1\n\n', '## layer-1\n\n- M-0579 [문서 수리 여덟 건을 검수하고 남은 요청·소유권·경계 질문을 독립 배정함] -- 양쪽183passed·기존단언 보존,030은 고정판의 R02/R07/R18만 읽고 후속 수리를 특정\n'))

diff = ''.join(''.join(difflib.unified_diff((O / (name + '.before')).read_text(encoding='utf-8-sig').splitlines(True),
    (RUN / name).read_text(encoding='utf-8-sig').splitlines(True), fromfile=name+'.before', tofile=name)) for name in ('context.md','plan.md','seams.md'))
write(O / 'common-docs.diff', diff)
updates = {
    'C2': '029 A1~A5와 독립 원자료/현재판 검수 사실을 추가했다. 기존 역사 실패와 전체G 미충족은 유지한다.',
    'C5': '완료된029 구현 배정 문단을030 세 독립 읽기/무공유실행 규칙으로 교체했다. 공식 검사 자원 조건은 유지한다.',
    'C8': '030 세 task에도 사용자 지정 gpt-6.1-sol/high를 명시했다. manager/제품 호출 설정은 그대로다.',
    'C9': 'R02/R07/R18과 관련 과거slice의 한정 후속 판단을 지정하고 다른 의미·PR 남김을 유지했다.',
    'C10': '여덟 문구/검사 issue의 지정 종결과 실제 parser/schema 소비·부재 반려를 반영했다. L01/instance 남김을 유지한다.',
    'C11': '부분183passed의 한계와 setup/probe 변경 뒤 전체판본 재사용 제한, 최종 관문을 유지했다.',
    'C12': '20비캐시 제품 마감과 원task129파일 보존, 바뀐설치/prompt와 불변하위성질의 한정 재사용을 기록했다.',
}
manager = dict(next='030', decision='029 doc-names의 A1~A5를 승인한다. 현재2675소스·허용22변경·양쪽동일183선택/고유passed/exit0·각875Python과 기존38문서ID/시험메서드/parser선언 보존을 실제 파일에 대조했다. 여덟028 발견은 문구와 실제정의·정확반례/현재직접소비로 해소됐으며 전체G로 확대하지 않는다. F2의 판본/외부결정/관문 한계를 유지한다. 다음030은 기존 R02/R07/R18의 구체적 미종결 질문을 세 독립 읽기로 판정한다. 공유파일·캐시·미완성 결과에 대한 의존이 없어 병렬가능하며, 완료된 문서/기존 후보의 재감사는 피한다. 각 결과의 실제 공백만 후속 수리·연결검증으로 묶는다. manager는 제품을 수정하지 않고 검수된20제품경로와 관리인계/기억을 마감한다.',
    reports=[dict(task='doc-names', state='read', detail='report 전문을 읽고 형식검사exit0 후 A1~A5의 실제 자료를 검수했다. 초기2실패/중간성공/관찰자오류를 최종c2/m2 성공과 구분한다.', evidence=['run:phases/029/tasks/doc-names/report.json',base+'report-check.stdout',base+'verification.json',base+'review.md'])],
    dispositions=[
        dict(item='029/doc-names/F1', action='resolve', destination=['run:context.md#C10','run:plan.md'], reason='여덟원finding의 실제정의/문구/반례와 양쪽정확passed ID, 기존단언 보존을 확인해 지정남김을 종결한다. 전체 자연어/독해 인증으로 확대하지 않는다.', evidence=[base+'verification.json',base+'review.md','run:phases/029/tasks/doc-names/evidence/finding-closure.json']),
        dict(item='029/doc-names/F2', action='carry', destination=['run:context.md#C11','run:context.md#C12','run:plan.md'], reason='새 parser/문서판본의 관련성공은 과거전체설치/실호출동등성이나 모델독해를 보증하지 않는다. 불변하위성질만 재사용하고 L01/byte·symlink·G4~G8의 미충족 책임을 보존한다.', evidence=[base+'verification.json',base+'review.md'])],
    context_updates=[dict(item=k, action='amend', destination=['run:context.md#'+k], reason=v, evidence=[base+'verification.json',base+'review.md',base+'common-docs.diff']) for k,v in updates.items()],
    plan_update='029 여덟수리 검수를 기록하고 다음을030 R02/R07/R18 세 고정판 독립판정으로 교체했다. 원래 G/외부결정/나머지의미질문은 유지하며 판정결과의 확인된 공백만 후속 구현·미러·실제연결로 묶는다. 최종review나 종료를 배정하지 않았다.', seam_updates=[], completion=None)
save(RUN / 'phases/029/manager.pending.json', manager)
print('prepared 030, current documents, M-0579 and manager.pending.json')
