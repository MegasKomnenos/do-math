import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

REPO = Path('C:/math')
RUN = REPO / 'docs/do-math/continuous-development-2026-10-13'
EVIDENCE = RUN / 'phases/029/tasks/doc-names/evidence'
PYTHON = sys.executable

def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def snapshot():
    previous = json.loads((RUN / 'phases/028/manager-evidence/source-inspected.json').read_text(encoding='utf-8-sig'))
    return previous

def hashes():
    paths = snapshot()
    return {path: hashlib.sha256((REPO / path).read_bytes()).hexdigest()
            for path in paths if (REPO / path).is_file()}

def compact(value):
    if isinstance(value, dict):
        return {k: compact(v) for k, v in value.items() if k not in
                ('source', 'sources', 'python_sources', 'python_sources_before', 'python_sources_after', 'rows')}
    if isinstance(value, list):
        return [compact(v) for v in value]
    return value

def execute(name, argv):
    temp = Path('C:/Temp/dm029').resolve()
    temp.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, TEMP=str(temp), TMP=str(temp), TMPDIR=str(temp), PYTHONDONTWRITEBYTECODE='1')
    save(name + '.source-before.json', hashes())
    with (EVIDENCE / (name + '.stdout')).open('wb') as out, (EVIDENCE / (name + '.stderr')).open('wb') as err:
        result = subprocess.run(argv, cwd=REPO, env=env, stdout=out, stderr=err)
    save(name + '.execution.json', {'argv': argv, 'cwd': str(REPO), 'temp': str(temp), 'exit_code': result.returncode})
    save(name + '.source-after.json', hashes())
    print(name, result.returncode, flush=True)
    return result.returncode

if __name__ == '__main__':
    if sys.argv[1] == 'start':
        current = hashes()
        prior = snapshot()
        changed = [p for p in prior if current.get(p) != prior[p]]
        save('source-start.json', current)
        save('start-comparison.json', {'prior_count': len(prior), 'current_count': len(current), 'changed': changed})
        result = subprocess.run(['git', 'status', '--porcelain', '-z'], cwd=REPO, capture_output=True)
        (EVIDENCE / 'git-start.nul').write_bytes(result.stdout)
        print('start', len(current), 'changed', changed)
        raise SystemExit(0)
    if sys.argv[1] == 'exec':
        raise SystemExit(execute(sys.argv[2], sys.argv[3:]))
    if sys.argv[1] == 'inspect':
        phase = json.loads((RUN / 'phases/029/phase.json').read_text(encoding='utf-8'))
        for reference in phase['tasks'][0]['inputs']:
            root, relative = reference.split(':', 1)
            path = (RUN if root == 'run' else REPO) / relative
            if path.suffix != '.json':
                continue
            if len(sys.argv) > 2 and sys.argv[2] not in reference:
                continue
            value = json.loads(path.read_text(encoding='utf-8-sig'))
            print(reference, 'size:', len(value))
            if path.name == 'report.json' and 'narrative' in value:
                print(json.dumps(value, ensure_ascii=False, indent=2))
            elif path.name not in ('source-inspected.json', 'verification.json', 'report.json'):
                print(json.dumps(compact(value), ensure_ascii=False, indent=2))
