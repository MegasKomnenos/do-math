"""Read-only verification of the phase 029 submission; writes only manager evidence."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

REPO = Path('C:/math')
RUN = REPO / 'docs/do-math/continuous-development-2026-10-13'
OUT = Path(__file__).resolve().parent
TASK = RUN / 'phases/029/tasks/doc-names'
E = TASK / 'evidence'
PY = sys.executable

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def task_files():
    return {p.relative_to(RUN).as_posix(): sha(p) for p in TASK.rglob('*') if p.is_file()}

def git(*args):
    p = subprocess.run(['git', *args], cwd=REPO, capture_output=True, check=True)
    return p.stdout

def methods(raw):
    tree = ast.parse(raw)
    result = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            for child in node.body:
                if isinstance(child, ast.FunctionDef):
                    result[node.name + '.' + child.name] = ast.dump(child, include_attributes=False)
    return result

original = task_files()
if (OUT / 'task-files.json').exists():
    assert original == read(OUT / 'task-files.json')
else:
    save('task-files.json', original)
for name in ('context.md', 'plan.md', 'seams.md'):
    target = OUT / (name + '.before')
    if not target.exists():
        target.write_bytes((RUN / name).read_bytes())

check = subprocess.run([PY, '-B', str(REPO / 'services/continuous-development/check.py'),
    'report', str(REPO), str(RUN), '029', 'doc-names'], cwd=REPO, capture_output=True)
(OUT / 'report-check.stdout').write_bytes(check.stdout)
(OUT / 'report-check.stderr').write_bytes(check.stderr)
assert check.returncode == 0, check.stderr
report = read(TASK / 'report.json')
phase = read(RUN / 'phases/029/phase.json')
start, end = read(E / 'source-start.json'), read(E / 'source-end.json')
previous = read(RUN / 'phases/028/manager-evidence/source-inspected.json')
assert start == previous
assert set(start) == set(end)
current = {p.relative_to(REPO).as_posix(): sha(p)
    for base in ('.claude/skills', '.agents/skills', '.agents/diff')
    for p in sorted((REPO / base).rglob('*'))
    if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
assert current == end
save('source-inspected.json', current)
changes = sorted(p for p in start if start[p] != end[p])
assert set(changes) == {r['path'] for r in report['changes']}
assert set(changes) <= set(phase['tasks'][0]['writes'])

runs = []
selections = {}
for label, folder, tree in [('focus', 'f', '.claude'), ('focus2', 'f2', '.claude'),
        ('final-c', 'c', '.claude'), ('final-m', 'm', '.agents'),
        ('final-c2', 'c2', '.claude'), ('final-m2', 'm2', '.agents')]:
    raw = read(E / folder / 'report.json')
    rows = [row for group in raw['reports'] for row in group['rows']]
    ids = [row['id'] for row in rows]
    assert len(ids) == len(set(ids)) == len(raw['selected'])
    assert set(ids) == set(raw['selected'])
    execution = read(E / (label + '.execution.json'))
    counts = dict(Counter(row['outcome'] for row in rows))
    assert execution['exit_code'] == (1 if label == 'focus' else 0)
    assert raw['complete'] and raw['successful'] == (label != 'focus')
    assert not raw['changed_during_run']
    edition = {p: sha(REPO / tree / 'skills/do-math/scripts' / p) for p in raw['source_sha256']}
    # Only the final runs are required to match the current final source edition.
    if folder in ('c2', 'm2'):
        assert edition == raw['source_sha256']
        before = read(E / (label + '.source-before.json'))
        after = read(E / (label + '.source-after.json'))
        assert set(before) == set(after) == set(current)
        assert all(before[p] == after[p] == current[p] for p in before if not p.endswith('/tests/.timings.json'))
        assert counts == {'passed': len(ids)}
        selections[folder] = raw['selected']
    runs.append(dict(label=label, selected=len(ids), counts=counts, exit_code=execution['exit_code'],
                     python_sources=len(edition), report_sha256=sha(E / folder / 'report.json')))
assert selections['c2'] == selections['m2']
final_ids = set(selections['c2'])
old_report = read(RUN / 'phases/027/tasks/doc-policy/evidence/c3/report.json')
old_doc_ids = {t for t in old_report['selected'] if t.startswith('structure.test_doc_code.')}
assert len(old_doc_ids) == 38 and old_doc_ids <= final_ids
closure = read(E / 'finding-closure.json')
expected_findings = {f'028/{task}/F{i}' for task, count in [('operator-names', 3), ('cli-control-names', 3), ('role-glossary-names', 2)] for i in range(1, count + 1)}
assert {r['finding'] for r in closure} == expected_findings
for row in closure:
    assert set(row['canonical_passed_test_ids']) <= final_ids
    assert set(row['mirror_passed_test_ids']) <= final_ids

preserved_methods = []
for relative in changes:
    if relative.startswith('.claude/') and '/tests/' in relative and relative.endswith('.py') and '/support/' not in relative:
        old = methods(git('show', 'HEAD:' + relative))
        new = methods((REPO / relative).read_bytes())
        assert all(new.get(k) == v for k, v in old.items()), relative
        preserved_methods.append(dict(path=relative, unchanged=len(old), added=sorted(set(new)-set(old))))

parser_checks = []
for filename in ('setup_lean.py', 'probe_cli.py'):
    relative = '.claude/skills/do-math/scripts/' + filename
    old = ast.parse(git('show', 'HEAD:' + relative))
    new = ast.parse((REPO / relative).read_bytes())
    main = next(n for n in old.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    builder = next(n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == 'build_parser')
    first = next(i for i, n in enumerate(main.body) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'parser' for t in n.targets))
    last = next(i for i, n in enumerate(main.body) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'args' for t in n.targets))
    statements = [n for n in builder.body if not isinstance(n, ast.Return) and not (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str))]
    assert [ast.dump(n) for n in main.body[first:last]] == [ast.dump(n) for n in statements]
    parser_checks.append(dict(path=relative, declarations_preserved=True, main_consumes_shared_parse_arguments=True))

for label in ('mirror-check', 'skill-c', 'skill-m'):
    assert read(E / (label + '.execution.json'))['exit_code'] == 0
assert '1336' in (E / 'mirror-check.stdout').read_text(encoding='utf-8')
for label in ('skill-c', 'skill-m'):
    assert json.loads((E / (label + '.stdout')).read_text(encoding='utf-8'))['status'] == 'verified'
counterexamples = read(E / 'counterexamples-final.json')['cases']
assert len(counterexamples) == 16 and all(row['issues'] for row in counterexamples)
assert task_files() == original
save('verification.json', dict(head=git('rev-parse', 'HEAD').decode().strip(), report_check_exit=0,
    source_count=len(current), previous_start_equal=True, current_end_equal=True, changes=changes,
    product_paths=[p for p in changes if not p.endswith('/tests/.timings.json')], runs=runs,
    old_document_ids=sorted(old_doc_ids), final_same_selection=True, closure=closure,
    preserved_methods=preserved_methods, parser_checks=parser_checks, counterexamples=counterexamples,
    task_file_count=len(original), task_bytes_unchanged=True,
    limitation='Data and source review only. No new product test/live call; final G4-G8 and L01 remain open.'))
print(json.dumps({'verified_sources': len(current), 'changes': len(changes), 'task_files': len(original), 'final_tests_each': len(final_ids)}, ensure_ascii=False))
