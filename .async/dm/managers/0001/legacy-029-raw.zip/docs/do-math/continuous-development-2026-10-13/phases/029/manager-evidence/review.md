# 029 manager 검수

doc-names report를 전문으로 읽고 report 검사를 통과한 뒤 실제 소스·원보고·diff를 대조했다. A1~A5의 지정 완료를 승인한다. 판정의 기계적 근거는 verification.json과 verify.py이며 새 제품 시험은 실행하지 않았다.

2675개 소스의 경로 집합과 SHA를 새로 열거해028/작업시작·작업종료/현재를 비교했다. 변경22개는 report/writes와 같고 정본10·미러10·비용캐시2다. 최종 c2/m2의 선택183·고유row183·전건passed·실제exit0와 각각875Python SHA, 실행 전후 비캐시 불변을 대조했다. 원task129파일은 검산 전후 불변이다. 027의 문서38ID는 양쪽 최종passed에 모두 존재하며 기존 시험메서드는 AST 동일하다.

두 main의 argparse 선언은 새 build_parser와 AST 동일하다. parse_arguments의 기존 교차 인자 반려를 유지하고 main이 먼저 호출하는 실제 코드와 새 invalid-before-host/inspect 입력 소비 단언을 읽었다. 문서 helper는 동일 parser를 사용하며 shell pipeline 뒤를 도구 argv로 넘기지 않는다. barefilename은 파일 참조로 구분한다. 이는 현재 예제 범위의 판단이며 임의 shell 문법 전체의 실행 인증이 아니다.

모듈 열거는 실제 adapter 클래스 속성과 비교하며 목록을 복제하지 않는다. config/grant는 실제 config/control 정의를, runtime 표는 해당 저장 enum을, query는 해당 parser 선택지를 소비한다. knowledge의 control shape와 candidate 의미 검사를 나누고 부분 relation_claim은 완전 요청으로 검사하지 않는다. 네 검토단계의 root/item/enum과 checkpoint 파일도 실제 stage/schema/value 소비에 연결돼 있다. 필요한 절·fence·선언 부재를 반려하는 단언을 확인했다. 028의14최소 반례와 모듈2반례는 원진단과 정확 최종 시험에 연결된다. 문구상 기존ID import·formal재사용·withdrawn재등록·HTTP 효과불명·kind의TEXT/같은묶음 권한은 현재 직접 소비 단언과 함께 읽었다. finding-closure의 여덟 finding을 모두 승인한다.

집중 실행 f의48passed/2failed는 문구의 무소유 dotted 표기와 barefilename/pipeline 추출 문제이며 f2의52passed 및 최종 정확ID에서 해소됐다. 첫 c/m183passed 뒤 문구를 바꿨으므로 c2/m2만 최종 인도 근거로 채택한다. 보조 AST 관찰자의 Expr 제거 오류와 Git/manifest 개행 관찰 오류는 task 원실패로 남고 제품 성공에 합산하지 않는다. manager의 초기 보조파일 조회 한 경로 부재는 제품 검증 실패나 원자료 소실로 해석하지 않았고 기존028 finalize를 참조했다.

F1은 지정 수리 완료로 resolve한다. F2는 C11/C12와 plan에 carry한다. parser/문구가 새 설치·prompt hash를 바꾸므로 과거 전체 설치/T4 판본 동등성이나 모델 독해를 주장하지 않는다. 불변 하위경계의 기존 승인 성질과 새 직접 소비 회귀만 유지한다. L01 외부 프로필/byte 결정·symlink 실반려 미검사·최종 G4~G8은 남는다.

030은 R02 요청생산/수신, R07 반환소유권 모집단, R18 외부경계 현재호출을 세 독립 읽기로 배정한다. 각 기존 질문/관련 PR slice와 기존 승인 한계를 지정해 중복 문서 조사·전체 과거 감사로 확장하지 않는다. 공식 시험/외부호출과 제품쓰기를 금지하므로 캐시·DB·포트 충돌이나 미완성 결과 의존이 없다. 결과에 따라 필요한 수리·미러·실제 연결검증을 후속에 통합한다.

공용 문서는 C2 검수사실, C5 다음 독립성, C8 같은 모델, C9 지정 요구/과거slice, C10 여덟종결, C11 관문 한계, C12 보존/인도를 갱신했다. C1의G 전부·기존 외부결정·역사 실패와 유효 근거는 보존했다. 현재 배정 문단만 교체했고 다른 과거 문장은 삭제하지 않았다. common-docs.diff가 전후 의미 대조 근거다. S계약 개정은 없다.
