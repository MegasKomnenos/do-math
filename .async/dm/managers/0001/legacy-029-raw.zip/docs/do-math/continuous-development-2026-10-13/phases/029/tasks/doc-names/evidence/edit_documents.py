from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).parent))
from task_io import REPO

def replace(path, old, new):
    target = REPO / '.claude/skills/do-math' / path
    raw = target.read_bytes()
    text = raw.decode('utf-8')
    assert text.count(old) == 1, (path, old)
    target.write_bytes(text.replace(old, new).encode('utf-8'))

replace('references/초기화-운전.md',
    'Codex 어댑터의 식별 모듈은 `cli_worker`, `codex_worker`, `control_transport`, `file_io`, `windows_job`, `scholarly`, `codex_adapter`이고,',
    'Codex 어댑터의 식별 모듈은 `cli_worker`, `codex_worker`, `control_transport`, `control_protocol`, `file_io`, `values`, `codex_stream`, `provider_final`, `control_server`, `worker_request`, `cli_execution`, `windows_job`, `scholarly`, `codex_adapter`이고,')
replace('references/CLI-실행-계약.md',
    '`knowledge`는 다섯 operation을 지원한다.',
    '`knowledge`는 `import`, `register-kind`, `withdraw-kind`, `import-relation`, `revise`, `invalidate` 여섯 operation을 지원한다.')
replace('references/CLI-실행-계약.md',
    '`id`를 제공해 기존 기록을 개정할 수 있으며 revision과 history를 보존한다.',
    '`id`를 제공하면 아직 사용하지 않은 새 canonical knowledge ID여야 한다. 기존 ID의 수입은 거부된다.')
replace('references/CLI-실행-계약.md',
    '`import`에 기존 ID를 넣는 방식은 완전한 후보 본문으로 그 기록을 대체할 때 사용한다. 필요한 필드를 모두 제출하며 생략한 선택 필드가 옛 값으로 유지된다고 가정하지 않는다. 기존 기록의 일부 필드만 바꾸려면 아래의 `operation="revise"`와 `changes`를 사용한다. 두 경로 모두 과거 판본을 보존하고 후보 상태로 돌아가며, Lean 원문이 있으면 형식·동일성 검토를 다시 받는다.',
    '기존 기록의 변경에는 아래의 `operation="revise"`와 `changes`를 사용한다. 개정은 새 replacement ID의 후보를 만들고 `supersedes`로 이전 기록을 연결하며 revision을 1 올린다. 옛 기록과 형식 결과·판정은 그대로 보존한다. Lean 원문·선언·의존이 바뀌지 않았고 기존 형식 결과가 현재 사용 가능하면 그 formal을 재사용하고 새 동일성 검토로 보낸다. 그렇지 않으면 새 형식 검사부터 진행한다.')
replace('references/CLI-실행-계약.md',
    '기존 token과 중복될 수 없다. 스킬에 설치된 지식·관계 종류의 token은 인스턴스를 만들 때 이미 활성으로 정의되므로 다시 등록하지 않는다.',
    '현재 철회되지 않은 같은 family/token과 중복될 수 없다. `withdraw-kind`로 철회된 정의는 새 정의로 재등록할 수 있으며 이전 정의를 보존한다. 스킬에 설치된 활성 지식·관계 종류의 token은 인스턴스를 만들 때 이미 정의되므로 다시 등록하지 않는다.')
replace('references/CLI-실행-계약.md',
    '개정은 이전 revision과 검토 계보를 보존하고 candidate·새 형식 검사·새 동일성 검토로 돌린다.',
    '개정은 새 replacement ID·revision+1·`supersedes`를 갖는 candidate를 만들고 옛 기록과 판정을 보존한다. 변경되지 않은 Lean 원문·선언·의존의 현재 사용 가능한 formal만 재사용하며, 새 동일성 검토는 다시 받는다. 그 외에는 새 형식 검사부터 진행한다.')
replace('references/CLI-실행-계약.md',
    '실행기는 `prepared`·`running` 상태를 기록하고, 전송 직전에 불리언 `transmitted=true`를 저장한 뒤 전송한다. transport 결과를 확정할 수 없으면 `unknown`이다. HTTP 응답을 받으면 `confirmed`, `http_status`, body hash를 기록하고 `succeeded`는 실행 기록에서 2xx 여부로 별도 계산한다.',
    '외부 operation 원장은 `prepared`를 유지한 채 전송 직전에 불리언 `transmitted=true`를 저장한다. 전송을 맡은 별도 execution의 상태는 `running`이다. HTTP 결과가 2xx이면 operation은 `confirmed`, `succeeded=true`가 된다. 비2xx 응답에서 효과 부재가 입증되면 `failed`, `succeeded=false`이고, 효과가 입증되지 않으면 `unknown`, `succeeded=null`이다. 응답의 `http_status`와 body hash를 보존하며 transport 결과를 확정할 수 없는 경우도 `unknown`으로 남긴다.')
replace('references/CLI-실행-계약.md',
    '| 외부 operation | `prepared`, `running`, `confirmed`, `failed`, `unknown`, `cancelled` |',
    '| 외부 operation | `prepared`, `confirmed`, `failed`, `unknown`, `cancelled` |')
replace('references/CLI-실행-계약.md',
    'kind enum은 실행 시점의 active knowledge 종류 정의에서 동적으로 만든다.',
    '`knowledge.kind`는 구조 검사에서 문자열(TEXT)로 받는다. 중앙 수신의 의미 검사는 입력의 활성 종류 또는 같은 편입 묶음에서 제안한 종류인지 확인하고, 미등록 종류는 반려한다. 신규 종류의 제안은 독립 의미 검사와 활성화 권한을 별도로 통과해야 한다.')
print('document replacements complete')
