# r02-fix 결과

F1을 workspace에서 수리했다. `contracts/pairs.py:worker_request_run`은 AI `research_work` 프로필을 명시적으로 선택하고 dispatched ticket과 prompt seal을 사용한다. limits 표본은 기존 `host_capacity_fixture`의 승인 제약과 요구량을 적용하고 resume 전에 start를 게시한다. pinned tools/lock은 profile에서만 오며, unpinned 표본에는 identity를 만들지 않는다. 내부 runner·adapter·worker·collector는 실제 코드이고 외부 Job 및 공급자 CLI만 기존 `ProviderJobs`·`ScriptedCLI`다.

`worker_request_runs`는 기존 공급자별20입력을 실행하고, pair는 실제 `request.json`을 읽은 값을 반환한다. `test_worker_samples_preserve_both_assigned_model_flags_for_each_legal_assignment`는 각 요청과 snapshot을 파일이 존재하는 동안 두 worker로 읽어 검사한다. 정확 binding·profile_ref·limits·tools·lock과 CLI argv, prompt/schema 바이트·hash, start 게시 순서, CLI1호출·worker exit0·Job done/closed를 확인한다. lock별 프로필 참조는 자기 프로필과 먼저 대조하며 서로 다름도 단언한다. lock 전송효과 비교에는 검사를 마친 프로필 참조와 실행별 evidence/snapshot 경로만 제외하고 control/workspace/tools는 그대로 둔다.

Claude pinned limits+control+scholarly+lock=True는 이20입력에 포함되므로 별도 중복 시험을 만들지 않았다. `test_scholarly_args_zero_one_and_many_reach_both_worker_commands`는 같은 최대 조합에서 두 공급자의 `[]`, `[absolute_server]`, `[absolute_server, '--flag']`를 저장과 CLI까지 연결한다. 설정 args의 순서·값과 추가 `--data-dir`를 확인한다. 기존 필수+선택 필드 역방향 및 collected/bound/incomplete/stopped8결과 표본의 의미 단언도 유지했다.

먼저 기존 최소 lock 시험에 실제 저장 입력 파일 단언을 넣었다. 원 helper에서는 두 공급자 모두 그 단언에 실패했다. 공식 보고는 failed1 row와 두 provider subtest 실패를 남겼으며 import/fixture 오류가 아니다. 재현 소스는 `red-test_pairs.py`, 당시 producer는 task의 base `pairs.py`다. 수리 후 관련 모듈6시험은 green1에서 통과했고, 관측 비용과 이유를 docstring에 남긴 최종 판본에서도6passed·exit0이다. 최종 선택과 실제 row는6개씩이며 소스 변경·미실행·fixture 오류는 없다. 최종 보고의875Python SHA는 제출판과 전건 일치한다.

최종 관련 실행은9.8초였다. 네 시험은0.2초 소프트 기준을 넘었고, 실제 파일·worker·collector를 연결하는 비용을 공식 budget row와 보고에 남겼다. 시간 차이를 개선 효과로 해석하지 않는다. 초기 green1 뒤에는 설명 docstring만 바꿨으며 최종 실행은 그 제출 판본을 확인한다.

미러는 공식 생성기로 갱신했다. 생성·검사의 exit는0이고1336파일에 드리프트가 없다. 실제 변경은 시험 정본2·대응 미러2·공식 비용캐시2의6경로이며 task writes에 모두 포함된다. 공유 runtime와 기존 provider support/sim 시험은 수정하지 않아 추가 소비자 실행은 필요하지 않았다. `check.py report`는 PASS다. 공용소스 통합·accepted·commit은 manager가 맡는다.

입력40행→시험ID/단언 대응은 `branch-assertion-map.json`, 실제 공식 row·exit·SHA·변경범위·미러는 `verification.json`, 원보고는 `red/`, `green1/`, `final/`에 있다. 공식 보고의 row는6시험이며40요청의 독립 row로 표시되지 않는다. 행별 입력 매핑은 코드 대응이고 실제 실행 근거는 각20실행을 단언한 공식 시험의 통과다. 임시 request/CLI 파일은 시험 안에서 확인했고 시험 종료 후 보존하지 않았다.

F2와 G4~G8 전체 최종 판본 실행은 남아 있다. 실제 모델·Windows Job·학술 서버·Lean·예약 호출 및 전체 관문은 이번에 실행하지 않았다. 029 설치/prompt 판본 한계, L01 Q1/Q2·UTF-8 byte 미충족, Windows1314 symlink 실제 반려 미검사와 다른 요청/저장 가족·K/P2·의미 질문의 상태는 바꾸지 않는다.
