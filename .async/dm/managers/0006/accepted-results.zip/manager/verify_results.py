"""Inspect submitted bytes and original reports; do not run product tests."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('C:/math')
RECORDS = ROOT / '.async/dm'
HERE = RECORDS / 'managers/0006'
sys.path.insert(0, str(ROOT / 'services/async-development'))
import check
import workspaces

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

result = {}
for task in ('r07-fix', 'r18-fix'):
    report = check.report(RECORDS, task)
    home, delta = workspaces.changes(RECORDS, task)
    changes = []
    diff = []
    for relative, (before, after) in sorted(delta.items()):
        current = workspaces.file_hash(ROOT / relative)
        assert current in (before, after), relative
        changes.append({'path': relative, 'base': before, 'workspace': after,
                        'source_before_integration': current})
        diff.extend(difflib.unified_diff(
            (home / 'base' / relative).read_text(encoding='utf-8').splitlines(True),
            (home / 'workspace' / relative).read_text(encoding='utf-8').splitlines(True),
            fromfile='base/' + relative, tofile='workspace/' + relative))
    (HERE / (task + '.diff')).write_text(''.join(diff), encoding='utf-8')
    pairs = []
    for item in changes:
        relative = item['path']
        if relative.startswith('.claude/'):
            mirror = relative.replace('.claude/', '.agents/', 1)
            equal = (home / 'workspace' / relative).read_bytes() == (home / 'workspace' / mirror).read_bytes()
            assert equal, relative
            pairs.append({'source': relative, 'mirror': mirror, 'bytes_equal': equal})
    runs = {}
    for run in ('red', 'green'):
        report_path = home / 'evidence' / run / 'report.json'
        raw = read(report_path)
        child = read(home / 'evidence' / run / 'structure/result.json')
        rows = [row for group in raw['reports'] for row in group['rows']]
        selected = raw['selected']
        assert rows == child['rows']
        assert sorted(selected) == sorted(row['id'] for row in rows)
        assert len({row['id'] for row in rows}) == len(rows)
        assert raw['complete'] and not raw['changed_during_run'] and not raw['fixture_counts']
        assert all(row['outcome'] == ('passed' if run == 'green' else 'failed') for row in rows)
        mismatches = []
        if run == 'green':
            for relative, expected in raw['source_sha256'].items():
                path = home / 'workspace/.claude/skills/do-math/scripts' / relative
                if digest(path) != expected:
                    mismatches.append(relative)
            assert not mismatches, mismatches
        runs[run] = {'report_sha256': digest(report_path), 'selected': selected,
                     'actual_rows': rows, 'counts': raw['counts'], 'complete': raw['complete'],
                     'successful': raw['successful'], 'fixture_counts': raw['fixture_counts'],
                     'changed_during_run': raw['changed_during_run'],
                     'python_hashes': len(raw['source_sha256']),
                     'final_workspace_mismatches': mismatches if run == 'green' else None,
                     'seconds': raw['total_seconds']}
    if task == 'r07-fix':
        runs['red']['parent_exit'] = None
        runs['red']['limit'] = 'Task did not retain parent exit; original failed assertion is preserved.'
        runs['green']['parent_exit'] = int((home / 'evidence/green-exit.txt').read_text().strip())
    else:
        v = read(home / 'evidence/verification.json')
        runs['red']['parent_exit'] = v['red']['exit']
        runs['green']['parent_exit'] = v['green']['exit']
    assert runs['green']['parent_exit'] == 0
    caches = []
    for prefix in ('.claude', '.agents'):
        relative = prefix + '/skills/do-math/scripts/tests/.timings.json'
        equal = (home / 'base' / relative).read_bytes() == (home / 'workspace' / relative).read_bytes()
        assert equal
        caches.append({'path': relative, 'restored_to_base': equal})
    result[task] = {'report_check': 'PASS', 'actual_changes': changes, 'mirror_pairs': pairs,
                    'runs': runs, 'cost_caches': caches, 'manager_product_test_runs': 0}

(HERE / 'source-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({task: {'files': len(v['actual_changes']), 'passed': v['runs']['green']['counts'],
                       'python_hashes': v['runs']['green']['python_hashes']}
                  for task, v in result.items()}, ensure_ascii=False))
