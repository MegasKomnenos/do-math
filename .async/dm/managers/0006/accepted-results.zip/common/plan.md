# 현재 계획: 남은 의미 질문과 실제 검사 공백 해결

## 수용 상태와 현재 배정

사용자 목표와 G1~G8은 context.md를 따른다. 새 queue의 task 완료만으로 원래 요구30·보존61·P2 12와 기존 재검토25영역을 축소하지 않는다. 과거 원자료는 sources/legacy 및 C:/math/docs/do-math/continuous-development-2026-10-13에 보존한다.

| task | 현재 결과·종료할 질문 | 선행과 수정 범위 |
|---|---|---|
| r02 | 수용. 실제 요청 생산 연결 공백을 찾아 r02-fix에 연결했다. | 무변경 조사, integration files=[] |
| r07 | 수용. 소유권39행과 output_contract 등록/내부 공유 공백을 확인했다. | 무변경 조사, integration files=[] |
| r18 | 수용. 현재 경계57행과 native 파일 교체 검사 누락을 확인했다. | 무변경 조사, integration files=[] |
| r02-fix | 수용. runner 저장·adapter·두 worker·collector와 공급자별20입력, args 0/1/여럿을 연결했다. 관련6passed 검수. F1 해결, F2 최종 판본 대기. | r02 선행. 정본 시험2·미러2·캐시2 통합 |
| r07-fix | 수용. output_contract 두 분기 등록·Claude json_copy와 실제 값/격리 단언. 관련12passed 검수. F1/F2 해결, R07/1-E 최종 판본 대기. | r07 선행. runtime1·시험1·정본 설명1과 미러3 통합. 캐시 복원 |
| r18-fix | 수용. native binding·tuple 소비 발견과 실제 source/이동 반례의 소유 판정. 관련7passed 검수. F1 해결, R18/9-A 최종 판본 대기. | r18 선행. 구조 시험1·미러1 통합. runtime 불변·캐시 복원 |
| r04 | 진행 중. 조건 enum·다섯 반복 한도 소비·결과8표본 JSON 내용의 남은1-A 질문과 시험 수리. 시작 배정 유지. | r02-fix 선행. pairs·test_pairs·test_storage_fields·test_repetition_hold_contract 및 미러 |
| r05 | 새 배정. 외부 값 네 경계의 수용/반려/변환과 저장·해시·JSON 소비를 판정하고 시험 공백 수리. 해당 경계의 실제 null도 함께 확인한다. | depends_on=[]. provider_native_storage·provider_observation_ingress·storage_repository·필요시 external_value_boundaries·provider_native_inputs와 미러 |
| r11 | 새 배정. 공개 run의 현행 종료 분기와 정상 봉투/추가 착수 없음, until_active/live-future 도달 전제 및 필요한 시험 보완. | depends_on=[]. scheduling_close_exits·remaining_exits·repair_exit·scheduling_exit_contracts와 미러 |

worker 모델은 gpt-6.1-sol/high, max_workers=3, 각 공식 시험은 jobs1이다. r04·r05·r11의 의미 있는 쓰기는 서로 겹치지 않는다. r05/r11은 수용된 현재 소스의 사본에서 시작하지만 r04의 중간 결과를 소비하지 않는다. 두 새 작업에 불필요한 선행 의존성을 넣지 않는다. 세 task 모두 비용 캐시는 evidence에 보존한 뒤 자기 base로 복원한다. runtime 결함 발견 시 정확 입력·영향·필요한 파일을 보고하고 범위 안 결과를 마친다.

## 이번 수용의 근거와 한계

manager 0006은 r07-fix·r18-fix의 실제 변경8경로와 정본/미러4쌍, 원 red/green 보고·하위 row·선택 ID·제출판 Python 각875해시를 대조했다. report 검사는 PASS, 통합은 충돌0, 통합판 미러 --check는1336파일 드리프트0이다. manager의 새 제품 시험은0이며 서로 다른 task 사본의12passed·7passed를 통합판 전체 성공으로 합산하지 않는다. r07 red parent exit 미회수와 r18의 AST 한정 탐색을 유지한다. 상세 근거는 managers/0006/review.md·source-review.json이다.

R07/1-E와 R18/9-A의 확인된 수리는 최종 판본 증거 대기로 옮긴다. PR06 B22와 K-51의 정본 소비 slice, PR02 B13/B14/B62/B85 지정 slice는 기존 판정 범위대로 유지한다. Temp 원보고 부재와 029의 전체 설치/prompt 판본 한계는 남는다. 이번 구조 수리는 Claude 실제 전송 실패 또는 Windows 교체 runtime 실패를 관측·수리한 결과가 아니다.

0001의 029 이관은 새 queue accepted task가 아니다. 현재 소스와 과거 원보고를 대조해 여덟028 finding과029 F1을 수용했고 F2를 유지했다. 근거는 managers/0001/inheritance-review.json·review.md다. r02-fix는0005에서 통합했으며 요청 가족 F1 해결과 F2 최종 판본 대기라는 처분을 유지한다. 0002~0005의 상세 판단은 각 managers/NNNN/review.md를 따른다.

## 후속 범위와 남은 질문

r05의 네 경계는 원문 R05의 유한 입력축으로 묶고, 같은 값 경계의 null 확인을 작은 별도 조사로 쪼개지 않는다. 다만 R06의 모든 명시 null 생산 필드·모든 소비자 모집단은 별도로 남긴다. r04의 여덟 결과 표본 내용 단언은 r04가 소유하며 r05는 pairs/provider_runs를 수정하지 않는다. r11은 현재 종료 분기표와 세 직접 소비 시험을 한 task에서 맡는다. until_active 질문에 도달 근거가 없으면 불가능성/미확인을 구별하고 합성 상태 성공으로 대신하지 않는다.

두 후속은 다른 요구30·보존61·P2 12, PR06/PR11/PR15 전체를 종결하는 작업이 아니다. requirement-state/tracking-state/prior-review-state의 원 ID를 써 충분한 기존 성질·수리·정확 미결·최종 증거 대기를 갱신한다. 무관한 전수 감사나 새 관리 체계를 만들지 않는다. 현재 검수한 문서 P01~P11·이름 작업은 새 반례 없이 다시 열지 않는다.

결과가 오면 실제 파일과 원보고를 검수하고 무변경 조사도 integrate한 뒤 accepted에 넣는다. 필요한 구현·관련 확인은 한 task에서 마치며 같은 helper의 수리는 묶고 독립 파일은 병렬로 배정한다. manager 도중 새로 도착한 완료 사건은 다음 inbox에서 처리하며 진행 중 정의를 바꾸지 않는다.

## 최종 판본과 종료

G1~G3의 남은 의미 질문과 필요한 수리 뒤 제품을 고정하여 G4 전체 일반, G5 fresh 전체 T3, G6 현재 함수 모집단의 극단 변이와 정상 기준, G7 실제 경계와 녹화의 최종 판본 연결을 확보한다. 과거 T4 각295passed 등은 판본·성질이 유효한 범위만 재사용한다. 작은 부분 결과의 합을 전체 통과로 쓰지 않는다. 최소 검증 원칙은 원래 명시된 최종 관문을 생략하는 근거가 아니다.

L01의 실제 운전 프로필·출력 단위 Q1/Q2와 원문 UTF-8 byte 미충족, Windows1314 symlink 실제 반려 미검사는 열린 상태다. 독립 작업이 가능하면 active를 유지한다. 외부 입력 없이는 진행할 수 없을 때만 정확한 질문과 이유로 blocked를 게시한다.

마지막에는 수용한 모든 work를 직접 또는 간접 선행으로 포함하는 제품 수정 없는 최종 review를 수행한다. 상속 성과와 원래 G1~G8, 미결 처분과 최종 통합판의 증거가 모두 충족되고 실행 중/미해결 task가 없을 때 queue complete를 게시한다. 최종 검증 중 제품을 바꾸지 않는다. push·graphify 갱신·기존 연구 재개/삭제는 하지 않는다.
