# do-math 비동기 개발의 현재 맥락

## 전환과 권위

2026-10-15 사용자가 현재 개발을 멈추고 `services/async-development`로 재개하라고 지시했다. 이전 continuous-development 실행기와 실행 중이던029 manager 및 자손은 중지됐다. 이 실행의 source_repo는 C:/math, records는 C:/math/.async/dm, engine은 C:/math/services/async-development다. 현재 진행의 정본은 이곳의 context/plan/seams/queue/state이며 과거 phase 기록은 보존된 원자료다. 새 서비스의 protocol.md와 principles.md를 읽고 적용한다. 과거 phase barrier, manager.json/next, task의 공용소스 직접 수정 절차는 이 실행에 적용하지 않는다.

사용자 목표·판단·개별 성과의 세부 사항은 `sources/legacy/context.md`, `sources/legacy/plan.md`, `sources/legacy/seams.md`에 전환 직전 원문 그대로 보존했다. 원래 대화 결정은 C:/math/docs/do-math/continuous-development-2026-10-13/sources/user-decisions.md, 모델 지정과 묶음 지시는 같은 sources의 model-policy-2026-10-14.md와 document-batching-2026-10-14.md다. legacy 원문 속 run: 참조는 모두 C:/math/docs/do-math/continuous-development-2026-10-13 기준이다. repo:는 새 작업자의 workspace 내부 소스 또는 manager의 source_repo를 뜻한다. 과거 원보고의 경로·판본은 바꾸지 않는다.

## 현재 상태: manager 0006

r02·r07·r18 조사와 r02-fix·r07-fix·r18-fix를 통합·수용했다. R02 요청 생산 연결, R07 output_contract의 검사 누락과 반환 내부 공유, R18 native 파일 교체 검사 누락은 해결됐고 해당 범위는 최종 판본 증거 대기다. r04는 시작 배정 그대로 계속 수행한다. 독립 후속 r05(외부 값 경계)·r11(공개 run 조기 반환)을 준비했다. 아래 0001~0005 절은 당시의 판단 이력이며 수리 대기 표현의 현재 상태는 이 절과 0006 절, plan의 표를 따른다.

## 이관 검수 완료와 현재 시작판

async manager 0001은 중단된 029/doc-names의 A1~A5와 F1의 지정 여덟 발견을 이관된 시작판의 성과로 수용했다. 현재 2675개 스킬 소스는 029 manager source-inspected 및 task 종료판과 전건 일치한다. 이관 snapshot 2681파일도 원래 해시와 같고, 추가 6파일은 루트 지침·설정이다. 원task 129파일은 불변이다. 현재 diff에서 정본10·미러10·비용캐시2의 범위, setup/probe의 실제 parser 공유, 문서 helper의 실제 정의 소비와 새 단언을 확인했다. 최종 c2/m2는 각각 183선택·183고유 passed·exit0이고 각875Python SHA가 현재와 같다. 기존38문서ID와 여덟 finding의 정확 시험ID도 그 결과에 포함된다. 새 제품 시험과 외부 호출은 실행하지 않았다.

판정의 정본은 `managers/0001/inheritance-review.json`과 `review.md`다. 과거 `phases/029/manager.pending.json`, 공용 문서와 M-0579는 중단 당시 초안으로 그대로 보존하며, 거기에 적힌 게시·압축·커밋 예정 표현을 완료 사실로 사용하지 않는다. 원task·제품 원바이트·중단로그·초안은 `managers/0001/legacy-029-raw.zip`과 `preservation.json`에 보존한다. 검수한20비캐시 제품경로의 관리 마감은 이번 manager의 commit 기록으로 연결한다. 기존 dirty/untracked·비용캐시·과거 관리초안은 이 작업의 제품 변경에 섞지 않는다.

029는 새 workspace task가 아니므로 integrate하거나 queue.accepted에 추가하지 않는다. 새 async 결과부터 실제 workspaces.py integrate와 accepted 절차를 따른다. 029 F2는 유지한다. parser·문구 변경은 설치/prompt hash를 바꾸므로 과거 전체 설치·실호출 판본 동등성이나 모델 독해를 재인증하지 않는다. 불변 하위경계 성질과 실제 관련 회귀만 재사용한다. L01 Q1/Q2와 원문 UTF-8 byte 미충족, Windows1314 symlink 실반려 미검사, G4~G8 및 다른 의미 질문은 열려 있다.

초기 읽기 배정은 r02(요청 생산·수신), r07(반환 소유권 모집단), r18(실제 외부 경계 호출)의 세 독립 work다. 기존030은 실행되지 않은 후보 원문이며 새 objective가 workspace/보고/경로 규약을 대체한다. 이 세 배정의 제품 writes와 depends_on은 비어 있다. 같은 읽기 질문을 전수 감사나 문서 작업으로 확대하지 않으며, 각 완료 사건에서 확인된 공백만 후속 구현·관련 검증에 연결한다.

## 0002: 요청 가족의 조사 수용과 시험 수리 배정

r02의 읽기 판정을 수용했다. report 검사는 PASS이며 `workspaces.py integrate` 결과는 files=[]이다. 제품 변경이나 새 제품 시험은 없다. `tasks/r02/evidence/branch-field-map.json`은 두 공급자의 필수·선택 필드 35행과 기존 helper의 40개 입력 조합을 실제 정의·단언·원보고에 연결한다. 필드명 역방향과 Codex의 model-lock 입력 무효과는 기존 근거의 범위에서 유지한다. 이 표를 실제 runner의 전 조합 실행 결과로 세지 않는다.

확인한 F1은 시험의 실제 생산자 연결 공백이다. `tests/contracts/pairs.py:_worker_request_samples`가 첫 생성 프로필인 `external_action`을 고르고 `worker_request_fields`를 직접 호출한다. 이 기계 프로필에는 ai가 없어 실제 `model_call.runner_assignment`의 모델·effort 조건을 충족하지 않는다. worker의 참조 형식 검사만 통과해도 실제 AI 배정·저장·수신 연결을 입증하지 못한다. 런타임 고장을 관측한 것은 아니다.

후속 `r02-fix`는 유효 AI 프로필·ticket·seal·필요한 host start publication으로 실제 `ModelRunner.run`이 저장한 요청을 두 worker에 연결한다. 기존 선택 필드 축, Codex lock 회귀, 결과 8표본을 보존하고 scholarly args의 0/1/여럿을 같은 시험 수리에 묶는다. 정본 시험·필요한 공유 helper·미러·관련 최소 검증을 한 task가 맡는다. 실제 프로필의 lock 값이 달라지면 profile_ref도 달라지므로 서로 다른 프로필 참조를 같다고 강제하지 않고 각 배정에 정확히 일치하는지 확인한다. r02만 선행이며 r07·r18의 종료는 필요하지 않다. 두 조사는 0002 inbox에서 실행 중이었고 배정을 변경하지 않았다.

판정 근거는 `managers/0002/review.md`와 `source-review.json`, 상세 후속 입력은 `tasks/r02-fix/objective.md`다. F1은 수리 대기이고 F2는 최종 판본 실행 대기다. 007 원보고는 실제 관련 row와 판본의 범위에서만 유지하며, 현재 없는 B49 Temp 원보고의 counts는 성공으로 합산하지 않는다. 1-A의 다른 요청 가족, K-78의 저장 가족, 다른 K/P2는 새로 종결하지 않았다. G4~G8, L01 및 Windows1314 symlink 미검사는 그대로 남는다.

## 0003: 반환 소유권 조사 수용과 한정 수리

r07의 R07/1-E 현재 모집단 대응을 수용했다. report 검사는 PASS이며 `workspaces.py integrate`는 files=[]이다. 기존 38항목의 소유권·유한 입력축 처분을 유지하고 새 builder를 포함한 ownership-map.json 39행으로 남은 질문을 좁혔다. r07이 읽은 소스 29파일의 해시가 현재 공용판과 같으며, 보존 B116/schema 8행과 B117/schema 11행의 passed를 원보고에서 확인했다. B117 전체 successful=false와 Temp 원보고 5개의 부재는 유지한다. 새 제품 시험·제품 변경은 없다.

F1은 `provider_final.output_contract`가 owned transport schema 생성자이면서 `test_schema_builders`의 실제 호출 목록에 없다는 공백이다. 이름에 schema가 없어 기존 자동 탐색으로 발견되지 않는다. F2는 Claude 분기의 deepcopy가 입력의 공유 leaf를 반환 내부에도 공유하는 현상이다. task의 순수 원본문 계산과 현재 정본 5절을 대조했다. 원 입력·다른 반환은 불변이므로 원문 1-E의 cross-result/global 실패와 구별한다. 현재 ModelRunner는 Codex에서만 이 함수를 사용하므로 Claude 실제 전송 실패로 보고하지 않는다.

`r07-fix`는 두 공급자·공유 leaf 입력을 기존 반복 격리 검사에 등록하고 Claude 반환에 기존 values.json_copy를 사용한다. 관련 정본 설명·미러·최소 구조 회귀를 함께 맡는다. r07만 선행이며 실행 중인 r18·r02-fix의 배정은 유지한다. 두 수리의 의미 있는 변경 파일은 독립적이다. r07-fix의 비용 캐시 변경은 근거를 보존한 뒤 자기 base로 복원해 불필요한 통합 충돌을 피한다.

근거는 `managers/0003/review.md`·`source-review.json`과 `tasks/r07/evidence/conclusion.md`다. R07/1-E는 읽기 완료·F1/F2 수리 대기이며 PR06 B22와 K-51의 정본 소비 slice만 유지한다. 다른 K/P2·요청/저장 가족, G4~G8, L01 및 Windows1314 symlink 미검사는 새로 종결하지 않는다.

## 0004: 외부 경계 조사 수용과 파일 교체 검사 수리

r18의 R18/9-A 현재 호출 모집단 조사를 수용했다. report 검사는 PASS이며 `workspaces.py integrate` 결과는 files=[]이다. 제품 변경·새 제품 시험·외부 호출은 없다. task가 기록한 workspace 소스 155파일의 해시를 현재 공용 소스와 대조해 모두 일치함을 확인했다. `tasks/r18/evidence/boundary-map.json`의 57행은 현재 정의·소비·단언·원보고의 연결이며 전체 완료율이 아니다.

직접 subprocess 2곳·주입 starter 7곳, `_job_run` 6소비, sys.executable 8함수와 실행파일 정규화 7호출/6소비의 현행 등록 판정을 유지한다. F1은 Windows 파일 교체의 검사 누락이다. `file_io._windows_files`가 `SetFileInformationByHandle`을 rename으로 반환하고 `_replace_once`가 소비하지만, `test_only_file_io_replaces_files`는 os.replace/shutil.move만 찾는다. 실제 owner는 올바른 file_io이며 제품 실행 실패를 관측한 것은 아니다.

`r18-fix`는 현재 native binding과 alias 소비를 같은 소유권 검사에 포함하고, 정상 source 및 다른 모듈로 옮긴 순수 AST 반례·미러·관련 구조 모듈 확인을 한 작업에서 처리한다. r18만 선행이다. r02-fix·r07-fix의 배정은 유지하며 세 수리의 의미 있는 변경 파일은 독립적이다. r18-fix도 공식 실행의 비용 캐시를 evidence에 보존한 뒤 자기 base로 복원한다.

PR02의 B13/B14/B62/B85 지정 slice와 029 parser 이동의 한정 처분을 유지한다. 보존 B85 원보고 3개의 해당 구조 6행, 010/012/013 및 018의 지정 row를 원보고에서 대조했다. B13/B14/B62의 임시 원보고 9참조(8고유 경로)는 현재 없다. 과거 counts를 합산하거나 현재 전체 설치·환경 인증으로 확대하지 않는다. R18/9-A는 모집단 읽기 완료·F1 수리 대기이며 PR02 전체, 관련 K/P2 전체, G4~G8, L01 및 Windows1314 symlink 실반려 미검사는 남는다. 근거는 `managers/0004/review.md`·`source-review.json`이다.

## 0005: 요청 시험 수리 수용과 남은 계약 연결

r02-fix의 F1을 수용하고 여섯 변경 파일을 workspaces.py integrate로 충돌 없이 통합했다. 정본 contracts/pairs.py·test_pairs.py와 대응 미러, 공식 비용 캐시 두 개다. 실제 base/workspace diff가 보고와 같고 캐시는 contracts.test_pairs 항목만 바뀌었다. worker_request_run은 research_work AI 프로필·ticket·seal·host start publication을 사용해 실제 runner 저장·adapter snapshot·두 worker·collector를 연결한다. 요청 표본을 helper로 직접 조립하던 공백이 해소됐다.

공급자별20 유효 조합과 scholarly args 0/1/여럿, 정확 profile_ref/binding·limits·schema·CLI lock 효과를 확인하는 단언을 검수했다. 기존 필수+선택 역방향과 결과8표본도 유지됐다. 최종 원보고의 선택6ID·실제6passed와 Python875개 SHA가 제출판에 일치한다. task 관측 exit0, fixture 오류·실행 중 소스 변경 없음이며 manager의 추가 제품 시험은0이다. 외부 Job·CLI는 기존 대역이고 실제 외부 호출 성공으로 확대하지 않는다. 9.8초와 네 ID의 소프트 기준 초과는 실제 경로 연결 비용으로 남긴다.

R02/1-A 요청 slice의 F1은 해결, F2는 최종 판본 실행 대기다. 다른 1-A 가족·K/P2 전체와 G4~G8, L01, symlink 미검사는 유지한다. 근거는 managers/0005/review.md·source-review.json 및 tasks/r02-fix/integration.json이다.

후속 r04는 수용된 pairs 위에서 조건 enum·반복 한도 다섯 키 소비·결과 영수증 JSON 전달의 남은 R04/1-A 질문을 처리한다. 충분한 기존 근거를 유지하고 확인된 시험 공백의 수리·미러·최소 확인을 한 task에 묶는다. r02-fix만 선행이며 r07-fix·r18-fix의 시작 배정은 유지한다. 세 작업의 의미 있는 쓰기는 독립적이다. r04의 비용 캐시는 evidence 보존 후 자기 base로 복원한다.

## 0006: 반환 소유권·native 경계 수리 수용과 독립 후속

r07-fix의 정본3·미러3과 r18-fix의 구조 시험 정본1·미러1을 workspaces.py integrate로 충돌 없이 통합했다. 실제 base/workspace 차이는 보고와 같고 두 task의 비용 캐시는 자기 base로 복원돼 통합에 들어오지 않았다. 공용판의 기존 r02-fix 캐시는 유지됐다. 통합판 미러 --check는 1336파일 드리프트0·exit0이다.

r07-fix는 output_contract의 두 공급자·공유 leaf 입력을 기존 반복 격리 검사에 연결하고 Claude 반환을 values.json_copy로 분리했다. Codex의 닫힌 output_json 봉투·원 schema 직렬화·미지원 provider 반려는 유지한다. 실제 값 보존과 형제/입력/다른 반환 불변을 단언한다. 수리 전 공식 보고는 Claude의 결과 내부 중복 노드로1failed이며 parent exit는 미회수다. 성공으로 추정하지 않는다. 수리 후 선택12·실제12passed·exit0과 Python875개 해시의 제출판 일치를 확인했다. 현재 ModelRunner의 호출은 Codex 한정이므로 Claude 실전송 고장을 고쳤다고 주장하지 않는다.

r18-fix는 SetFileInformationByHandle 직접 binding과 tuple 반환/unpack으로 연결된 native 호출을 _replacement_sites에서 발견한다. 실제 _windows_files/_replace_once 두 위치, 전체 이동·소비만 이동한 AST의 동일 소유 판정 반려와 무관한 reader/rename 비발견을 검수했다. 수리 전1failed·exit1, 수리 후 기존6+신규1의7passed·exit0과 Python875개 해시 일치를 확인했다. runtime 파일 교체 코드는 불변이며 새 Windows 실경계 실행 증거는 아니다. 범용 별칭/동적 우회 완전성도 주장하지 않는다.

manager의 새 제품 시험은0이다. 원보고와 실제 단언·변경을 대조했고 추가 불확실성이 없는 관련 시험을 반복하지 않았다. source-review.json은 task별 제출판을 검증하며 두 독립 사본의 결과를 통합판 전체 실행으로 합산하지 않는다. R07/1-E와 R18/9-A의 확인된 수리는 해결·최종 판본 대기로 옮긴다. PR06/B22·K-51 및 PR02의 지정 slice와 원자료 부재 한계는 유지하고 다른 의미 질문·전체 K/P2·G4~G8·L01·symlink 미검사는 남긴다.

후속 r05는 R05/1-C의 네 값 경계와 해당 경계의 실제 null 소비를 검사·필요한 시험 수리까지 함께 맡는다. 제품 전체 R06 null 모집단은 남는다. r11은 R11/2-C의 현행 종료 분기와 until_active/live-future 도달 전제를 판정하고 빠진 시험을 함께 보완한다. 두 task는 기존 원문에 있는 질문이며 r04의 완료를 필요로 하지 않는다. writes는 서로 독립된 시험/해당 helper·미러이고 runtime은 읽기 전용이다. 비용 캐시는 evidence 보존 후 각 base로 복원한다. 완료 사건·원검수의 근거는 managers/0006/review.md·source-review.json과 두 task의 integration.json이다.

## 모델·권한·자원

worker는 gpt-6.1-sol/high, manager는 gpt-6-astra/xhigh, 독해 기본은 gpt-6.1-sol/high다. settings의 공통 model config와 각 task.model/effort에 명시하고 모델 부하 오류를 성공으로 바꾸지 않는다. max_workers=3. 개발 시간은 소프트 기준이며 정확성을 희생하거나시간만으로시험실패/변이포착을판정하지않는다. push·graphify갱신·기존연구재개/삭제는하지않는다. 서비스전환은 기존 외부실험권한을 확대하지않는다.

## 격리·비동기 통합의 실제 사용

worker는 base/inputs를 보존하고 workspace의writes만 수정한다. C:/math 공용소스와 다른task 기록은 읽기전용이다. manager만 workspaces.py integrate로 충돌확인 후 결과를 통합·수용한다. independent task는 최대3개 동시진행하며 완료사건마다 검수한다. 모든동료의종료를기다리는옛phase장벽을만들지않는다. depends_on은실제선행결과만표시한다. 같은파일/공유helper 수정은한task로묶거나수용뒤후속으로배정해불필요한통합충돌을줄인다. 독립소스사본의정적조사는병렬진행하고 캐시/미러도자기사본에서다룬다.

공식검사에는workspace의scripts/run_tests.py를쓰고 실제불확실성을해결하는최소범위를선택한다. worker당기본jobs1, 동시시험worker합계3이하. 공유실환경/예약/도구설치변경과전체관문은동시실행하지않도록manager가배정한다. 최종G4~G8은원래명시된완료요건이므로최소검증원칙을이유로삭제하지않는다. snapshot의Git메타데이터는없다. 과거Git조회는명시적으로 git -C C:/math를읽기전용사용하고, fixture는저장소밖짧은임시경로에자기Gitrepo를만든다. 실행환경 GIT_CEILING_DIRECTORIES는 records/tasks로두어workspace에서상위C:/math를자기repo로오인하지않게한다. --skip-git-repo-check는Codex기동용이다. 제품Git동작의대체근거가아니다.

snapshot_paths는현재skills정본·미러·생성규칙과필요한루트지침이다. 각workspace는그파일의당시바이트를받는다. 과거대형증거/docs/기억/설치toolchain은C:/math의원문을필요부분만읽는다. workspace에없는과거report를누락된제품파일로오인하지않는다. 실Lean/도구는절대경로로읽기전용연결하며제품설치루트의차이는검증입력에명시한다. 범위확장이필요하면manager가settings snapshot을수정하고README의재시작절차를따르되전체원자료를무작정복사하지않는다.

임시자료는 workspace밖 task/evidence 또는저장소밖짧은임시경로에쓴다. Windows의긴cwd/상위Git탐색문제를반복하지않게짧은task ID와출력경로를쓴다. live JSON관찰은do_math.file_io.read_bytes_shared를사용한다. 최종source고정·선택/실제row·exit·판본은필요한검증에서보존하고이미충분한근거를새이유없이반복하지않는다. task는Gitcommit하지않고manager만검수된자기변경을commit-harness의필수기억/색인과함께관리마감한다. 관리작문/기록을위해제품전개를매번과도하게멈추지않는다.

## C1 사용자 목표와 완료 기준

결함이 시험을 빠져나가는 기제를 막는 것이 목표다. 실제 제품 경로를 시험하고 대역은 외부 경계에 두며, 계약·불변식에서 기대값을 얻고, 이전 개선을 보존한다. 정확성·합리적인 개발 속도·유지 비용을 함께 만족해야 한다. 출발 요구와 사용자의 교정은 C:/math/docs/do-math/continuous-development-2026-10-13/sources/user-decisions.md, 원문 위치와 시작 상태는 C:/math/docs/do-math/continuous-development-2026-10-13/sources/baseline.json 및 C:/math/docs/do-math/continuous-development-2026-10-13/sources/requirements-index.json에 있다. 요구 목록이 아니라 검토 가능한 증거로 아래 기준을 충족해야 한다.

### G1 원문 기능·시험 의무

원래 1단계 19개와 2단계 11개 의무의 명시 모집단·입력축·성질을 현재 구현과 시험에 연결한다. 실제 생산/수신, 저장, 형식·부재/null, 전이, 진행성, 정산, 역할·근거, 대기·계수, 시간·발동, 기동·운전·문서를 포함한다. 각 ID에 충족한 성질, 증거 판본, 구체적 남김과 판정이 있다. 목록 존재·설명·형식 검사만으로 의미 검증을 대신하지 않는다. 원문에 없는 무한 입력 공간의 무결함 증명을 새 종료조건으로 만들지 않는다.

### G2 기존 개선과 기대값 보존

원래 K ID의 보존 성질 61개와 원래 P2 12개 ID를 각각 현행 근거에 연결한다. K ID는 K-01~K-78 안의 비연속 집합이며 sources/requirements-index.json의 preservation 모집단을 따른다. 과거 원문의 timeout 등 폐기된 수단은 최신 사용자 지시와 현재 계약으로 처리한다. 기존 변경 재검토는 실제 diff·현재 소비자·원보고를 사용해 유지/교정/제거/추가 판정 필요를 결정한다. B01~B109를 25영역에 매핑했다는 사실은 검토 완료가 아니다. 결함 동작을 정상 기대값으로 남기지 않는다.

### G3 검증 방식의 실질

실제 제품 코드를 대역으로 가리는 시험, 현재와 다른 fixture, 속도 때문에 약해진 단언, 실제 최종 반환을 증명하지 못하는 문서용 AST 추정 등을 해소한다. 부류·등록·일반 검사가 현재 구성원을 실제로 검사하며 누락을 실패로 드러내는지 확인한다. 구현 방식의 복잡성과 실익을 검토하고 불필요한 장치를 늘리지 않는다. 의미 검토와 최종 실행 대기를 구분한다.

### G4 최종 판본 전체 일반 검사

최종 제품·시험 판본에서 공식 run_tests.py의 기본 전체 선택을 완결한다. 선택과 실제 결과가 전건 대응하고 실패·오류·미실행이 없어야 한다. 조건부 환경 건너뜀은 원문 계약상 정당성을 별도 판정하고 통과로 세지 않는다. 실행 전후 소스 해시와 종료 상태를 보존한다. B129의 실패 보고와 이후 부분 수리를 더해 전체 성공으로 만들지 않는다.

### G5 재사용 없는 최종 T3

최종 판본의 --tier T3 --full 실행으로 측정 누락 없는 분기 합집합과 함수 진입/선택 색인을 확보한다. 미도달은 실제 누락을 수리하거나 원문상 정당한 제외의 근거를 검토한다. 과거 수치·증분 캐시·부분 선택을 fresh 전체 증거로 대체하지 않는다.

### G6 대상 함수 전체의 극단 변이와 정상 기준

현재 대상 함수·변이 종류·선택 시험·정상 기준의 모집단을 실제 코드와 T3 자료로 확정한다. 기존 17개 파일 분할은 실행 준비의 출발점이며 고정된 함수 수가 아니다. 정상 기준 통과와 각 변이의 실제 결과를 대응시킨다. 시간 초과·측정 부재·환경 실패를 변이 포착으로 세지 않으며 생존·미실행을 숨기지 않는다.

### G7 실제 경계와 말뭉치

T4의 실제 구현 계약, T5의 최소 공급자 실호출 및 Job·Lean/Mathlib·예약·학술 도구 등 요구된 실제 연쇄를 현재 환경에서 확인한다. 공급자별 최소 호출을 실제 녹화와 함께 사용하고 판본·조건·실패·파싱 결과를 보존한다. --version 성공이나 합성 출력을 모델 호출 성공으로 세지 않는다. 필요한 외부 조건이 없으면 해당 기준은 미충족이며 정확히 상신한다.

### G8 최종 검토와 인도 일치

G1~G7의 증거를 대상으로 제품 수정 없는 최종 review phase를 수행한다. 모든 기준의 근거, 이전 발견의 처분, 실제 연결, 남김을 대조한다. 검증한 제품·시험·제품 문서와 main·미러·지침이 일치한다. review 후 그 내용을 바꾸면 필요한 work와 review를 다시 배정한다. next:null은 이 전체 완료에만 사용하며 중단·문제 은폐에 사용하지 않는다. push는 하지 않는다.
