"""Record static scope/edition checks and the two preserved official runs."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import sys

HOME = Path(__file__).resolve().parents[1]
WORKSPACE = HOME / 'workspace'
EVIDENCE = HOME / 'evidence'
sys.path.insert(0, 'C:/math/services/async-development')
from workspaces import changes


def save(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


_, delta = changes(HOME.parents[1], HOME.name)
expected = {
    runtime + '/skills/do-math/scripts/' + rel
    for runtime in ('.claude', '.agents')
    for rel in ('do_math/provider_final.py', 'tests/structure/test_schema_builders.py', '이음새-정본.md')
}
assert set(delta) == expected, delta
save('source-delta.json', {path: {'base_sha256': old, 'final_sha256': new}
                           for path, (old, new) in sorted(delta.items())})
diff = []
for path in sorted(delta):
    diff.extend(difflib.unified_diff((HOME / 'base' / path).read_text(encoding='utf-8').splitlines(True),
                                   (WORKSPACE / path).read_text(encoding='utf-8').splitlines(True),
                                   fromfile='base/' + path, tofile='workspace/' + path))
(EVIDENCE / 'source.diff').write_text(''.join(diff), encoding='utf-8')

prefix = Path('.claude/skills/do-math/scripts')
provider_rel = prefix / 'do_math/provider_final.py'
test_rel = prefix / 'tests/structure/test_schema_builders.py'
old_provider = ast.parse((HOME / 'base' / provider_rel).read_text(encoding='utf-8'))
new_provider = ast.parse((WORKSPACE / provider_rel).read_text(encoding='utf-8'))
old_function = next(node for node in old_provider.body if isinstance(node, ast.FunctionDef) and node.name == 'output_contract')
new_function = next(node for node in new_provider.body if isinstance(node, ast.FunctionDef) and node.name == 'output_contract')
assert ast.dump(old_function.body[1]) == ast.dump(new_function.body[1]), 'Codex branch changed'
assert ast.dump(old_function.body[-1]) == ast.dump(new_function.body[-1]), 'Unsupported-provider rejection changed'
old_tests = ast.parse((HOME / 'base' / test_rel).read_text(encoding='utf-8'))
new_tests = ast.parse((WORKSPACE / test_rel).read_text(encoding='utf-8'))
old_definitions = {node.name: ast.dump(node) for node in old_tests.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
new_definitions = {node.name: ast.dump(node) for node in new_tests.body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
preserved_definitions = [name for name in old_definitions if name not in ('_composition_calls', 'SchemaBuilderTests')]
assert all(old_definitions[name] == new_definitions[name] for name in preserved_definitions)
old_class = next(node for node in old_tests.body if isinstance(node, ast.ClassDef) and node.name == 'SchemaBuilderTests')
new_class = next(node for node in new_tests.body if isinstance(node, ast.ClassDef) and node.name == 'SchemaBuilderTests')
old_methods = {node.name: ast.dump(node) for node in old_class.body if isinstance(node, ast.FunctionDef)}
new_methods = {node.name: ast.dump(node) for node in new_class.body if isinstance(node, ast.FunctionDef)}
assert all(old_methods[name] == new_methods[name] for name in old_methods)
mirror_rows = []
for relative in ('do_math/provider_final.py', 'tests/structure/test_schema_builders.py', '이음새-정본.md'):
    source = WORKSPACE / prefix / relative
    mirror = WORKSPACE / '.agents/skills/do-math/scripts' / relative
    assert source.read_bytes() == mirror.read_bytes()
    mirror_rows.append({'relative_path': relative, 'source_and_mirror_sha256': digest(source)})
save('static-checks.json', {
    'codex_branch_ast_unchanged': True,
    'unsupported_provider_raise_ast_unchanged': True,
    'preserved_test_definitions': preserved_definitions,
    'all_prior_SchemaBuilderTests_methods_ast_unchanged': sorted(old_methods),
    'mirror_byte_equality': mirror_rows,
    'mirror_generation': {'exit': 0, 'created': 0, 'updated': 3, 'deleted': 0, 'total': 1336},
    'mirror_check_exit': int((EVIDENCE / 'mirror-check-exit.txt').read_text()),
    'consumer_scope': 'ModelRunner.run calls output_contract only for unbound Codex; Claude serializes output_schema directly. semantic_output calls it to validate the Codex envelope. No consumer was changed.'
})

runs = []
for name in ('red', 'green'):
    report = json.loads((EVIDENCE / name / 'report.json').read_text(encoding='utf-8'))
    rows = [row for group in report['reports'] for row in group['rows']]
    assert sorted(report['selected']) == sorted(row['id'] for row in rows)
    assert len({row['id'] for row in rows}) == len(rows)
    assert not report['changed_during_run']
    mismatches = []
    if name == 'green':
        for relative, sha in report['source_sha256'].items():
            if digest(WORKSPACE / prefix / relative) != sha:
                mismatches.append(relative)
        assert not mismatches
        assert report['complete'] and report['successful'] and report['counts'] == {'passed': 12}
    else:
        assert report['complete'] and not report['successful'] and report['counts'] == {'failed': 1}
        detail = '\n'.join(rows[0]['details'])
        assert 'output_contract' in detail and 'a node appears twice in one result' in detail
    runs.append({
        'run': name,
        'command': 'python -u -B .claude/skills/do-math/scripts/run_tests.py ' +
                   ('structure.test_schema_builders.SchemaBuilderTests.test_unnamed_schema_composition_results_detach_every_mutable_node' if name == 'red' else 'structure.test_schema_builders') +
                   ' --jobs 1 --output C:/dm-r07fix-' + name,
        'report': name + '/report.json', 'report_sha256': digest(EVIDENCE / name / 'report.json'),
        'complete': report['complete'], 'successful': report['successful'], 'counts': report['counts'],
        'selected': report['selected'], 'actual_rows': rows, 'changed_during_run': report['changed_during_run'],
        'source_sha256_count': len(report['source_sha256']),
        'provider_final_sha256': report['source_sha256']['do_math/provider_final.py'],
        'test_schema_builders_sha256': report['source_sha256']['tests/structure/test_schema_builders.py'],
        'exit': int((EVIDENCE / 'green-exit.txt').read_text()) if name == 'green' else None,
        'exit_limit': None if name == 'green' else 'The terminal call yielded; its session ID/parent exit was not retained by the orchestration. The complete official failed report and exact assertion were preserved. No retry was needed to establish the defect.',
        'final_source_mismatches': mismatches if name == 'green' else None,
    })
save('verification.json', runs)

report = {
    'status': 'complete',
    'summary': 'R07 F1/F2를 수리했다. output_contract의 Codex/Claude 두 분기와 shared-leaf schema를 기존 _composition_calls 반복 ID 격리 검사에 등록하고 Claude deepcopy를 정본 values.json_copy로 교체했다. 값 보존·입력 격리를 확인하는 직접 단언, 이음새-정본 5절 설명과 공식 생성 미러를 함께 반영했다. Codex 전송 봉투·미지원 provider 반려 및 기존 빌더/transformer/borrowed 처분은 유지했다. 최종 제품 변경은 정본3·미러3파일이며 비용 캐시는 근거 보존 후 자기 base 원바이트로 복원했다.',
    'changes': sorted(delta),
    'verification': '공식 run_tests.py jobs1로 등록 후 수리 전 최소 ID를 한 번 실행해 complete=true, failed=1을 확인했다. 두 실패 관찰은 output_contract Claude 변형(index1)의 repeat0/1에서 a node appears twice in one result였고 import/fixture 오류가 아니었다. red parent exit는 도구 호출에서 회수하지 못했으며 evidence/verification.json에 그 한계를 명시했다. 수리 후 structure.test_schema_builders 한 모듈은 선택12·고유 실제row12 모두 passed, complete/successful=true, exit0, changed_during_run=[]였다. 공식 source_sha256 전건을 최종 workspace와 대조해 차이0이며 원보고를 evidence/red·green에 보존했다. 직접 시험은 Claude 값과 sibling/input/second 반환 불변, Codex 닫힌 output_json 봉투와 원 schema description 값을 확인했다. Codex 분기·미지원 provider raise와 기존 시험 메서드의 AST 불변, 세 정본/미러 byte 일치를 확인했고 생성기는 3파일만 갱신했다. --check --target .agents는 1336파일 drift0·exit0이다. provider 전반·미러 시험 재실행·실제 모델/Job/Lean/예약·전체 일반/T3/변이는 수행하지 않았다.',
    'findings': [
        '해결 F1 [G1/G3, R07/1-E]: tests/structure/test_schema_builders.py:_composition_calls가 output_contract의 두 provider에 shared-leaf schema를 제공한다. 기존 _isolation_problems는 각 변형을 두 번 호출하고 전역/이전 결과/결과 내부 노드 공유를 판정한다. 기존 schema-name 탐색의 범위는 그대로이며 명시 등록을 전체 모집단 자동발견으로 확대하지 않는다. 정확 전후 row·SHA는 evidence/verification.json에 있다.',
        '해결 F2 [G3, 이음새-정본 5절]: provider_final.py:output_contract의 Claude 반환을 values.json_copy로 바꾸어 반복 leaf를 분리했다. 실제 모듈 시험에서 left enum 변경 뒤 right·입력·다른 반환 불변 및 원 값 보존을 확인했다. 이는 결과 내부 격리 수리이며 원래 1-E의 전역/다른 반환 결함이나 Claude 실제 전송 실패를 관측한 것으로 해석하지 않는다. ModelRunner의 Codex 한정 호출은 그대로다.',
        '유지 [1-E/PR06 B22, 관련 K-51 slice]: 기존 _calls·_isolation_problems·_constant_object_calls·탐색·검사 자체 반례 및 모든 기존 SchemaBuilderTests 메서드 AST가 불변이다. transformer·borrowed repetition_outcome/recovery_outcome에 새 복사 의무를 부과하지 않았다. evidence/static-checks.json과 source.diff 참조. R07/1-E는 이 한정 수리 확인 후 최종 판본 증거 대기로 넘길 수 있다.',
        '남김 [G4~G8 및 다른 미결]: 최종 통합판 전체 일반/fresh T3/함수 전체 변이/실제 경계/최종 review는 별도 배정이다. L01 Q1/Q2·원문 UTF-8 byte, Windows1314 symlink 실반려 미검사 및 다른 요구/K/P2는 종결하지 않는다. 공용 통합·accepted·관리 마감은 manager가 맡는다. red의 미회수 parent exit는 성공으로 추정하지 않았고 해당 공식 실패 보고만 근거로 사용했다.'
    ]
}
(HOME / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': report['status'], 'changes': report['changes'], 'run_counts': [run['counts'] for run in runs]}, ensure_ascii=False))
