# R18/9-A native 파일 교체 검사 수리

배정한 F1 수리를 완료했다. 제품 delta는 `test_boundary_invariants.py` 정본과 공식 생성 미러 두 파일이다. runtime과 다른 task의 제품·공용 기록은 수정하지 않았다.

`_replacement_sites`가 기존 Python 교체 호출과 함께 실제 `SetFileInformationByHandle` 바인딩을 발견한다. 같은 함수의 직접 별칭과 tuple 반환의 해당 슬롯을 추적하고, 소비자의 tuple unpack에서 얻은 별칭 호출을 발견한다. 다른 모듈의 소비는 absolute from-import로 원 tuple 생산자에 연결한다. 함수 이름을 허용 목록에 넣거나 모든 `rename` 호출을 교체로 간주하지 않는다. `_sites`의 기존 제품 모집단은 유지하고, 같은 탐색에 메모리 AST를 전달할 수 있게 했다.

실제 source의 연결은 `native-path.json`에 있다. 현재 발견은 `file_io._replace_once`의 `os.replace`, `file_io._windows_files`의 native binding(53행), `file_io._replace_once`의 native call(87행)이다. 56행 tuple 반환과 71행 unpack을 연결했다. `shared_reader`는 같은 tuple을 받지만 create만 호출하므로 교체 소비로 발견되지 않는다.

수정 전 공식 red 실행은 새 단언 하나의 실제 실패(exit 1)다. 기대한 binding/call 두 항목에 대해 발견 결과가 빈 목록이었다. import·준비 오류가 아니며 red/report.json의 source 판본과 실패 자료를 보존했다. 이때 `_replacement_sites`는 기존 검사 조건을 그대로 추출했을 뿐이다.

수정 후 공식 green 실행은 `structure.test_boundary_invariants --jobs 1`이다. 기존 6 ID와 새 1 ID의 선택이 7개의 고유 passed row와 정확히 대응하고 complete/successful=true, exit 0, changed_during_run=[]이다. 새 시험은 현재 source에서 얻은 binding/consumer/reader AST를 사용한다. 반례에서는 non-Windows os.replace 분기를 제거하여 기존 검사에 잡히는 별도 호출이 native 누락을 가리지 않게 했다. 정상 owner는 수용되고 전체 native 구현 이동과 소비만 이동은 실제 inventory와 동일한 `_assert_file_io_replacements`에서 반려된다. 관계없는 모듈에 동일 rename/helper 이름과 tuple 형태가 있어도 발견되지 않는다. fixture-observations.json에 각 AST source, 기존 조건의 빈 발견값, 수리 후 site/위반 owner를 기록했다. 이 관찰은 실행 가능한 제품 파일이나 Windows API 호출이 아니다.

생성기는 `--target .agents`에서 생성0/갱신1/삭제0, exit 0이었다. 비용 캐시를 보존하고 base로 복원한 뒤 `--check --target .agents`는 드리프트 없음(1336파일), exit 0이었다. 모듈의 정본/미러 원바이트는 같다. 미러에서 동일 시험을 반복하지 않았다. 최종 scripts Python 875파일 해시가 green 보고의 소스 판본과 모두 같고 baseline 2681파일 및 새 파일 비교에서 제품 변경은 두 모듈뿐이다. red/green의 두 비용 캐시 원바이트는 evidence에 보존했으며 최종 workspace 캐시는 각각 자기 base와 같다. 상세 검증과 판본은 verification.json, 제품 diff는 product.diff다.

현재 직접 바인딩→tuple 반환→unpack과 absolute from-import 소비 이동만 다루는 유한 구조 검사다. 범용 Python 별칭/동적 우회 검증을 추가하지 않았다. 기존 process/Job/interpreter/normalization/stdlib 모집단·정확 단언을 유지했다. 새 실제 모델/Job/Lean/예약/네트워크/Windows 파일 교체 경계, 전체 일반/T3/변이/T4/T5는 실행하지 않았다. file_io runtime을 바꾸지 않았고 기존 storage_atomic_replace 4 ID 및 018의 실경계 근거는 과거 실행 범위로 유지한다.

manager는 F1 수리를 통합·수용하고 R18/9-A를 최종 통합 판본 증거 대기로 옮길 수 있다. PR02 전체·관련 K/P2 전체, G4~G8, L01 Q1/Q2·UTF-8 byte, Windows1314 symlink 실반려 미검사와 다른 의미 질문은 종결하지 않았다.
