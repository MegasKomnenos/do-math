from pathlib import Path
import ast
import difflib
import hashlib
import importlib.util
import json

workspace = Path.cwd()
task = workspace.parent
evidence = task / 'evidence'
relative = '.claude/skills/do-math/scripts/tests/structure/test_boundary_invariants.py'
module_path = workspace / relative
spec = importlib.util.spec_from_file_location('boundary_invariants', module_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(name, value):
    (evidence / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def observations(trees):
    return [{'relative': relative, 'function': function, 'kind': kind, 'line': node.lineno,
             'expression': ast.unparse(node)} for relative, function, kind, node in module._replacement_sites(trees)]

runtime_relative = 'do_math/file_io.py'
runtime_tree = ast.parse((module.SCRIPTS / runtime_relative).read_text(encoding='utf-8'))
functions = {node.name: node for node in runtime_tree.body if isinstance(node, ast.FunctionDef)}
write_json('native-path.json', {
    'method': 'Pure AST observation of the current workspace file_io source; no WinAPI invocation.',
    'runtime_sha256': digest(module.SCRIPTS / runtime_relative),
    'sites': observations([(runtime_relative, runtime_tree)]),
    'tuple_return': [ast.unparse(node) for node in ast.walk(functions['_windows_files']) if isinstance(node, ast.Return)],
    'tuple_consumption': [ast.unparse(node) for node in ast.walk(functions['_replace_once'])
                          if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call)
                          and isinstance(node.value.func, ast.Name) and node.value.func.id == '_windows_files'],
    'ignored_reader': 'shared_reader unpacks the native slot into _ and only calls create; no replacement call discovered there.',
})

binding = functions['_windows_files']
consumer = ast.parse(ast.unparse(functions['_replace_once'])).body[0]
consumer.body = [statement for statement in consumer.body
                 if not any(isinstance(node, ast.Call) and module._is(node.func, 'os', {'replace'})
                            for node in ast.walk(statement))]
reader = functions['shared_reader']
def tree(*nodes):
    return ast.Module(body=list(nodes), type_ignores=[])
owner, other = runtime_relative, 'do_math/relocated_file_boundary.py'
unrelated = ast.parse('''
def rename(handle, kind, buffer, size):
    return None
def _windows_files():
    return None, None, None, rename
def unrelated_call(handle, buffer, size):
    create, close, invalid, rename = _windows_files()
    return rename(handle, 22, buffer, size)
''')
cases = {
    'current': [(owner, tree(binding, consumer, reader)), (other, unrelated)],
    'both relocated': [(other, tree(binding, consumer, reader))],
    'consumer relocated': [(owner, tree(binding, reader)),
                           (other, tree(ast.parse('from do_math.file_io import _windows_files').body[0], consumer))],
}
fixture_evidence = {}
for label, trees in cases.items():
    old = [{'relative': relative, 'function': function, 'line': node.lineno}
           for relative, function, node in module._sites(trees)
           if isinstance(node, ast.Call) and (module._is(node.func, 'os', {'replace'}) or module._is(node.func, 'shutil', {'move'}))]
    current = observations(trees)
    fixture_evidence[label] = {'ast_sources': {relative: ast.unparse(source) for relative, source in trees},
                               'previous_predicate_sites': old, 'repaired_sites': current,
                               'outside_file_io': sorted({row['relative'] for row in current if row['relative'] != owner})}
write_json('fixture-observations.json', {
    'method': 'Static observations through the same _sites/_replacement_sites as the official tests.',
    'fixture_scope': 'Actual native binding/consumer/reader AST, omitting only the non-Windows os.replace branch; no fixture files are product files.',
    'owner_assertion': 'BoundaryInvariantTests._assert_file_io_replacements is shared by product inventory and relocation cases in the official run.',
    'cases': fixture_evidence,
})

baseline = json.loads((task / 'baseline.json').read_text(encoding='utf-8-sig'))
changes = [path for path, value in baseline.items() if not (workspace / path).is_file() or digest(workspace / path) != value]
new_files = [path.relative_to(workspace).as_posix() for path in workspace.rglob('*')
             if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc'
             and path.relative_to(workspace).as_posix() not in baseline]
expected = [relative, relative.replace('.claude/', '.agents/', 1)]
assert sorted(changes) == sorted(expected), changes
assert not new_files, new_files
assert (workspace / expected[0]).read_bytes() == (workspace / expected[1]).read_bytes()

red = json.loads((evidence / 'red/report.json').read_text(encoding='utf-8-sig'))
green = json.loads((evidence / 'green/report.json').read_text(encoding='utf-8-sig'))
rows = [row for group in green['reports'] for row in group['rows']]
assert green['complete'] and green['successful'] and green['counts'] == {'passed': 7}
assert len(rows) == 7 and len({row['id'] for row in rows}) == 7
assert set(green['selected']) == {row['id'] for row in rows}
assert all(row['outcome'] == 'passed' for row in rows)
assert green['changed_during_run'] == []
mismatches = [path for path, sha in green['source_sha256'].items() if digest(module.SCRIPTS / path) != sha]
assert not mismatches, mismatches
cache_checks = {runtime: {'sha256': digest(workspace / f'{runtime}/skills/do-math/scripts/tests/.timings.json'),
                         'matches_base': (workspace / f'{runtime}/skills/do-math/scripts/tests/.timings.json').read_bytes()
                         == (task / 'base' / f'{runtime}/skills/do-math/scripts/tests/.timings.json').read_bytes()}
                for runtime in ('.claude', '.agents')}
assert all(row['matches_base'] for row in cache_checks.values())
write_json('verification.json', {
    'red': {'report': 'red/report.json', 'exit': 1, 'selected': red['selected'], 'counts': red['counts'],
            'complete': red['complete'], 'changed_during_run': red['changed_during_run'],
            'reason': 'Native expected binding/call list was empty under the unchanged os.replace/shutil.move predicate; genuine assertion failure, not preparation/import error.'},
    'green': {'report': 'green/report.json', 'exit': 0, 'selected': green['selected'], 'rows': rows,
              'counts': green['counts'], 'complete': green['complete'], 'successful': green['successful'],
              'changed_during_run': green['changed_during_run'], 'python_source_hashes_checked': len(green['source_sha256']),
              'final_python_source_hash_mismatches': mismatches},
    'mirror': {'build_exit': 0, 'build_created': 0, 'build_updated': 1, 'build_deleted': 0,
               'check_exit': 0, 'check_files': 1336, 'test_module_bytes_equal': True,
               'scope': 'Generated with build_skill_mirrors.py --target .agents; --check after cache restore; no mirrored test rerun.'},
    'baseline_files_checked': len(baseline), 'changes': changes, 'new_product_files': new_files,
    'final_source_sha256': {path: digest(workspace / path) for path in expected},
    'cost_caches': cache_checks,
    'limits': 'One structure module only. No fresh Windows runtime, model, Job, Lean, scheduler, network, whole general/T3/mutation/T4/T5 execution. Historical runtime evidence remains historical.'
})
(evidence / 'product.diff').write_text(''.join(difflib.unified_diff(
    (task / 'base' / relative).read_text(encoding='utf-8').splitlines(keepends=True),
    module_path.read_text(encoding='utf-8').splitlines(keepends=True),
    fromfile='base/' + relative, tofile='workspace/' + relative)), encoding='utf-8')
report = {
    'status': 'complete',
    'summary': 'R18/9-A F1의 Windows native 파일 교체 소유권 검사 공백을 수리했다. 기존 os.replace/shutil.move 검사에 실제 SetFileInformationByHandle 바인딩, 직접 별칭과 tuple 반환/소비의 호출 추적을 더했다. 현재 _windows_files의 바인딩과 _replace_once의 소비를 모두 발견하며 같은 소유 판정으로 전체 구현 이동과 소비만 이동한 AST 반례를 반려한다. 일반 reader와 관계없는 rename/helper 이름을 오인하지 않는다. 설명은 모듈에 반영하고 공식 생성기로 미러를 생성했다. runtime은 변경하지 않았다.',
    'changes': changes,
    'verification': 'workspace의 공식 run_tests.py --jobs 1로 수정 전 새 단언 1개가 native 발견값 [] 때문에 failed, exit 1임을 확인했다(evidence/red/report.json). 수정 후 structure.test_boundary_invariants의 기존 6 ID+새 1 ID가 7선택/7고유 실제 passed row, complete/successful true, exit 0이며 changed_during_run=[]다(evidence/green/report.json). 최종 scripts Python 875파일 해시가 green 판본과 전부 같다. _sites/_replacement_sites의 실제 source 연결과 순수 AST 3경우를 native-path.json/fixture-observations.json에 기록했다. 미러 생성 exit 0(갱신1), --check exit 0(1336파일), 해당 모듈 원바이트 동일을 확인했다. 두 비용 캐시는 red/green evidence에 보존하고 자기 base로 복원했다. baseline 2681파일 비교 및 새 파일 검사에서 실제 제품 delta는 정본/미러 2파일이다. Windows 실경계 및 전체 관문은 실행하지 않았다.',
    'findings': [
        'R18 F1은 이 workspace에서 수리·관련 확인 완료이며 R18/9-A의 최종 통합 판본 증거 대기로 옮길 근거가 있다. native-path.json은 실제 file_io._windows_files 바인딩/tuple 반환과 _replace_once tuple 소비/호출을 연결하고 fixture-observations.json은 native만 있는 이동 반례의 기존 조건 누락과 수리 후 발견을 기록한다. manager가 통합·accepted를 판단한다.',
        '탐색 범위는 현재 직접 native 바인딩→tuple 반환→tuple unpack 및 소비 이동의 absolute from-import다. 범용 Python 별칭/동적 우회 분석은 수행하지 않았다. 기존 process/Job/interpreter/normalization/stdlib 모집단·정확 단언을 유지했고 기존 6 ID가 green에서 passed다.',
        'file_io.py와 boundary/test_storage_atomic_replace.py 및 다른 runtime/helper/정본 문서는 변경하지 않았다. 기존 Windows 실경계 4 ID/018 원보고의 성질을 이번 새 실행으로 보고하지 않는다. PR02 전체·관련 K/P2 전체·G4~G8·L01 Q1/Q2/UTF-8 byte·Windows1314 symlink 실반려 미검사 및 다른 의미 질문은 남는다.'
    ]
}
(task / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'changes': changes, 'green_passed': len(rows), 'source_hashes_checked': len(green['source_sha256']), 'cache_matches_base': True}, ensure_ascii=False))
