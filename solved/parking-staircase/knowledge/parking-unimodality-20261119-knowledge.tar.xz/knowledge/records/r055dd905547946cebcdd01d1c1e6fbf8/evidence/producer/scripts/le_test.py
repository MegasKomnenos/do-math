# 추측 시험: 머묾 흐름 J_n(y)=Pr(M_{n+1}<=y)-Pr(M_n<=y-1) 대 Euler 상계 ((n+1-y)/(n+1)) Pr(M_n=y) 의 비.
# 정확한 정수 표 (마지막 차 재귀), n<=NMAX.
import sys
from fractions import Fraction
from math import comb
NMAX = int(sys.argv[1]) if len(sys.argv)>1 else 60
# A[n][l] = #PF 길이 n, 최대 변위 <= l  (l=-1..n-1)
A = [[1]*(NMAX+2) for _ in range(NMAX+2)]  # A[n][l+1]
def getA(n,l):
    if n==0: return 1
    if l<0: return 0
    if l>=n-1: return (n+1)**(n-1)
    return T[n][l]
T = [dict() for _ in range(NMAX+2)]
for l in range(0, NMAX+1):
    # column: A_{n,l} for n=1..NMAX+1 via last-car recursion
    col = [1]
    for n in range(1, NMAX+2):
        s = 0
        for sidx in range(1, n+1):
            s += comb(n-1, sidx-1)*min(sidx, l+1)*col[sidx-1]*col[n-sidx]
        col.append(s)
        T[n][l] = s
mn = None; arg=None
mn_sc=None; arg_sc=None
rows=[]
for n in range(2, NMAX+1):
    pn = (n+1)**(n-1); pn1=(n+2)**n
    for y in range(1, n):
        cell = Fraction(getA(n,y)-getA(n,y-1), pn)
        J = Fraction(getA(n+1,y), pn1) - Fraction(getA(n,y-1), pn)
        eul = Fraction(n+1-y, n+1)*cell
        ratio = J/eul
        if mn is None or ratio<mn: mn=ratio; arg=(n,y)
        if n<=2*y+1:
            if mn_sc is None or ratio<mn_sc: mn_sc=ratio; arg_sc=(n,y)
        rows.append((n,y,float(ratio)))
print('min ratio overall', float(mn), arg)
print('min ratio single-chain (n<=2y+1)', float(mn_sc), arg_sc)
# 행 NMAX의 비를 결손별로
n=NMAX
print('row n=%d: ratio by y:'%n)
print(' '.join('%d:%.3f'%(y,r) for (nn,y,r) in rows if nn==n))
