# Check of Proposition 3.15 (growth-ratio lower bound; lower Euler inequality in the deep cells).
#  y >= 1, Y = y+1, alpha_n = A_{n,y}/n!, r = psi(Y) = (1+1/Y)^(Y-1), eps_1 = 1, eps_i = (i-1)^(i-1)/i!,
#  G_Y = sum_{i=1}^{Y} eps_i r^{-(i-1)}.
#  (a) alpha_N >= G_Y alpha_{N-1} for N >= Y                       [exact, y <= YMAX, N <= NMAX]
#      ingredients: 1/sum alpha_n x^n = 1 - sum kappa_i x^i with kappa_i >= 0, kappa_i = eps_i for i <= Y; alpha_{n+1} <= r alpha_n
#  (b) if F_n(y-1) <= (2 G_Y/e - 1) F_n(y) then (LE) holds at (n,y)   [exact: every cell of the table satisfying the hypothesis is checked]
#  (c) G_Y >= 7/5 for Y >= 3: exact values for 3 <= Y <= 7 and the bound sum_{i<=8} eps_i e^{-(i-1)} > 1.44 for Y >= 8
#  (d) observation (double precision, N <= NF): the first n from which F_n(y-1)/F_n(y) <= 2 G_Y/e - 1 holds up to NF,
#      next to the first N at which the first-tree source of Proposition 3.14 is negative (from peer_le_source_sign.out)
import sys, math
from math import comb, factorial
from fractions import Fraction as Fr
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 60
YMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 10
NF = int(sys.argv[3]) if len(sys.argv) > 3 else 300
binom = [[comb(n, j) for j in range(n + 1)] for n in range(NMAX + 2)]
def column(c):
    A = [1]
    for n in range(1, NMAX + 1):
        bn = binom[n - 1]
        A.append(sum(bn[j] * min(j + 1, c) * A[j] * A[n - 1 - j] for j in range(n)))
    return A
eps = lambda i: Fr(1) if i == 1 else Fr((i - 1) ** (i - 1), factorial(i))
def G(Y):
    r = Fr(Y + 1, Y) ** (Y - 1)
    return sum(eps(i) / r ** (i - 1) for i in range(1, Y + 1))
p = [1] + [(n + 1) ** (n - 1) for n in range(1, NMAX + 1)]
elo, ehi = Fr(271828, 100000), Fr(271829, 100000)
cols = {c: column(c) for c in range(1, YMAX + 3)}
na = nb = 0; hyp_cells = 0
for y in range(1, YMAX + 1):
    Y = y + 1
    al = [Fr(cols[Y][n], factorial(n)) for n in range(NMAX + 1)]
    be = [Fr(cols[y][n], factorial(n)) for n in range(NMAX + 1)]
    r = Fr(Y + 1, Y) ** (Y - 1); g = G(Y)
    # ingredients
    kap = [Fr(0)] * (NMAX + 1)
    for n in range(1, NMAX + 1):
        kap[n] = al[n] - sum(kap[i] * al[n - i] for i in range(1, n))
    assert all(kap[i] >= 0 for i in range(1, NMAX + 1)) and all(kap[i] == eps(i) for i in range(1, Y + 1))
    assert all(al[n + 1] <= r * al[n] for n in range(NMAX))
    for N in range(Y, NMAX + 1):
        assert al[N] >= g * al[N - 1]; na += 1                                  # (a)
    w = 2 * g / ehi - 1                                                         # a lower bound for 2G/e - 1
    for n in range(y, NMAX):
        Fy = Fr(cols[Y][n], p[n]); Fy1 = Fr(cols[y][n], p[n])
        if Fy1 <= w * Fy:
            hyp_cells += 1
            lhs = Fr(cols[Y][n + 1], p[n + 1]) - Fy1
            assert lhs >= Fr(1, 2) * Fr(n + 1 - y, n + 1) * (Fy - Fy1); nb += 1  # (b)
print("exact: (a) alpha_N >= G_Y alpha_{N-1} in %d cells (y <= %d, Y <= N <= %d); (b) %d cells satisfy the hypothesis and (LE) holds in all of them" % (na, YMAX, NMAX, nb))
# (c)
for Y in range(3, 8):
    assert G(Y) >= Fr(7, 5)
s8 = sum(eps(i) / elo ** (i - 1) for i in range(1, 9))                           # sum_{i<=8} eps_i e^{-(i-1)} <= this; need a lower bound: use ehi
s8lo = sum(eps(i) / ehi ** (i - 1) for i in range(1, 9))
assert s8lo > Fr(144, 100)
print("G_Y for Y = 2..8: " + ", ".join("%.4f" % float(G(Y)) for Y in range(2, 9)) + " ; sum_{i<=8} eps_i e^{-(i-1)} > %.4f ; e - 1 = %.4f" % (float(s8lo), math.e - 1))
print("2 G_Y/e - 1 for y = 1..8: " + ", ".join("%+.4f" % (2 * float(G(y + 1)) / math.e - 1) for y in range(1, 9)))
# (d) floats
import numpy as np
lg = [math.lgamma(i + 1) for i in range(NF + 3)]
lp = [0.0] + [(n - 1) * math.log(n + 1) for n in range(1, NF + 2)]
def colf(th):
    b = np.zeros(NF + 1); b[0] = 1.0
    w_ = np.minimum(np.arange(1, NF + 2), th).astype(float)
    for n in range(1, NF + 1):
        b[n] = math.exp(-1) * np.dot(w_[:n] * b[:n], b[n - 1::-1][:n]) / n
    return b
def Gf(Y):
    r = (1 + 1.0 / Y) ** (Y - 1); s = 1.0; t = 1.0
    for i in range(2, Y + 1):
        t = math.exp((i - 1) * math.log(i - 1) - math.lgamma(i + 1) - (i - 1) * math.log(r)); s += t
    return s
print("y | 2G_Y/e - 1 | first n with F_m(y-1)/F_m(y) <= 2G_Y/e - 1 for all n <= m <= %d | ratio at n = %d" % (NF, NF))
for y in [2, 3, 4, 5, 6, 8, 10, 15, 20, 30]:
    a = colf(y + 1); b = colf(y)
    w = 2 * Gf(y + 1) / math.e - 1
    ratio = b / a
    ok = None
    for n in range(NF, y - 1, -1):
        if ratio[n] <= w: ok = n
        else: break
    print("%3d | %.4f | %s | %.4f" % (y, w, ok, ratio[NF]))
