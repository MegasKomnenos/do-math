# Tree-level diagonal lower bound:  y_{t,k} >= gamma_k * t * y_{t-1,k-1} ?  (y = tree row; gamma_k=(1+1/k)^(k-2))
from pf import *
def y(t, l):
    if l < 0 or l > t - 1: return 0
    return (l + 1) * A(t - 1, l) - l * A(t - 1, l - 1)
NMAX = 70
viol = []; mn = None
for k in range(2, 36):
    g = Fr(k + 1, k) ** (k - 2)
    for t in range(k + 1, NMAX + 1):
        lhs = y(t, k); rhs = g * t * y(t - 1, k - 1)
        if rhs == 0: continue
        r = Fr(lhs) / rhs
        if lhs < rhs: viol.append((k, t, float(r)))
        if t > k + 1 and (mn is None or r < mn[0]): mn = (r, k, t)
print("violations:", len(viol), viol[:20])
print("min ratio (t>k+1): %.6f at (k,t)=%s" % (float(mn[0]), mn[1:]))
# also forest-level Dg for comparison
mn2 = None
for k in range(2, 36):
    g = Fr(k + 1, k) ** (k - 2)
    for n in range(k + 2, NMAX + 1):
        r = Fr(b(n, k)) / (g * n * b(n - 1, k - 1))
        if mn2 is None or r < mn2[0]: mn2 = (r, k, n)
print("forest Dg min ratio (n>k+1): %.6f at %s" % (float(mn2[0]), mn2[1:]))
