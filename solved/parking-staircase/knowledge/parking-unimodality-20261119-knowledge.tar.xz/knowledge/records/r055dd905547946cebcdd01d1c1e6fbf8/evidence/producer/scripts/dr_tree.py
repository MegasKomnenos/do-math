# (DR)의 나무 수준 꼴 (대각 기울임 x = (k/(k+1))^{k-2}).
#  나무 칸: p_t(y) = Pr(크기 t의 나무의 수준이 꼭 y) = (1/t)[F_{t-1}(y) + y P_{t-1}(y)]   (F_n(l)=Pr(M_n<=l), P_n(l)=Pr(M_n=l))
#  xi_t(y) = x w_{t-1} p_t(y)   (기울인 나무 칸; w_j = x^j (j+1)^{j-1}/j!)
#  첫 층: V_n = sum_t w_{n-t} xi_t(k) (n<=2k+1),  U_n = sum_t w_{n-t} xi_t(k-1) (n<=2k-1)
#  나무의 대각 초과: DT_t = xi_t(k) - xi_{t-1}(k-1);  Delta_n = V_n - U_{n-1} = sum_t w_{n-t} DT_t  (n<=2k)
#  sum_{n=k+1}^{2k} Delta_n = sum_t W(2k-t) DT_t,  W(m) = sum_{i<=m} w_i
# 조각의 크기와 부호를 본다. 단위 u0 = x w_{k-1}/k.
import sys
from mpmath import mp, mpf
mp.dps = 50

def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a

for k in [int(a) for a in sys.argv[1:]]:
    T = 2*k; nmax = T+2
    aP = col(k+1, nmax); a0 = col(k, nmax); aM = col(k-1, nmax); cay = col(10**9, nmax)
    x = (mpf(k)/(k+1))**(k-2)
    w = [x**j*cay[j] for j in range(nmax+1)]
    F = lambda a, n: a[n]/cay[n]
    # forest: F_n(k) = aP, F_n(k-1) = a0, F_n(k-2) = aM
    def p(t, lev):      # tree cell at level lev in {k-1, k}
        n = t-1
        if lev == k:   Fl = F(aP, n); Pl = F(aP, n) - F(a0, n)
        else:          Fl = F(a0, n); Pl = F(a0, n) - F(aM, n)
        return (Fl + lev*Pl)/t if t >= lev+1 else mpf(0)
    xi = {(t, lev): x*w[t-1]*p(t, lev) for t in range(1, nmax+1) for lev in (k-1, k)}
    U = [w[j]*(F(a0, j)-F(aM, j)) for j in range(nmax+1)]
    V = [w[j]*(F(aP, j)-F(a0, j)) for j in range(nmax+1)]
    u0 = x*w[k-1]/k
    W = [mpf(0)]*(nmax+1); s = mpf(0)
    for i in range(nmax+1):
        s += w[i]; W[i] = s
    # 대조: V_n, U_n 의 합성곱 꼴
    errV = max(abs(V[n] - sum(w[n-t]*xi[(t, k)] for t in range(k+1, n+1))) for n in range(k+1, T+1))
    errU = max(abs(U[n] - sum(w[n-t]*xi[(t, k-1)] for t in range(k, n+1))) for n in range(k, T))
    DT = {t: xi[(t, k)] - xi[(t-1, k-1)] for t in range(k+1, T+1)}
    sumDelta = sum(V[n]-U[n-1] for n in range(k+1, T+1))
    treeSum = sum(W[T-t]*DT[t] for t in range(k+1, T+1))
    negs = [t-k for t in range(k+1, T+1) if DT[t] < 0]
    # 조각: k*DT_t/(x w_{t-2}) = [(k+1)p_t(k) - k p_{t-1}(k-1)] + k(rho_t-(k+1)/k) p_t(k)
    main = mpf(0); slack = mpf(0); mainW1 = mpf(0); dneg = []
    for t in range(k+1, T+1):
        lam = W[T-t]*w[t-2]/w[k-1]
        dT = (k+1)*p(t, k) - k*p(t-1, k-1)
        rho = w[t-1]/w[t-2]
        main += lam*dT; mainW1 += dT
        slack += lam*k*(rho - mpf(k+1)/k)*p(t, k)
        if dT < 0: dneg.append(t-k)
    lam_list = [W[T-t]*w[t-2]/w[k-1] for t in range(k+1, T+1)]
    print('k=%d: conv check errV=%.1e errU=%.1e | sumDelta/u0=%.4f tree form/u0=%.4f | U_2k/u0=%.4f U_{2k-1}/u0=%.4f | W(k-1)=%.4f'
          % (k, float(errV), float(errU), float(sumDelta/u0), float(treeSum/u0), float(U[T]/u0), float(U[T-1]/u0), float(W[k-1])))
    print('     tree diagonal excess DT_t < 0 at x=t-k in %s%s ; (k+1)p_t(k)-k p_{t-1}(k-1) < 0 at %s%s'
          % (negs[:8], '...' if len(negs) > 8 else '', dneg[:8], '...' if len(dneg) > 8 else ''))
    print('     pieces/u0: sum lam*dT = %.4f (sum dT = %.4f, W(k-1)*sum dT = %.4f), tilt slack = %.4f, total = %.4f ; min lam = %.4f (at x=%d), lam_1 = %.4f, lam_k = %.4f'
          % (float(main), float(mainW1), float(W[k-1]*mainW1), float(slack), float(main+slack), float(min(lam_list)), lam_list.index(min(lam_list))+1, float(lam_list[0]), float(lam_list[-1])))
