# 항등식 (I_d):  x sigma_k(x) = k sum_{i=0}^{x-1} R_N(i+1) alpha_k(x-i),  R_N(b) = 1 - sum_{g<b} q_N(g),  N = k+x
# 과, 그것과 정리 A (sigma_{k-1}(x') >= sigma_k(x') - (x'/k) alpha_k(x'))를 원천에 넣은 하계
#   L_k(x) >= sum_{m=1}^{x-1} alpha_k(x-m) Ccoef(m),
#   Ccoef(m) = k sum_{g=1}^{m} C2(g) R_{N-g}(m-g+1) - C2(m) (x-m)^2/k + c1(m),   C2(g) = (N+k-2)/(2(k-1)) q_{N-1}(g)/(2k+x-g)
# 의 실제 크기와 계수의 부호를 본다. (논증의 걸음의 확인; 정확한 유리수는 작은 k, 그 밖은 50자리.)
import sys
from fractions import Fraction as Fr
from math import factorial
from mpmath import mp, mpf
mp.dps = 50

def run(k, xs, exact):
    num = (lambda a, b=1: Fr(a, b)) if exact else (lambda a, b=1: mpf(a)/b)
    X = max(xs); NMAX = k + X + 2
    def col(c, nmax):
        a = [num(1)]
        for n in range(1, nmax+1):
            s = num(0)
            for j in range(n):
                s += min(j+1, c) * a[j] * a[n-1-j]
            a.append(s/n)
        return a
    aK = col(k, NMAX); aKm = col(k-1, NMAX)
    cay = [num(1)] + [num((n+1)**(n-1), factorial(n)) if exact else mpf(n+1)**(n-1)/mp.factorial(n) for n in range(1, NMAX+1)]
    tau = [None] + [num(j**(j-1), factorial(j)) if exact else mpf(j)**(j-1)/mp.factorial(j) for j in range(1, NMAX+2)]
    def Pk(N):  return aK[N-1]/cay[N-1] if N-1 >= k else num(1)
    def Pkm(N): return aKm[N-1]/cay[N-1] if N-1 >= k-1 else num(1)
    ek = [num(0)] + [1 - num(k, k+y)*Pk(k+y) for y in range(1, X+2)]
    ekm = [num(0)] + [1 - num(k-1, k-1+y)*Pkm(k-1+y) for y in range(1, X+2)]
    al = [num(0)] + [ek[y]-ek[y-1] for y in range(1, X+2)]
    sgk = [num(1)] + [1-ek[y] for y in range(1, X+2)]
    sgm = [num(1)] + [1-ekm[y] for y in range(1, X+2)]
    def q(N, g): return tau[g]*tau[N-g]/tau[N]
    Rc = {}
    def R(N, b):        # R_N(b) = 1 - sum_{g<b} q_N(g)
        if (N, b) not in Rc:
            s = num(1); Rc[(N, 1)] = s
            for g in range(1, N):
                s = s - q(N, g); Rc[(N, g+1)] = s
        return Rc[(N, b)]
    for x in xs:
        N = k+x
        # (I_d)
        lhs = x*sgk[x]; rhs = k*sum(R(N, i+1)*al[x-i] for i in range(0, x))
        okid = (lhs == rhs) if exact else (abs(lhs-rhs) < mpf(10)**(-40))
        # 원천과 계수
        L = num(0); bound = num(0); negC = []
        C2 = {}; c1 = {}
        for g in range(1, x):
            qq = q(N-1, g)
            Gam = (N-1)*((1-R(N-1, g+1)) - (1-R(N, g+1)))
            c1[g] = Gam - qq*num(x + g*(k-1), 2*k+x-g)
            C2[g] = num(N+k-2, 2*(k-1))*qq/(2*k+x-g)
            L += c1[g]*al[x-g] + C2[g]*(x-g)*sgm[x-g]
        for m in range(1, x):
            Cm = k*sum(C2[g]*R(N-g, m-g+1) for g in range(1, m+1)) - C2[m]*num((x-m)**2, k) + c1[m]
            bound += al[x-m]*Cm
            if Cm < 0: negC.append(m)
        # 정확한 꼴: L = sum_m alpha_k(x-m) C(m) + (1/k) sum_g C2(g)(x-g) EE_k(x-g),  EE_k(y) = y alpha_k(y) - k nabla_k(y) >= 0 (정리 A)
        EEsum = sum(C2[g]*(x-g)*((x-g)*al[x-g] - k*(sgk[x-g]-sgm[x-g])) for g in range(1, x))/k
        okex = (L == bound + EEsum) if exact else (abs(L - bound - EEsum) < mpf(10)**(-40))
        # 보조정리 8과 (I_d)로 alpha_k(x-1)을 alpha_k(x-m) (m>=2)의 양의 결합으로 바꾼다 (x>=3):
        #   alpha_k(x-1) = sum_{m=2}^{x-1} alpha_k(x-m) E(m),  E(m) = [k kk_{N-1}(m-1) + (k/(x-2)) R_{N-2}(m-1)]/(N-1),
        #   kk_N(m) = Pi_N(m) - Pi_{N-1}(m-1)  (머묾 핵)
        Cm = {}
        for m in range(1, x):
            Cm[m] = k*sum(C2[g]*R(N-g, m-g+1) for g in range(1, m+1)) - C2[m]*num((x-m)**2, k) + c1[m]
        def kk(NN, m): return (1-R(NN, m+1)) - (1-R(NN-1, m))
        info = ''
        if x >= 3:
            E = {m: (k*kk(N-1, m-1) + num(k, x-2)*R(N-2, m-1))/(N-1) for m in range(2, x)}
            chkE = al[x-1] - sum(al[x-m]*E[m] for m in range(2, x))
            okE = (chkE == 0) if exact else (abs(chkE) < mpf(10)**(-40))
            D = {m: Cm[m] + Cm[1]*E[m] for m in range(2, x)}
            negD = [m for m in range(2, x) if D[m] < 0]
            info = ' | alpha(x-1) expansion %s; D(m)=C(m)+C(1)E(m)<0 at m in %s' % ('OK' if okE else 'FAIL', negD[:6])
            if negD and x >= 4:
                # 한 번 더: alpha_k(x-2) = sum_{m>=3} alpha_k(x-m) E2(m)
                E2 = {m: (k*kk(N-2, m-2) + num(k, x-3)*R(N-3, m-2))/(N-2) for m in range(3, x)}
                D2 = {m: D[m] + D[2]*E2[m] for m in range(3, x)}
                negD2 = [m for m in range(3, x) if D2[m] < 0]
                info += '; after second step negative at %s' % (negD2[:6],)
            mnr = min((D[m]/abs(Cm[m]) if Cm[m] != 0 else 9) for m in range(2, x))
            info += ' ; min D(m)/|C(m)| = %.3f' % float(mnr)
        print('k=%d x=%d: (I_d) %s exact-form %s | N*L=%.5f  N*sum(alpha C)=%.5f (ratio %.3f) | C(m)<0 at m in %s%s'
              % (k, x, 'OK' if okid else 'FAIL', 'OK' if okex else 'FAIL', float(L*N), float(bound*N), float(bound/L), (negC[:6] + ['...'] if len(negC) > 6 else negC), info))

run(7, list(range(2, 9)), True)
run(12, [2, 3, 5, 8, 13], True)
if len(sys.argv) > 1:
    for kk in sys.argv[1:]:
        kk = int(kk)
        xs = sorted(set([2, 3, 4, 5, 6, 8, 10, 15, 20] + [int(t*kk**(2.0/3)) for t in (0.5, 1, 1.5, 2, 3, 4)] + [kk//2, (3*kk)//4, kk, kk+1]))
        run(kk, [x for x in xs if 2 <= x <= kk+1], False)
