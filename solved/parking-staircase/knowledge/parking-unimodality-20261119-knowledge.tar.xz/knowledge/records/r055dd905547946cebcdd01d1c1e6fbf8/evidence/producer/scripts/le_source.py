# (LE)의 갱신 꼴:  Omega_k(x) = (k/(N-1)) sum_g q_{N-1}(g) (N+k-2)/(2k+x-g) Omega_k(x-g) + (2k/(N-1)) L_k(x)
#   L_k(x) = sum_{g=1}^{x-1} { alpha_k(x-g) [ q_{N-1}(g) (g(k+1+x-g)-x)/(2k+x-g) - G_N(g) ]
#                              + (N+k-2)/(2(k-1)) q_{N-1}(g) (x-g) sigma_{k-1}(x-g)/(2k+x-g) }
# 원천 L_k(x)의 부호를 첫 층 2<=x<=k+1에서 본다 (논증에서 나온 추측의 작은 예 시험).
import sys
from mpmath import mp, mpf
mp.dps = 50
KMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 40
NMAX = 2*KMAX+4

def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
cay = col(10**9, NMAX)
cols = {c: col(c, NMAX) for c in range(1, KMAX+2)}
def P(y, N):      # Pr(M_{N-1} < y)
    n = N-1
    if y >= N: return mpf(1)
    return cols[y][n]/cay[n]
tau = [None] + [mpf(j)**(j-1)/mp.factorial(j) for j in range(1, NMAX+2)]
def q(N, g): return tau[g]*tau[N-g]/tau[N]
Pi_cache = {}
def Pi(N, m):
    if (N, m) not in Pi_cache:
        s = mpf(0);
        for g in range(1, m+1):
            s += q(N, g); Pi_cache[(N, g)] = s
    return Pi_cache[(N, m)] if m >= 1 else mpf(0)
def Gam(N, m): return (N-1)*(Pi(N-1, m) - Pi(N, m))
def e(k, x):
    if x <= 0: return mpf(0)
    return 1 - mpf(k)/(k+x)*P(k, k+x)

worst = None; nneg = 0; ncell = 0; chkmax = mpf(0)
rows = []
for k in range(3, KMAX+1):
    Om = {}
    for x in range(1, k+2):
        N = k+x
        al = lambda xx: e(k, xx) - e(k, xx-1)
        na = lambda xx: e(k-1, xx) - e(k, xx)
        sg = lambda xx: 1 - e(k-1, xx)
        Om[x] = (2*k+x)*na(x) - mpf(x)/(k-1)*sg(x) - x*al(x)
        if x < 2: continue
        L = mpf(0); ren = mpf(0); Lneg = mpf(0); Lpos = mpf(0)
        for g in range(1, x):
            qq = q(N-1, g)
            c1 = qq*(g*(k+1+x-g) - x)/(2*k+x-g) - (g*qq - Gam(N, g))
            c2 = mpf(N+k-2)/(2*(k-1))*qq*(x-g)/(2*k+x-g)
            t1 = al(x-g)*c1; t2 = sg(x-g)*c2
            L += t1 + t2
            if t1 < 0: Lneg += -t1
            else: Lpos += t1
            Lpos += t2
            ren += qq*mpf(N+k-2)/(2*k+x-g)*Om[x-g]
        chk = Om[x] - (mpf(k)/(N-1)*ren + 2*mpf(k)/(N-1)*L)
        chkmax = max(chkmax, abs(chk))
        ncell += 1
        ratio = Lpos/Lneg if Lneg > 0 else mpf(10)**6
        if L < 0: nneg += 1
        if worst is None or ratio < worst[0]: worst = (ratio, k, x)
        if k in (KMAX,) and (x <= 6 or x % max(1, (k+1)//12) == 0 or x >= k):
            rows.append((k, x, float(L*N), float(ratio), float(Om[x]*N)))
print('cells %d, source negative in %d, identity check max |err| = %.1e' % (ncell, nneg, float(chkmax)))
print('worst ratio (positive part / negative part of L): %.4f at (k,x)=(%d,%d)' % (float(worst[0]), worst[1], worst[2]))
for r in rows:
    print('  k=%d x=%d: N*L=%.5f  pos/neg=%.3f  N*Omega=%.5f' % r)
