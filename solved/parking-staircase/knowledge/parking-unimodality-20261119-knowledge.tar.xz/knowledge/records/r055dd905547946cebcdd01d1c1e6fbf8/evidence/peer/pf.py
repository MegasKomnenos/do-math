# Peer's own exact tables. A[n][l] = #{parking functions of length n with max displacement <= l}.
# Built by the last-car recursion  n*a_n(c) = sum_{j=0}^{n-1} min(j+1,c) a_j(c) a_{n-1-j}(c),  a_n(c)=A_{n,c-1}/n!
# (the last car parks at the spot that splits the others into a left block of j cars and a right block;
#  its displacement is one of 0..j, restricted to <c).  Validated against brute force for n<=7 in test_base.py.
from fractions import Fraction as Fr
from math import factorial
from functools import lru_cache
import itertools

def column(c, nmax):
    """a_n(c) = A_{n,c-1}/n! for n=0..nmax (Fractions)."""
    a = [Fr(1)]
    for n in range(1, nmax + 1):
        s = Fr(0)
        for j in range(n):
            s += min(j + 1, c) * a[j] * a[n - 1 - j]
        a.append(s / n)
    return a

_cols = {}
def A(n, l, nmax=None):
    """A_{n,l} as an int. l<0 -> 0 (n>=1) ; n=0 -> 1."""
    if n == 0: return 1
    if l < 0: return 0
    if l >= n - 1: return (n + 1) ** (n - 1)
    c = l + 1
    key = c
    if key not in _cols or len(_cols[key]) <= n:
        _cols[key] = column(c, max(n, nmax or 0, 2 * c + 12))
    v = _cols[key][n] * factorial(n)
    assert v.denominator == 1
    return int(v)

def b(n, l):
    if l < 0 or l > n - 1: return 0
    return A(n, l) - A(n, l - 1)

def brute(n):
    """max-displacement histogram by brute force over all preference sequences."""
    hist = [0] * n
    for pref in itertools.product(range(1, n + 1), repeat=n):
        occ = [False] * (n + 2)
        M = 0; ok = True
        for a in pref:
            s = a
            while s <= n and occ[s]: s += 1
            if s > n: ok = False; break
            occ[s] = True
            M = max(M, s - a)
        if ok: hist[M] += 1
    return hist
