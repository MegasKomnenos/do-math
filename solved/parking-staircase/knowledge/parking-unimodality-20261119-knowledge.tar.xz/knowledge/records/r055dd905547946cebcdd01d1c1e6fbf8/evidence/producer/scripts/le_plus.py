# 정리 T+ :  y >= 1, y <= n <= 2y+1 에서
#    Pr(M_{n+1}<=y) - Pr(M_n<=y-1) >= ((y+1)/(n+y+2)) ((n+1-y)/(n+1)) Pr(M_n=y)
# 와 그 증명의 핵의 부등식
#    (K+): ((N-1)/k) S(m) + ((k+m-1)/k) q_{N-1}(m) >= G_N(m)     (k>=2, 2<=x<=k+1, N=k+x, 1<=m<=x-1)
# 의 대조.  (1) (K+): 정확한 유리수 N<=40, 부동소수 N<=400 전부와 표본.  (2) 정리 자체: 60자리, n<=NMAX의 첫 층 전체.
import sys
from fractions import Fraction as Fr
from math import factorial, lgamma, log
import numpy as np
from mpmath import mp, mpf

def exactK(NMAX):
    tau = [None] + [Fr(j**(j-1), factorial(j)) for j in range(1, NMAX+2)]
    def q(M, g): return tau[g]*tau[M-g]/tau[M]
    Pi = {}
    for M in range(2, NMAX+1):
        s = Fr(0); Pi[(M, 0)] = s
        for g in range(1, M):
            s += q(M, g); Pi[(M, g)] = s
    def R(M, b): return 1 - Pi[(M, b-1)]
    def G(N, m): return m*q(N-1, m) - (N-1)*(Pi[(N-1, m)] - Pi[(N, m)])
    ok = True; worst = None; cnt = 0
    for N in range(4, NMAX+1):
        for x in range(2, (N+1)//2 + 1):
            k = N-x
            if k < 2 or x > k+1: continue
            for m in range(1, x):
                S = sum(q(N-1, g)*R(N-g, m-g+1) for g in range(1, m))
                lhs = Fr(N-1, k)*S + Fr(k+m-1, k)*q(N-1, m); rhs = G(N, m); cnt += 1
                if lhs < rhs: ok = False
                if m >= 2:
                    r = lhs/rhs
                    if worst is None or r < worst[0]: worst = (r, N, x, m)
    print('(K+) exact, N <= %d: %d cases, all hold: %s ; min ratio over m>=2: %.4f at (N,x,m)=(%d,%d,%d)' % (NMAX, cnt, ok, float(worst[0]), worst[1], worst[2], worst[3]))

def floatK(NTOP):
    LT = np.array([0.0] + [(j-1)*log(j) - lgamma(j+1) for j in range(1, NTOP+3)])
    def qrow(M, upto):
        g = np.arange(1, upto+1)
        return np.exp(LT[g] + LT[M-g] - LT[M])
    worst = (1e9, None); bad = 0; cnt = 0
    Ns = list(range(4, min(NTOP, 400)+1)) + [n for n in (600, 601, 1000, 1001, 2000, 3001) if n <= NTOP]
    for N in Ns:
        mmax = (N-1)//2
        RR = np.zeros((mmax+1, mmax+3))
        for g in range(0, mmax+1):
            M = N-g; up = min(mmax+1, M-1)
            RR[g, 1] = 1.0; RR[g, 2:up+2] = 1.0 - np.cumsum(qrow(M, up))
        qA = qrow(N-1, mmax); qB = qrow(N, mmax)
        Gam = (N-1)*(np.cumsum(qA) - np.cumsum(qB))
        ms = np.arange(1, mmax+1)
        G = ms*qA - Gam
        S = np.zeros(mmax+1)
        for m in range(2, mmax+1):
            g = np.arange(1, m)
            S[m] = np.sum(qA[g-1]*RR[g, m-g+1])
        xs = range(2, (N+1)//2 + 1) if N <= 400 else sorted(set([2, 3, 4, 5, 8, 16, 32, 64, 128, 256, 512, 1024, (N+1)//2 - 1, (N+1)//2, N//3, N//4]))
        for x in xs:
            k = N-x
            if k < 2 or x > k+1 or x < 2: continue
            m = np.arange(1, x)
            lhs = (N-1.0)/k*S[m] + (k+m-1.0)/k*qA[m-1]
            ratio = lhs/G[m-1]; cnt += len(m)
            bad += int(np.sum(ratio < 1 - 1e-12))
            if x >= 3:
                j = int(np.argmin(ratio[1:])) + 1
                if ratio[j] < worst[0]: worst = (float(ratio[j]), (N, x, j+1))
    print('(K+) floats, N <= %d: %d cases, violations: %d ; min ratio over m>=2: %.4f at (N,x,m)=%s' % (Ns[-1], cnt, bad, worst[0], worst[1]))

def theorem(NMAX):
    mp.dps = 60
    def col(c, nmax):
        a = [mpf(1)]
        for n in range(1, nmax+1):
            s = mpf(0)
            for j in range(n):
                s += min(j+1, c)*a[j]*a[n-1-j]
            a.append(s/n)
        return a
    cay = col(10**9, NMAX+1)
    ymax = NMAX
    cols = {c: col(c, NMAX+1) for c in range(1, ymax+2)}
    def F(n, l):
        if l < 0: return mpf(0)
        if l >= n-1: return mpf(1)
        return cols[l+1][n]/cay[n]
    mn = (mpf(10), None); cnt = 0; mn3 = (mpf(10), None)
    for y in range(1, NMAX):
        for n in range(y+1, min(2*y+1, NMAX)+1):
            J = F(n+1, y) - F(n, y-1); cell = F(n, y) - F(n, y-1)
            th = J/(mpf(n+1-y)/(n+1)*cell); cnt += 1
            r = th/(mpf(y+1)/(n+y+2))
            if r < mn[0]: mn = (r, (n, y))
            if th < mn3[0]: mn3 = (th, (n, y))
    print('Theorem T+ on the first layer, n <= %d: %d cells; min of theta/[(y+1)/(n+y+2)] = %.6f at (n,y)=%s ; min theta = %.6f at %s'
          % (NMAX, cnt, float(mn[0]), mn[1], float(mn3[0]), mn3[1]))

exactK(int(sys.argv[1]) if len(sys.argv) > 1 else 36)
floatK(int(sys.argv[2]) if len(sys.argv) > 2 else 3001)
theorem(int(sys.argv[3]) if len(sys.argv) > 3 else 150)
