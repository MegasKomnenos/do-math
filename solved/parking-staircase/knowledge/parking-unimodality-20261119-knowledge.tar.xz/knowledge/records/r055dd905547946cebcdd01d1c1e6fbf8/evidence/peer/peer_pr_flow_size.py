# Size of the flow share in the amplification of the published partial-repayment lemma (r43a26ea3, Lemma PR), double precision.
#   Lambda_m(qbar)  = sum_{j=qbar+1}^{m} a_j Gamma_{min(m-j,k)}(k/m; x)                              (published; cell source only)
#   Lambda+_m(qbar) = Lambda_m(qbar) + sum_{j=qbar+2}^{min(m,2k+3)} a'_j Gamma_{min(m-j,k)}(k/m; x)  (Corollary 4.2; uses Theorem 3.12)
# a_j = x (j-k)/(j(j-1)),  a'_j = x^2 gamma_{j-1} (j-1-k)/(2 (j-1)^2),  x = 1/gamma_k.  Only Cayley-type numbers enter.
import math, sys
def run(k, qbar, ms):
    gam = lambda j: (1 + 1.0 / j) ** (j - 2)
    x = 1 / gam(k)
    leps = [0.0, 0.0] + [(i - 1) * math.log(i - 1) - math.lgamma(i + 1) for i in range(2, k + 2)]
    xe = [0.0, x] + [math.exp(i * math.log(x) + leps[i]) for i in range(2, k + 2)]         # x^i eps_i
    a = lambda j: x * (j - k) / (j * (j - 1.0))
    ap = lambda j: x * x * gam(j - 1) * (j - 1 - k) / (2.0 * (j - 1) ** 2)
    res = []
    for m in ms:
        om = k / float(m)
        G = [1.0]
        for t in range(1, k + 1):
            G.append(x * (1 + om) * G[t - 1] + sum(xe[i] * G[t - i] for i in range(2, t + 1)))
        Gam = [0.0] * (k + 1); s = 0.0
        for t in range(k + 1):
            s += G[t]; Gam[t] = s
        L0 = sum(a(j) * Gam[min(m - j, k)] for j in range(qbar + 1, m + 1))
        L1 = L0 + sum(ap(j) * Gam[min(m - j, k)] for j in range(qbar + 2, min(m, 2 * k + 3) + 1))
        res.append((m, L0, L1))
    return res
for k in [int(s) for s in sys.argv[1:]] or [160, 175, 184, 265]:
    rc = next(r for r in range(1, k) if r ** 3 > k * k)
    for name, qbar in (("k+r_c(k)", k + rc), ("k+[27k/100]", k + (27 * k) // 100)):
        ms = [2 * k, 2 * k + (k // 8), qbar + k - 2, qbar + k - 2 + int(1.1 * k ** (2 / 3.0))]
        out = run(k, qbar, ms)
        print("k=%d qbar=%s=%d: " % (k, name, qbar) + " ; ".join("m=%d: Lambda=%.3f Lambda+=%.3f (x%.2f), 1/(1+L)=%.3f -> %.3f" % (m, L0, L1, L1 / L0, 1 / (1 + L0), 1 / (1 + L1)) for m, L0, L1 in out))
