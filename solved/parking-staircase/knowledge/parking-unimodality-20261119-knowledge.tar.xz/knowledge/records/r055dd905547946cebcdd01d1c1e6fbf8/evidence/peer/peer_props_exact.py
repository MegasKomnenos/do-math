# Peer's exact check (Fractions) of the producer's Prop 2 (ga),(da), Prop 4, Prop 9, Prop 13 and the claim (DR)-sign for tiny k.
from pf import *
def tau(j): return Fr(j ** (j - 1), factorial(j))
def q(N, g): return tau(g) * tau(N - g) / tau(N)
def Pi(N, m): return sum((q(N, g) for g in range(1, m + 1)), Fr(0))
def kst(N, m): return Pi(N, m) - Pi(N - 1, m - 1)
def R(N, b): return 1 - Pi(N, b - 1)
def P(y, N): return Fr(A(N - 1, y - 1), N ** (N - 2)) if N >= 2 else Fr(1)
def e(k, x): return Fr(0) if x <= 0 else 1 - Fr(k, k + x) * P(k, k + x)
def al(k, x): return e(k, x) - e(k, x - 1)
cnt = 0
for k in range(2, 13):
    # Prop 13
    for y in range(2, k + 3):
        Np = k + y
        rhs = Fr(1, Np) * sum((k * kst(Np, j) + Fr(k, y - 1) * R(Np - 1, j)) * al(k, y - j) for j in range(1, y))
        assert al(k, y) == rhs, ("P13", k, y); cnt += 1
    for xt in (Fr(k, k + 1) ** (k - 2), Fr(k, k + 1) ** (k - 1), Fr(1, 3)):
        cst = lambda n: Fr((n + 1) ** (n - 1), factorial(n)) if n >= 1 else Fr(1)
        om = lambda n: xt ** n * cst(n)
        u = lambda j, c: xt ** j * Fr(A(j, c - 1), factorial(j)) if j >= 1 else Fr(1)      # u_j(c) = x^j A_{j,c-1}/j!
        eta = lambda j: u(j, k + 1) - 2 * u(j, k) + u(j, k - 1)
        DC = lambda j: u(j + 1, k + 1) - 2 * u(j, k) + u(j - 1, k - 1)
        for T in range(k, 2 * k + 1):
            lhs = sum(eta(j) for j in range(k, T + 1))
            assert lhs == sum(DC(j) for j in range(k, T + 1)) + (om(k) - om(k - 1)) - (u(T + 1, k + 1) - u(T, k - 1)), ("P2ga", k, T); cnt += 1
    # Prop 2 (da) at the diagonal tilt, with DC at the critical tilt
    xd = Fr(k, k + 1) ** (k - 2); xc = Fr(k, k + 1) ** (k - 1)
    ud = lambda j, c: xd ** j * Fr(A(j, c - 1), factorial(j)) if j >= 1 else Fr(1)
    uc = lambda j, c: xc ** j * Fr(A(j, c - 1), factorial(j)) if j >= 1 else Fr(1)
    DCc = lambda j: uc(j + 1, k + 1) - 2 * uc(j, k) + uc(j - 1, k - 1)
    for T in range(k, 2 * k + 1):
        L = Fr(1, k + 1) * sum(ud(i, k + 1) for i in range(k + 1, T + 2)) - Fr(1, k) * sum(ud(i, k - 1) for i in range(k, T)) - ud(T + 1, k + 1) + ud(T, k - 1)
        lhs = sum(ud(j, k + 1) - 2 * ud(j, k) + ud(j, k - 1) for j in range(k, T + 1))
        assert lhs == sum(Fr(k + 1, k) ** j * DCc(j) for j in range(k, T + 1)) + L, ("P2da", k, T); cnt += 1
    # Prop 4 (inequality) at the diagonal tilt
    cst = lambda n: Fr((n + 1) ** (n - 1), factorial(n)) if n >= 1 else Fr(1)
    om = [xd ** n * cst(n) for n in range(2 * k + 3)]
    a = lambda j: om[j + 1] - om[j]
    Fq = lambda n, l: Fr(A(n, l), (n + 1) ** (n - 1))
    for T in range(k + 2, 2 * k + 1):
        lhs = sum(a(j) * (Fq(j, k - 1) - Fq(j, k - 2)) for j in range(k, T))
        rhs = a(k) + sum((a(j + 1) - a(j)) * Fq(j, k - 2) for j in range(k, T - 1)) - a(T - 1) * Fq(T - 1, k - 2)
        assert lhs >= rhs; cnt += 1
        # discarded amount = sum a_j J_j(k-1)
        assert lhs - rhs == sum(a(j) * (Fq(j, k - 1) - Fq(j - 1, k - 2)) for j in range(k, T)); cnt += 1
# Prop 9 (top diagonal)
for n in range(2, 60):
    qtop = 1 - Fr((n + 1) ** (2 * n - 2), (n + 2) ** n * n ** (n - 2))
    assert qtop >= Fr(1, n + 1)
    J = Fr(A(n + 1, n - 1), (n + 2) ** n) - Fr(A(n, n - 2), (n + 1) ** (n - 1)); cell = Fr(b(n, n - 1), (n + 1) ** (n - 1))
    assert J / cell == qtop; cnt += 1
print("checks passed:", cnt)
