# Peer's independent exact check of every displayed identity/inequality in the proof of Theorem T
# (producer's report 6.1-6.2: Prop 11 (I_d), Lemma T1, T2, T3, T4, T5, the coefficient bound, and the theorem).
from pf import *
import sys
KMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 20

def tau(j): return Fr(j ** (j - 1), factorial(j))
def q(N, g): return tau(g) * tau(N - g) / tau(N)            # first-gap weight, 1<=g<=N-1
def Pi(N, m): return sum((q(N, g) for g in range(1, m + 1)), Fr(0))
def Gam(N, m): return (N - 1) * (Pi(N - 1, m) - Pi(N, m))
def G(N, m): return m * q(N - 1, m) - Gam(N, m)
def kst(N, m): return Pi(N, m) - Pi(N - 1, m - 1)             # stay kernel
def R(N, b): return 1 - Pi(N, b - 1)
def calR(t): return Fr(t + 1, t) ** (t - 1)

def P(y, N):  # Pr(M_{N-1} < y)
    return Fr(A(N - 1, y - 1), N ** (N - 2)) if N >= 2 else Fr(1)
def e(k, x):  # tree exceedance prob, size k+x, level >= k
    if x <= 0: return Fr(0)
    return 1 - Fr(k, k + x) * P(k, k + x)
def sig(k, x): return 1 - e(k, x)
def al(k, x): return e(k, x) - e(k, x - 1)
def nab(k, x): return e(k - 1, x) - e(k, x)

def Omega(c, k, x):
    N = k + x; w = c * x / (N - 1)
    return k * (P(k, N) - w * P(k, N - 1) - (1 - w) * P(k - 1, N - 1))

bad = 0; n_id = 0; n_ineq = 0
for k in range(2, KMAX + 1):
    for x in range(1, k + 2):
        N = k + x
        # Lemma 0 [R] (published) and Prop 11 (I_d)
        assert N * e(k, x) == x + k * sum(q(N, g) * e(k, x - g) for g in range(1, x)); n_id += 1
        assert x * sig(k, x) == k * sum(R(N, i + 1) * al(k, x - i) for i in range(0, x)); n_id += 1
        # alpha >= 0
        assert al(k, x) >= 0
        cx = Fr(k, 2 * k + x - 1)
        for c in (cx, Fr(1, 3), Fr(1, 2)):
            if x == 1:
                assert Omega(c, k, 1) == 0; n_id += 1
                continue
            Lam = lambda g: (N - 1 - c * x) / (N - 1 - c * x - g * (1 - c))
            Kc = lambda g: Fr(k - 1, N - 1) * Lam(g) * q(N - 1, g)
            def Cc(m):
                return (Gam(N, m) - c * x * q(N - 1, m) + c * (x - m) * Fr(k - 1, k) * Lam(m) * q(N - 1, m)
                        + (1 - c) * sum(q(N - 1, g) * Lam(g) * R(N - g, m - g + 1) for g in range(1, m + 1)))
            lhs = Omega(c, k, x)
            # (star_c)
            star = Fr(k, N - 1) * sum((N - 1 - c * x) * q(N - 1, g) * nab(k, x - g) + (Gam(N, g) - c * x * q(N - 1, g)) * al(k, x - g) for g in range(1, x))
            assert lhs == star; n_id += 1
            rhs = sum(Kc(g) * Omega(c, k, x - g) for g in range(1, x)) + Fr(k, N - 1) * sum(Cc(m) * al(k, x - m) for m in range(1, x))
            assert lhs == rhs, (k, x, c); n_id += 1
            if c == cx:
                for m in range(1, x):
                    S = sum(q(N - 1, g) * R(N - g, m - g + 1) for g in range(1, m))
                    low = (1 - c) * Gam(N, m) + c * (Fr(k + m - 1, k) * q(N - 1, m) + Fr(N - 1, k) * S - G(N, m))
                    assert Cc(m) >= low >= 0, (k, x, m); n_ineq += 2
                    # (K+)
                    assert Fr(N - 1, k) * S + Fr(k + m - 1, k) * q(N - 1, m) >= G(N, m); n_ineq += 1
                assert lhs >= 0; n_ineq += 1
# Lemma T2, T3, T4 for N up to 2*KMAX+1
import math
for N in range(4, 2 * KMAX + 2):
    for b in range(2, N):
        assert R(N - 1, b - 1) - R(N, b) == kst(N, b - 1) > 0; n_id += 1
    for j in range(1, N - 2):
        d = G(N, j) - G(N, j + 1)
        assert d == j * q(N - 1, j) + (N - 2 - j) * q(N - 1, j + 1) - (N - 1) * q(N, j + 1); n_id += 1
        # d = q_{N-1}(j) R(j) [phi(j)+phi(N-2-j)-phi(N-1)],  phi(t)=t/calR(t)
        phi = lambda t: t / calR(t)
        assert d == q(N - 1, j) * calR(j) * (phi(j) + phi(N - 2 - j) - phi(N - 1)); n_id += 1
        if N >= 5 and 2 * j <= N - 2:
            assert d <= q(N - 1, j) / 2, (N, j); n_ineq += 1
    if N >= 5:
        J = N // 2
        for m in range(1, J + 1):
            assert G(N, m) <= R(N - 1, m) / 2 + Fr(N - 2, 2 * N * (N - 1)); n_ineq += 1
            assert R(N - 1, m) >= Fr(1, N - 1); n_ineq += 1
            assert G(N, m) <= Fr(N - 1, N) * R(N - 1, m); n_ineq += 1
        if N % 2 == 1: assert G(N, J) == Fr(1, N)
        else: assert G(N, J) < Fr(1, N) and R(N - 1, J) == Fr(1, N - 1)
    # sum of first-gap weights and transition structure
    assert Pi(N, N - 1) == Fr(2 * (N - 1), N)
    for m in range(1, N - 1):
        assert q(N - 1, m) == kst(N, m) + Gam(N, m) / (N - 1) and q(N, m) == kst(N, m) + Gam(N, m - 1) / (N - 1)
        assert Gam(N, m) >= 0 and kst(N, m) > 0
# R(j) >= e(4j-1)/(4j+5) numerically (floats; margin)
mn = min(float(calR(j)) / (math.e * (4 * j - 1) / (4 * j + 5)) for j in range(1, 400))
print("identities checked:", n_id, " inequalities checked:", n_ineq, " min calR(j)/(e(4j-1)/(4j+5)) on j<400: %.6f" % mn)
print("ALL OK")
