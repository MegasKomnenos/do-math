# Peer's independent reproduction (double precision) of the producer's Table 1 / Table 3 / Prop 18 numbers,
# plus the tilt budget.  Units: omega_k/k.   Columns from the tilted last-car recursion.
import numpy as np, sys, math
def run(k):
    x = (k / (k + 1)) ** (k - 2); lx = math.log(x); NN = 2 * k + 2
    lg = [math.lgamma(i + 1) for i in range(NN + 3)]
    om = np.array([math.exp(n * lx + (n - 1) * math.log(n + 1) - lg[n]) for n in range(NN + 1)])
    def col(c):
        u = np.zeros(NN + 1); u[0] = 1.0
        w = np.minimum(np.arange(1, NN + 2), c).astype(float)
        for n in range(1, NN + 1):
            u[n] = x * np.dot(w[:n] * u[:n], u[n - 1::-1][:n]) / n
        return u
    c2, c1, c0, cp = col(k - 2), col(k - 1), col(k), col(k + 1)   # thresholds k-2,k-1,k,k+1  <->  levels <=k-3,k-2,k-1,k
    F = lambda j, l: {k - 2: c1, k - 1: c0, k: cp, k - 3: c2}[l][j] / om[j]          # Pr(M_j <= l)
    P = lambda j, l: F(j, l) - F(j, l - 1)
    U = lambda j: om[j] * P(j, k - 1); V = lambda j: om[j] * P(j, k)
    unit = om[k] / k
    a = lambda j: om[j + 1] - om[j]
    Gam = lambda j: P(j - 1, k - 1) - P(j, k)
    Tk = sum(a(j) * P(j, k - 1) for j in range(k, 2 * k))
    NJ = sum(om[j] * max(Gam(j), 0) for j in range(k + 1, 2 * k + 1))
    Nneg = sum(om[j] * max(-Gam(j), 0) for j in range(k + 1, 2 * k + 1))
    SD = sum(V(j) - U(j - 1) for j in range(k + 1, 2 * k + 1))
    h = -sum(V(j) - U(j) for j in range(k, 2 * k + 1))
    prop4 = a(k) + sum((a(j + 1) - a(j)) * F(j, k - 2) for j in range(k, 2 * k - 1)) - a(2 * k - 1) * F(2 * k - 1, k - 2)
    lostJ = sum(a(j) * (F(j, k - 1) - F(j - 1, k - 2)) for j in range(k, 2 * k))
    recT = sum(a(j) * (k / (j + k)) * ((j - k + 1) / j) * P(j - 1, k - 1) for j in range(k, 2 * k))
    recH = sum(a(j) * ((j - k + 1) / (2.0 * j)) * P(j - 1, k - 1) for j in range(k, 2 * k))      # constant 1/2 (Theorem 3.12)
    lhs0 = a(k) + sum((a(j + 1) - a(j)) * F(j, k - 2) for j in range(k, 2 * k - 1))
    rhs0 = a(2 * k - 1) * F(2 * k - 1, k - 2) + U(2 * k) + NJ
    # sign change of Gamma, budget
    astar = max(j - k for j in range(k + 1, 2 * k + 1) if Gam(j) > 0)
    psi = lambda i: (1 + 1 / i) ** (i - 1); gk = (1 + 1 / k) ** (k - 2)
    S = lambda aa: sum(psi(i + 1) / gk - 1 for i in range(k + aa, 2 * k))
    amax = max(aa for aa in range(0, k) if S(aa) >= 1)
    mind = min(V(j) - U(j - 1) for j in range(k + 2, 2 * k + 1))
    print("k=%d: T_k=%.3f N_J=%.3f |neg|=%.3f U_2k=%.3f SumDelta=%.3f -h_2k=%.3f | Prop4 bound=%.3f lost=%.3f T-recovered=%.3f | a*=%d S(a*)=%.3f S(0)=%.3f amax=%d (%.3fk) | U_{2k-1}/U_{2k}=%.4f minDelta>0:%s"
          % (k, Tk / unit, NJ / unit, Nneg / unit, U(2 * k) / unit, SD / unit, -h / unit, prop4 / unit, lostJ / unit, recT / unit, astar, S(astar), S(0), amax, amax / k, U(2 * k - 1) / U(2 * k), mind > 0))
    print("      (DR-T') ratio=%.3f ; with Theorem 3.1 (constant k/(j+k)): %.3f ; with constant 1/2: recovered=%.3f ratio=%.3f"
          % (lhs0 / rhs0, (lhs0 + recT) / rhs0, recH / unit, (lhs0 + recH) / rhs0))
for k in [int(s) for s in sys.argv[1:]] or [100, 160, 184, 250, 349]:
    run(k)
print("limit budget 5/2 - (3/2) ln 2 = %.4f" % (2.5 - 1.5 * math.log(2)))
