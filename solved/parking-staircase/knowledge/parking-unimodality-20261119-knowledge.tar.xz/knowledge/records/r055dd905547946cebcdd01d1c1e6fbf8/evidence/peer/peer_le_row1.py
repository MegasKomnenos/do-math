# Exact check of Proposition 3.13 (lower Euler inequality with constant 1/2 on the whole row y = 1) and of its lemma.
#  f_n := A_{n,1}/n! = [x^n] 1/(2 - e^x):  f_0 = 1,  f_n = sum_{k=1}^n f_{n-k}/k!
#  (a) A_{n,1} from the parking-function recurrence equals n! f_n                                  (n <= NMAX)
#  (b) Lemma (i): 10/7 <= f_n/f_{n-1} <= 22/15 for n >= 3  (and f_2/f_1 = 3/2)                      (n <= NMAX)
#  (c) the inequality itself, in the form of the proposition:
#        Pr(M_{n+1} <= 1) - Pr(M_n <= 0) >= (1/2) (n/(n+1)) Pr(M_n = 1)                               (1 <= n <= NMAX-1)
#      and in the form (3.11):  f_N >= psi(N) [ (N+1)/(2N) + ((N-1)/(2N)) f_{N-1} ],  psi(N) = (1+1/N)^(N-1)
#  (d) the numbers used in the proof:
#      induction step of (i):  1 + x/2 + x^2/6 + x^3/24 + x^4/120 >= 10/7 at x = 15/22 ;  e^{7/10} < 2.013753 ;
#                              (10/7)(e^{7/10} - 1) + 1/4000 < 22/15 ;  1/720 + 1/5040 <= f_6/4000
#      N >= 8:                 (7/5 - e/2 + e/16) (7/5)^6 > (e/2)(9/8)
#      3 <= N <= 7:            the two sides of (3.11)
import sys
from math import comb, factorial
from fractions import Fraction as Fr
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 30
f = [Fr(1)]
for n in range(1, NMAX + 1):
    f.append(sum(f[n - k] / factorial(k) for k in range(1, n + 1)))
A = [1]
for n in range(1, NMAX + 1):
    A.append(sum(comb(n - 1, j) * min(j + 1, 2) * A[j] * A[n - 1 - j] for j in range(n)))
assert all(A[n] == factorial(n) * f[n] for n in range(NMAX + 1))                                  # (a)
assert A[:6] == [1, 1, 3, 13, 75, 541]
assert f[2] / f[1] == Fr(3, 2)
assert all(Fr(10, 7) <= f[n] / f[n - 1] <= Fr(22, 15) for n in range(3, NMAX + 1))                # (b)
p = lambda n: (n + 1) ** (n - 1) if n >= 1 else 1
mn = None; sides = []
for n in range(1, NMAX):                                                                           # (c)
    lhs = Fr(A[n + 1], p(n + 1)) - Fr(factorial(n), p(n))
    cell = Fr(A[n] - factorial(n), p(n))
    assert lhs >= Fr(1, 2) * Fr(n, n + 1) * cell
    N = n + 1
    psi = Fr(N + 1, N) ** (N - 1)
    rhs = psi * (Fr(N + 1, 2 * N) + Fr(N - 1, 2 * N) * f[N - 1])
    assert f[N] >= rhs
    if 3 <= N <= 7: sides.append("N=%d: %.4f >= %.4f" % (N, float(f[N]), float(rhs)))
    if n >= 2:
        th = lhs / (Fr(n, n + 1) * cell)
        if mn is None or th < mn[0]: mn = (th, n)
elo, ehi = Fr(271828, 100000), Fr(271829, 100000)                                                  # (d)
x = Fr(15, 22)
assert 1 + x / 2 + x ** 2 / 6 + x ** 3 / 24 + x ** 4 / 120 >= Fr(10, 7)
e07 = sum(Fr(7, 10) ** k / factorial(k) for k in range(9)) + (Fr(7, 10) ** 9 / factorial(9)) / (1 - Fr(7, 100))
assert e07 < Fr(2013753, 1000000)
assert Fr(10, 7) * (Fr(2013753, 1000000) - 1) + Fr(1, 4000) < Fr(22, 15)
assert Fr(1, 720) + Fr(1, 5040) <= f[6] / 4000
assert (Fr(7, 5) - ehi / 2 + elo / 16) * Fr(7, 5) ** 6 > ehi / 2 * Fr(9, 8)
print("n <= %d: (a) A_{n,1} = n! f_n, (b) 10/7 <= f_n/f_{n-1} <= 22/15 (n >= 3), (c) the inequality on the row y = 1, (d) the numbers of the proof: all exact checks OK" % NMAX)
print("(3.11) for 3 <= N <= 7: " + "; ".join(sides))
print("min of theta(n,1) over 2 <= n <= %d: %.6f at n = %d ; 1/(e log 2) = 0.530738" % (NMAX - 1, float(mn[0]), mn[1]))
print("f_1..f_7 =", ", ".join(str(v) for v in f[1:8]))
