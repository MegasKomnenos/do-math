# Peer's independent exact check (Fractions, tilt-free form scaled by a rational tilt) of the producer's Props 1, 2(ga), 15, 16, 17
# for small k, with the rational diagonal tilt x = (k/(k+1))^(k-2).
from pf import *
import sys
def chk(k):
    x = Fr(k, k + 1) ** (k - 2)
    NN = 2 * k + 1
    cst = lambda n: Fr((n + 1) ** (n - 1), factorial(n)) if n >= 1 else Fr(1)
    om = [x ** n * cst(n) for n in range(NN + 2)]
    Fq = lambda n, l: Fr(A(n, l), (n + 1) ** (n - 1)) if n >= 1 else Fr(1)
    Pq = lambda n, l: Fq(n, l) - (Fq(n, l - 1) if l >= 1 else 0) if (0 <= l <= n - 1 or n == 0) else Fr(0)
    def Pc(n, l):
        if n == 0: return Fr(1) if l == 0 else Fr(0)
        if l < 0 or l > n - 1: return Fr(0)
        return Fr(b(n, l), (n + 1) ** (n - 1))
    U = lambda j: om[j] * Pc(j, k - 1); V = lambda j: om[j] * Pc(j, k)
    eta = lambda j: V(j) - U(j)
    tau = lambda g: Fr(g ** (g - 1), factorial(g))
    th = lambda g: x ** g * tau(g)
    def ptree(t, y):            # Pr(tree of size t has level exactly y)
        if y < 0 or y > t - 1: return Fr(0)
        return (Fq(t - 1, y) + y * Pc(t - 1, y)) / t if t >= 2 else Fr(1 if y == 0 else 0)
    xi = lambda t, y: th(t) * ptree(t, y)
    u0 = th(k) / k
    # Prop 15 (ga)
    for n in range(k + 1, 2 * k + 2):
        assert V(n) == sum(om[n - t] * xi(t, k) for t in range(k + 1, n + 1)), ("V", n)
    for n in range(k, 2 * k):
        assert U(n) == sum(om[n - t] * xi(t, k - 1) for t in range(k, n + 1)), ("U", n)
    assert U(2 * k) == sum(om[2 * k - t] * xi(t, k - 1) for t in range(k, 2 * k + 1)) - u0 ** 2 / 2
    # Prop 1 (ga), (na) ; Prop 15 (na),(da)
    Delta = lambda j: V(j) - U(j - 1)
    DT = lambda t: xi(t, k) - xi(t - 1, k - 1)
    for T in range(k + 1, 2 * k + 1):
        assert sum(eta(j) for j in range(k, T + 1)) == sum(Delta(j) for j in range(k + 1, T + 1)) - U(T)
    for n in range(k + 1, 2 * k + 1):
        assert Delta(n) == sum(om[n - t] * DT(t) for t in range(k + 1, n + 1))
        assert DT(n) >= 0                      # tree-level Dg (peer's Prop)
        assert Delta(n) == (om[n] - om[n - 1]) * Pc(n - 1, k - 1) - om[n] * (Pc(n - 1, k - 1) - Pc(n, k))
    H = lambda s: sum(xi(t, k) - xi(t, k - 1) for t in range(k, s + 1))
    for n in range(k, 2 * k):
        assert -sum(eta(j) for j in range(k, n + 1)) == -sum(om[n - s] * H(s) for s in range(k, n + 1))
    assert sum(eta(j) for j in range(k, 2 * k + 1)) == sum(om[2 * k - s] * H(s) for s in range(k, 2 * k + 1)) + u0 ** 2 / 2
    # Prop 16 (na): Volterra equation for H
    Lam = lambda s, u: sum(th(g) / (u + g) for g in range(1, s - u + 1))
    for s in range(k, 2 * k + 1):
        rhs = -u0 + sum(k * (Lam(s, u) - Lam(s, u + 1)) * H(u) for u in range(k, s)) + sum(Lam(s, u) * (xi(u, k - 1) + xi(u, k)) for u in range(k, s))
        assert H(s) == rhs, ("H", s)
    # Prop 17: renewal equation for Delta with explicit source
    gam = lambda m: Fr(m + 1, m) ** (m - 2)
    kap = lambda m: x ** m * Fr((m - 1) ** (m - 1), factorial(m)) if m >= 2 else x
    J = lambda n, l: Fq(n, l) - Fq(n - 1, l - 1)
    for n in range(k + 1, 2 * k + 1):
        sig = x ** 2 / (n - 1) * om[n - 2] * (gam(n - 1) * J(n - 1, k) + (gam(n - 1) - gam(k)) * Fq(n - 2, k - 1)) + Fr(n - k, n * (n - 1)) * x * U(n - 2)
        rhs = sig + k * x / n * (Delta(n - 1) if n - 1 >= k + 1 else 0) + sum(kap(m) * Delta(n - m) for m in range(1, n - k))
        assert Delta(n) == rhs, ("Dmu", n)
    # (DR) value
    return float(sum(eta(j) for j in range(k, 2 * k + 1)) / (om[k] / k))
for k in (3, 4, 6, 9, 12, 16):
    print(k, "identities OK;  -h_2k in units omega_k/k = %.4f" % chk(k))
