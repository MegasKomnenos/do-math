# 정리 T (첫 층에서 q_N(r) >= (r+1)/(3N))의 증명의 걸음을 대조한다.
#  기호: tau_j = j^{j-1}/j!, q_M(g) = tau_g tau_{M-g}/tau_M, Pi_M(m) = sum_{g<=m} q_M(g), R_M(b) = 1 - Pi_M(b-1),
#        kk_M(m) = Pi_M(m) - Pi_{M-1}(m-1), Gamma_N(m) = (N-1)(Pi_{N-1}(m) - Pi_N(m)), G_N(m) = m q_{N-1}(m) - Gamma_N(m),
#        RR(t) = (1+1/t)^{t-1}, eta(t) = t((1-1/t)^{t-1} - 1/e).
#  (A)  R_{M-1}(b-1) - R_M(b) = kk_M(b-1) > 0
#  (B)  G_N(j) - G_N(j+1) = q_{N-1}(j) RR(j) [eta(j+1) + eta(N-1-j) - eta(N)]
#  (C)  RR(j) >= e(4j-1)/(4j+5)   (<=>  RR(j)[2 eta(j+1) - 1/(2e)] <= 1/2)
#  (C') G_N(j) - G_N(j+1) <= q_{N-1}(j)/2   for 1 <= j <= (N-2)/2
#  (D)  G_N(floor(N/2)) <= 1/N,  R_{N-1}(floor(N/2)) >= 1/(N-1),  G_N(m) <= R_{N-1}(m)/2 + (N-2)/(2N(N-1))  (1 <= m <= floor(N/2))
#  (K)  2 sum_{g=1}^{m-1} q_{N-1}(g) R_{N-g}(m-g+1) + q_{N-1}(m) >= G_N(m)   (1 <= m <= (N-1)/2)
#  (S)  sum_{g=1}^{M-1} q_M(g) = 2(M-1)/M
import sys
from fractions import Fraction as Fr
from math import factorial, lgamma, log, exp, e as E
import numpy as np

def exact(NMAX):
    tau = [None] + [Fr(j**(j-1), factorial(j)) for j in range(1, NMAX+2)]
    def q(M, g): return tau[g]*tau[M-g]/tau[M]
    Pi = {}
    for M in range(2, NMAX+1):
        s = Fr(0); Pi[(M, 0)] = s
        for g in range(1, M):
            s += q(M, g); Pi[(M, g)] = s
    def R(M, b): return 1 - Pi[(M, b-1)]
    def Gam(N, m): return (N-1)*(Pi[(N-1, m)] - Pi[(N, m)])
    def G(N, m): return m*q(N-1, m) - Gam(N, m)
    ok = dict(A=True, B=True, Cp=True, D=True, K=True, S=True, Gpos=True)
    worstK = None
    for M in range(3, NMAX+1):
        if Pi[(M, M-1)] != Fr(2*(M-1), M): ok['S'] = False
        for b in range(2, M):
            kkv = Pi[(M, b-1)] - Pi[(M-1, b-2)]
            if R(M-1, b-1) - R(M, b) != kkv or kkv <= 0: ok['A'] = False
    for N in range(5, NMAX+1):
        J = N//2
        for j in range(1, N-2):
            # (B): RR, eta 는 유리수가 아니므로 등식은 phi 로 대조한다: phi(t) = t^t/(t+1)^{t-1};  RR(j)[...] = RR(j)[phi(j)+phi(N-2-j)-phi(N-1)]
            phi = lambda t: Fr(t**t, (t+1)**(t-1))
            RRj = Fr((j+1)**(j-1), j**(j-1))
            lhs = G(N, j) - G(N, j+1)
            rhs = q(N-1, j)*RRj*(phi(j) + phi(N-2-j) - phi(N-1))
            if lhs != rhs: ok['B'] = False
            if j <= (N-2)/2 and lhs > q(N-1, j)/2: ok['Cp'] = False
        if G(N, J) > Fr(1, N) or R(N-1, J) < Fr(1, N-1): ok['D'] = False
        for m in range(1, J+1):
            if G(N, m) > R(N-1, m)/2 + Fr(N-2, 2*N*(N-1)): ok['D'] = False
            if Gam(N, m) < 0: ok['Gpos'] = False
        for m in range(1, (N-1)//2 + 1):
            S = sum(q(N-1, g)*R(N-g, m-g+1) for g in range(1, m))
            lhsK = 2*S + q(N-1, m); rhsK = G(N, m)
            if lhsK < rhsK: ok['K'] = False
            if m >= 2:
                r = lhsK/rhsK
                if worstK is None or r < worstK[0]: worstK = (r, N, m)
    print('exact, N <= %d:' % NMAX, ok, ' min (K) ratio over m>=2: %.4f at (N,m)=(%d,%d)' % (float(worstK[0]), worstK[1], worstK[2]))

def floats(NTOP):
    LT = np.array([0.0] + [(j-1)*log(j) - lgamma(j+1) for j in range(1, NTOP+3)])
    def qrow(M, upto):
        g = np.arange(1, upto+1)
        return np.exp(LT[g] + LT[M-g] - LT[M])
    worstK = (1e9, None); worstD = (-1e9, None); worstCp = (-1e9, None); bad = 0
    Ns = [N for N in range(5, min(NTOP, 400)+1)] + [N for N in (500, 501, 700, 1000, 1001, 1500, 2000, 2001, 3000, 4001, 6000, 8001, 12000) if N <= NTOP]
    for N in Ns:
        J = N//2; mmax = (N-1)//2
        qA = qrow(N-1, N-2); qB = qrow(N, N-1)
        PiA = np.cumsum(qA); PiB = np.cumsum(qB)
        m = np.arange(1, J+1)
        Gam = (N-1)*(PiA[m-1] - PiB[m-1]); G = m*qA[m-1] - Gam
        Rm = 1.0 - np.concatenate(([0.0], PiA[:J-1]))        # R_{N-1}(m), m=1..J
        d = G - (Rm/2 + (N-2.0)/(2*N*(N-1)))
        i = int(np.argmax(d))
        if d[i] > worstD[0]: worstD = (float(d[i]), (N, i+1))
        jj = np.arange(1, (N-2)//2 + 1)
        if len(jj) >= 1 and len(G) > len(jj):
            dec = (G[jj-1] - G[jj]) / qA[jj-1]
            i2 = int(np.argmax(dec))
            if dec[i2] > worstCp[0]: worstCp = (float(dec[i2]), (N, i2+1))
        # (K): 보조정리 A를 쓴 꼴 2 R(1-R) + q(m) >= G(m)  (m>=3)  과 실제 꼴은 작은 N에서만 (exact) 본다
        mm = np.arange(1, mmax+1)
        rho = Rm[mm-1]
        lhs = 2*rho*(1-rho) + qA[mm-1]
        ratio = lhs[2:]/G[mm-1][2:] if mmax >= 3 else np.array([9.0])
        if len(ratio):
            i3 = int(np.argmin(ratio))
            if ratio[i3] < worstK[0]: worstK = (float(ratio[i3]), (N, i3+3))
            bad += int(np.sum(ratio < 1))
    print('floats, N in 5..%d (all N <= 400, then sampled): max of G_N(m) - [R_{N-1}(m)/2 + (N-2)/(2N(N-1))] = %.3e at %s (must be <= 0)' % (Ns[-1], worstD[0], worstD[1]))
    print('   max of [G_N(j)-G_N(j+1)]/q_{N-1}(j) over j <= (N-2)/2 = %.6f at %s (must be <= 1/2)' % worstCp)
    print('   min over m>=3 of [2R(1-R)+q(m)]/G_N(m), R=R_{N-1}(m): %.4f at %s ; violations %d' % (worstK[0], worstK[1], bad))
    # (C)
    j = np.arange(1, 2000001, dtype=float)
    RRv = np.exp((j-1)*np.log1p(1/j))
    gap = RRv - E*(4*j-1)/(4*j+5)
    print('   (C): min over j <= 2e6 of RR(j) - e(4j-1)/(4j+5) = %.3e (at j=%d); j^2*gap at j=1e3,1e6: %.5f, %.5f (e/12 = %.5f)'
          % (gap.min(), int(j[int(np.argmin(gap))]), 1e6*gap[999], 1e12*gap[999999], E/12))

exact(int(sys.argv[1]) if len(sys.argv) > 1 else 40)
floats(int(sys.argv[2]) if len(sys.argv) > 2 else 3000)
