# Exact check (own integer tables) of Proposition 3.14: the first-tree recursion for the defect of the lower Euler
# inequality with constant c, at all sizes, and the closed formulas for its source.
#  y >= 1, Y = y+1, a_n = Pr(M_n <= y), b_n = Pr(M_n <= y-1), d_n = a_n - b_n, h(j) = min(1, Y/j),
#  lam_N = c (N-y)/N,   L(N) := a_N - lam_N a_{N-1} - (1-lam_N) b_{N-1}        (L(N) >= 0 is (LE) with constant c at (n,y) = (N-1,y))
#  pi_n(j) = C(n-1,j-1) j^(j-1) p_{n-j}/p_n,  pit_N(j) = ((j-1)/N) pi_{N-1}(j-1) + ((N-j)/N) pi_{N-1}(j),  Q_N(j) = h(j) a_{j-1} a_{N-j}
#  (1) a_N = sum_j pi_N(j) Q_N(j)                                         [first-tree / last-car decomposition]
#  (2) L(N) = sum_{i=1}^{N-1} pi_{N-1}(i) [ (i/N) h(i+1) a_{N-1-i} L(i) + ((N-i)/N) h(i) a_{i-1} L(N-i) ] + R_N - X_N,
#      R_N = sum_i pi_{N-1}(i) rho_N(i),   X_N = sum_{j<N} (pit_N(j) - pi_N(j)) (Q_N(j) - Q_N(N)) >= 0,
#      with m = N-1-i, mu = (1-c)(m+1) + c y:
#      i <= y   :  N rho_N(i) = (1-c) i d_m
#      i >= y+1 :  N rho_N(i) = b_m b_{i-1} {[(1-c)(i-y) - cY]/(i+1) + mu/i} + b_m d_{i-1} Y [mu/i - cY/(i+1)]
#                               + d_m b_{i-1} Y ((1-c) i - c)/(i+1)  -  d_m d_{i-1} c Y^2/(i+1)
#  (3) for c = 1/2: sign of the source R_N - X_N in every cell of the table (reported, not asserted)
import sys
from math import comb
from fractions import Fraction as Fr
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 24
binom = [[comb(n, j) for j in range(n + 1)] for n in range(NMAX + 2)]
def column(c):
    A = [1]
    for n in range(1, NMAX + 1):
        bn = binom[n - 1]
        A.append(sum(bn[j] * min(j + 1, c) * A[j] * A[n - 1 - j] for j in range(n)))
    return A
cols = {c: column(c) for c in range(0, NMAX + 2)}
p = [1] + [(n + 1) ** (n - 1) for n in range(1, NMAX + 1)]
def F(n, l):
    if l < 0: return Fr(1) if n == 0 else Fr(0)
    return Fr(cols[min(l + 1, NMAX + 1)][n], p[n])
def pi(n, j): return Fr(binom[n - 1][j - 1] * j ** (j - 1) * p[n - j], p[n]) if 1 <= j <= n else Fr(0)
cnt = 0; neg = []; cells = 0; worst = None
for c in (Fr(1, 2), Fr(1, 3), Fr(0)):
    for y in range(1, NMAX - 1):
        Y = y + 1
        h = lambda j: Fr(1) if j <= Y else Fr(Y, j)
        A = [F(n, y) for n in range(NMAX + 1)]; B = [F(n, y - 1) for n in range(NMAX + 1)]
        d = [A[n] - B[n] for n in range(NMAX + 1)]
        lam = lambda N: c * Fr(N - y, N)
        L = {N: A[N] - lam(N) * A[N - 1] - (1 - lam(N)) * B[N - 1] for N in range(1, NMAX + 1)}
        for N in range(2, NMAX + 1):
            Q = lambda j: h(j) * A[j - 1] * A[N - j]
            assert A[N] == sum(pi(N, j) * Q(j) for j in range(1, N + 1))                                   # (1)
            ker = sum(pi(N - 1, i) * (Fr(i, N) * h(i + 1) * A[N - 1 - i] * L[i] + Fr(N - i, N) * h(i) * A[i - 1] * L[N - i]) for i in range(1, N))
            R = Fr(0)
            for i in range(1, N):
                m = N - 1 - i
                if i <= y:
                    rho = (1 - c) * i * d[m] / N
                else:
                    mu = (1 - c) * (m + 1) + c * y
                    rho = (B[m] * B[i - 1] * (((1 - c) * (i - y) - c * Y) / (i + 1) + mu / i) + B[m] * d[i - 1] * Y * (mu / i - c * Y / (i + 1))
                           + d[m] * B[i - 1] * Y * ((1 - c) * i - c) / (i + 1) - d[m] * d[i - 1] * c * Y * Y / (i + 1)) / N
                R += pi(N - 1, i) * rho
            pit = lambda j: Fr(j - 1, N) * pi(N - 1, j - 1) + Fr(N - j, N) * pi(N - 1, j)
            assert all(pit(j) >= pi(N, j) for j in range(1, N))
            X = sum((pit(j) - pi(N, j)) * (Q(j) - Q(N)) for j in range(1, N))
            assert X >= 0
            assert L[N] == ker + R - X, (c, y, N); cnt += 1                                                   # (2)
            if c == Fr(1, 2) and N >= y + 2:
                cells += 1
                scale = Fr(N - y, N) * d[N - 1]
                rel = (R - X) / scale
                if R - X < 0: neg.append((y, N))
                if worst is None or rel < worst[0]: worst = (rel, y, N)
print("N <= %d: decomposition (1) and recursion (2) with the closed source formulas hold exactly in %d cells (c = 1/2, 1/3, 0)" % (NMAX, cnt))
print("c = 1/2: source R_N - X_N < 0 in %d of %d cells with N >= y+2; they are %s" % (len(neg), cells, neg))
print("c = 1/2: smallest source/scale = %.5f at (y, N) = (%d, %d)   [scale = ((N-y)/N) Pr(M_{N-1} = y)]" % (float(worst[0]), worst[1], worst[2]))
