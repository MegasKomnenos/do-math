# End-to-end exact check of the proof of Theorem 3.12 with actual parking-function numbers (own integer tables):
# for k <= KMAX and 1 <= z <= k+1, with N = k+z, c = 1/2:
#   (a) Omega(z) := k [P_k(N) - w P_k(N-1) - (1-w) P_{k-1}(N-1)], w = z/(2(N-1)), equals k*(difference of the two sides of (3.7)) at (n,y)=(N-2,k-1);
#   (b) renewal form (3.3):  Omega(z) = sum_g K(g) Omega(z-g) + (k/(N-1)) sum_{m=1}^{z-1} C(m) alpha_k(z-m);
#   (c) after one elimination (Lemma 3.9 at excess z-1), for z >= 3:
#         Omega(z) = sum_g K(g) Omega(z-g) + (k/(N-1)) sum_{m=2}^{z-1} [C(m) + C(1) E(m)] alpha_k(z-m);
#   (d) every term on the right of the form used in the induction is >= 0  (kernel > 0, alpha >= 0, and
#       C(m) + min(C(1),0) E(m) >= 0), hence Omega(z) >= 0.
import sys
from math import comb, factorial
from fractions import Fraction as Fr
KMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 14
NMAX = 2 * KMAX + 3
binom = [[comb(n, j) for j in range(n + 1)] for n in range(NMAX + 1)]
def column(c):
    A = [1]
    for n in range(1, NMAX + 1):
        bn = binom[n - 1]
        A.append(sum(bn[j] * min(j + 1, c) * A[j] * A[n - 1 - j] for j in range(n)))
    return A
cols = {c: column(c) for c in range(0, NMAX + 2)}
def A(n, l):
    if l < 0: return 1 if n == 0 else 0
    return cols[min(l + 1, NMAX + 1)][n]
p = lambda n: (n + 1) ** (n - 1) if n >= 1 else 1
F = lambda n, l: Fr(A(n, l), p(n))                       # Pr(M_n <= l)
Pt = lambda y, N: F(N - 1, y - 1)                        # P_y(N) = Pr(M_{N-1} < y)
def e(k, z): return Fr(0) if z <= 0 else 1 - Fr(k, k + z) * Pt(k, k + z)
al = lambda k, z: e(k, z) - e(k, z - 1)
tau = lambda j: Fr(j ** (j - 1), factorial(j))
q = lambda M, g: tau(g) * tau(M - g) / tau(M)
def Pi(M, m): return sum((q(M, g) for g in range(1, m + 1)), Fr(0))
R = lambda M, b: 1 - Pi(M, b - 1)
Gam = lambda N, m: (N - 1) * (Pi(N - 1, m) - Pi(N, m))
kap = lambda N, m: Pi(N, m) - Pi(N - 1, m - 1)
cnt = 0
for k in range(2, KMAX + 1):
    Om = {}
    for z in range(1, k + 2):
        N = k + z; L = 2 * k + z - 2; n = N - 2; y = k - 1
        w = Fr(z, 2 * (N - 1))
        Om[z] = k * (Pt(k, N) - w * Pt(k, N - 1) - (1 - w) * Pt(k - 1, N - 1))
        # (a)
        lhs = F(n + 1, y) - F(n, y - 1); rhs = Fr(1, 2) * Fr(n + 1 - y, n + 1) * (F(n, y) - F(n, y - 1))
        assert Om[z] == k * (lhs - rhs); cnt += 1
        assert Om[z] >= 0; cnt += 1
        if z == 1:
            assert Om[z] == 0; continue
        Lam = lambda g: Fr(L, L - g)
        K = lambda g: Fr(k - 1, N - 1) * Lam(g) * q(N - 1, g)
        C = lambda m: (Gam(N, m) - Fr(z, 2) * q(N - 1, m) + Fr(1, 2) * (z - m) * Fr(k - 1, k) * Lam(m) * q(N - 1, m)
                       + Fr(1, 2) * sum(q(N - 1, g) * Lam(g) * R(N - g, m - g + 1) for g in range(1, m + 1)))
        ker = sum(K(g) * Om[z - g] for g in range(1, z))
        # (b)
        assert Om[z] == ker + Fr(k, N - 1) * sum(C(m) * al(k, z - m) for m in range(1, z)); cnt += 1
        assert all(K(g) > 0 for g in range(1, z)) and all(al(k, t) >= 0 for t in range(1, z)); cnt += 1
        if z >= 3:
            E = lambda m: (k * kap(N - 1, m - 1) + Fr(k, z - 2) * R(N - 2, m - 1)) / (N - 1)
            # elimination identity for alpha_k(z-1)
            assert al(k, z - 1) == sum(E(m) * al(k, z - m) for m in range(2, z)); cnt += 1
            # (c)
            assert Om[z] == ker + Fr(k, N - 1) * sum((C(m) + C(1) * E(m)) * al(k, z - m) for m in range(2, z)); cnt += 1
            # (d)
            assert all(C(m) + min(C(1), 0) * E(m) >= 0 for m in range(2, z)); cnt += 1
        else:
            assert C(1) == Gam(N, 1) >= 0; cnt += 1
print("k <= %d: end-to-end checks passed: %d" % (KMAX, cnt))
