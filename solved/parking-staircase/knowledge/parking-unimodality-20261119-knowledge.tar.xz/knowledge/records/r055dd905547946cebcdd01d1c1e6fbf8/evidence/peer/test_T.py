# Direct exact check of Theorem T (producer's 6.2) on my own tables.
from pf import *
import sys
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 60
def F(n, l):  # Pr(M_n <= l)
    return Fr(A(n, l), (n + 1) ** (n - 1))
worst = None; cnt = 0; viol = 0
worst_half = None
for n in range(1, NMAX):
    for y in range(1, n + 1):
        if not (y <= n <= 2 * y + 1): continue
        lhs = F(n + 1, y) - F(n, y - 1)
        cell = F(n, y) - F(n, y - 1)
        if cell == 0: 
            # y = n: Pr(M_n = n) = 0 ; statement reads lhs >= 0
            assert lhs >= 0; continue
        c = Fr(y + 1, n + y + 2)
        rhs = c * Fr(n + 1 - y, n + 1) * cell
        cnt += 1
        if lhs < rhs: viol += 1; print("VIOLATION", n, y)
        theta = lhs / (Fr(n + 1 - y, n + 1) * cell)   # = q_N(r) * N/(r+1)
        ratio = theta / c
        if worst is None or ratio < worst[0]: worst = (ratio, n, y)
        if worst_half is None or theta < worst_half[0]: worst_half = (theta, n, y)
print("first-layer cells checked:", cnt, "violations:", viol)
print("min theta/c_x = %.6f at (n,y)=%s" % (float(worst[0]), worst[1:]))
print("min theta = %.6f at (n,y)=%s" % (float(worst_half[0]), worst_half[1:]))
# beyond the first layer: does the same inequality (constant (y+1)/(n+y+2)) and (LE) (constant 1/2) hold?
v1 = v2 = c2 = 0; mn = None
for n in range(2, NMAX):
    for y in range(1, n):
        if n <= 2 * y + 1: continue
        lhs = F(n + 1, y) - F(n, y - 1); cell = F(n, y) - F(n, y - 1)
        theta = lhs / (Fr(n + 1 - y, n + 1) * cell); c2 += 1
        if theta < Fr(y + 1, n + y + 2): v1 += 1
        if theta < Fr(1, 2): v2 += 1
        if mn is None or theta < mn[0]: mn = (theta, n, y)
print("outside first layer: cells", c2, "viol(T-constant)", v1, "viol(1/2)", v2, "min theta %.5f at %s" % (float(mn[0]), mn[1:]))
