# 게시된 보조정리 Dmu (r6af349eb c09)를 mu = gamma_k (대각 기울임 x = 1/gamma_k)에서 적은 것:
#   Delta_n = sig_n + (k x/n) Delta_{n-1} + sum_{m=1}^{n-k-1} kap_m Delta_{n-m}    (k+1 <= n <= 2k; kap_m = x^m (m-1)^{m-1}/m!)
#   sig_n = (x^2/(n-1)) w_{n-2} [ gam_{n-1} J_{n-1}(k) + (gam_{n-1} - gam_k) F_{n-2}(k-1) ] + ((n-k) x/(n(n-1))) U_{n-2}
#   (J_{n-1}(k) = F_{n-1}(k) - F_{n-2}(k-1): 머무는 흐름; 정리 T가 하계를 준다)
# 등식의 대조와, 세 원천 조각이 sum Delta 에 주는 몫, 정리 T의 하계를 넣었을 때의 값.
import sys
from mpmath import mp, mpf
mp.dps = 40
def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
for k in [int(a) for a in sys.argv[1:]]:
    T = 2*k; nmax = T+2
    aP = col(k+1, nmax); a0 = col(k, nmax); aM = col(k-1, nmax); cay = col(10**9, nmax)
    x = (mpf(k)/(k+1))**(k-2)
    w = [x**j*cay[j] for j in range(nmax+1)]
    Fk = [aP[n]/cay[n] for n in range(nmax+1)]; Fk1 = [a0[n]/cay[n] for n in range(nmax+1)]; Fk2 = [aM[n]/cay[n] for n in range(nmax+1)]
    U = [w[n]*(Fk1[n]-Fk2[n]) for n in range(nmax+1)]; V = [w[n]*(Fk[n]-Fk1[n]) for n in range(nmax+1)]
    gam = lambda m: (1+mpf(1)/m)**(m-2)
    kap = [None] + [x**m*mpf(max(m-1, 1))**(m-1)/mp.factorial(m) if m >= 2 else x for m in range(1, k+2)]
    kap[1] = x
    Delta = {n: V[n]-U[n-1] for n in range(k+1, T+1)}; Delta[k] = mpf(0)
    partJ = {}; partF = {}; partU = {}; partT = {}
    err = mpf(0)
    for n in range(k+1, T+1):
        J = Fk[n-1] - Fk1[n-2]
        pJ = x*x/(n-1)*w[n-2]*gam(n-1)*J
        pF = x*x/(n-1)*w[n-2]*(gam(n-1)-gam(k))*Fk1[n-2]
        pU = (n-k)*x/(n*(n-1))*U[n-2]
        # 정리 T: J_{n-1}(k) >= ((y+1)/(n'+y+2)) ((n'+1-y)/(n'+1)) P_{n'}(y), n' = n-2, y = k
        cT = mpf(k+1)/(n-2+k+2)*mpf(n-2+1-k)/(n-2+1)
        pT = x*x/(n-1)*w[n-2]*gam(n-1)*cT*(Fk[n-2]-Fk1[n-2])
        partJ[n] = pJ; partF[n] = pF; partU[n] = pU; partT[n] = pT
        rhs = pJ + pF + pU + k*x/n*Delta[n-1] + sum(kap[m]*Delta[n-m] for m in range(1, n-k))
        err = max(err, abs(Delta[n] - rhs))
    def solve(src):
        D = {k: mpf(0)}
        for n in range(k+1, T+1):
            D[n] = src[n] + k*x/n*D[n-1] + sum(kap[m]*D[n-m] for m in range(1, n-k))
        return sum(D[n] for n in range(k+1, T+1))
    unit = w[k]/k
    sJ = solve(partJ); sF = solve(partF); sU = solve(partU); sT = solve(partT)
    tot = sum(Delta[n] for n in range(k+1, T+1))
    print('k=%d: Lemma Dmu identity max err %.1e (unit w_k/k) | sum Delta = %.4f = J-part %.4f + F-part %.4f + U-part %.4f | U_2k = %.4f'
          % (k, float(err/unit), float(tot/unit), float(sJ/unit), float(sF/unit), float(sU/unit), float(U[T]/unit)))
    print('     with Theorem T in place of J: J-part >= %.4f ; total >= %.4f ; ratio to U_2k: %.3f (true ratio %.3f) ; raw sources sum (no feedback): %.4f'
          % (float(sT/unit), float((sT+sF+sU)/unit), float((sT+sF+sU)/U[T]), float(tot/U[T]), float(sum(partJ[n]+partF[n]+partU[n] for n in range(k+1, T+1))/unit)))
