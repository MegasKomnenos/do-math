# Exact check of the steps of Proposition 3.15 (c): the lower Euler inequality with constant 1/2 on the whole row y = 2.
# (Base-case computation: only rows n <= 18 of the exact table enter the proof; larger n are checked here but not used.)
#  f_n = A_{n,1}/n!, alpha_n = A_{n,2}/n!, G_3 = 191/128, w = 2 G_3/e - 1.
#  (1) 10/7 <= f_n/f_{n-1} <= 22/15 for n >= 3 (checked for n <= NMAX; the induction step uses the two numbers below)
#  (2) alpha_n >= G_3 alpha_{n-1} for n >= 3, hence rho_n := F_n(1)/F_n(2) = f_n/alpha_n is nonincreasing for n >= 3
#  (3) base: (LE) at the cells (n, 2), 2 <= n <= n0-1, and rho_{n0} <= w, with n0 = 18 (rows n <= 18 of the table)
#  (4) numbers used in the induction step of (1):
#      1 + (15/22)/2 + (15/22)^2/6 + (15/22)^3/24 + (15/22)^4/120 >= 10/7 ;  (10/7)(e^{7/10} - 1) + 1/4000 < 22/15 ;  e^{7/10} < 2.013753
import sys
from math import comb, factorial
from fractions import Fraction as Fr
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 30
n0 = 18
def column(c):
    A = [1]
    for n in range(1, NMAX + 1):
        A.append(sum(comb(n - 1, j) * min(j + 1, c) * A[j] * A[n - 1 - j] for j in range(n)))
    return A
A1 = column(2); A2 = column(3); A0 = [factorial(n) for n in range(NMAX + 1)]
p = [1] + [(n + 1) ** (n - 1) for n in range(1, NMAX + 1)]
f = [Fr(A1[n], factorial(n)) for n in range(NMAX + 1)]
al = [Fr(A2[n], factorial(n)) for n in range(NMAX + 1)]
assert all(Fr(10, 7) <= f[n] / f[n - 1] <= Fr(22, 15) for n in range(3, NMAX + 1))                     # (1)
G3 = 1 + Fr(1, 2) / Fr(16, 9) + Fr(2, 3) / Fr(16, 9) ** 2
assert G3 == Fr(191, 128) and G3 > Fr(22, 15)
assert all(al[n] >= G3 * al[n - 1] for n in range(3, NMAX + 1))                                         # (2)
rho = [Fr(A1[n], A2[n]) for n in range(NMAX + 1)]
assert all(rho[n] <= rho[n - 1] for n in range(3, NMAX + 1))
ehi = Fr(271829, 100000)
w = 2 * G3 / ehi - 1
for n in range(2, n0):                                                                                    # (3)
    lhs = Fr(A2[n + 1], p[n + 1]) - Fr(A1[n], p[n])
    assert lhs >= Fr(1, 2) * Fr(n - 1, n + 1) * Fr(A2[n] - A1[n], p[n])
assert rho[n0] <= w
x = Fr(15, 22)
assert 1 + x / 2 + x ** 2 / 6 + x ** 3 / 24 + x ** 4 / 120 >= Fr(10, 7)                                   # (4)
e07 = sum(Fr(7, 10) ** k / factorial(k) for k in range(9)) + (Fr(7, 10) ** 9 / factorial(9)) / (1 - Fr(7, 100))
assert e07 < Fr(2013753, 1000000)
assert Fr(10, 7) * (Fr(2013753, 1000000) - 1) + Fr(1, 4000) < Fr(22, 15)
assert Fr(1, 720) + Fr(1, 5040) <= Fr(1, 4000) * f[6]
print("row y = 2: (1) ratio bounds n <= %d, (2) growth bound and monotone rho, (3) base cells n <= %d and rho_%d = %.5f <= w = %.5f, (4) numbers: all exact checks OK"
      % (NMAX, n0 - 1, n0, float(rho[n0]), float(w)))
print("A_{18,1} = %d, A_{18,2} = %d" % (A1[18], A2[18]))
print("rho_n for n = 14..20: " + ", ".join("%.4f" % float(rho[n]) for n in range(14, 21)))
print("f_n/f_{n-1}, n = 3..8: " + ", ".join("%.5f" % float(f[n] / f[n - 1]) for n in range(3, 9)) + " ; alpha_n/alpha_{n-1}, n = 3..8: " + ", ".join("%.5f" % float(al[n] / al[n - 1]) for n in range(3, 9)))
