# 나무의 빚:  -hT(s) = sum_{t=k}^{s} xi_t(k) - xi_t(k-1),  xi_t(y) = x w_{t-1} p_t(y)   (대각 기울임)
#  숲의 빚은 그 Cayley 합성곱:  -h_n = sum_{s=k}^{n} w_{n-s} (-hT(s))   (n <= 2k-1; n = 2k 에서는 아주 작은 둘째 층 항이 더 있다)
# 나무의 빚의 부호, 갚는 자리, 접합부에서의 크기를 본다. 단위 u0 = x w_{k-1}/k.
import sys
from mpmath import mp, mpf
mp.dps = 50
def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
for k in [int(a) for a in sys.argv[1:]]:
    T = 2*k; nmax = T+2
    aP = col(k+1, nmax); a0 = col(k, nmax); aM = col(k-1, nmax); cay = col(10**9, nmax)
    x = (mpf(k)/(k+1))**(k-2)
    w = [x**j*cay[j] for j in range(nmax+1)]
    F = lambda a, n: a[n]/cay[n]
    def p(t, lev):
        n = t-1
        if t < lev+1: return mpf(0)
        if lev == k:   Fl = F(aP, n); Pl = F(aP, n) - F(a0, n)
        else:          Fl = F(a0, n); Pl = F(a0, n) - F(aM, n)
        return (Fl + lev*Pl)/t
    u0 = x*w[k-1]/k
    xi = lambda t, lev: x*w[t-1]*p(t, lev)
    mhT = {}; s = mpf(0)
    for t in range(k, T+1):
        s += xi(t, k) - xi(t, k-1); mhT[t] = s
    # 숲의 빚과의 대조 (n = 2k-1)
    mh_forest = sum(w[j]*((F(aP, j)-F(a0, j)) - (F(a0, j)-F(aM, j))) for j in range(k, T))
    conv = sum(w[T-1-t]*mhT[t] for t in range(k, T))
    mh2k = sum(w[j]*((F(aP, j)-F(a0, j)) - (F(a0, j)-F(aM, j))) for j in range(k, T+1))
    conv2k = sum(w[T-t]*mhT[t] for t in range(k, T+1))
    sstar = min(t for t in range(k, T+1) if mhT[t] >= 0)
    mono = all(mhT[t+1] >= mhT[t] for t in range(sstar, T))
    tmin = min(range(k, T+1), key=lambda t: mhT[t])
    negpart = sum(w[T-t]*(-mhT[t]) for t in range(k, T+1) if mhT[t] < 0)
    pospart = sum(w[T-t]*mhT[t] for t in range(k, T+1) if mhT[t] >= 0)
    print('k=%d: check n=2k-1: %.2e ; n=2k: forest -h=%.5f u0, convolution=%.5f u0 (diff %.2e u0)' % (k, float(abs(mh_forest-conv)/u0), float(mh2k/u0), float(conv2k/u0), float((conv2k-mh2k)/u0)))
    print('     tree debt: min of -hT = %.4f u0 at s-k=%d ; repaid (-hT>=0) from s-k=%d ; nondecreasing after: %s ; -hT(2k) = %.4f u0, -hT(1.5k) = %.4f u0'
          % (float(mhT[tmin]/u0), tmin-k, sstar-k, mono, float(mhT[T]/u0), float(mhT[k+k//2]/u0)))
    print('     convolution at 2k: positive part %.4f u0, negative part %.4f u0 (ratio %.3f)' % (float(pospart/u0), float(negpart/u0), float(pospart/negpart)))
    print('     -hT(s)/u0 at s-k: ' + ', '.join('%d:%.3f' % (xx, float(mhT[k+xx]/u0)) for xx in sorted(set(v for v in (0, 1, 2, 5, 10, 20, 30, 40, 60, 80, k//2, (3*k)//4, k-10, k-1, k) if 0 <= v <= k))))
