# Float test (double) of the single-elimination condition for the constant c=1/2:
#   (H_m)  C(m) + min(C(1),0)*E(m) >= 0   for 2<=m<=x-1,   where C = C^{1/2} of Lemma T1 and
#   E(m) = [k*kst_{N-1}(m-1) + (k/(x-2)) R_{N-2}(m-1)]/(N-1).
import numpy as np, math, sys
def run(k, xs):
    worst = (1e9, None)
    lg = [0.0] + [math.lgamma(i + 1) for i in range(1, 2 * k + 6)]
    ltau = lambda j: (j - 1) * math.log(j) - lg[j]
    def qrow(M):  # q_M(g), g=1..M-1  (index g)
        a = np.zeros(M + 1)
        lt = ltau(M)
        for g in range(1, M): a[g] = math.exp(ltau(g) + ltau(M - g) - lt)
        return a
    cacheq = {}
    def Q(M):
        if M not in cacheq: cacheq[M] = qrow(M)
        return cacheq[M]
    cachePi = {}
    def PiM(M):
        if M not in cachePi: cachePi[M] = np.cumsum(Q(M))
        return cachePi[M]
    for x in xs:
        N = k + x; L = 2 * k + x - 2
        q1 = Q(N - 1); PiN1 = PiM(N - 1); PiN = PiM(N); PiN2 = PiM(N - 2)
        Gam = lambda m: (N - 1) * (PiN1[m] - PiN[m])
        R = lambda M, b: 1.0 - (PiM(M)[b - 1] if b >= 2 else 0.0)
        Lam = lambda g: L / (L - g)
        C = np.zeros(x)
        for m in range(1, x):
            s = sum(q1[g] * Lam(g) * R(N - g, m - g + 1) for g in range(1, m + 1))
            C[m] = Gam(m) - 0.5 * x * q1[m] + 0.5 * (x - m) * (k - 1) / k * Lam(m) * q1[m] + 0.5 * s
        c1 = min(C[1], 0.0)
        for m in range(2, x):
            kst = PiN1[m - 1] - (PiN2[m - 2] if m >= 2 else 0.0)        # kst_{N-1}(m-1) = Pi_{N-1}(m-1) - Pi_{N-2}(m-2)
            E = (k * kst + k / (x - 2) * R(N - 2, m - 1)) / (N - 1)
            val = C[m] + c1 * E
            rel = val / (abs(C[m]) + abs(c1 * E) + 1e-300)
            if rel < worst[0]: worst = (rel, (x, m, C[m], c1 * E))
    return worst
for k in [int(s) for s in sys.argv[1:]] or [40, 100, 200, 400]:
    xs = sorted(set([3, 4, 5, 6, 8, 10, 15, 20, 30, k // 4, k // 3, k // 2, (2 * k) // 3, (3 * k) // 4, (9 * k) // 10, k - 2, k - 1, k, k + 1]))
    xs = [x for x in xs if 3 <= x <= k + 1]
    w = run(k, xs)
    print("k=%d: worst relative margin (val/(|C(m)|+|debt|)) = %.4f at (x,m)=(%d,%d): C(m)=%.5g, C(1)^- * E(m)=%.5g" % (k, w[0], w[1][0], w[1][1], w[1][2], w[1][3]))
