# Exact check (own integer tables) of Corollary 4.2: the flow share added to the published partial-repayment lemma
# (r43a26ea3, Lemma PR), via Theorem 3.12.
#  (a) (DgA+):  A_{n-1,k} - gamma_{n-1} n A_{n-2,k-1} >= (gamma_{n-1}/2) (n(n-1-k)/(n-1)) b_{n-2,k}  (k>=1, k+2 <= n <= 2k+3); also with gamma_k on the left
#  (b) source of the diagonal excess: Delta_n >= a_n U_{n-2} + a'_n V_{n-2} + (k x/n) Delta_{n-1} + sum_{i=1}^{n-k-1} kappa_i Delta_{n-i}
#      for k+2 <= n <= 2k+3  (a'_n = x^2 gamma_{n-1} (n-1-k)/(2 (n-1)^2));   kappa_i = x^i C_{i,k}/i!
#  (c) partial repayment with the larger amplification:  h_m^+ <= U_m / (1 + Lambda^+_m(qbar)),
#      Lambda^+_m(qbar) = sum_{j=qbar+1}^{m} [a_j + a'_j 1(qbar+2 <= j <= 2k+3)] Gamma_{min(m-j,k)}(k/m; x),   qbar >= q_0(k).
#      Also prints Lambda (published, cell source only) and Lambda^+.
import sys
from math import comb, factorial
from fractions import Fraction as Fr
ks = [int(a) for a in sys.argv[1:]] or [6, 9, 12, 16, 20, 24]
for k in ks:
    NMAX = 3 * k + 4
    binom = [[comb(n, j) for j in range(n + 1)] for n in range(NMAX + 1)]
    def column(c):
        A = [1]
        for n in range(1, NMAX + 1):
            bn = binom[n - 1]
            A.append(sum(bn[j] * min(j + 1, c) * A[j] * A[n - 1 - j] for j in range(n)))
        return A
    cols = {c: column(c) for c in (k - 1, k, k + 1)}       # thresholds k-1,k,k+1 <-> levels <= k-2, k-1, k
    A = lambda n, l: cols[l + 1][n]                           # l in {k-2,k-1,k}
    b = lambda n, l: A(n, l) - A(n, l - 1)                    # l in {k-1,k}
    gam = lambda j: Fr(j + 1, j) ** (j - 2)
    x = 1 / gam(k)
    U = lambda j: x ** j * Fr(b(j, k - 1), factorial(j))
    V = lambda j: x ** j * Fr(b(j, k), factorial(j))
    Delta = {j: V(j) - U(j - 1) for j in range(k + 1, NMAX + 1)}; Delta[k] = Fr(0)
    # prime counts C_{i,k}: 1/A_{k-1}(x) = 1 - sum C_{i,k} x^i/i!   (A_{k-1}(x) = sum A_{n,k-1} x^n/n!)
    a_ = [Fr(A(n, k - 1), factorial(n)) for n in range(NMAX + 1)]
    cpr = [Fr(0)] * (NMAX + 1)
    for n in range(1, NMAX + 1):                              # a_n = sum_{i=1}^n c_i a_{n-i}
        cpr[n] = a_[n] - sum(cpr[i] * a_[n - i] for i in range(1, n))
    kappa = [cpr[i] * x ** i for i in range(NMAX + 1)]
    eps = lambda i: Fr((i - 1) ** (i - 1), factorial(i)) if i >= 2 else Fr(1)
    assert all(kappa[i] == x ** i * eps(i) for i in range(1, k + 1))       # kernel below the threshold
    a = lambda j: x * Fr(j - k, j * (j - 1))
    ap = lambda j: x * x * gam(j - 1) * Fr(j - 1 - k, 2 * (j - 1) ** 2)
    cnt = 0
    for n in range(k + 2, 2 * k + 4):
        lhs = A(n - 1, k) - gam(k) * n * A(n - 2, k - 1)
        assert lhs >= gam(n - 1) / 2 * Fr(n * (n - 1 - k), n - 1) * b(n - 2, k); cnt += 1            # (a)
        assert A(n - 1, k) - gam(n - 1) * n * A(n - 2, k - 1) >= gam(n - 1) / 2 * Fr(n * (n - 1 - k), n - 1) * b(n - 2, k); cnt += 1   # (a), stronger form
        assert ap(n) == a(n) * gam(n - 1) / (2 * gam(k)) * Fr(n, n - 1) * (1 - Fr(1, n - k)); cnt += 1
        assert ap(n) >= a(n) / 2 * (1 - Fr(1, n - k)); cnt += 1
        fb = k * x / n * Delta[n - 1] + sum(kappa[i] * Delta[n - i] for i in range(1, n - k))
        assert Delta[n] >= a(n) * U(n - 2) + ap(n) * V(n - 2) + fb; cnt += 1                            # (b)
    d = lambda j: b(j, k) - b(j, k - 1)
    q0 = min(j for j in range(k + 1, NMAX + 1) if d(j) > 0)
    assert all(d(j) >= 0 for j in range(q0, NMAX + 1))
    h = {}; s = Fr(0)
    for j in range(k, NMAX + 1):
        s -= V(j) - U(j); h[j] = s
    out = []
    for m in range(max(q0 + 1, k + 2), NMAX + 1):
        om = Fr(k, m)
        G = [Fr(1)]
        for t in range(1, min(m - k, k) + 1):
            G.append(x * (1 + om) * G[t - 1] + sum(x ** i * eps(i) * G[t - i] for i in range(2, t + 1)))
        Gam = [sum(G[:t + 1]) for t in range(len(G))]
        for qbar in (q0, min(q0 + 2, m - 1)):
            L0 = sum(a(j) * Gam[min(m - j, k)] for j in range(qbar + 1, m + 1))
            L1 = L0 + sum(ap(j) * Gam[min(m - j, k)] for j in range(qbar + 2, min(m, 2 * k + 3) + 1))
            hp = max(h[m], 0)
            assert hp * (1 + L0) <= U(m); assert hp * (1 + L1) <= U(m); cnt += 2                       # (c)
            if qbar == q0 and m in (2 * k, 2 * k + 3, NMAX): out.append((m, float(L0), float(L1), float(h[m] / U(m))))
    print("k=%d q0=%d checks %d OK;  (m, Lambda, Lambda+, h_m/U_m): %s" % (k, q0, cnt, ", ".join("(%d, %.3f, %.3f, %.2f)" % t for t in out)))
