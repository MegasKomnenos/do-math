# 상수 c의 (LE_c):  q_N(r) >= c (r+1)/N.  첫 층에서
#   Omega^c_k(x) := k [P_k(N) - w P_k(N-1) - (1-w) P_{k-1}(N-1)],  w = c x/(N-1),  N = k+x,
#   Omega^c_k(x) = sum_g K_c(g) Omega^c_k(x-g) + (k/(N-1)) sum_{m=1}^{x-1} Cc(m) alpha_k(x-m),
#   K_c(g) = (k-1)(N-1-cx) q_{N-1}(g) / ((N-1)(N-g-1-c(x-g))),
#   Cc(m) = Gamma_N(m) - c x q_{N-1}(m) + c (x-m) q_{N-1}(m) Lam(m) (k-1)/k + (1-c) sum_{g=1}^{m} q_{N-1}(g) Lam(g) R_{N-g}(m-g+1),
#   Lam(g) = (N-1-cx)/(N-g-1-c(x-g)).
# (1) 등식의 대조(작은 k, 정확한 유리수)  (2) 계수 Cc(m)의 부호(부동소수, Borel 수만)  (3) c=1/3의 충분조건
#   (K): 2 sum_{g=1}^{m-1} q_{N-1}(g) R_{N-g}(m-g+1) + q_{N-1}(m) >= G_N(m) = m q_{N-1}(m) - Gamma_N(m),   1 <= m <= (N-1)/2.
import sys
from fractions import Fraction as Fr
from math import factorial, lgamma, log, exp
import numpy as np

# ---------- (1) 정확한 대조 ----------
def exact_check(k, c):
    X = k+1; NMAX = k+X+2
    def col(cc, nmax):
        a = [Fr(1)]
        for n in range(1, nmax+1):
            s = Fr(0)
            for j in range(n):
                s += min(j+1, cc)*a[j]*a[n-1-j]
            a.append(s/n)
        return a
    aK = col(k, NMAX); aKm = col(k-1, NMAX)
    cay = [Fr(1)] + [Fr((n+1)**(n-1), factorial(n)) for n in range(1, NMAX+1)]
    tau = [None] + [Fr(j**(j-1), factorial(j)) for j in range(1, NMAX+2)]
    def Pk(N):  return aK[N-1]/cay[N-1] if N-1 >= k else Fr(1)
    def Pkm(N): return aKm[N-1]/cay[N-1] if N-1 >= k-1 else Fr(1)
    ek = [Fr(0)] + [1 - Fr(k, k+y)*Pk(k+y) for y in range(1, X+2)]
    al = [Fr(0)] + [ek[y]-ek[y-1] for y in range(1, X+2)]
    def q(N, g): return tau[g]*tau[N-g]/tau[N]
    def R(N, b): return 1 - sum(q(N, g) for g in range(1, b))
    def Om(x):
        N = k+x; w = c*Fr(x, N-1)
        return k*(Pk(N) - w*Pk(N-1) - (1-w)*Pkm(N-1))
    ok = True; allpos = True
    for x in range(2, k+2):
        N = k+x
        Lam = lambda g: (N-1-c*x)/(N-g-1-c*(x-g))
        ren = sum((k-1)*(N-1-c*x)*q(N-1, g)/((N-1)*(N-g-1-c*(x-g)))*Om(x-g) for g in range(1, x))
        src = Fr(0)
        for m in range(1, x):
            Gam = (N-1)*((1-R(N-1, m+1)) - (1-R(N, m+1)))
            Cc = Gam - c*x*q(N-1, m) + c*(x-m)*q(N-1, m)*Lam(m)*Fr(k-1, k) + (1-c)*sum(q(N-1, g)*Lam(g)*R(N-g, m-g+1) for g in range(1, m+1))
            src += Cc*al[x-m]
            if Cc < 0: allpos = False
        if Om(x) != ren + Fr(k, N-1)*src: ok = False
    return ok, allpos
for c in (Fr(1, 2), Fr(1, 3), Fr(2, 5)):
    res = [exact_check(k, c) for k in (3, 5, 8, 11)]
    print('c=%s: renewal identity for k=3,5,8,11: %s ; all coefficients >= 0: %s' % (c, all(r[0] for r in res), [r[1] for r in res]))

# ---------- (2),(3) 부동소수 ----------
def ltau(j): return (j-1)*log(j) - lgamma(j+1)
def qrow(M, upto):
    lt = LT
    g = np.arange(1, upto+1)
    return np.exp(lt[g] + lt[M-g] - lt[M])
NTOP = int(sys.argv[1]) if len(sys.argv) > 1 else 400
LT = np.array([0.0] + [ltau(j) for j in range(1, NTOP+3)])
def Rrows(N, mmax):
    # RR[g][b] = R_{N-g}(b) for g = 0..mmax, b = 1..mmax+1
    RR = np.zeros((mmax+1, mmax+3))
    for g in range(0, mmax+1):
        M = N-g
        up = min(mmax+1, M-1)
        qq = qrow(M, up)
        RR[g, 1] = 1.0
        RR[g, 2:up+2] = 1.0 - np.cumsum(qq)
    return RR
worstK = (1e9, None); badK = 0
worst = {}
cs = (0.5, 0.45, 0.4, 1.0/3, 0.25)
for c in cs: worst[c] = (1e9, None, 0)
Ns = list(range(5, min(NTOP, 260)+1)) + [n for n in (300, 400, 600, 800, 1200, 1600, 2400, 3200, 5000) if n <= NTOP]
for N in Ns:
    mmax = (N-1)//2
    RR = Rrows(N, mmax)
    qA = qrow(N-1, mmax)            # q_{N-1}(g), g=1..mmax
    qB = qrow(N, mmax)
    PiA = np.cumsum(qA); PiB = np.cumsum(qB)
    Gam = (N-1)*(PiA - PiB)         # Gamma_N(m), m=1..mmax
    G = np.arange(1, mmax+1)*qA - Gam
    # S(m) = sum_{g=1}^{m-1} q_{N-1}(g) R_{N-g}(m-g+1)
    S = np.zeros(mmax+1)
    for m in range(1, mmax+1):
        g = np.arange(1, m)
        S[m] = np.sum(qA[g-1]*RR[g, m-g+1]) if m >= 2 else 0.0
    ratio = (2*S[1:] + qA)/G
    i = int(np.argmin(ratio))
    if ratio[i] < worstK[0]: worstK = (float(ratio[i]), (N, i+1))
    badK += int(np.sum(ratio < 1))
    # 실제 계수 Cc(m): 모든 x (k = N-x, 2 <= x <= k+1, m <= x-1)
    for x in range(2, (N+1)//2 + 1):
        k = N-x
        if k < 2 or x > k+1: continue
        ms = np.arange(1, x)
        for c in cs:
            Lam = (N-1-c*x)/(N-ms-1-c*(x-ms))
            # T(m) = sum_{g=1}^{m} q_{N-1}(g) Lam(g) R_{N-g}(m-g+1)
            T = np.zeros(x)
            for m in range(1, x):
                g = np.arange(1, m+1)
                T[m] = np.sum(qA[g-1]*Lam[g-1]*RR[g, m-g+1])
            Cc = Gam[ms-1] - c*x*qA[ms-1] + c*(x-ms)*qA[ms-1]*Lam*(k-1.0)/k + (1-c)*T[1:]
            rel = Cc/(ms*qA[ms-1])       # 갱신 질량 m q(m)에 대한 상대값
            j = int(np.argmin(rel))
            w0 = worst[c]
            nneg = w0[2] + int(np.sum(Cc < 0))
            worst[c] = ((float(rel[j]), (N, x, j+1), nneg) if rel[j] < w0[0] else (w0[0], w0[1], nneg))
print('(K): N in %d..%d (sampled above 260): min ratio LHS/RHS = %.4f at (N,m)=%s ; violations: %d' % (Ns[0], Ns[-1], worstK[0], worstK[1], badK))
for c in cs:
    print('c=%.4f: min over (N,x,m) of Cc(m)/(m q_{N-1}(m)) = %.5f at (N,x,m)=%s ; number of negative coefficients: %d' % (c, worst[c][0], worst[c][1], worst[c][2]))
