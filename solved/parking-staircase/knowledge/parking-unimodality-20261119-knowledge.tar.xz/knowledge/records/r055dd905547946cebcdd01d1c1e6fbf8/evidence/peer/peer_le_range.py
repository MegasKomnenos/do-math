# Peer re-check (exact integers, own code) of two producer observations:
#   (a) Theorem 3.1 at every first-layer cell y <= n <= 2y+1 with n <= NMAX-1,
#   (b) the range of theta := q_N(r) N/(r+1) over ALL cells 1 <= y <= n-1, 2 <= n <= NMAX-1 (conjecture (LE): theta >= 1/2).
# A_n(c) := number of parking functions of length n with all displacements < c  (= A_{n,c-1}),
# integer recursion (last car):  A_n(c) = sum_{j=0}^{n-1} C(n-1,j) min(j+1,c) A_j(c) A_{n-1-j}(c).
import sys
from math import comb
from fractions import Fraction as Fr
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 151
binom = [[comb(n, j) for j in range(n + 1)] for n in range(NMAX + 1)]
def column(c):
    A = [1]
    for n in range(1, NMAX + 1):
        bn = binom[n - 1]
        A.append(sum(bn[j] * min(j + 1, c) * A[j] * A[n - 1 - j] for j in range(n)))
    return A
cols = {c: column(c) for c in range(0, NMAX + 2)}      # cols[c][n] = A_{n,c-1}; c = 0 gives A_{n,-1} = 0 for n >= 1
def A(n, l):                                           # A_{n,l}
    if l < 0: return 1 if n == 0 else 0
    return cols[min(l + 1, NMAX + 1)][n]
p = [(n + 1) ** (n - 1) if n >= 1 else 1 for n in range(NMAX + 1)]
for n in range(1, NMAX + 1):
    assert A(n, n - 1) == p[n]
first = viol = 0; minratio = None; mn = None; mx = None; cells = 0; below_half = 0
for n in range(2, NMAX):
    for y in range(1, n):
        b = A(n, y) - A(n, y - 1)
        num = (A(n + 1, y) * p[n] - A(n, y - 1) * p[n + 1]) * (n + 1)
        den = p[n + 1] * b * (n + 1 - y)
        th = Fr(num, den); cells += 1
        if mn is None or th < mn[0]: mn = (th, n, y)
        if mx is None or th > mx[0]: mx = (th, n, y)
        if 2 * th < 1: below_half += 1
        if n <= 2 * y + 1:
            first += 1
            c = Fr(y + 1, n + y + 2)
            if th < c: viol += 1
            r = th / c
            if minratio is None or r < minratio[0]: minratio = (r, n, y)
print("rows n <= %d: cells %d ; theta < 1/2 at %d cells" % (NMAX - 1, cells, below_half))
print("min theta = %.5f at (n,y)=(%d,%d) ; max theta = %.5f at (n,y)=(%d,%d)" % (float(mn[0]), mn[1], mn[2], float(mx[0]), mx[1], mx[2]))
print("first-layer cells %d ; violations of Theorem 3.1: %d ; min theta/c = %.6f at (n,y)=(%d,%d)" % (first, viol, float(minratio[0]), minratio[1], minratio[2]))
