from pf import *
root_table = {1:[1],2:[2,1],3:[6,7,3],4:[24,51,34,16],5:[120,421,377,253,125],6:[720,3963,4594,3688,2546,1296],
              7:[5040,42253,62145,57398,46142,32359,16807]}
ok = True
for n in range(1, 8):
    rec = [b(n, l) for l in range(n)]
    br = brute(n) if n <= 7 else None
    ok &= (rec == root_table[n]) and (br == rec)
    print(n, rec == root_table[n], br == rec)
print("ALL OK" if ok else "MISMATCH")
# sanity: totals
for n in (10, 20, 30):
    assert sum(b(n, l) for l in range(n)) == (n + 1) ** (n - 1)
print("totals ok")
