# Peer exploration tied to one step: what does Theorem T buy inside the published profile-free sufficient condition
# (r3bd6df85 exposition 9.6, eq (9.3)-(9.4))?  There the comparison profile Phi^1 assumes the up-move probability theta_n = 1.
# Theorem T gives theta_n <= 1 - k(n-k+1)/(n(n+k))  (first layer).   Floats (double) ; identities re-checked numerically.
import numpy as np, sys, math
def run(k, T=None):
    T = T or 2 * k - 1
    x = (k / (k + 1)) ** (k - 2)
    lx = math.log(x)
    NN = 2 * k + 2
    lgam = [math.lgamma(i + 1) for i in range(NN + 2)]
    om = np.array([math.exp(n * lx + (n - 1) * math.log(n + 1) - lgam[n]) for n in range(NN + 1)])       # omega_n
    pi = np.array([0.0] + [math.exp(n * lx + (n - 2) * math.log(n) - lgam[n]) for n in range(1, NN + 1)])  # pi_n
    kap = np.array([0.0, x] + [math.exp(m * lx + (m - 1) * math.log(m - 1) - lgam[m]) for m in range(2, NN + 1)])
    def col(c):   # tilted u_n(c) = x^n A_{n,c-1}/n!
        u = np.zeros(NN + 1); u[0] = 1.0
        w = np.minimum(np.arange(1, NN + 2), c).astype(float)
        for n in range(1, NN + 1):
            u[n] = x * np.dot(w[:n] * u[:n], u[n - 1::-1][:n]) / n
        return u
    um, u0, up = col(k - 1), col(k), col(k + 1)
    U = u0 - um; V = up - u0
    Phi = np.zeros(NN + 2)
    for n in range(1, NN + 1): Phi[n] = u0[n - 1] / om[n - 1]
    hT = -sum(V[j] - U[j] for j in range(k, T + 1))
    # Green functions
    def green(c):
        G = np.zeros((T + 1, T + 1))
        for M in range(k, T + 1):
            G[M, M] = 1.0
            for n in range(M + 1, T + 1):
                # sum_{m=1}^{n-M} kap_m G[n-m,M]
                G[n, M] = c * x / n * G[n - 1, M] + np.dot(kap[1:n - M + 1], G[n - 1:M - 1:-1, M] if M > 0 else G[n - 1::-1, M])
        return G
    Gm = green(k - 1); Gp = green(k + 1)
    cGm = Gm.sum(axis=0); cGp = Gp.sum(axis=0)       # calG(T;M)
    W = np.zeros(T + 2)
    for M in range(k + 1, T + 1): W[M] = (cGp[M] - cGm[M]) * pi[M]
    debt = cGm[k] * pi[k]
    lhs93 = sum(W[M] * Phi[M] for M in range(k + 1, T + 1)) - debt
    # U from Green (check)
    Ucheck = max(abs(sum(Gm[j, M] * pi[M] * Phi[M] for M in range(k, j + 1)) - U[j]) / U[j] for j in range(k, T + 1))
    def comp(thbar):
        Ph = np.zeros(T + 2); Ph[k] = Ph[k + 1] = 1.0
        Uc = np.zeros(T + 1)
        for n in range(k + 1, T):
            j = n - 1
            Uc[j] = sum(Gm[j, M] * pi[M] * Ph[M] for M in range(k, j + 1))
            Ph[n + 1] = Ph[n] - thbar(n) * Uc[j] / om[n - 1]
        H = sum(W[M] * Ph[M] for M in range(k + 1, T + 1)) - debt
        # dual weights y
        y = np.zeros(T + 2)
        for M in range(T - 1, k + 1, -1):
            y[M - 1] = W[M] + y[M] - pi[M] * sum(y[n] * thbar(n) / om[n - 1] * Gm[n - 1, M] for n in range(M + 1, T))
        slack = sum(y[n] * (thbar(n) * U[n - 1] / om[n - 1] - (Phi[n] - Phi[n + 1])) for n in range(k + 1, T))
        gmin = min(thbar(n) * U[n - 1] / om[n - 1] - (Phi[n] - Phi[n + 1]) for n in range(k + 1, T))
        ident = abs((-hT) - (H + slack)) / pi[k]
        return H, y[k + 1:T - 1].min(), Ph, ident, gmin
    th1 = lambda n: 1.0
    thT = lambda n: 1.0 - k * (n - k + 1) / (n * (n + k))          # Theorem T
    thLE = lambda n: 1.0 - (n - k + 1) / (2.0 * n)                 # conjecture (LE), constant 1/2
    thEUlow = lambda n: (k - 1) / n                                # published LOWER bound on theta (for reference: gives an upper comparison)
    res = {}
    for name, th in (("theta=1", th1), ("TheoremT", thT), ("LE(1/2)", thLE)):
        H, ymin, Ph, ident, gmin = comp(th); res[name] = (H / pi[k], ymin / pi[k], H / debt, ident, gmin)
    # true theta range
    tau = max(((Phi[n] - Phi[n + 1]) / (U[n - 1] / om[n - 1])) * n / k - 1 for n in range(k + 1, T))
    print("k=%d T=%d  -h_T/pi_k=%.3f  (9.3) rhs/pi_k=%.3f  U-check rel err=%.1e  debt/pi_k=%.2f  max tau_n=%.3f" % (k, T, -hT / pi[k], lhs93 / pi[k], Ucheck, debt / pi[k], tau))
    for name in res:
        print("    %-9s  H/pi_k=%.3f   H/debt=%.2f%%   min y/pi_k=%.3f   |(-h_T)-(H+sum y g)|/pi_k=%.1e   min_n g_n %s 0" % (name, res[name][0], 100 * res[name][2], res[name][1], res[name][3], ">=" if res[name][4] >= 0 else "<"))
for k in [int(a) for a in sys.argv[1:]] or [40, 60, 100, 160]:
    run(k)
