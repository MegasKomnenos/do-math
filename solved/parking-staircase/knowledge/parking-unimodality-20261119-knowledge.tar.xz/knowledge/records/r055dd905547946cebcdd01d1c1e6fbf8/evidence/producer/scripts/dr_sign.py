# 부호만 쓰는 환원:  (Dg) 와
#   (M1_a): Gamma_j = P_{j-1}(k-1) - P_j(k) <= 0   (k+a+1 <= j <= 2k)
#   (M2_a): U_i >= U_{2k}                          (k+a <= i <= 2k-1; 대각 기울임)
# 이면  sum_{j=k+1}^{2k} Delta_j >= U_{2k} * S(a),  S(a) = sum_{i=k+a}^{2k-1} (psi(i+1)/gamma_k - 1).
# 실제 a*(k) (Gamma 가 그 뒤로 음이 아닌 것이 없는 가장 작은 a), S(a*), (M2) 의 성립을 본다.
import sys
from mpmath import mp, mpf
mp.dps = 40
def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
for k in [int(a) for a in sys.argv[1:]]:
    T = 2*k; nmax = T+2
    aP = col(k+1, nmax); a0 = col(k, nmax); aM = col(k-1, nmax); cay = col(10**9, nmax)
    x = (mpf(k)/(k+1))**(k-2)
    w = [x**j*cay[j] for j in range(nmax+1)]
    Pk = [(aP[n]-a0[n])/cay[n] for n in range(nmax+1)]; Pk1 = [(a0[n]-aM[n])/cay[n] for n in range(nmax+1)]
    U = [w[n]*Pk1[n] for n in range(nmax+1)]
    Gam = {j: Pk1[j-1] - Pk[j] for j in range(k+1, T+1)}
    astar = max([j-k for j in range(k+1, T+1) if Gam[j] > 0] + [0])       # Gamma_j <= 0 for j >= k+astar+1
    def S(a): return sum(w[i+1]/w[i] - 1 for i in range(k+a, T))
    # 가장 큰 a 로서 S(a) >= 1
    amax = max(a for a in range(0, k) if S(a) >= 1)
    m2 = min(i-k for i in range(k, T) if all(U[ii] >= U[T] for ii in range(i, T)))   # (M2_a) 가 성립하는 가장 작은 a
    lower = sum((w[i+1]/w[i] - 1)*U[i] for i in range(k+astar, T))
    tot = sum(w[j]*Pk[j] - U[j-1] for j in range(k+1, T+1))
    print('k=%d: a*(k)=%d (a*/k=%.3f) ; S(a*)=%.4f ; largest a with S(a)>=1: %d (%.3f k) ; (M2_a) holds from a=%d ; tilt sum beyond a* / U_2k = %.4f ; true sum Delta / U_2k = %.4f'
          % (k, astar, astar/float(k), float(S(astar)), amax, amax/float(k), m2, float(lower/U[T]), float(tot/U[T])))
