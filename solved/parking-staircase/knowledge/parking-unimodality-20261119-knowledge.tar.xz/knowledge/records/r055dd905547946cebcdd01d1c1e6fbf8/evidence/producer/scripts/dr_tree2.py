# 나무 수준의 열 방정식과 쌍대 꼴.
#  D(t) = p_t(k) - p_t(k-1)  (나무 칸의 차),  c2(t) = p_t(k-1) + p_t(k).
#  (##)  t D(t) = -[t=k] + k sum_{g=1}^{t-k} q_t(g) D(t-g) + sum_{g=1}^{t-k} q_t(g) c2(t-g)     (k <= t <= 2k)
#  (TDR) sum_{t=k}^{2k} w_t D(t) >= 0,  w_t = W(2k-t) w_{t-1}   <=>  (DR) (끝의 아주 작은 둘째 층 항을 빼고)
#  쌍대: GG(s) = (1/s)[w_s + k sum_{t>s} q_t(t-s) GG(t)],  HH(u) = sum_{s>u} q_s(s-u) GG(s)
#        sum_t w_t D(t) = sum_{u=k}^{2k-1} HH(u) c2(u) - GG(k)
import sys
from mpmath import mp, mpf
mp.dps = 50
def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
for k in [int(a) for a in sys.argv[1:]]:
    T = 2*k; nmax = T+2
    aP = col(k+1, nmax); a0 = col(k, nmax); aM = col(k-1, nmax); cay = col(10**9, nmax)
    x = (mpf(k)/(k+1))**(k-2)
    w = [x**j*cay[j] for j in range(nmax+1)]
    F = lambda a, n: a[n]/cay[n]
    def p(t, lev):
        n = t-1
        if t < lev+1: return mpf(0)
        if lev == k:   Fl = F(aP, n); Pl = F(aP, n) - F(a0, n)
        else:          Fl = F(a0, n); Pl = F(a0, n) - F(aM, n)
        return (Fl + lev*Pl)/t
    tau = [None, mpf(1)]
    for j in range(2, nmax+2): tau.append(tau[-1]*(mpf(j)/(j-1))**(j-2))
    def q(M, g): return tau[g]*tau[M-g]/tau[M]
    D = {t: p(t, k) - p(t, k-1) for t in range(k, T+1)}
    c2 = {t: p(t, k) + p(t, k-1) for t in range(k, T+1)}
    # (##) 대조
    err = mpf(0)
    for t in range(k, T+1):
        rhs = (-1 if t == k else 0) + k*sum(q(t, g)*D[t-g] for g in range(1, t-k+1)) + sum(q(t, g)*c2[t-g] for g in range(1, t-k+1))
        err = max(err, abs(t*D[t] - rhs))
    Wc = [mpf(0)]*(nmax+1); s = mpf(0)
    for i in range(nmax+1):
        s += w[i]; Wc[i] = s
    wt = {t: Wc[T-t]*w[t-1] for t in range(k, T+1)}
    GG = {}
    for sidx in range(T, k-1, -1):
        GG[sidx] = (wt[sidx] + k*sum(q(t, t-sidx)*GG[t] for t in range(sidx+1, T+1)))/sidx
    HH = {u: sum(q(sidx, sidx-u)*GG[sidx] for sidx in range(u+1, T+1)) for u in range(k, T)}
    total = sum(wt[t]*D[t] for t in range(k, T+1))
    dual = sum(HH[u]*c2[u] for u in range(k, T)) - GG[k]
    u0 = w[k-1]/k        # 여기서는 x를 곱하지 않은 단위 (xi_t = x w_{t-1} p_t 의 x는 공통 인자)
    pos = sum(HH[u]*c2[u] for u in range(k+1, T))
    rhs0 = GG[k] - HH[k]*c2[k]
    # 분포: 양의 쪽이 어디서 오는가
    cum = mpf(0); marks = {}
    for u in range(k+1, T):
        cum += HH[u]*c2[u]
        for frac in (0.25, 0.5, 0.75, 0.9):
            if frac not in marks and cum >= frac*pos: marks[frac] = u-k
    print('k=%d: (##) max err %.1e | sum w_t D(t) / u0 = %.4f (dual form %.4f) | LHS sum_{u>k} HH c2 = %.4f, RHS GG(k)-HH(k)/k = %.4f (ratio %.4f) | quantiles of LHS in x=u-k: %s'
          % (k, float(err), float(total/u0), float(dual/u0), float(pos/u0), float(rhs0/u0), float(pos/rhs0), marks))
    print('     HH(u)/u0 at x=u-k: ' + ', '.join('%d:%.3f' % (xx, float(HH[k+xx]/u0)) for xx in (1, 2, 5, 10, 20, 40, k//2, k-5, k-1) if k+xx < T))
    print('     k*c2(u) at x: ' + ', '.join('%d:%.4f' % (xx, float(k*c2[k+xx])) for xx in (1, 2, 5, 10, 20, 40, k//2, k-5, k-1) if k+xx <= T))
