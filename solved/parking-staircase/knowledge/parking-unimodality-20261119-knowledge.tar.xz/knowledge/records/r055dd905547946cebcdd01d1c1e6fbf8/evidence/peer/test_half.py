# Peer test tied to one step: Lemma T1 at c = 1/2 gives  Omega^{1/2}_k(x) = sum K(g) Omega^{1/2}_k(x-g) + (k/(N-1)) sum_m C^{1/2}(m) alpha_k(x-m)
# (exact identity, alpha-only source).  Is the source >= 0 ?  Coefficients after the producer's elimination (Prop 13)?
from fractions import Fraction as Fr
from math import factorial
import sys
def tau(j): return Fr(j ** (j - 1), factorial(j))
_q = {}
def q(N, g):
    if (N, g) not in _q: _q[(N, g)] = tau(g) * tau(N - g) / tau(N)
    return _q[(N, g)]
_Pi = {}
def Pi(N, m):
    if m <= 0: return Fr(0)
    if (N, m) not in _Pi: _Pi[(N, m)] = Pi(N, m - 1) + q(N, m)
    return _Pi[(N, m)]
def Gam(N, m): return (N - 1) * (Pi(N - 1, m) - Pi(N, m))
def kst(N, m): return Pi(N, m) - Pi(N - 1, m - 1)
def R(N, b): return 1 - Pi(N, b - 1)
def coeffs(k, x, c):
    N = k + x
    Lam = lambda g: (N - 1 - c * x) / (N - 1 - c * x - g * (1 - c))
    C = {}
    for m in range(1, x):
        C[m] = (Gam(N, m) - c * x * q(N - 1, m) + c * (x - m) * Fr(k - 1, k) * Lam(m) * q(N - 1, m)
                + (1 - c) * sum(q(N - 1, g) * Lam(g) * R(N - g, m - g + 1) for g in range(1, m + 1)))
    return C
def eliminate(k, x, C):
    N = k + x; C = dict(C); nel = 0
    for s in range(1, x - 1):
        if C[s] < 0:
            nel += 1
            for m in range(s + 1, x):
                E = (k * kst(N - s, m - s) + Fr(k, x - s - 1) * R(N - s - 1, m - s)) / (N - s)
                C[m] += C[s] * E
            C[s] = Fr(0)
    return C, nel
KMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 14
c = Fr(1, 2); bad = 0; tot = 0; negraw = 0; maxel = 0; firstneg = None
for k in range(2, KMAX + 1):
    for x in range(2, k + 2):
        C = coeffs(k, x, c); tot += 1
        if any(v < 0 for v in C.values()):
            negraw += 1
            if firstneg is None: firstneg = (k, x, [m for m in C if C[m] < 0])
        C2, nel = eliminate(k, x, C); maxel = max(maxel, nel)
        if any(v < 0 for v in C2.values()): bad += 1; print("FAIL after elimination", k, x, [(m, float(v)) for m, v in C2.items() if v < 0])
print("c=1/2: (k,x) pairs %d ; with some raw negative coefficient %d (first: %s); failures after elimination %d ; max #eliminations %d" % (tot, negraw, firstneg, bad, maxel))
