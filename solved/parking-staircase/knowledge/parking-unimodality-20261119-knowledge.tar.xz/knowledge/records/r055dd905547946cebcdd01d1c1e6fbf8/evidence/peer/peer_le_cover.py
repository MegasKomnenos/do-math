# Observation (double precision): outside the first layer, every cell (N-1, y) with 2 <= y, 2y+3 <= N <= NMAX is covered by
#   (S) the source of the first-tree recursion (3.12), c = 1/2, is >= 0 at N                      [Proposition 3.14], or
#   (D) F_{N-1}(y-1) <= (2 G_Y/e - 1) F_{N-1}(y)                                                   [Proposition 3.15 (b)].
# Reports the cells covered by neither, and the smallest source/scale over the cells where (D) fails.  Not a proof step.
import sys, math
import numpy as np
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 300
lg = [math.lgamma(i + 1) for i in range(NMAX + 3)]
lp = [0.0] + [(n - 1) * math.log(n + 1) for n in range(1, NMAX + 2)]
lc = [lp[n] - lg[n] for n in range(NMAX + 2)]
def col(th):
    b = np.zeros(NMAX + 1); b[0] = 1.0
    w = np.minimum(np.arange(1, NMAX + 2), th).astype(float)
    for n in range(1, NMAX + 1):
        b[n] = math.exp(-1) * np.dot(w[:n] * b[:n], b[n - 1::-1][:n]) / n
    return b
def logpi(n, j): return lg[n - 1] - lg[j - 1] - lg[n - j] + (j - 1) * math.log(j) + lp[n - j] - lp[n]
PI = {n: np.array([0.0] + [math.exp(logpi(n, j)) for j in range(1, n + 1)]) for n in range(1, NMAX + 1)}
scalev = np.array([math.exp(n - lc[n]) for n in range(NMAX + 1)])
cols = {}
def surv(th):
    if th not in cols: cols[th] = col(th) * scalev
    return cols[th]
ymax = (NMAX - 3) // 2
cells = both = onlyS = onlyD = neither = 0
worst = (1e9, None)
for y in range(2, ymax + 1):
    Y = y + 1
    A = surv(Y); B = surv(y)
    cols.pop(y - 1, None)
    h = np.array([1.0] * (Y + 1) + [Y / j for j in range(Y + 1, NMAX + 3)])
    L = np.zeros(NMAX + 1)
    for N in range(1, NMAX + 1): L[N] = A[N] - (N - y) / (2.0 * N) * A[N - 1] - (1 - (N - y) / (2.0 * N)) * B[N - 1]
    rY = (1 + 1.0 / Y) ** (Y - 1); GY = 1.0 + sum(math.exp((i - 1) * math.log(i - 1) - lg[i] - (i - 1) * math.log(rY)) for i in range(2, Y + 1))
    wy = 2 * GY / math.e - 1
    for N in range(2 * y + 3, NMAX + 1):
        i = np.arange(1, N)
        ker = np.sum(PI[N - 1][1:N] * ((i / N) * h[i + 1] * A[N - 1 - i] * L[i] + ((N - i) / N) * h[i] * A[i - 1] * L[N - i]))
        scale = (N - y) / N * (A[N - 1] - B[N - 1])
        rel = (L[N] - ker) / scale
        S = rel >= 0; D = B[N - 1] <= wy * A[N - 1]
        cells += 1
        if S and D: both += 1
        elif S: onlyS += 1
        elif D: onlyD += 1
        else: neither += 1
        if not D and rel < worst[0]: worst = (rel, (y, N))
print("levels 2 <= y <= %d, sizes 2y+3 <= N <= %d: %d cells; (S) and (D): %d, (S) only: %d, (D) only: %d, neither: %d" % (ymax, NMAX, cells, both, onlyS, onlyD, neither))
print("smallest source/scale over the cells where (D) fails: %+.4f at (y, N) = %s" % worst)
