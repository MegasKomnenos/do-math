# 상수를 x에 따라 바꾼 꼴 c(x) = k/(2k+x-1) = k/(N+k-1) 에서 계수 Cc(m) (le_third.py의 식)의 부호를 본다. Borel 수만 쓴다.
import sys
from math import lgamma, log
import numpy as np
NTOP = int(sys.argv[1])
LT = np.array([0.0] + [(j-1)*log(j) - lgamma(j+1) for j in range(1, NTOP+3)])
def qrow(M, upto):
    g = np.arange(1, upto+1)
    return np.exp(LT[g] + LT[M-g] - LT[M])
def Rrows(N, mmax):
    RR = np.zeros((mmax+1, mmax+3))
    for g in range(0, mmax+1):
        M = N-g; up = min(mmax+1, M-1)
        RR[g, 1] = 1.0; RR[g, 2:up+2] = 1.0 - np.cumsum(qrow(M, up))
    return RR
forms = {'k/(N+k-1)': lambda k, x: k/(2.0*k+x-1), 'k/(N+k)': lambda k, x: k/(2.0*k+x), '(k-1)/(N+k-1)': lambda k, x: (k-1.0)/(2.0*k+x-1)}
worst = {name: (1e9, None, 0) for name in forms}
Ns = list(range(4, min(NTOP, 200)+1)) + [n for n in (260, 400, 800, 1600) if n <= NTOP]
for N in Ns:
    mmax = (N-1)//2
    RR = Rrows(N, mmax)
    qA = qrow(N-1, mmax); qB = qrow(N, mmax)
    Gam = (N-1)*(np.cumsum(qA) - np.cumsum(qB))
    for x in range(2, (N+1)//2 + 1):
        k = N-x
        if k < 2 or x > k+1: continue
        ms = np.arange(1, x)
        for name, cf in forms.items():
            c = cf(k, x)
            Lam = (N-1-c*x)/(N-ms-1-c*(x-ms))
            T = np.zeros(x)
            for m in range(1, x):
                g = np.arange(1, m+1)
                T[m] = np.sum(qA[g-1]*Lam[g-1]*RR[g, m-g+1])
            Cc = Gam[ms-1] - c*x*qA[ms-1] + c*(x-ms)*qA[ms-1]*Lam*(k-1.0)/k + (1-c)*T[1:]
            rel = Cc/(ms*qA[ms-1]); j = int(np.argmin(rel))
            w0 = worst[name]; nneg = w0[2] + int(np.sum(Cc < 0))
            worst[name] = ((float(rel[j]), (N, x, j+1), nneg) if rel[j] < w0[0] else (w0[0], w0[1], nneg))
for name in forms:
    print('c(x) = %s: min Cc(m)/(m q(m)) = %.6f at (N,x,m)=%s ; negative coefficients: %d' % (name, worst[name][0], worst[name][1], worst[name][2]))
