# Exact (rational) check of every step of the proposed proof of (H_{k,z}):  2 C(m) >= Dbar(m)  for 2 <= m <= z-1.
# Notation: N = k+z, L = 2k+z-2, q(g) = q_{N-1}(g), tau_j = j^(j-1)/j!.
from fractions import Fraction as Fr
from math import factorial
import sys
def tau(j): return Fr(j ** (j - 1), factorial(j))
def calR(t): return Fr(t + 1, t) ** (t - 1)
_q = {}
def q(M, g):
    if (M, g) not in _q: _q[(M, g)] = tau(g) * tau(M - g) / tau(M)
    return _q[(M, g)]
_Pi = {}
def Pi(M, m):
    if m <= 0: return Fr(0)
    if (M, m) not in _Pi: _Pi[(M, m)] = Pi(M, m - 1) + q(M, m)
    return _Pi[(M, m)]
def R(M, b): return 1 - Pi(M, b - 1)
def Gam(N, m): return (N - 1) * (Pi(N - 1, m) - Pi(N, m))
def kap(N, m): return Pi(N, m) - Pi(N - 1, m - 1)          # stay kernel
def G(N, m): return m * q(N - 1, m) - Gam(N, m)

KMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 22
cnt_id = cnt_in = 0
worst2 = None; worst3 = None
for k in range(2, KMAX + 1):
    for z in range(3, k + 2):
        N = k + z; L = 2 * k + z - 2
        Lam = lambda g: Fr(L, L - g)
        q1 = q(N - 1, 1)
        C = {}
        for m in range(1, z):
            C[m] = (Gam(N, m) - Fr(z, 2) * q(N - 1, m) + Fr(1, 2) * (z - m) * Fr(k - 1, k) * Lam(m) * q(N - 1, m)
                    + Fr(1, 2) * sum(q(N - 1, g) * Lam(g) * R(N - g, m - g + 1) for g in range(1, m + 1)))
        # (3.6)
        assert C[1] == Gam(N, 1) - q1 * Fr((z - 2) * (N - 1), 2 * k * (L - 1)); cnt_id += 1
        for m in range(2, z):
            E = (k * kap(N - 1, m - 1) + Fr(k, z - 2) * R(N - 2, m - 1)) / (N - 1)
            T = sum(q(N - 1, g) * Lam(g) * R(N - g, m - g + 1) for g in range(1, m))
            mu = Fr(L * (k - z + m) + k * m * (z - m), k * (L - m))
            rho = R(N - 1, m)
            # step 1: identity
            assert 2 * C[m] == Gam(N, m) + T + mu * q(N - 1, m) - G(N, m); cnt_id += 1
            # step 4: D <= Dbar
            D = max(-2 * C[1], 0) * E
            Dbar = q1 * ((z - 1) * kap(N - 1, m - 1) + rho) / (L - 1)
            assert R(N - 2, m - 1) == rho + kap(N - 1, m - 1); cnt_id += 1
            assert D <= Dbar; cnt_in += 1
            assert kap(N - 1, m - 1) <= q(N - 1, m - 1); cnt_in += 1
            val = 2 * C[m] - Dbar
            assert val > 0, (k, z, m); cnt_in += 1
            if m == 2:
                # closed form of the m = 2 quantity
                B2 = Fr(N * N - k * N - 4 * N + 2 * k * k - 2 * k + 4, k * (N + k - 4))
                q2 = q(N - 1, 2)
                Fbar = 2 * Gam(N, 2) + q1 - 2 * q1 * q1 * Fr(N - 2, L - 1) - q2 * B2
                assert Fbar == val, (k, z); cnt_id += 1
                assert q1 == 1 / calR(N - 2) and q2 == q1 / calR(N - 3); cnt_id += 2
                # junction value (real k0 = (N-1)/2)
                F0 = 2 * Gam(N, 2) + q1 - 4 * q1 * q1 * Fr(N - 2, 3 * N - 7) - q2 * Fr(4 * N * N - 22 * N + 22, 3 * (N - 1) * (N - 3))
                assert Fbar >= F0 > 0, (k, z); cnt_in += 2
                rel = val / (2 * C[m] + Dbar)
                if worst2 is None or rel < worst2[0]: worst2 = (rel, k, z)
            else:
                tN = Fr(N - 2, 2 * N * (N - 1))
                # step 2, 3
                S = sum(q(N - 1, g) * R(N - g, m - g + 1) for g in range(1, m))
                assert T >= Fr(L, L - 1) * S >= Fr(L, L - 1) * rho * (1 - rho); cnt_in += 2
                assert G(N, m) <= rho / 2 + tN; cnt_in += 1
                # step 6: concavity bound   g(rho) - tN >= -((N-2)/(N(N-3))) (rho - 1/(N-1))
                g = rho * (Fr(1, 2) - rho) + rho * (1 - rho - q1) / (L - 1)
                assert Fr(1, N - 1) <= rho < Fr(1, 2); cnt_in += 1
                assert g - tN >= -Fr(N - 2, N * (N - 3)) * (rho - Fr(1, N - 1)); cnt_in += 1
                # step 7
                assert rho - Fr(1, N - 1) == Fr(1, 2) * sum(q(N - 1, gg) for gg in range(m, N - m)); cnt_id += 1
                assert rho - Fr(1, N - 1) <= Fr(N - 2 * m, 2) * q(N - 1, m); cnt_in += 1
                assert g - tN >= -q(N - 1, m) / 2; cnt_in += 1
                # step 8
                assert mu >= 1; cnt_in += 1
                # step 9
                low = q(N - 1, m) / 2 - q1 * (z - 1) * q(N - 1, m - 1) / (L - 1)
                assert val >= Gam(N, m) + low >= low; cnt_in += 2
                assert q(N - 1, m) / q(N - 1, m - 1) == calR(m - 1) / calR(N - 1 - m); cnt_id += 1
                assert low >= q(N - 1, m - 1) / calR(N - 2) / 4; cnt_in += 1
                rel = val / (2 * C[m] + Dbar)
                if worst3 is None or rel < worst3[0]: worst3 = (rel, k, z, m)
print("k <= %d: identities %d, inequalities %d: ALL OK" % (KMAX, cnt_id, cnt_in))
print("m = 2: smallest relative margin (2C-Dbar)/(2C+Dbar) = %.4f at (k,z)=(%d,%d)" % (float(worst2[0]), worst2[1], worst2[2]))
print("m >= 3: smallest relative margin = %.4f at (k,z,m)=(%d,%d,%d)" % (float(worst3[0]), worst3[1], worst3[2], worst3[3]))
