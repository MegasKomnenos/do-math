# (LE) 시험, 더 큰 범위: theta_n(y) = J_n(y) / [((n+1-y)/(n+1)) Pr(M_n=y)],  J_n(y)=Pr(M_{n+1}<=y)-Pr(M_n<=y-1)
# 고정밀 부동소수 (mpmath). 열별 재귀 a_n(c) = A_{n,c-1}/n!.
import sys
from mpmath import mp, mpf
mp.dps = 60
NMAX = int(sys.argv[1])
cols = {}
def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
cay = col(10**9, NMAX+1)
for c in range(1, NMAX+2):
    cols[c] = col(c, NMAX+1)
def S(n, c):   # Pr(M_n <= c-1)
    if c <= 0: return mpf(0)
    if c >= n: return mpf(1)
    return cols[c][n]/cay[n]
mn = (mpf(10), None); mx = (mpf(0), None)
rowmin = {}
for n in range(2, NMAX+1):
    rm = (mpf(10), None)
    for y in range(1, n):
        cell = S(n, y+1) - S(n, y)
        J = S(n+1, y+1) - S(n, y)
        th = J/(mpf(n+1-y)/(n+1)*cell)
        if th < mn[0]: mn = (th, (n, y))
        if th > mx[0]: mx = (th, (n, y))
        if th < rm[0]: rm = (th, y)
    rowmin[n] = rm
print('min theta', float(mn[0]), mn[1], ' max theta', float(mx[0]), mx[1])
for n in (10, 20, 40, 80, 120, NMAX):
    if n in rowmin: print('row', n, 'min theta %.5f at y=%d' % (float(rowmin[n][0]), rowmin[n][1]))
n = NMAX
print('row %d theta at selected y:' % n, ' '.join('%d:%.3f' % (y, float((S(n+1,y+1)-S(n,y))/(mpf(n+1-y)/(n+1)*(S(n,y+1)-S(n,y))))) for y in sorted(set([1,2,3,5,8,12,20,30,40,50,60,70,80,90,100,110,120,130,140,145,148,n-1])) if 1<=y<n))
