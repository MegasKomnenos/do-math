# Peer's own computation (double precision) of the Green-function shares of the three sources of the diagonal excess
# (Proposition 5.3):   Delta_n = sigma_n + (k x/n) Delta_{n-1} + sum_{m=1}^{n-k-1} kappa_m Delta_{n-m}   (k+1 <= n <= 2k),
#   sigma_n = pi_n [ J_{n-1}(k) + (1 - gamma_k/gamma_{n-1}) F_{n-2}(k-1) ] + ((n-k) x/(n(n-1))) U_{n-2}.
# Reproduces the producer's numbers of section 4.3 and adds the flow share with the lower Euler bounds
# (Theorem 3.1: constant (k+1)/(n-1+k+1) ; Theorem 3.12: constant 1/2).      Units: omega_k/k.
import numpy as np, sys, math
def run(k):
    x = (k / (k + 1)) ** (k - 2); lx = math.log(x); NN = 2 * k + 2
    lg = [math.lgamma(i + 1) for i in range(NN + 3)]
    om = np.array([math.exp(n * lx + (n - 1) * math.log(n + 1) - lg[n]) for n in range(NN + 1)])
    pi = np.array([0.0] + [math.exp(n * lx + (n - 2) * math.log(n) - lg[n]) for n in range(1, NN + 1)])
    kap = np.array([0.0, x] + [math.exp(m * lx + (m - 1) * math.log(m - 1) - lg[m]) for m in range(2, NN + 1)])
    gam = lambda j: (1 + 1.0 / j) ** (j - 2)
    def col(c):
        u = np.zeros(NN + 1); u[0] = 1.0
        w = np.minimum(np.arange(1, NN + 2), c).astype(float)
        for n in range(1, NN + 1):
            u[n] = x * np.dot(w[:n] * u[:n], u[n - 1::-1][:n]) / n
        return u
    c1, c0, cp = col(k - 1), col(k), col(k + 1)
    F = lambda j, l: {k - 2: c1, k - 1: c0, k: cp}[l][j] / om[j]
    P = lambda j, l: F(j, l) - F(j, l - 1)
    U = lambda j: om[j] * P(j, k - 1); V = lambda j: om[j] * P(j, k)
    J = lambda n, l: F(n, l) - F(n - 1, l - 1)
    unit = om[k] / k
    Delta = {n: V(n) - U(n - 1) for n in range(k + 1, 2 * k + 1)}; Delta[k] = 0.0
    s_flow = {}; s_surv = {}; s_cell = {}; s_flow_T = {}; s_flow_H = {}
    for n in range(k + 1, 2 * k + 1):
        s_flow[n] = pi[n] * J(n - 1, k)
        s_surv[n] = pi[n] * (1 - gam(k) / gam(n - 1)) * F(n - 2, k - 1)
        s_cell[n] = (n - k) * x / (n * (n - 1)) * U(n - 2)
        # lower Euler bounds for J_{n-1}(k) = stay flow from size n-2 at level k  (first layer: k <= n-2 <= 2k+1)
        if n - 2 >= k:
            base = ((n - 1 - k) / (n - 1)) * P(n - 2, k)
            s_flow_T[n] = pi[n] * ((k + 1) / (n + k)) * base
            s_flow_H[n] = pi[n] * 0.5 * base
        else:
            s_flow_T[n] = s_flow_H[n] = 0.0
    # check the recursion
    err = max(abs(Delta[n] - (s_flow[n] + s_surv[n] + s_cell[n] + k * x / n * Delta[n - 1]
              + sum(kap[m] * Delta[n - m] for m in range(1, n - k)))) for n in range(k + 1, 2 * k + 1)) / unit
    def solve(src):
        D = {k: 0.0}
        for n in range(k + 1, 2 * k + 1):
            D[n] = src[n] + k * x / n * D[n - 1] + sum(kap[m] * D[n - m] for m in range(1, n - k))
        return sum(D[n] for n in range(k + 1, 2 * k + 1)) / unit
    tot = sum(Delta[n] for n in range(k + 1, 2 * k + 1)) / unit
    fl, su, ce = solve(s_flow), solve(s_surv), solve(s_cell)
    flT, flH = solve(s_flow_T), solve(s_flow_H)
    raw = sum(s_flow[n] + s_surv[n] + s_cell[n] for n in range(k + 1, 2 * k + 1)) / unit
    U2k = U(2 * k) / unit
    print("k=%d: recursion err %.1e | SumDelta=%.3f = flow %.3f + survival %.3f + cell %.3f | raw source sum %.3f (amplification %.2f)"
          % (k, err, tot, fl, su, ce, raw, tot / raw))
    print("      flow share with Theorem 3.1 bound: %.3f -> lower bound of SumDelta %.3f (%.0f%%), ratio to U_2k %.2f ; with constant 1/2: %.3f -> %.3f (%.0f%%), ratio %.2f ; true ratio %.2f"
          % (flT, flT + su + ce, 100 * (flT + su + ce) / tot, (flT + su + ce) / U2k, flH, flH + su + ce, 100 * (flH + su + ce) / tot, (flH + su + ce) / U2k, tot / U2k))
for k in [int(a) for a in sys.argv[1:]] or [160, 184, 250]:
    run(k)
