# (DR) <=> sum_{j=k+1}^{2k} Delta_j >= U_{2k},  Delta_j = V_j - U_{j-1}  (대각 기울임 x = (k/(k+1))^{k-2})
# Delta_j = (w_j - w_{j-1}) c_{j-1}(k-1)  +  w_j [c_j(k) - c_{j-1}(k-1)]
#           (기울임 부분)                    (결손 r=j-k를 고정한 셀 확률의 N에 대한 차분)
# 단위 w_k/k. 논증의 걸음(분해의 각 조각의 크기와 부호)을 확인하는 계산.
import sys
from mpmath import mp, mpf
mp.dps = 50

def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a

for k in [int(a) for a in sys.argv[1:]]:
    T = 2*k; nmax = T+2
    aP = col(k+1, nmax); a0 = col(k, nmax); aM = col(k-1, nmax); cay = col(10**9, nmax)
    x = (mpf(k)/(k+1))**(k-2)
    w = [x**j*cay[j] for j in range(nmax+1)]
    cK = [(aP[j]-a0[j])/cay[j] for j in range(nmax+1)]     # Pr(M_j = k)
    cKm = [(a0[j]-aM[j])/cay[j] for j in range(nmax+1)]    # Pr(M_j = k-1)
    unit = w[k]/k
    U = [w[j]*cKm[j] for j in range(nmax+1)]
    V = [w[j]*cK[j] for j in range(nmax+1)]
    tilt = mpf(0); neg = mpf(0); pos = mpf(0); jcross = None; tot = mpf(0)
    for j in range(k+1, T+1):
        t1 = (w[j]-w[j-1])*cKm[j-1]
        t2 = w[j]*(cK[j]-cKm[j-1])
        tilt += t1
        if t2 < 0: neg += -t2
        else:
            pos += t2
            if jcross is None: jcross = j
        tot += V[j]-U[j-1]
    mh = sum(V[j]-U[j] for j in range(k, T+1))
    jmaxU = max(range(k, T+1), key=lambda j: U[j])
    # U_j 가 jmaxU 뒤에서 단조 감소인가
    mono = all(U[j+1] <= U[j] for j in range(jmaxU, T))
    print('k=%d: tilt=%.4f  Jdiff: -%.4f +%.4f (net %.4f, first positive at j-k=%d)  U_2k=%.4f  sumDelta=%.4f  -h=%.4f chk=%.1e | argmax U at j-k=%d (U=%.4f), U nonincreasing after: %s'
          % (k, float(tilt/unit), float(neg/unit), float(pos/unit), float((pos-neg)/unit), jcross-k, float(U[T]/unit),
             float(tot/unit), float(mh/unit), float((tot-U[T]-mh)/unit), jmaxU-k, float(U[jmaxU]/unit), mono))
    # 기울임 부분의 하계 후보: (1/k) sum U_{j-1}
    lb = sum(U[j-1] for j in range(k+1, T+1))/k
    print('     (1/k)sum_{j=k}^{2k-1}U_j = %.4f ; tilt - that = %.4f' % (float(lb/unit), float((tilt-lb)/unit)))
    # 명제 3 (Abel 합과 정리 S): tilt >= a_k + sum_{j=k}^{T-2}(a_{j+1}-a_j) F_j(k-2) - a_{T-1} F_{T-1}(k-2),  a_j = w_{j+1}-w_j
    a = [w[j+1]-w[j] for j in range(nmax)]
    Fm = [aM[j]/cay[j] for j in range(nmax+1)]     # F_j(k-2) = Pr(M_j <= k-2)
    mid = sum((a[j+1]-a[j])*Fm[j] for j in range(k, T-1))
    endt = a[T-1]*Fm[T-1]
    abel = a[k] + mid - endt
    monot = all(a[j+1] >= a[j] for j in range(k-1, T))
    print('     Abel bound: a_k=%.4f + middle=%.4f - end=%.4f = %.4f  (tilt=%.4f; loss %.4f; a_j nondecreasing: %s; F_{2k-1}(k-2)=%.3e)'
          % (float(a[k]/unit), float(mid/unit), float(endt/unit), float(abel/unit), float(tilt/unit), float((tilt-abel)/unit), monot, float(Fm[T-1])))
    print('     margins: tilt/(U_2k+N_J) = %.3f ; Abel/(U_2k+N_J) = %.3f ; (tilt-U_2k)/N_J = %.2f' %
          (float(tilt/(U[T]+neg)), float(abel/(U[T]+neg)), float((tilt-U[T])/neg)))
    # 정리 T (J_j(k-1) >= (1/3)((j-k+1)/j) P_{j-1}(k-1), k <= j <= 2k)가 명제 4의 손실에서 되찾는 양
    gainT = sum(a[j]*mpf(j-k+1)/(3*j)*cKm[j-1] for j in range(k, T))
    # 정리 T의 상수 (y+1)/(n+y+2) = k/(j+k)  ((n,y) = (j-1,k-1))
    gainTp = sum(a[j]*mpf(k)/(j+k)*mpf(j-k+1)/j*cKm[j-1] for j in range(k, T))
    print('     Theorem T with constant k/(j+k): recovered %.4f ; ratio [a_k+middle+recovered]/[end+U_2k+N_J] = %.3f'
          % (float(gainTp/unit), float((a[k]+mid+gainTp)/(endt+U[T]+neg))))
    lossJ = sum(a[j]*(a0[j]/cay[j] - aM[j-1]/cay[j-1]) for j in range(k, T))      # sum a_j J_j(k-1) = tilt - abel
    lhs2 = a[k] + mid + gainT; rhs2 = endt + U[T] + neg
    print('     Theorem T: recovered %.4f of the loss %.4f (check tilt-abel=%.4f); (DR-T\'\') ratio [a_k+middle+recovered]/[end+U_2k+N_J] = %.3f (without: %.3f)'
          % (float(gainT/unit), float(lossJ/unit), float((tilt-abel)/unit), float(lhs2/rhs2), float((a[k]+mid)/rhs2)))
