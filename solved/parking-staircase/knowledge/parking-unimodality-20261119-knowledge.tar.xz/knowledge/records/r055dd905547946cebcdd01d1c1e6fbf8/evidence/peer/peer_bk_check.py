# Peer's exact check of the producer's constant-1/2 route (report Props 6, 8, 12): 
#   Omega_k(z) := (2k+z) nabla_k(z) - (z/(k-1)) sigma_{k-1}(z) - z alpha_k(z)  =  2 * Omega^{1/2}_k(z)
#   Prop 8 :  Omega_k(z) = (k/(N-1)) sum_g [(N+k-2) q_{N-1}(g)/(2k+z-g)] Omega_k(z-g) + (2k/(N-1)) L_k(z)
#   Prop 12:  L_k(z) = sum_m C(m) alpha_k(z-m) + (1/k) sum_g C2(g)(z-g) Eul_k(z-g),   Eul_k(y) = y alpha_k(y) - k nabla_k(y) >= 0
from pf import *
def tau(j): return Fr(j ** (j - 1), factorial(j))
def q(N, g): return tau(g) * tau(N - g) / tau(N)
def Pi(N, m): return sum((q(N, g) for g in range(1, m + 1)), Fr(0))
def Gam(N, m): return (N - 1) * (Pi(N - 1, m) - Pi(N, m))
def R(N, b): return 1 - Pi(N, b - 1)
def P(y, N): return Fr(A(N - 1, y - 1), N ** (N - 2)) if N >= 2 else Fr(1)
def e(k, z): return Fr(0) if z <= 0 else 1 - Fr(k, k + z) * P(k, k + z)
def sig(k, z): return 1 - e(k, z)
def al(k, z): return e(k, z) - e(k, z - 1)
def nab(k, z): return e(k - 1, z) - e(k, z)
def Om(k, z): return (2 * k + z) * nab(k, z) - Fr(z, k - 1) * sig(k - 1, z) - z * al(k, z)
def OmHalf(k, z):
    N = k + z; w = Fr(z, 2 * (N - 1))
    return k * (P(k, N) - w * P(k, N - 1) - (1 - w) * P(k - 1, N - 1))
cnt = 0
for k in range(2, 13):
    for z in range(1, k + 2):
        N = k + z
        assert Om(k, z) == 2 * OmHalf(k, z); cnt += 1
        if z == 1: continue
        c1 = lambda g: Gam(N, g) - q(N - 1, g) * Fr(z + g * (k - 1), 2 * k + z - g)
        c2 = lambda g: Fr(N + k - 2, 2 * (k - 1)) * q(N - 1, g) * Fr(z - g, 2 * k + z - g)
        L = sum(c1(g) * al(k, z - g) + c2(g) * sig(k - 1, z - g) for g in range(1, z))
        rhs = Fr(k, N - 1) * sum(Fr(N + k - 2, 2 * k + z - g) * q(N - 1, g) * Om(k, z - g) for g in range(1, z)) + Fr(2 * k, N - 1) * L
        assert Om(k, z) == rhs, ("P8", k, z); cnt += 1
        C2 = lambda g: Fr(N + k - 2, 2 * (k - 1)) * q(N - 1, g) / (2 * k + z - g)
        Cm = lambda m: k * sum(C2(g) * R(N - g, m - g + 1) for g in range(1, m + 1)) - C2(m) * Fr((z - m) ** 2, k) + c1(m)
        Eul = lambda y: y * al(k, y) - k * nab(k, y)
        L2 = sum(Cm(m) * al(k, z - m) for m in range(1, z)) + Fr(1, k) * sum(C2(g) * (z - g) * Eul(z - g) for g in range(1, z))
        assert L == L2, ("P12", k, z); cnt += 1
        assert all(Eul(y) >= 0 for y in range(1, z)); assert L >= 0
print("checks passed:", cnt)
