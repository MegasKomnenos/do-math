# 나무의 빚의 Volterra 방정식 (대각 기울임 x = (k/(k+1))^{k-2}):
#   H(s) := -hT(s) = sum_{t=k}^{s} dt_t,  dt_t = xi_t(k) - xi_t(k-1) = x^t tau_t [p_t(k) - p_t(k-1)]
#   th_g := x^g tau_g,   Lam_s(u) := sum_{g=1}^{s-u} th_g/(u+g),   K_s(u) := k [Lam_s(u) - Lam_s(u+1)] >= 0
#   (TD')  H(s) = -u0 + sum_{u=k}^{s-1} K_s(u) H(u) + Src(s),   Src(s) := sum_{u=k}^{s-1} Lam_s(u) [xi_u(k-1) + xi_u(k)],  u0 = x^k tau_k / k
#   -h_{2k} >= sum_s w_{2k-s} H(s)
# (1) (TD')의 대조.  (2) 원천을 하계로 바꾼 비교 해 Hlow 로도 sum_s w_{2k-s} Hlow(s) >= 0 인가.
#     하계 A: 참 누적 칸 질량 C_y(u) = sum_{u'<=u} p_{u'}(y) 를 쓰되 무게는 구간 최솟값으로.
#     하계 B: C_y(u) >= e_y(.) >= elow(.),  elow(x) = x^{3/2}/(x^{3/2} + c k)  (c 는 인자).
import sys
from mpmath import mp, mpf
mp.dps = 40
def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
def run(k, cpar):
    T = 2*k; nmax = T+2
    aP = col(k+1, nmax); a0 = col(k, nmax); aM = col(k-1, nmax); cay = col(10**9, nmax)
    x = (mpf(k)/(k+1))**(k-2)
    w = [x**j*cay[j] for j in range(nmax+1)]
    F = lambda a, n: a[n]/cay[n]
    def p(t, lev):
        n = t-1
        if t < lev+1: return mpf(0)
        if lev == k:   Fl = F(aP, n); Pl = F(aP, n) - F(a0, n)
        else:          Fl = F(a0, n); Pl = F(a0, n) - F(aM, n)
        return (Fl + lev*Pl)/t
    th = [None] + [x*w[g-1] for g in range(1, nmax+1)]          # th_g = x^g tau_g = x w_{g-1}
    u0 = th[k]/k
    xi = {(t, lev): th[t]*p(t, lev) for t in range(k, T+1) for lev in (k-1, k)}
    H = {}; s_ = mpf(0)
    for t in range(k, T+1):
        s_ += xi[(t, k)] - xi[(t, k-1)]; H[t] = s_
    # Lam_s(u) for all k <= u < s <= T :  Lam_s(u) = sum_{g=1}^{s-u} th_g/(u+g)
    Lam = {}
    for u in range(k, T+1):
        acc = mpf(0); Lam[(u, u)] = acc
        for s in range(u+1, T+1):
            acc += th[s-u]/s; Lam[(s, u)] = acc
    err = mpf(0); Src = {}
    for s in range(k, T+1):
        src = sum(Lam[(s, u)]*(xi[(u, k-1)] + xi[(u, k)]) for u in range(k, s))
        Src[s] = src
        rhs = -u0 + sum(k*(Lam[(s, u)] - (Lam[(s, u+1)] if u+1 <= s else 0))*H[u] for u in range(k, s)) + src
        err = max(err, abs(H[s] - rhs))
    conv_true = sum(w[T-s]*H[s] for s in range(k, T+1))
    kmass = [float(k*Lam[(s, k)]) for s in (k+1, k+k//4, k+k//2, T)]
    # 하계 A, B
    C = {lev: {} for lev in (k-1, k)}
    for lev in (k-1, k):
        acc = mpf(0)
        for u in range(k, T+1):
            acc += p(u, lev); C[lev][u] = acc
    def elow(xx):
        if xx <= 0: return mpf(0)
        return mpf(xx)**1.5/(mpf(xx)**1.5 + cpar*k)
    def solve(srclow):
        Hl = {}
        for s in range(k, T+1):
            Hl[s] = -u0 + sum(k*(Lam[(s, u)] - (Lam[(s, u+1)] if u+1 <= s else 0))*Hl[u] for u in range(k, s)) + srclow[s]
        return Hl
    SA = {}; SB = {}
    for s in range(k, T+1):
        bestA = mpf(0); bestB = mpf(0)
        # 무게 a(u) = Lam_s(u) th_u 의 [k, v] 위의 최솟값 * 누적 질량 (v 를 고른다)
        mn = None
        for v in range(k, s):
            a_v = Lam[(s, v)]*th[v]
            mn = a_v if mn is None else min(mn, a_v)
            candA = mn*(C[k-1][v] + C[k][v])
            candB = mn*(elow(v-k+1) + elow(v-k))
            if candA > bestA: bestA = candA
            if candB > bestB: bestB = candB
        SA[s] = bestA; SB[s] = bestB
    HA = solve(SA); HB = solve(SB)
    convA = sum(w[T-s]*HA[s] for s in range(k, T+1)); convB = sum(w[T-s]*HB[s] for s in range(k, T+1))
    # 참 e 와 elow 의 비교
    e_true = lambda lev, xx: 1 - mpf(lev)/(lev+xx)*(F(a0, lev+xx-1) if lev == k else F(aM, lev+xx-1))
    worst = min(float(e_true(k, xx)/elow(xx)) for xx in range(1, k+1))
    print('k=%d: (TD\') max err %.1e u0 | kernel mass k*Lam_s(k) at s=k+1, 1.25k, 1.5k, 2k: %s' % (k, float(err/u0), ['%.4f' % v for v in kmass]))
    print('     Src(s)/u0 at s-k = 1, 10, k/4, k/2, k: %s' % ['%.3f' % float(Src[k+d]/u0) for d in (1, 10, k//4, k//2, k)])
    print('     sum_s w_{2k-s} H(s) / u0: true %.4f ; with source bound A %.4f ; with source bound B (c=%.2f; min e_k/elow = %.3f) %.4f'
          % (float(conv_true/u0), float(convA/u0), cpar, worst, float(convB/u0)))
    print('     H(2k)/u0: true %.3f, A %.3f, B %.3f ; SrcA/Src, SrcB/Src at s=1.5k: %.3f, %.3f ; at 2k: %.3f, %.3f'
          % (float(H[T]/u0), float(HA[T]/u0), float(HB[T]/u0), float(SA[k+k//2]/Src[k+k//2]), float(SB[k+k//2]/Src[k+k//2]), float(SA[T]/Src[T]), float(SB[T]/Src[T])))
ks = [int(a) for a in sys.argv[2:]]
for k in ks: run(k, float(sys.argv[1]))
