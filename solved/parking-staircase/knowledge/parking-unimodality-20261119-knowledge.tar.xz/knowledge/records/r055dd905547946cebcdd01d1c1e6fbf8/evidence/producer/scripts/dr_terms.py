# L(T) = sum_{j=k}^{T} (Gp_j - Gm_j),  Gp_j = u_j(k+1) - (k/(k+1)) u_{j+1}(k+1),  Gm_j = ((k+1)/k) u_{j-1}(k-1) - u_j(k-1)
# (대각 기울임). 항별 윤곽과 부분합을 본다. 단위 w_k/k.
import sys
from mpmath import mp, mpf
mp.dps = 40
def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
k = int(sys.argv[1]); T = 2*k; nmax = T+3
aP = col(k+1, nmax); aM = col(k-1, nmax); cay = col(10**9, nmax)
x = (mpf(k)/(k+1))**(k-2); rho = mpf(k+1)/k
uP = [x**j*aP[j] for j in range(nmax+1)]; uM = [x**j*aM[j] for j in range(nmax+1)]
unit = x**k*cay[k]/k
L = mpf(0); rows = []
for j in range(k, T+1):
    Gp = uP[j] - uP[j+1]/rho
    Gm = rho*uM[j-1] - uM[j]
    L += Gp - Gm
    rows.append((j, Gp/unit, Gm/unit, L/unit))
sel = sorted(set([k, k+1, k+2, k+3, k+5, k+8, k+12, k+20, k+30, k+45, k+60, k+80, k+100, int(1.6*k), int(1.7*k), int(1.8*k), int(1.9*k), 2*k-1, 2*k]))
print('k=%d' % k)
for (j, gp, gm, l) in rows:
    if j in sel:
        print('  j=%4d (j-k=%3d): Gp=%9.5f  Gm=%9.5f  Gp-Gm=%9.5f   L(j)=%9.5f' % (j, j-k, float(gp), float(gm), float(gp-gm), float(l)))
