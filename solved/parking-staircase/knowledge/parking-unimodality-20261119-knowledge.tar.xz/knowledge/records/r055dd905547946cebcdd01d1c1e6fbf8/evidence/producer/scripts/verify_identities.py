# 보고서의 항등식들을 정확한 유리수로 대조한다 (작은 k; 논증의 걸음을 작은 예에서 확인하는 계산).
#  (1) 대각 재배열: P_T(x) = sum_{j=k}^T DC_x(j) + (w_k - w_{k-1}) - [u_{T+1}(k+1) - u_T(k-1)]   (임의의 유리수 기울임 x)
#  (2) DC_x(j) = rho^j DC_{x_k}(j) + gain_j,  rho = x/x_k,  gain_j = (1-1/rho) u_{j+1}(k+1) - (rho-1) u_{j-1}(k-1)
#  (3) (LE)의 나무 꼴 Omega_k(x) 와 숲 꼴의 동치, 재귀 (★), (★★)
import sys
from fractions import Fraction as Fr
from math import comb, factorial

def cum_col(c, nmax):
    # a_n = A_{n,c-1}/n!  (모든 변위 < c)
    a = [Fr(1)]
    for n in range(1, nmax+1):
        s = Fr(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a

ok = True
def check(name, lhs, rhs):
    global ok
    if lhs != rhs:
        ok = False
        print('FAIL', name, lhs, rhs)

# ---------- (1), (2) ----------
for k in (3, 5, 8, 13):
    nmax = 2*k+4
    aP = cum_col(k+1, nmax); a0 = cum_col(k, nmax); aM = cum_col(k-1, nmax)
    cay = cum_col(10**6, nmax)
    xk = Fr(k, k+1)**(k-1)
    for x in (xk, Fr(k, k+1)**(k-2), Fr(2, 5), Fr(1, 2)):
        rho = x/xk
        u = lambda a, j: x**j*a[j]
        for T in range(k, 2*k+3):
            P = sum(x**j*(aP[j]-2*a0[j]+aM[j]) for j in range(k, T+1))
            DCx = [x**(j+1)*aP[j+1] - 2*x**j*a0[j] + x**(j-1)*aM[j-1] for j in range(k, T+1)]
            bnd = x**k*cay[k] - x**(k-1)*cay[k-1]
            E = x**(T+1)*aP[T+1] - x**T*aM[T]
            check('rearr k=%d T=%d' % (k, T), P, sum(DCx) + bnd - E)
            for j in range(k, T+1):
                DCc = xk**(j+1)*aP[j+1] - 2*xk**j*a0[j] + xk**(j-1)*aM[j-1]
                gain = (1-1/rho)*u(aP, j+1) - (rho-1)*u(aM, j-1)
                check('split k=%d j=%d' % (k, j), DCx[j-k], rho**j*DCc + gain)
print('rearrangement and tilt-split identities:', 'OK' if ok else 'FAILED')

# ---------- (3) ----------
def tau(j): return Fr(j**(j-1), factorial(j))
def q(N, g): return tau(g)*tau(N-g)/tau(N)
def Pi(N, m): return sum(q(N, g) for g in range(1, m+1))
def Gam(N, m): return (N-1)*(Pi(N-1, m) - Pi(N, m))
KMAX = 9
P = {}
for y in range(0, KMAX+3):
    col = cum_col(y, 2*KMAX+6) if y >= 1 else None
    for N in range(1, 2*KMAX+6):
        n = N-1
        if y == 0: P[(y, N)] = Fr(0) if n >= 1 else Fr(1)
        else:
            P[(y, N)] = col[n]/Fr((n+1)**(n-1), factorial(n)) if n >= 1 else Fr(1)
def e(k, x):
    if x <= 0: return Fr(0)
    return 1 - Fr(k, k+x)*P[(k, k+x)]
ok3 = True; mn = None
for k in range(3, KMAX+1):
    for x in range(2, k+2):
        N = k+x
        al = lambda xx: e(k, xx) - e(k, xx-1)
        na = lambda xx: e(k-1, xx) - e(k, xx)
        sig = 1 - e(k-1, x)
        Om = (2*k+x)*na(x) - Fr(x, k-1)*sig - x*al(x)
        # 숲 꼴: LE 결함 = P_k(N) - w P_k(N-1) - (1-w) P_{k-1}(N-1), w = x/(2(N-1));  Omega = 2N * (k/N) * 결함 ?
        w = Fr(x, 2*(N-1))
        defect = P[(k, N)] - w*P[(k, N-1)] - (1-w)*P[(k-1, N-1)]
        if Om != 2*k*defect: ok3 = False; print('FAIL forest/tree', k, x, Om, 2*k*defect)
        # (★)
        star = Fr(k, N-1)*sum((N+k-2)*q(N-1, g)*na(x-g) - (x*q(N-1, g) - 2*Gam(N, g))*al(x-g) for g in range(1, x))
        if Om != star: ok3 = False; print('FAIL star', k, x, Om, star)
        # (★★)
        EE = lambda xx: (k+xx)*e(k, xx) - xx*e(k, xx-1) - k*e(k-1, xx)
        ss = sum(al(x-g)*(((x-2*g) + Fr((x-2)*(x-g), k))*q(N-1, g) + 2*Gam(N, g)) for g in range(1, x)) - Fr(N+k-2, k)*sum(q(N-1, g)*EE(x-g) for g in range(1, x))
        if Om != Fr(k, N-1)*ss: ok3 = False; print('FAIL starstar', k, x)
        if defect < 0: ok3 = False; print('LE violated', k, x)
        th = (P[(k, N)] - P[(k-1, N-1)])/(2*w*(P[(k, N-1)] - P[(k-1, N-1)]))
        if mn is None or th < mn[0]: mn = (th, k, x)
print('LE tree/forest forms, (★), (★★):', 'OK' if ok3 else 'FAILED', ' min theta in range: %.5f at (k,x)=(%d,%d)' % (float(mn[0]), mn[1], mn[2]))

# ---------- (4) 명제 1 (가),(나), 명제 4의 부등식 (정확한 유리수; 대각 기울임과 다른 기울임) ----------
ok4 = True
for k in (3, 5, 8, 13):
    nmax = 2*k+3
    aP = cum_col(k+1, nmax); a0 = cum_col(k, nmax); aM = cum_col(k-1, nmax)
    cay = cum_col(10**6, nmax)
    for x in (Fr(k, k+1)**(k-2), Fr(k, k+1)**(k-1), Fr(2, 5)):
        w = [x**j*cay[j] for j in range(nmax+1)]
        Pk = [(aP[j]-a0[j])/cay[j] for j in range(nmax+1)]      # Pr(M_j = k)
        Pkm = [(a0[j]-aM[j])/cay[j] for j in range(nmax+1)]     # Pr(M_j = k-1)
        Fkm2 = [aM[j]/cay[j] for j in range(nmax+1)]            # Pr(M_j <= k-2)
        U = [w[j]*Pkm[j] for j in range(nmax+1)]; V = [w[j]*Pk[j] for j in range(nmax+1)]
        for T in range(k+2, 2*k+2):
            eta = sum(V[j]-U[j] for j in range(k, T+1))
            Delta = [V[j]-U[j-1] for j in range(k+1, T+1)]
            if eta != sum(Delta) - U[T]: ok4 = False; print('FAIL prop1a', k, T)
            for j in range(k+1, T+1):
                Gam_j = Pkm[j-1] - Pk[j]
                if V[j]-U[j-1] != (w[j]-w[j-1])*Pkm[j-1] - w[j]*Gam_j: ok4 = False; print('FAIL prop1b', k, j)
            a = [w[j+1]-w[j] for j in range(nmax)]
            if all(a[j] >= 0 for j in range(k, T)):
                lhs = sum(a[j]*Pkm[j] for j in range(k, T))
                rhs = a[k] + sum((a[j+1]-a[j])*Fkm2[j] for j in range(k, T-1)) - a[T-1]*Fkm2[T-1]
                loss = sum(a[j]*((a0[j]/cay[j]) - Fkm2[j-1]) for j in range(k, T))   # sum a_j J_j(k-1)
                if lhs < rhs or lhs - rhs != loss: ok4 = False; print('FAIL prop4', k, T, x)
print('Prop 1 (a),(b) and Prop 4 (inequality and exact loss):', 'OK' if ok4 else 'FAILED')

# ---------- (5) 명제 8의 갱신 꼴, L_k(2) = Gamma_{k+2}(1)/(k+1), 명제 9의 닫힌 식 ----------
ok5 = True
for k in range(3, KMAX+1):
    Om = {}
    al = lambda xx: e(k, xx) - e(k, xx-1)
    na = lambda xx: e(k-1, xx) - e(k, xx)
    sg = lambda xx: 1 - e(k-1, xx)
    for x in range(1, k+2):
        N = k+x
        Om[x] = (2*k+x)*na(x) - Fr(x, k-1)*sg(x) - x*al(x)
        if x == 1:
            if Om[1] != 0: ok5 = False; print('FAIL Omega(1)', k)
            continue
        L = Fr(0); ren = Fr(0)
        for g in range(1, x):
            qq = q(N-1, g)
            c1 = Gam(N, g) - qq*Fr(x + g*(k-1), 2*k+x-g)
            c2 = Fr(N+k-2, 2*(k-1))*qq*Fr(x-g, 2*k+x-g)
            L += c1*al(x-g) + c2*sg(x-g)
            ren += qq*Fr(N+k-2, 2*k+x-g)*Om[x-g]
        if Om[x] != Fr(k, N-1)*ren + Fr(2*k, N-1)*L: ok5 = False; print('FAIL renewal', k, x)
        if x == 2 and L != Gam(k+2, 1)/(k+1): ok5 = False; print('FAIL L(2)', k)
        if L < 0: ok5 = False; print('source negative', k, x)
for n in range(2, 2*KMAX):
    # q_{n+1}(1) = 1 - (n+1)^{2n-2}/((n+2)^n n^{n-2}) >= 1/(n+1)
    qtop = 1 - Fr((n+1)**(2*n-2), (n+2)**n * n**(n-2))
    Jn = P[(n, n+2)] - P[(n-1, n+1)] if (n, n+2) in P and (n-1, n+1) in P else None   # Pr(M_{n+1}<=n-1) - Pr(M_n<=n-2)
    cell = (1 - P[(n-1, n+1)]) if (n-1, n+1) in P else None                           # Pr(M_n = n-1)
    if Jn is not None and cell is not None and Jn/cell != qtop: ok5 = False; print('FAIL top closed form', n)
    if qtop < Fr(1, n+1): ok5 = False; print('FAIL top LE', n)
print('Prop 8 renewal form, L_k(2) closed form, Prop 9 closed form:', 'OK' if ok5 else 'FAILED')
