# float check of the one-variable inequality (J_N) and of each analytic bound used for it
import math
E = math.e
def calR(t): return math.exp((t - 1) * math.log1p(1.0 / t))
worst = (1e9, None); bad = []
for N in list(range(5, 3000)) + [5000, 10**4, 10**5, 10**6]:
    u = N - 1
    a, b, c = calR(u), calR(u - 1), calR(u - 2)
    # exact-form quantity
    F0b = 2 * u * ((1 - b / a) + (1 / c - 1 / a)) + 1 - 4 * (u - 1) / ((3 * u - 4) * b) - (4 * u * u - 14 * u + 4) / (3 * u * (u - 2) * c)
    w = 1.0 / (u - 1); x = 1.0 / (u - 2)
    # bounds
    okB1 = (1 / b <= (1 + 1 / (u - 1)) ** 1.5 / E * (1 + 1e-13)) and (1 / c <= (1 + 1 / (u - 2)) ** 1.5 / E * (1 + 1e-13))
    okB2 = (a / b >= 1 + (u + 2) / u ** 3 - 1e-15) and (2 * u * (1 - b / a) >= 2 / u - 1e-15)
    X2 = (1 - 1.5 * x + x / u) * (1 + x) ** 1.5
    okX2 = X2 <= 1 + 1e-13
    lower = (1 - 8 / (3 * E)) + 2 * w / (1 + w) - (4 / (3 * E)) * w * (11 / 6 + 3 * w / 8) / (1 - w / 3)
    okchain = F0b >= lower - 1e-12 and lower > 0
    if not (okB1 and okB2 and okX2 and okchain): bad.append(N)
    if F0b < worst[0]: worst = (F0b, N)
    if N in (5, 6, 7, 10, 20, 31, 50, 100, 1000, 10**4, 10**6):
        print("N=%d  F0*b=%.6f  analytic lower bound=%.6f   N*(F0*b-(1-8/(3e)))=%.3f" % (N, F0b, lower, N * (F0b - (1 - 8 / (3 * E)))))
print("violations of any bound:", bad)
print("min F0*b over tested N: %.6f at N=%d ; limit 1-8/(3e) = %.6f" % (worst[0], worst[1], 1 - 8 / (3 * E)))
