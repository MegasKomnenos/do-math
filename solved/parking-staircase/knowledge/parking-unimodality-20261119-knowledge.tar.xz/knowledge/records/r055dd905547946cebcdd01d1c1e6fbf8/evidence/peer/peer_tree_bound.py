# size of the lower bound for sum Delta_n that the published tree-level diagonal bound [TD] gives (double precision)
import numpy as np, math, sys
def run(k):
    x = (k / (k + 1)) ** (k - 2); lx = math.log(x); NN = 2 * k + 2
    lg = [math.lgamma(i + 1) for i in range(NN + 3)]
    om = np.array([math.exp(n * lx + (n - 1) * math.log(n + 1) - lg[n]) for n in range(NN + 1)])
    th = np.array([0.0] + [math.exp(g * lx + (g - 1) * math.log(g) - lg[g]) for g in range(1, NN + 1)])
    def col(c):
        u = np.zeros(NN + 1); u[0] = 1.0
        w = np.minimum(np.arange(1, NN + 2), c).astype(float)
        for n in range(1, NN + 1):
            u[n] = x * np.dot(w[:n] * u[:n], u[n - 1::-1][:n]) / n
        return u
    c1, c0, cp = col(k - 1), col(k), col(k + 1)
    F = lambda j, l: {k - 2: c1, k - 1: c0, k: cp}[l][j] / om[j]
    P = lambda j, l: F(j, l) - F(j, l - 1)
    ptree = lambda t, y: (F(t - 1, y) + y * P(t - 1, y)) / t
    xi = lambda t, y: th[t] * ptree(t, y)
    u0 = th[k] / k
    W = np.cumsum(om)
    U = lambda j: om[j] * P(j, k - 1); V = lambda j: om[j] * P(j, k)
    SD = sum(V(j) - U(j - 1) for j in range(k + 1, 2 * k + 1))
    bound = sum(W[2 * k - t] * ((t - k - 1) / (k * t)) * xi(t - 1, k - 1) for t in range(k + 2, 2 * k + 1))
    chk = sum(W[2 * k - t] * (xi(t, k) - xi(t - 1, k - 1)) for t in range(k + 1, 2 * k + 1))
    print("k=%d: sumDelta/u0=%.3f (via tree: %.3f)  [TD]-bound/u0=%.3f  U_2k/u0=%.3f  W(10)/W(k)=%.3f  W(k)=%.3f  unit ratio (om_k/k)/u0=%.3f" % (k, SD / u0, chk / u0, bound / u0, U(2 * k) / u0, W[10] / W[k], W[k], (om[k] / k) / u0))
for k in [int(s) for s in sys.argv[1:]] or [160, 184, 349]:
    run(k)
