# L(T) = A - B - C + D - w_k/k 의 몫들을 잰다 (대각 기울임, 단위 w_k/k).
#  A = sum_{i=k}^{T-1} U_i/k + sum_{i=k+1}^{T} V_i/(k+1)   (수준 k-1, k의 기울인 머묾)
#  B = U_T + (k/(k+1)) V_{T+1}                             (끝 셀)
#  C = (1/(k(k+1))) sum_{i=k+1}^{T-1} w_i Phi_{i+1}        (생존 질량)
#  D = ((k+2)/(k+1)) w_T Phi_{T+1} - (k/(k+1)) w_{T+1} Phi_{T+2}
import sys
from mpmath import mp, mpf
mp.dps = 40
def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        for j in range(n):
            s += min(j+1, c) * a[j] * a[n-1-j]
        a.append(s/n)
    return a
for k in [int(a) for a in sys.argv[1:]]:
    for T in (2*k-1, 2*k):
        nmax = T+3
        aK1 = col(k+1, nmax); aK = col(k, nmax); aKm = col(k-1, nmax)
        x = (mpf(k)/(k+1))**(k-2)
        cay = col(10**9, nmax)
        w = [x**j*cay[j] for j in range(nmax+1)]
        U = [x**j*(aK[j]-aKm[j]) for j in range(nmax+1)]
        V = [x**j*(aK1[j]-aK[j]) for j in range(nmax+1)]
        Phi = [None]+[aK[j]/cay[j] for j in range(nmax)]   # Phi_{i+1} = Pr(M_i<=k-1)
        unit = w[k]/k
        A1 = sum(U[k:T])/k; A2 = sum(V[k+1:T+1])/(k+1)
        B1 = U[T]; B2 = mpf(k)/(k+1)*V[T+1]
        C = sum(w[i]*Phi[i+1] for i in range(k+1, T))/(k*(k+1))
        D = mpf(k+2)/(k+1)*w[T]*Phi[T+1] - mpf(k)/(k+1)*w[T+1]*Phi[T+2]
        L = A1+A2-B1-B2-C+D-unit
        # 검산: L = -h_T - conv
        eta = [x**j*(aK1[j]-2*aK[j]+aKm[j]) for j in range(nmax+1)]
        xc = (mpf(k)/(k+1))**(k-1)
        conv = sum(x**j*(aK1[j+1]*xc - 2*aK[j] + aKm[j-1]/xc) for j in range(k, T+1))
        chk = sum(eta[k:T+1]) - conv - L
        print('k=%d T=%d (unit w_k/k): A_U=%.4f A_V=%.4f B_U=%.4f B_V=%.4f C=%.4f D=%.4f | L=%.4f  -h_T=%.4f conv=%.4f chk=%.1e' % (
            k, T, float(A1/unit), float(A2/unit), float(B1/unit), float(B2/unit), float(C/unit), float(D/unit), float(L/unit), float(sum(eta[k:T+1])/unit), float(conv/unit), float(chk/unit)))
