# Observation (double precision): where the source of the two recursions for the defect of the lower Euler inequality
# changes sign.  Not a proof step.
#  (T) first-tree recursion of Proposition 3.14 (constant c = 1/2 and c = 0): source/scale, scale = ((N-y)/N) Pr(M_{N-1} = y)
#  (P) prime (renewal) recursion, c = 1/2:  alpha_n = A_{n,y}/n!, beta_n = A_{n,y-1}/n!, 1/F_y = 1 - sum kappa_i x^i,
#      M(N) = alpha_N - u_N alpha_{N-1} - v_N beta_{N-1} = sum_{i<N} kappa_i M(N-i) + S_N,  u_N = psi(N) (N-y)/(2N), v_N = psi(N) - u_N,
#      S_N = kappa_N + sum_{i=1}^{N-1} [kappa_i (u_{N-i} - u_N) alpha_{N-1-i} + (kappa_i v_{N-i} - kappa^-_i v_N) beta_{N-1-i}]
# The script also checks each recursion against the directly computed defect (relative error printed).
import sys, math
import numpy as np
NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 300
ys = [int(a) for a in sys.argv[2:]] or [1, 2, 3, 4, 5, 6, 8, 10, 15, 20, 30, 60, 100]
lg = [math.lgamma(i + 1) for i in range(NMAX + 3)]
lp = [0.0] + [(n - 1) * math.log(n + 1) for n in range(1, NMAX + 2)]
lc = [lp[n] - lg[n] for n in range(NMAX + 2)]
def col(th):                                   # alpha_n e^{-n} for threshold th (levels <= th-1)
    b = np.zeros(NMAX + 1); b[0] = 1.0
    w = np.minimum(np.arange(1, NMAX + 2), th).astype(float)
    for n in range(1, NMAX + 1):
        b[n] = math.exp(-1) * np.dot(w[:n] * b[:n], b[n - 1::-1][:n]) / n
    return b
def primes(a):
    k = np.zeros(NMAX + 1)
    for n in range(1, NMAX + 1):
        k[n] = a[n] - np.dot(k[1:n], a[n - 1:0:-1])
    return k
psi = lambda N: (1 + 1.0 / N) ** (N - 1)
def logpi(n, j): return lg[n - 1] - lg[j - 1] - lg[n - j] + (j - 1) * math.log(j) + lp[n - j] - lp[n]
PI = {n: np.array([0.0] + [math.exp(logpi(n, j)) for j in range(1, n + 1)]) for n in range(1, NMAX + 1)}
maxerr = 0.0; deep = []
print("y | first-tree source, c=1/2: first N with source<0, min source/scale (at N), value at N=2y+3 | c=0: first N<0 | prime source, c=1/2: first N<0")
for y in ys:
    Y = y + 1
    al = col(Y); be = col(y)
    A = np.array([al[n] * math.exp(n - lc[n]) for n in range(NMAX + 1)]); B = np.array([be[n] * math.exp(n - lc[n]) for n in range(NMAX + 1)])
    h = np.array([1.0] * (Y + 1) + [Y / j for j in range(Y + 1, NMAX + 3)])
    res = {}
    for c in (0.5, 0.0):
        lam = lambda N: c * (N - y) / N
        L = np.zeros(NMAX + 1)
        for N in range(1, NMAX + 1): L[N] = A[N] - lam(N) * A[N - 1] - (1 - lam(N)) * B[N - 1]
        first = None; worst = (1e9, None); atj = None; rels = {}
        for N in range(y + 2, NMAX + 1):
            i = np.arange(1, N)
            ker = np.sum(PI[N - 1][1:N] * ((i / N) * h[i + 1] * A[N - 1 - i] * L[i] + ((N - i) / N) * h[i] * A[i - 1] * L[N - i]))
            # source by the closed formulas (c = 1/2 only), to check the recursion in floating point
            scale = (N - y) / N * (A[N - 1] - B[N - 1])
            rel = (L[N] - ker) / scale
            rels[N] = rel
            if rel < 0 and first is None: first = N
            if rel < worst[0]: worst = (rel, N)
            if N == 2 * y + 3: atj = rel
        res[c] = (first, worst, atj, rels)
    ka = primes(al); km = primes(be)
    u = np.array([0.0] + [psi(N) * 0.5 * (N - y) / N / math.e for N in range(1, NMAX + 1)])
    v = np.array([0.0] + [psi(N) / math.e for N in range(1, NMAX + 1)]) - u
    M = np.zeros(NMAX + 1)
    for N in range(1, NMAX + 1): M[N] = al[N] - u[N] * al[N - 1] - v[N] * be[N - 1]
    firstp = None
    for N in range(y + 2, NMAX + 1):
        i = np.arange(1, N)
        S = ka[N] + np.sum(ka[1:N] * (u[N - i] - u[N]) * al[N - 1 - i] + (ka[1:N] * v[N - i] - km[1:N] * v[N]) * be[N - 1 - i])
        chk = M[N] - np.dot(ka[1:N], M[N - 1:0:-1])
        maxerr = max(maxerr, abs(S - chk) / max(abs(S), abs(chk), al[N]))
        if S < 0 and firstp is None: firstp = N
    f5, w5, j5, rels5 = res[0.5]; f0 = res[0.0][0]
    # deep-cell criterion of Proposition 3.15 (b): F_n(y-1)/F_n(y) <= 2 G_Y/e - 1 ; n2 = first n from which it holds up to NMAX
    rY = (1 + 1.0 / Y) ** (Y - 1); GY = 1.0 + sum(math.exp((i - 1) * math.log(i - 1) - lg[i] - (i - 1) * math.log(rY)) for i in range(2, Y + 1))
    wy = 2 * GY / math.e - 1; n2 = None
    for n in range(NMAX, y - 1, -1):
        if B[n] <= wy * A[n]: n2 = n
        else: break
    if y >= 2 and n2 is not None and n2 >= 2 * y + 3:
        rng = [rels5[N] for N in range(2 * y + 3, n2 + 1)]
        deep.append('%d: n2=%d, min source/scale over 2y+3 <= N <= n2: %+.4f' % (y, n2, min(rng)))
    elif y >= 2:
        deep.append('%d: n2=%s' % (y, n2))
    print("%3d | %s, %+.4f (N=%d), %s | %s | %s" % (y, f5, w5[0], w5[1], ("%+.4f" % j5) if j5 is not None else "-", f0, firstp))
print("cells outside the first layer not covered by the deep-cell criterion (Prop. 3.15 (b)) are the cells n = N-1 with 2y+3 <= N <= n2(y); there the first-tree source/scale is at least:")
for d_ in deep: print("  y=" + d_)
print("prime recursion: max relative difference between S_N by the formula and M(N) - sum kappa_i M(N-i): %.1e" % maxerr)

# ---- the parts of the first-tree source (c = 1/2), by the closed formulas of Proposition 3.14, in units of the scale:
#      light first trees (i <= y), heavy first trees: the three positive terms and the tie term, and X_N.
def parts(y, N):
    Y = y + 1; c = 0.5
    al = col(Y); be = col(y)
    A = np.array([al[n] * math.exp(n - lc[n]) for n in range(NMAX + 1)]); B = np.array([be[n] * math.exp(n - lc[n]) for n in range(NMAX + 1)])
    d = A - B
    h = lambda j: 1.0 if j <= Y else Y / j
    light = pos = tie = lead = 0.0
    for i in range(1, N):
        m = N - 1 - i
        if i <= y:
            light += PI[N - 1][i] * (1 - c) * i * d[m] / N
        else:
            mu = (1 - c) * (m + 1) + c * y
            t0 = B[m] * B[i - 1] * (((1 - c) * (i - y) - c * Y) / (i + 1) + mu / i)
            pos += PI[N - 1][i] * (t0 + B[m] * d[i - 1] * Y * (mu / i - c * Y / (i + 1)) + d[m] * B[i - 1] * Y * ((1 - c) * i - c) / (i + 1)) / N
            tie += PI[N - 1][i] * d[m] * d[i - 1] * c * Y * Y / (i + 1) / N
            if m <= y: lead += PI[N - 1][i] * t0 / N
    pit = lambda j: (j - 1) / N * (PI[N - 1][j - 1] if j - 1 >= 1 else 0.0) + (N - j) / N * (PI[N - 1][j] if j <= N - 1 else 0.0)
    Q = lambda j: h(j) * A[j - 1] * A[N - j]
    X = sum((pit(j) - PI[N][j]) * (Q(j) - Q(N)) for j in range(1, N))
    scale = (N - y) / N * d[N - 1]
    return light / scale, pos / scale, tie / scale, X / scale, lead / scale, d[N - 1] / B[N - 1] * y
print("parts of the first-tree source, c = 1/2, in units of the scale: (y, N): light, heavy positive, tie, X  => source ;  [heavy first tree with light rest, survival term] ; y*P_{N-1}(y)/F_{N-1}(y-1)")
for (y, N) in [(30, 63), (30, 90), (30, 200), (30, 300), (100, 203), (100, 300), (3, 9), (3, 60), (3, 92), (3, 180)]:
    if N <= NMAX:
        l, p_, t, X, ld, hz = parts(y, N)
        print("  (%3d, %3d): %+.4f, %+.4f, %-.4f, %.4f => %+.4f ; [%.4f] ; %.3f" % (y, N, l, p_, -t, X, l + p_ - t - X, ld, hz))
