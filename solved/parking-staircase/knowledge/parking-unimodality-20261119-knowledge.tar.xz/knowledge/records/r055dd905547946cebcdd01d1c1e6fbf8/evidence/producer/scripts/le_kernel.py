# (LE)의 원천의 핵 꼴:  L_k(x) = sum_{m=1}^{x-1} alpha_k(x-m) C(m) + (1/k) sum_g C2(g)(x-g) EE_k(x-g)   [EE >= 0: 정리 A]
#   C(m) = k sum_{g=1}^{m} C2(g) R_{N-g}(m-g+1) - C2(m)(x-m)^2/k + c1(m),
#   C2(g) = (N+k-2)/(2(k-1)) q_{N-1}(g)/(2k+x-g),  c1(m) = Gamma_N(m) - q_{N-1}(m)(x+m(k-1))/(2k+x-m).
# 음의 계수를 보조정리 8과 (I_d)로 지운다 (정확한 등식):
#   alpha_k(x-s) = sum_{m>s} alpha_k(x-m) E_s(m),  E_s(m) = [k kk_{N-s}(m-s) + (k/(x-s-1)) R_{N-s-1}(m-s)]/(N-s)   (x-s >= 2)
# 지운 뒤의 계수가 모두 음이 아니면 L_k(x) >= 0 이 Borel 수만의 부등식에서 따른다.
# 이 스크립트는 주차함수의 수를 쓰지 않는다 (tau_j = j^{j-1}/j! 만 쓴다).
import sys
from mpmath import mp, mpf
mp.dps = 30

def analyse(k, x, tau, verbose=False):
    N = k+x
    def q(NN, g): return tau[g]*tau[NN-g]/tau[NN]
    # R_{NN}(b), b=1..x  for NN = N, N-1, ..., N-x
    Rt = {}
    def Rrow(NN, upto):
        if NN not in Rt:
            row = [None, mpf(1)]
            s = mpf(1)
            for g in range(1, upto+1):
                s = s - q(NN, g); row.append(s)
            Rt[NN] = row
        return Rt[NN]
    for NN in range(N-x, N+1):
        Rrow(NN, min(x, NN-1))
    def R(NN, b): return Rt[NN][b]
    def Pi(NN, m): return 1 - R(NN, m+1) if m >= 1 else mpf(0)
    def kk(NN, m): return Pi(NN, m) - Pi(NN-1, m-1)
    C2 = [None]; c1 = [None]
    for g in range(1, x):
        qq = q(N-1, g)
        Gam = (N-1)*(Pi(N-1, g) - Pi(N, g))
        c1.append(Gam - qq*mpf(x + g*(k-1))/(2*k+x-g))
        C2.append(mpf(N+k-2)/(2*(k-1))*qq/(2*k+x-g))
    C = [None]
    for m in range(1, x):
        C.append(k*sum(C2[g]*R(N-g, m-g+1) for g in range(1, m+1)) - C2[m]*mpf((x-m)**2)/k + c1[m])
    coef = C[:]
    steps = []
    for s in range(1, x-1):            # alpha_k(x-s), x-s >= 2
        if coef[s] < 0:
            steps.append(s)
            for m in range(s+1, x):
                E = (k*kk(N-s, m-s) + mpf(k)/(x-s-1)*R(N-s-1, m-s))/(N-s)
                coef[m] += coef[s]*E
            coef[s] = mpf(0)
    ok = all(coef[m] >= 0 for m in range(1, x))
    # 여유: 지운 뒤 남은 계수 / 원래의 양의 계수 의 최솟값 (원래 양이던 m에서)
    marg = min([coef[m]/C[m] for m in range(1, x) if C[m] > 0 and m not in steps] or [mpf(1)])
    negC = [m for m in range(1, x) if C[m] < 0]
    return ok, steps, negC, marg, C

def main():
    ks = [int(a) for a in sys.argv[1:]]
    for k in ks:
        tau = [None, mpf(1)]
        for j in range(2, 2*k+4):
            tau.append(tau[-1]*(mpf(j)/(j-1))**(j-2))
        if k <= 120: xs = list(range(2, k+2))
        else: xs = sorted(set(list(range(2, 41)) + [int(t*k) for t in (0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95)] + [k-1, k, k+1]))
        bad = []; maxsteps = 0; worst = (mpf(10), None); firstneg = None; first2 = None
        for x in xs:
            ok, steps, negC, marg, C = analyse(k, x, tau)
            if not ok: bad.append(x)
            maxsteps = max(maxsteps, len(steps))
            if marg < worst[0]: worst = (marg, x)
            if firstneg is None and negC: firstneg = x
            if first2 is None and len(steps) >= 2: first2 = x
        print('k=%d: tested %d values of x in [2,%d]; failures (some final coefficient < 0): %s; max elimination steps %d; '
              'C(1)<0 first at x=%s; two steps first at x=%s; worst remaining margin %.4f at x=%s'
              % (k, len(xs), k+1, bad, maxsteps, firstneg, first2, float(worst[0]), worst[1]))
        sys.stdout.flush()
main()
