# 명제 8의 원천 L_k(x)의 부호를 큰 k의 창(x <= XMUL * k^{2/3})에서 본다.
# 필요한 것은 열 c = k, k-1 의 누적 수뿐이다 (a_n(c) = A_{n,c-1}/n!; 열별 재귀).
# 논증에서 나온 추측(「첫 층에서 L_k(x) >= 0」)의 시험: 눈금 극한의 어림이 큰 z에서 음을 예고하므로 그 자리에서 직접 본다.
import sys
from mpmath import mp, mpf, factorial
mp.dps = 40
k = int(sys.argv[1]); XMUL = float(sys.argv[2]) if len(sys.argv) > 2 else 4.0
X = min(k+1, int(XMUL * k**(2.0/3)) + 2)
NMAX = k + X + 2

def col(c, nmax):
    a = [mpf(1)]
    for n in range(1, nmax+1):
        s = mpf(0)
        h = (n-1)//2
        for j in range(0, h+1):
            i = n-1-j
            if i == j:
                s += min(j+1, c) * a[j] * a[j]
            else:
                s += (min(j+1, c) + min(i+1, c)) * a[j] * a[i]
        a.append(s/n)
    return a
aK = col(k, NMAX); aKm = col(k-1, NMAX)
cay = [mpf(1)]
for n in range(1, NMAX+1):
    cay.append(cay[-1] * (mpf(n+1)/n)**(n-1) if n >= 2 else mpf(1))   # c_n/c_{n-1} = (1+1/n)^{n-1}
# 점검: c_n = (n+1)^{n-1}/n!
assert abs(cay[5] - mpf(6**4)/factorial(5)) < mpf(10)**(-30)
def Pk(N):  return aK[N-1]/cay[N-1] if N-1 >= k else mpf(1)      # P_k(N) = Pr(M_{N-1} < k)
def Pkm(N): return aKm[N-1]/cay[N-1] if N-1 >= k-1 else mpf(1)   # P_{k-1}(N)
ek = [mpf(0)] + [1 - mpf(k)/(k+y)*Pk(k+y) for y in range(1, X+2)]          # e_k(y)
ekm = [mpf(0)] + [1 - mpf(k-1)/(k-1+y)*Pkm(k-1+y) for y in range(1, X+2)]  # e_{k-1}(y)
al = [mpf(0)] + [ek[y]-ek[y-1] for y in range(1, X+2)]
sg = [mpf(1)] + [1-ekm[y] for y in range(1, X+2)]
na = [mpf(0)] + [ekm[y]-ek[y] for y in range(1, X+2)]
tau = [None, mpf(1)]
for j in range(2, NMAX+2):
    tau.append(tau[-1] * (mpf(j)/(j-1))**(j-2))      # tau_j/tau_{j-1} = (j/(j-1))^{j-2}
assert abs(tau[6] - mpf(6**5)/factorial(6)) < mpf(10)**(-30)

xs = sorted(set([2, 3, 5, 10] + [int(t*k**(2.0/3)) for t in (0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.25, 3.5, 3.75, 4, 5, 6, 8) if 2 <= int(t*k**(2.0/3)) <= X-1]))
print('k=%d  k^(2/3)=%.1f  X=%d' % (k, k**(2.0/3), X))
for x in xs:
    N = k+x
    L = mpf(0); pos = mpf(0); neg = mpf(0); gam_part = mpf(0); sig_part = mpf(0)
    PiA = mpf(0); PiB = mpf(0)     # Pi_{N-1}(g), Pi_N(g)
    for g in range(1, x):
        qA = tau[g]*tau[N-1-g]/tau[N-1]; qB = tau[g]*tau[N-g]/tau[N]
        PiA += qA; PiB += qB
        Gam = (N-1)*(PiA - PiB)
        cneg = qA*mpf(x + g*(k-1))/(2*k+x-g)
        c2 = mpf(N+k-2)/(2*(k-1))*qA*mpf(x-g)/(2*k+x-g)
        t_gam = Gam*al[x-g]; t_neg = cneg*al[x-g]; t_sig = c2*sg[x-g]
        gam_part += t_gam; neg += t_neg; sig_part += t_sig
    L = gam_part + sig_part - neg
    Om = (2*k+x)*na[x] - mpf(x)/(k-1)*sg[x] - x*al[x]
    w = mpf(x)/(2*(N-1))
    cell = Pk(N-1) - Pkm(N-1)
    theta = (Pk(N) - Pkm(N-1))/(2*w*cell)
    print('  x=%5d z=%.2f : N*L=% .5e  (sigma part %.3e, Gamma part %.3e, negative %.3e; pos/neg=%.4f)  N*Omega=% .5e  theta=%.4f  sigma_{k-1}(x)=%.3e'
          % (x, x/k**(2.0/3), float(L*N), float(sig_part*N), float(gam_part*N), float(neg*N), float((gam_part+sig_part)/neg), float(Om*N), float(theta), float(sg[x])))
