# 부록: 본문 밖의 결과, 인용으로 돌린 것, 막힌 자리

본문(`exposition.md`)의 3–6절이 두 구획을 닫는 줄기다. 이 부록은 시도가 그 줄기 밖에서 얻은 것을 지위별로 적는다. 기호는 본문 1절의 것이다. A와 H는 게시된 결과와 겹쳐 인용으로 돌린 것, B와 D와 E는 증명된 명제, C는 계산으로 본 반례, F는 증명이 아닌 선두 차수 계산, G는 막힌 자리다. 이 파일의 절 A–H는 논문의 부록 B(계산 항목)나 게시된 기록 r496399b6의 부록 B(정리 5.9의 증명)와 다른 것이다.

---

## A. 인용으로 돌린 것: 곡률의 비는 맨 아래 사슬 하나의 비로 눌린다

시도의 보고 3절은 다음을 증명했다. 첫 층의 자리에서 $u_m(y):=\frac y{N-m}\Lambda_m(y;N)$, $\rho_m:=\dfrac{\Delta^2u_m(k+1)}{\Delta^2u_m(k)}$ ($2\le m\le r$; $\Delta^2u(x)=u(x+1)-2u(x)+u(x-1)$)로 두면 $1=\rho_2\le\rho_3\le\dots\le\rho_r$이고 $C_+/C_-\le\rho_r$이다. 따라서 $\rho_r<B_+/B_-$이면 $\mathcal S_{n,k}>0$이다. 재료는 둘이다. 거듭제곱의 둘째 차분 $\delta_q(x)=(x+1)^q-2x^q+(x-1)^q$의 비 $\delta_q(x_2)/\delta_q(x_1)$ ($x_1<x_2$)가 $q$에 대해 비감소라는 것과, 게시된 r3dc4f6e9의 따름정리 D (라)다.

같은 진술이 같은 두 재료로 r69068ac5의 주장 `p-single-chain-bound` (가), (나)에 게시되었다(그 기록의 보조정리 4.4와 정리 4.5; 범위는 $k\ge3$, $k+2\le n\le2k$). 시도는 그 게시 전에 따로 얻었다. 이 기록은 그것을 주장으로 내지 않고 인용한다. 시도의 증명은 `evidence/source/producer-report.md`의 3절에 있고, 동료가 손으로 따라가고 네 자리에서 정확한 유리수로 대조했다(`evidence/peer/v10_secondary.out`). 같은 주장의 (라)는 순서 $\rho_r\le\sigma(k+1)$까지 준다. 아래 B는 $\rho_r$의 다른 상계를 준다.

---

## B. 한 문턱 가중 법칙 아래의 판정식 (시도; 증명됨)

정리 5.9의 증명과 본문 4절의 판정식은 곡률 쪽과 경계 쪽을 서로 다른 균질한 법칙과 견준다. 이 절은 두 쪽을 길이 $r$의 합성 위의 문턱 가중 법칙 하나로 적는다. 본문의 줄기에는 쓰이지 않는다.

### 기호와 세 사실

첫 층의 자리 $(n,k)$를 고정한다($N=n+1$, $r=n-k\ge2$). 실수 $\eta>0$에 대해 $\mathbf P_\eta$는 길이 $r$의 합성 위에서 문턱 윤곽 $\lambda_s=\eta/(N-s)$를 준 법칙이고(총질량 $\Lambda_r(\eta;N)$), $\mathbf E_\eta$는 그 평균이다. $J=|S|$, $Q=J+1$이고, $\gamma:=r-\max(S\cup\{0\})$는 자리 $r$ 쪽 끝의 토막의 길이다. $\alpha(g):=a_{g+1}/a_g=(1+\frac1g)^{g-1}$.

**(F1)** $\eta\,\Lambda_r'(\eta)/\Lambda_r(\eta)=\mathbf E_\eta J$이고 $\mathbf E_\eta J$는 $\eta$에 대해 비감소다($\frac d{d\log\eta}\mathbf E_\eta J=\mathrm{Var}_\eta J$).

**(F2)** $P(y):=y\Lambda_r(y)=\sum_{q=1}^rp_qy^q$로 두면 $\mathbf P_\eta(Q=q)\propto p_q\eta^q$이고, $y>0$에서 $D(y):=\dfrac{yP'''(y)}{P''(y)}=\dfrac{\mathbf E_yQ(Q-1)(Q-2)}{\mathbf E_yQ(Q-1)}$이다. $D(y)$는 $q(q-1)p_qy^q$에 비례하는 법칙 아래 $Q-2$의 평균이고, 그 법칙이 $\log y$에 대한 지수족이므로 $D$는 비감소다.

**(F3)** $y>0$에서 $\Lambda_{r+1}(y;N)=\Lambda_r(y;N)\Bigl(\dfrac y{N-r}+\mathbf E_y\,\alpha(\gamma)\Bigr)$. ($r+1$의 합성의 맨 끝 칸을 떼어 낸다. 거꾸로 $r$의 합성 하나에서 $r+1$의 합성이 둘 나온다. 끝에 길이 $1$의 토막을 붙이면 자르는 점 $r$의 인자 $\frac y{N-r}$와 $a_1=1$이 곱해지고, 끝 토막 $\gamma$를 $\gamma+1$로 늘리면 무게가 $\alpha(\gamma)$배가 된다. 다른 자르는 점의 인자는 바뀌지 않는다. r3dc4f6e9의 9.1절이 적은 등식이다.)

### 판정식

**명제 B.1.** 첫 층의 자리에서

$$\mathcal D:=D(k+2)\,\log\frac k{k-1},\qquad\mathcal B:=(k-2)\log\Bigl(1+\frac1k\Bigr)-\log\Bigl(\frac{k-1}{k+1}+\mathbf E_{k-1}\alpha(\gamma)\Bigr)+\mathbf E_{k-1}J\cdot\log\frac k{k-1}+\mathbf E_kJ\cdot\log\Bigl(1+\frac2k\Bigr)$$

로 두면 $\log\dfrac{C_+}{C_-}\le\log\rho_r\le\mathcal D$이고 $\log\dfrac{B_+}{B_-}\ge\mathcal B$이다. 따라서 $\mathcal D<\mathcal B$이면 $\mathcal S_{n,k}>0$이다.

*증명.* 첫 부등식은 A의 인용이다. 둘째. $u_r$은 $P$의 상수 배이므로 $\rho_r=\Delta^2P(k+1)/\Delta^2P(k)$이고, $\Delta^2P(x)=\int_{-1}^1(1-|t|)P''(x+t)\,dt$이다. $t\in[-1,1]$이면 (F2)로

$$\log\frac{P''(k+1+t)}{P''(k+t)}=\int_{k+t}^{k+1+t}D(\eta)\,\frac{d\eta}\eta\ \le\ D(k+2)\log\frac{k+1+t}{k+t}\ \le\ D(k+2)\log\frac k{k-1}$$

이다. $(1-|t|)$를 곱해 적분하면 $\Delta^2P(k+1)\le e^{\mathcal D}\Delta^2P(k)$이다. 셋째. (5.8)과 $\frac k{k+1}\cdot\frac{a_{k+1}}{a_k}=(1+\frac1k)^{k-2}$로

$$\log\frac{B_+}{B_-}=(k-2)\log\Bigl(1+\frac1k\Bigr)+\log\frac{\Lambda_r(k+2)}{\Lambda_r(k)}+\log\frac{\Lambda_r(k)}{\Lambda_r(k-1)}-\log\frac{\Lambda_{r+1}(k-1)}{\Lambda_r(k-1)}$$

이다. (F1)로 $\log\frac{\Lambda_r(k+2)}{\Lambda_r(k)}=\int_k^{k+2}\mathbf E_\eta J\,\frac{d\eta}\eta\ge\mathbf E_kJ\log(1+\frac2k)$이고 $\log\frac{\Lambda_r(k)}{\Lambda_r(k-1)}\ge\mathbf E_{k-1}J\log\frac k{k-1}$이다. (F3)에 $y=k-1$, $N-r=k+1$을 넣으면 마지막 항이 나온다. $\square$

**따름 B.2.** 모든 $y>0$에서 $D(y)\le\dfrac32\cdot\dfrac{\mathbf E_yQ(Q-1)}{\mathbf E_yQ}$이다. 따라서 첫 층의 자리에서 $\dfrac32\cdot\dfrac{\mathbf E_{k+2}Q(Q-1)}{\mathbf E_{k+2}Q}\cdot\log\dfrac k{k-1}<\mathcal B$이면 $\mathcal S_{n,k}>0$이다.

*증명.* $\mathbf P_y(Q=q)\propto p_qy^q$이고 $(p_q)_{1\le q\le r}$은 $\Lambda_r(\cdot;N)$의 계수여서 양이고 로그오목이다(r3dc4f6e9의 따름정리 D (라)). $y^q$를 곱해도 그렇다. 보조정리 B.3의 $j=2$가 $\bigl(\frac12\mathbf EQ(Q-1)\bigr)^2\ge\mathbf EQ\cdot\frac16\mathbf EQ(Q-1)(Q-2)$를 준다. $\square$

**보조정리 B.3 (Brenti의 판정법).** $(p_q)_{q\ge0}$이 음이 아닌 유한 수열이고 로그오목이며 안쪽에 $0$이 없으면, $b_j:=\sum_q\binom qjp_q$에 대해 모든 $j\ge1$에서 $b_j^2\ge b_{j-1}b_{j+1}$이다.

이것은 「계수가 음이 아니고 로그오목이며 안쪽에 $0$이 없는 다항식 $P(x)$에 대해 $P(x+1)$의 계수도 로그오목」이라는 알려진 사실이다($\sum_jb_jt^j=\sum_qp_q(1+t)^q$). 문헌에서는 Brenti의 것으로 인용된다(F. Brenti, *Unimodal, log-concave and Pólya frequency sequences in combinatorics*, Mem. Amer. Math. Soc. 413 (1989)). r69068ac5의 `p-homogeneous-mean` (라)도 같은 사실을 Wang–Yeh의 인용(Brenti 1994, Hoggar 1974)과 함께 적었다. 이 기록은 원문의 정리 번호를 대조하지 못했으므로 문헌을 걸음으로 쓰지 않고 시도의 증명을 적는다.

*증명.* $b_j^2-b_{j-1}b_{j+1}=\sum_{q,q'}p_qp_{q'}\bigl[\binom qj\binom{q'}j-\binom q{j-1}\binom{q'}{j+1}\bigr]$을 합 $s=q+q'$별로 묶고 $q\leftrightarrow q'$로 대칭화하면 $\frac12\sum_s\sum_{q=0}^sw_s(q)\varphi_s(q)$, $w_s(q):=p_qp_{s-q}$,

$$\varphi_s(q):=2\binom qj\binom{s-q}j-\binom q{j-1}\binom{s-q}{j+1}-\binom{s-q}{j-1}\binom q{j+1}$$

이고 $w_s$, $\varphi_s$는 $q\mapsto s-q$에 대해 대칭이다. (a) $\sum_{q=0}^s\binom qa\binom{s-q}b=\binom{s+1}{a+b+1}$이므로 $\sum_q\varphi_s(q)=0$이다. (b) $0\le q\le s/2$에서 $\varphi_s$는 부호를 많아야 한 번, 음에서 양으로 바꾼다. $q<j$이면 $\varphi_s(q)\le0$이고, $j\le q\le s/2$이면 $a:=q-j\le b:=s-q-j$로 두어 $\varphi_s(q)=\binom qj\binom{s-q}j\bigl[2-\frac j{j+1}\bigl(\frac b{a+1}+\frac a{b+1}\bigr)\bigr]$인데, $a+b$를 고정하면 $\frac b{a+1}+\frac a{b+1}$이 $a\le b$에서 $a$에 대해 비증가이기 때문이다. (c) 따라서 왼쪽 부분합 $\sum_{q<q_0}\varphi_s(q)$는 $q_0$가 늘 때 줄다가 늘고, 왼쪽 절반의 끝에서의 값이 $s$가 홀수이면 $0$, 짝수이면 $-\frac12\varphi_s(s/2)\le0$이므로 모두 $0$ 이하다. (a)와 대칭으로 $F_s(q_0):=\sum_{q=q_0}^{s-q_0}\varphi_s(q)=-2\sum_{q<q_0}\varphi_s(q)\ge0$이다. (d) 로그오목성과 안쪽에 $0$이 없다는 것에서 $w_s$는 $0\le q\le s/2$에서 비감소다. $\varepsilon_{q_0}:=w_s(q_0)-w_s(q_0-1)\ge0$ ($w_s(-1):=0$)으로 두면 $w_s(q)=\sum_{q_0\le\min(q,s-q)}\varepsilon_{q_0}$이고 $\sum_qw_s(q)\varphi_s(q)=\sum_{q_0\le s/2}\varepsilon_{q_0}F_s(q_0)\ge0$이다. $\square$

### 이 판정식이 요구하는 것

네 자리 $(20,13),(30,21),(45,33),(60,46)$에서 정확한 유리수로 계산하면 $\log\frac{C_+}{C_-}\le\log\rho_r\le\mathcal D<\log\frac{B_+}{B_-}$이다. $(60,46)$에서 네 값은 $0.0683,\ 0.0823,\ 0.0867,\ 0.1543$이다(`evidence/peer/v10_secondary.out`). 시도의 계산에서는 행 $31,45,60,94$의 감소 자리 모두에서 따름 B.2의 조건이 성립하고 행 $94$의 한가운데 $(94,48)$에서 깨진다(`evidence/source/work/t01_falling_side.out`, `t02_all_first_layer.out`).

$\mu:=\mathbf EJ$, $V:=\mathrm{Var}\,J$로 적고 세 매개값 $k-1,k,k+2$의 차이를 무시하면 따름 B.2의 조건은 「절단 수의 분산이 평균의 제곱의 삼분의 일쯤보다 작다」는 꼴이다. 이것을 일반으로 증명하려면 문턱 가중 법칙 아래 $J$의 분산의 **상계**가 필요하다. 균질한 법칙에서는 닫힌 꼴 $T_{m,q}$가 그것을 주지만((평균)의 둘째 부등식), 문턱 윤곽에서는 얻지 못했다. 시도가 시험한 충분조건이 C의 모양 가정이고, 그것은 벌크에서 거짓이다. 본문의 줄기는 그래서 균질한 법칙과의 견줌(보조정리 3.1, 3.2)으로 갔다.

---

## C. 모양 가정 (H)의 반례 (시도의 계산; 동료가 다시 계산)

> **(H)** 문턱 윤곽의 법칙 $\mathbf P_\eta$ 아래 $j\mapsto\mathbf P_\eta(J=j)/(j+1)$이 로그오목이다.

같은 진술 「$\mathbb P_\lambda(Q=q)/q$가 $q$에 대해 로그오목」을 r3dc4f6e9의 `p-monotone-observations` (2)가 문턱 윤곽 $150$개($3\le m\le12$)에서 관찰했다. (H)가 서면 B의 끝에 적은 분산의 상계가 나온다. $v_j=\mathbf P(J=j)/(j+1)$이 로그오목이면 $\mathbf EJ(J-1)\le\frac32(\mathbf EJ)^2$이다(r69068ac5의 `p-homogeneous-mean` (라)가 적은 일반 꼴; 균질한 법칙에서는 $v_j$의 닫힌 꼴이 로그오목성을 준다).

**(H)는 문턱 윤곽에서 일반으로 성립하지 않는다.** $(n,k)=(400,201)$, 곧 $N=401$, 길이 $r=199$, $\eta=201$에서 $v_1^2/(v_0v_2)=0.990072$, $v_2^2/(v_1v_3)=0.995881$이고 $j\ge3$에서는 로그오목이다. $(200,101)$에서는 성립한다(같은 비가 $1.00179$, $1.00738$). 계산은 $\Lambda_r$의 계수의 점화식을 60자리 부동소수로 돌린 것이고(모든 항이 양이어서 지워짐이 없다; `evidence/peer/v12_H_check.py`, `.out`), 시도의 계산(`evidence/source/work/t07_H_check.out`; 40자리)과 여섯 자리까지 같다. 어긋남이 $10^{-2}$ 크기여서 계산 오차와 거리가 멀지만, 정확한 유리수 계산은 아니다.

까닭은 F의 포화 법칙으로 읽힌다. 벌크에서 $J$의 법칙은 $j=0$ 근처에서 평평해지고, 평평한 수열을 $j+1$로 나눈 것은 로그볼록이다. 그러므로 (H)는 기껏해야 곡선 근처와 그 뒤에서만 참일 수 있고, 게시된 관찰은 짧은 길이에 한정된 것이다.

---

## D. 구획의 극한 꼴: 극한 밀도가 오르는 쪽 전체에서 $W<0$ (시도; 증명됨)

구획 (X↓)의 임계 창에서의 극한 꼴은 「극한 밀도가 오르는 곳에서 $W<0$」이다. 게시된 기록은 $W<0$을 값이 정해지지 않은 $z\le z_a$와 $z\ge z_b$에서 증명하고 그 사이를 추측으로 남겼다(r496399b6의 `p-limit-tails`, `p-limit-conjecture`). 이 절은 $z_a$를 명시적인 값 $(4/5)^{2/3}=0.8617\ldots$로 잡을 수 있고 그 범위가 밀도가 오르는 쪽 전체를 품는다는 것을 보인다. 극한 대상에 대한 정리이고, 이산의 어떤 진술도 함의하지 않는다(게시된 대응은 발견적이다).

### 기호와 진술

기호는 r496399b6의 `p-limit-form`의 것이다. $B$는 표준 브라운 운동, $\bar B_t=\max_{s\le t}B_s$, $\mathcal A_z=\int_0^z\bar B_t\,dt$, $\psi(z)=\mathbb Ee^{-\mathcal A_z}$, $f=-\psi'$, $m_j(z)=\mathbb E[\bar B_z^je^{-\mathcal A_z}]$, $\tau_b=\inf\{t:B_t>b\}$, $T=\tau_1^{-1/2}$, $V=\mathcal A_{\tau_1}\tau_1^{-3/2}$, $\beta_j(z)=\frac12z^{(j-1)/2}\,\mathbb E[T^{j+1}e^{-z^{3/2}V}]$, $W=f''m_2+f'm_3$, $\lambda_C=m_3/m_2$, $\gamma=\frac{2\sqrt2}3$, $E(p,b)=\exp(-\gamma((p+b)^{3/2}-p^{3/2}))$. 그 주장의 증명된 부분에서 다음 셋을 쓴다. (i) $p>0$과 음이 아닌 가측 함수 $\varphi$에 대해 $\int_0^\infty e^{-pz}\,\mathbb E[\varphi(\bar B_z)e^{-\mathcal A_z}]\,dz=\int_0^\infty\varphi(b)\sqrt2\,(p+b)^{-1/2}E(p,b)\,db$. (ii) $j\ge1$에서 $m_j'=j\beta_{j-1}-m_{j+1}$. (iii) $W=\beta_0'm_2+(m_3\beta_0-2\beta_1m_2)$이고 $\beta_0'm_2<0$. 그래서 부등식 (Y): $m_3\beta_0\le2\beta_1m_2$가 성립하는 $z$에서 $W(z)<0$이다.

**정리 D.1.** $c:=\sqrt{2/\pi}$, $u:=z^{3/2}$로 적는다. $0<u\le\frac45$인 모든 $z$에서

$$\frac{\lambda_C(z)}{2\beta_1(z)/\beta_0(z)}\ \le\ \frac{\bigl(2c-\frac74u+\frac{86}{63}c\,u^2\bigr)\bigl(c-\frac12u+\frac4{15}c\,u^2\bigr)}{2\exp\bigl(-\frac{11}5c\,u\bigr)}\ <\ 1$$

이다. 따라서 $0<z\le(4/5)^{2/3}$에서 (Y)가 엄격하게 성립하고 $W(z)<0$이다.

**따름 D.2 (구획의 극한 꼴).** $f$가 $[0,z]$에서 비감소이면 $W(z)<0$이다. 그런 $z$에서 $f''(z)<-\lambda_C(z)f'(z)\le0$이다.

*증명.* ra98af63d의 `c-limit-mode`에 따라 $f$가 $[0,z]$에서 비감소이면 $z^{3/2}\le\sqrt{2/\pi}=0.7978\ldots<\frac45$이다. 정리 D.1이 $W(z)<0$을 주고, $W=f''m_2+f'm_3$, $m_2>0$, $f'(z)\ge0$에서 둘째 문장이 나온다. $\square$

### 닫힌 꼴의 모멘트

$M:=\bar B_1$, $A:=\mathcal A_1$로 적는다($0\le A\le M$).

**보조정리 D.3.** 정수 $j,l\ge0$에 대해

$$\mathbb E[M^jA^l]=\frac{(-1)^l\,l!\,(j+l)!\;h_{j,j+l}}{\gamma^{\,j+l}\;\Gamma\bigl(\frac{j+3l}2+1\bigr)},\qquad h_{j,i}:=[w^i]\,\bigl((1+w)^{2/3}-1\bigr)^j(1+w)^{-2/3}.$$

*증명.* 브라운 눈금으로 $m_j(z)=z^{j/2}\,\mathbb E[M^je^{-z^{3/2}A}]=\sum_{l\ge0}\frac{(-1)^l}{l!}\mathbb E[M^jA^l]\,z^{(j+3l)/2}$이고, Watson의 보조정리로 $p\to\infty$에서 $\int_0^\infty e^{-pz}m_j(z)\,dz\sim\sum_l\frac{(-1)^l}{l!}\mathbb E[M^jA^l]\,\Gamma\bigl(\frac{j+3l}2+1\bigr)p^{-(j+3l)/2-1}$이다. 한편 (i)의 우변에서 $\varphi(b)=b^j$로 두고 $b=pt$, $w=(1+t)^{3/2}-1$로 바꾸면 $\sqrt2\int_0^\infty b^j(p+b)^{-1/2}E(p,b)\,db=\gamma\,p^{j+1/2}\int_0^\infty\bigl((1+w)^{2/3}-1\bigr)^j(1+w)^{-2/3}e^{-\gamma p^{3/2}w}\,dw$이고, 다시 Watson의 보조정리로 이것은 $\sum_{i\ge j}h_{j,i}\,i!\,\gamma^{-i}\,p^{\,j-1-3i/2}$에 점근한다. $i=j+l$에서 두 전개의 계수를 견준다. $\square$

필요한 값: $\mathbb EM=c$, $\mathbb EM^2=1$, $\mathbb EM^3=2c$, $\mathbb E[MA]=\frac58$, $\mathbb E[M^2A]=\frac65c$, $\mathbb E[MA^2]=\frac{16}{21}c$, $\mathbb E[M^3A]=\frac74$, $\mathbb E[M^3A^2]=\frac{172}{63}c$.

**보조정리 D.4.** $j\ge1$과 $u\ge0$에 대해 $\mu_j(u):=\mathbb E[M^je^{-uA}]$, $\nu_j(u):=\mathbb E[M^jAe^{-uA}]$로 두면 $\mathbb E[T^je^{-uV}]=\mu_j(u)+\frac uj\bigl(2\mu_{j+1}(u)-3\nu_j(u)\bigr)$이다. 따라서 $l\ge1$에서 $\mathbb E[T^jV^l]=\bigl(1+\frac{3l}j\bigr)\mathbb E[M^jA^l]-\frac{2l}j\,\mathbb E[M^{j+1}A^{l-1}]$이고 $\mathbb E[T^j]=\mathbb E[M^j]$이다.

*증명.* $m_j(z)=z^{j/2}\mu_j(z^{3/2})$를 미분하면 $m_j'=z^{j/2-1}\bigl[\frac j2\mu_j-\frac32u\,\nu_j\bigr]$ ($u=z^{3/2}$)이다. (ii)의 $j\beta_{j-1}=m_j'+m_{j+1}$에 이것과 $m_{j+1}=z^{j/2-1}u\,\mu_{j+1}$, $\beta_{j-1}=\frac12z^{j/2-1}\,\mathbb E[T^je^{-uV}]$를 넣는다. 둘째 문장은 $u$의 거듭제곱의 계수를 견준 것이다. $\square$

필요한 값: $\mathbb ET=c$, $\mathbb ET^2=1$, $\mathbb E[TV]=\frac12$, $\mathbb E[T^2V]=c$, $\mathbb E[TV^2]=\frac8{15}c$.

### 정리 D.1의 증명

$m_3=z^{3/2}\mu_3(u)$, $m_2=z\mu_2(u)$, $\beta_0=\frac12z^{-1/2}\mathbb E[Te^{-uV}]$, $\beta_1=\frac12\mathbb E[T^2e^{-uV}]$이므로

$$\frac{\lambda_C}{2\beta_1/\beta_0}=\frac{\mathbb E[M^3e^{-uA}]\cdot\mathbb E[Te^{-uV}]}{2\,\mathbb E[M^2e^{-uA}]\cdot\mathbb E[T^2e^{-uV}]}$$

이다. 분자는 $e^{-t}\le1-t+\frac{t^2}2$ ($t\ge0$)로 위에서 막는다: $\mathbb E[M^3e^{-uA}]\le2c-\frac74u+\frac{86}{63}cu^2=:P_1(u)$, $\mathbb E[Te^{-uV}]\le c-\frac12u+\frac4{15}cu^2=:P_2(u)$. 분모는 Jensen 부등식으로 아래에서 막는다. $M^2\,d\mathbb P$와 $T^2\,d\mathbb P$가 확률측도이므로 $\mathbb E[M^2e^{-uA}]\ge e^{-\frac65cu}$, $\mathbb E[T^2e^{-uV}]\ge e^{-cu}$다. 이것이 첫 부등식이다. 둘째 부등식 $U:=P_1P_2<2e^{-\frac{11}5cu}=:L$을 $0\le u\le\frac45$에서 보인다. $P_1$은 $u<0.8033$에서, $P_2$는 $u<1.17$에서 감소하고 둘 다 $[0,\frac45]$에서 양이므로 $U$는 감소하고, $L$도 감소한다. 그러므로 분할의 각 구간 $[u_i,u_{i+1}]$에서 $U(u_i)<L(u_{i+1})$이면 충분하다.

| $u_i$ | $0$ | $0.25$ | $0.40$ | $0.55$ | $0.70$ | $0.78$ |
|---|---|---|---|---|---|---|
| $U(u_i)$ | $1.27324$ | $0.84150$ | $0.67619$ | $0.56537$ | $0.49939$ | $0.48007$ |
| $L(u_{i+1})$ | $1.28957$ | $0.99105$ | $0.76163$ | $0.58532$ | $0.50864$ | $0.49109$ |

($u_6=\frac45$.) $\square$

보조정리 D.3의 값들은 기호 계산으로, 표는 다른 코드로 다시 계산했다(`evidence/peer/v07_limit.out`; 구간 $(0,\frac45]$에서 $U/L$의 최댓값은 $u=\frac45$의 $0.971$). 같은 논법은 $u=0.81$을 넘으면 서지 않는다.

### 읽기

밀도가 오르는 쪽에서는 기울임의 세기 $u=z^{3/2}$이 $0.8$ 아래에 머문다. 그래서 기울이지 않은 브라운 법칙 둘레의 이차 전개가 (Y)를 닫는다. 이산에서는 정리 5.9가 $u\le1$을, 본문의 정리 4.2가 $u\le\frac{11}5$을 덮는다. 곧 감소 자리에서 교차곱의 부등식은 극한에서도 이산에서도 여유를 가지고 선다. 구획에 모자랐던 것은 감소 자리가 그 범위 안에만 있다는 것, 곧 교차의 자리였다(본문 5–6절).

---

## E. 대각 걸음의 정확한 등식 (시도; 증명됨)

결손 $r\ge2$를 고정하고 $\Phi(k;r):=C_-(k+r,k)/B_-(k+r,k)$로 둔다($k\ge\max(r+1,3)$). 사슬을 초과의 열 $\mathbf c=(j_1>\dots>j_q)$, $r\ge j_1$, $j_q\ge1$, $q\ge0$으로 적고($j_i$는 사슬의 $i$째 무거운 꼭짓점의 크기에서 $k$를 뺀 값) $j_0:=r+1$, $W(\mathbf c):=\prod_{i=1}^qa_{j_{i-1}-j_i}$로 둔다. (5.8)에서

$$\frac{C_-}{n!}=\sum_{q\ge2}W(\mathbf c)\,\kappa_k(k+j_q)\,\frac{\delta_q(k)}{\prod_i(k+j_i)},\qquad\frac{B_-}{n!}=\frac{a_k}k\sum_{q\ge0}W(\mathbf c)\,a_{j_q}\frac{(k-1)^q}{\prod_i(k+j_i)}$$

이다($\delta_q(x)=(x+1)^q-2x^q+(x-1)^q$). 두 합의 항에 비례하는 확률측도를 $\mathbf E_C$, $\mathbf E_B$라 하자. $\kappa_k(k+j)=a_{k+j}\,\ell_k(j)$로 적고

$$X(\mathbf c):=\prod_{i=1}^q\frac{k(k+j_i)}{(k-1)(k+1+j_i)},\qquad\omega(\mathbf c):=\frac{(k+1)(k-1)^2}{k^3}\cdot\frac{\alpha(k+j_q)}{\alpha(k)}\cdot\frac{\ell_{k+1}(j_q)}{\ell_k(j_q)}\cdot\frac{\delta_q(k+1)}{\delta_q(k)}\Bigl(\frac{k-1}k\Bigr)^{q-2}$$

로 두면

$$\frac{\Phi(k+1;r)}{\Phi(k;r)}=\frac{\mathbf E_C[\omega X]}{\mathbf E_B[X]} \tag{E.1}$$

이다.

*증명.* 대각선을 따라 한 칸 가면($k\to k+1$, $n\to n+1$) 초과의 열과 간격 무게 $W$는 그대로다. 항 하나의 비는 $C_-$ 쪽에서 $\alpha(k+j_q)\frac{\ell_{k+1}(j_q)}{\ell_k(j_q)}\frac{\delta_q(k+1)}{\delta_q(k)}\prod_i\frac{k+j_i}{k+1+j_i}$, $B_-$ 쪽에서 $\frac{k\,\alpha(k)}{k+1}\bigl(\frac k{k-1}\bigr)^q\prod_i\frac{k+j_i}{k+1+j_i}$이고, $\prod_i\frac{k+j_i}{k+1+j_i}=\bigl(\frac{k-1}k\bigr)^qX$다. 두 쪽에 공통인 $(n+1)!/n!$은 지워진다. $\square$

$k\log X\approx\frac1k\sum_i(j_i+1)$은 사슬의 넓이이므로, (E.1)은 rbc6a3c2f가 발견적으로 적은 「잃음의 무게로 잰 넓이가 얻음의 무게로 잰 넓이를 넘는 몫」의 정확한 꼴이다. 시도는 대각선의 첫 감소 자리 세 곳 $(r,k)=(10,21),(14,46),(18,75)$에서 두 변을 계산했다. 등식은 열 자리까지 맞고, $k(\frac{\Phi(k+1)}{\Phi(k)}-1)=-0.401,-0.534,-0.586$이다(`evidence/source/work/t06_exact_step.out`). 동료는 등식을 손으로 따라갔고 이 수들을 다시 계산하지 않았다.

**한계.** $\Phi(\cdot;r)$는 단조가 아니다. 결손 $18$에서 $\Phi(19)=1.439<\Phi(20)=1.446$이고 그 뒤로 준다(`evidence/source/work/t04_diag_ratio.out`). 그래서 「$\Phi\le1$이면 걸음이 음」의 증명도 $\Phi>1$인 벌크를 따로 떼어야 한다. 이 등식에서 정리는 나오지 않았다. 대각 방향의 진술(노드 (Diag$_1$))에 대해 지금 게시된 것은 r69068ac5의 `p-crossing-staircase`다.

---

## F. 벌크의 선두 차수 계산 (시도; 어림이고 증명이 아니다)

이 절의 진술에는 증명이 없다. 오차항을 다스리지 않은 선두 차수 계산이다. 적는 까닭은 A의 판정 $\rho_r<B_+/B_-$와 C의 (H)가 왜 벌크에서 깨지는지를 한 그림으로 보여 주기 때문이다. 같은 극한 상수들은 r69068ac5의 `p-bulk-limit`(발견적 계산으로 게시됨)에 있고, 꼬리의 등식은 r496399b6의 `p-limit-tails`가 극한 대상에서 증명했다. 여기서 더하는 것은 (3)의 등식 하나다.

Borel 정규화 $\hat a_j:=e^{-j}a_j$를 쓴다($\sum_j\hat a_j=1$, $\hat a_j\approx j^{-3/2}/\sqrt{2\pi}$). 무거운 꼭짓점을 초과 $j=(\text{크기})-k$로 적으면 매개값 $y=k$에서 그 인자는 $k/(k+j)\approx e^{-j/k}$다. 영역은 벌크 $k^{2/3}\ll r\le k$다.

**포화 법칙.** 맨 아래가 정해진 사슬($\Lambda_r$, $\Lambda_{r+1}$)에서 문턱 바로 위(초과 $O(k^{2/3})$)의 점들은 간격이 독립인 갱신열이고, 점이 $j$개인 배치의 무게의 합은 $\prod_{i=1}^j\bigl(\sum_\gamma\hat a_\gamma e^{-i\gamma/k}\bigr)\approx\exp\bigl(-\sum_{i\le j}\sqrt{2i/k}\bigr)\approx\exp(-\beta\ell^{3/2})$, $\ell:=j/k^{1/3}$, $\beta:=\frac{2\sqrt2}3$이다. 곧 그 점의 수를 $k^{1/3}$으로 나눈 것의 법칙이 밀도 $\propto e^{-\beta\ell^{3/2}}$을 가진다. 인자 없는 법칙의 극한(Rayleigh)과 다르게 $0$에서 밀도가 양이다. 얼린 다항식 $K$의 사슬에서는 맨 아래 꼭짓점이 자유로워서 밀도에 $\ell^{-1/2}$이 더 곱해진다.

**(1) 두 쪽의 선두항이 같다.** 곡률 쪽 $k\,K'''/K''\approx k^{1/3}\beta^{-2/3}\Gamma(\frac73)/\Gamma(\frac53)$과 경계 쪽 $2\,\mathbf EJ\approx2k^{1/3}\beta^{-2/3}\Gamma(\frac43)/\Gamma(\frac23)$은 같은 값 $1.3717\,k^{1/3}$이다. 벌크에서 교차곱의 양성은 $k^{1/3}$ 눈금의 항이 아니라 그 아래 $O(1)$ 눈금의 항으로 정해진다는 뜻이다(`p-limit-tails`의 극한값 $2c_1/c_0=1.3717\ldots$과 같은 등식).

**(2) 맨 아래 사슬 하나의 비는 선두 차수에서 경계 쪽을 넘는다.** $\dfrac{\mathbb E[\ell^3]}{2\,\mathbb E[\ell^2]\,\mathbb E[\ell]}=\dfrac53\cdot\dfrac{\Gamma(\frac23)^2}{\Gamma(\frac13)}\approx1.1408>1$. 그러므로 A의 판정은 벌크 깊은 곳에서 큰 $n$에 깨져야 한다(`p-bulk-limit` (마)의 $1.565$ 대 $1.372$와 같은 수다. 게시된 계산에서 한가운데의 $\log\rho_r/\log(B_+/B_-)$는 $n=241,\dots,7681$에서 $0.837$에서 $1.0011$까지 오른다).

**(3) 문턱 바로 위의 점들 안에서는 막힘이 동률보다 크다.** 인자를 $e^{-j/k}$로, 가벼움의 확률을 간격 법칙의 꼬리 $\bar\ell(x):=\sum_{g\ge x}\hat a_g$로 바꾼 모형에서 $\phi(\theta):=\sum_g\hat a_ge^{-\theta g}$로 두면, 맨 아래가 정해진 사슬의 무게는 $W(q)=\prod_{i=1}^q\phi(i/k)$, 맨 아래가 자유로운 사슬의 무게는 $K_q=W(q-1)\sum_{x\ge1}\bar\ell(x)e^{-qx/k}$다. $1-\phi(\theta)=(e^\theta-1)\sum_{x\ge1}\bar\ell(x)e^{-\theta x}$이므로 $W(q-1)-W(q)=(e^{q/k}-1)K_q$이고, Abel 합이

$$\sum_{q\ge1}q\,(e^{q/k}-1)\,K_q=\sum_{q\ge0}W(q)$$

를 준다(이 등식은 그 모형 안에서 정확하다). 우변을 $k$로 나눈 것이 이 모형의 막힘 $B_-$이고 동률 $C_-$는 $\sum_q\frac{q(q-1)}{k^2}K_q$인데, $e^{q/k}-1>\frac{q-1}k$이므로 이 모형의 문턱 바로 위의 점들만으로는 막힘이 동률보다 크다. 벌크에서 $d_{n,k}=C_--B_->0$이 되게 하는 것은 그 점들이 아니고, 가상 뿌리 가까이의 점들이 드는 쌍이다. 이 계산은 그 합의 부호를 증명하는 길을 주지 않는다.

**구획에 대해 말하는 것.** 얼린 분해 $d_{n,k}=C_--B_-$, $\mathcal S=B_+C_--B_-C_+$는 벌크에서 두 진술 모두를 선두 차수가 지워진 차로 적는다. 반대로 곡선 근처와 그 뒤, 곧 실제로 감소가 일어나는 영역에서는 세 양이 같은 차수 $\sqrt r$에서 상수 배로 갈린다. 그래서 감소 자리의 교차곱(구획 (X↓))은 행 안의 견줌으로 닿고, 벌크의 증가는 닿지 않는다. r69068ac5가 벌크의 증가를 열 방향의 견줌으로 닫은 것과 맞는다.

---

## G. 막힌 자리와 버린 접근

시도가 시험하고 버린 것이다. 무엇을 배제하고 무엇을 배제하지 않는지를 함께 적는다.

1. **가정 $d_{n,k}\le0$을 부등식의 재료로 쓰기.** 가정은 $C_-\le B_-$, 곧 사슬 곡률들의 합의 상계다. 그런데 교차곱의 부등식에서 $\Lambda_{r+1}(k-1)$은 작은 쪽에 있어야 하고, 가정을 항별로 쓰면 그 하계가 나와 방향이 반대다. 필요한 것은 모양의 부등식(분산 대 평균의 제곱)이고 가정은 크기의 부등식이다. 배제하는 것: 가정을 얼린 분해의 항들에 직접 넣어 (X)를 얻는 논증. 배제하지 않는 것: 가정을 다른 분해(열의 방정식)에서 쓰는 논증. 실제로 구획은 가정을 열의 말(「교차 앞」)로 바꾸어 닫혔다.
2. **균질한 법칙 둘 사이에 끼우기.** 문턱 윤곽은 인자 $k/(k+r)$와 $k/(k+2)$ 사이에 있으므로 우도비 순서로 두 균질한 법칙 사이에 낀다. 그러나 두 법칙의 평균의 비가 곡선 위에서 상수 배여서 여유보다 많이 잃는다. 가운데 인자의 견줌(보조정리 3.2)이 이 손실을 한쪽에서 없앴다.
3. **얼린 다항식의 계수의 로그오목성.** $K_{n,k}$의 계수가 로그오목이면 곡률 쪽을 $K$의 측도의 둘째 모멘트로 누를 수 있다. 계산한 열여덟 자리에서 성립하지만 증명하지 못했다(`evidence/source/work/t03_hierarchy.out`). A가 곡률을 사슬 하나로 모으므로 이 길은 버렸다.
4. **기울임을 넓이의 거듭제곱으로 전개하기.** 문턱 인자의 곱은 $e^{-A/k}$쯤이고($A$는 사슬 위 꼭짓점들의 초과의 합), $1-\frac Ak+\frac{A^2}{2k^2}$ 꼴의 한계로 곡률 쪽을 누르려 했다. 다시 무게 준 법칙 아래 $A/k$의 평균이 $0.94\,u$쯤이어서(시도의 어림이고 저장된 계산은 없다) $u>1$에서는 한계 $1-\frac Ak$의 평균이 음이 된다. D의 극한 정리가 $u\le\frac45$에서 멈춘 것과 같은 사정이다. 배제하는 것: $u\gtrsim1$에서 기울임을 유한 차수의 전개로 다루는 논증.
5. **합성과 그 뒤집은 것을 짝짓기.** 보조정리 3.2를 처음에는 합성 $S$와 뒤집은 합성 $S'$의 짝마다 $(W(S)-W(S'))(\bar s(S)-\frac m2)\ge0$을 보여 얻으려 했다. 자르는 점이 둘이면 성립하고 셋이면 깨진다(예: $m=20$, $N=60$, $y=30$, $S=\{1,12,16\}$; `evidence/source/work/t25_first_part_check.out`). 짝을 두 토막의 맞바꿈으로 잡으면 항마다 부호가 정해진다.
6. **「길이를 하나 줄이는」 걸음에도 가운데 인자를 쓰기.** 그 걸음의 평균 $\mathbb E_{\lambda'}[a_{\gamma_0+1}/a_{\gamma_0}]$($\gamma_0$는 첫 토막)를 가운데 인자의 균질한 법칙의 값으로 누를 수 있다는 부등식은 거짓이다. $(r,k)=(54,265)$에서 좌변이 $1.8238$, 가운데 인자의 법칙의 값이 $1.7713$, 게시된 견줌(인자 $h_-$)의 값이 $1.8379$다(같은 파일; 정확한 유리수). 첫 토막의 법칙은 맨 위쪽 자르는 점들의 인자로 정해지고 선분 전체의 평균으로 정해지지 않는다. 그 걸음에서 쓸 수 있는 것이 보조정리 3.1이다.
7. **곡률 쪽의 견줌.** 본문 8.1절의 열린 문제다.

---

## H. 개정 28과 29로 덮인 시도의 결과

시도의 보고에 있으나 이 기록이 주장으로 내지 않는 것과 그 까닭이다. 증명은 모두 `evidence/source/producer-report.md`에 있다.

| 시도의 보고 | 내용 | 지금의 사정 |
|---|---|---|
| 3절 (보조정리 3.1, 명제 3.2, 따름 3.3) | $C_+/C_-\le\rho_r$ | r69068ac5의 `p-single-chain-bound` (가), (나)로 게시됨 (A) |
| 10.3절의 평균의 하계의 일반 꼴 | $\mu_h\ge\mu_0(X)$ | r69068ac5의 `p-homogeneous-mean`으로 게시됨 |
| 10.4절 | $s_r$의 상계를 문헌에서 가져옴 | rc693abe9의 보조정리 6과 r790d81e5의 `c-stirling`에서 나온다(본문 3.3절) |
| 정리 12.1 | $k\ge729$에서 $q_0(k)\le k+\lfloor(3k/2)^{2/3}\rfloor+1$ | rc693abe9의 정리 9($k\ge537$에서 $q_0(k)\le k+r_c(k)$)가 더 강하다 |
| 버려진 초안의 「$33/20$의 짝」 | $k\ge535$에서 $q_0(k)\le k+\lfloor(33k/20)^{2/3}\rfloor+1$ | $k\ge537$에서는 같다. $k=535,536$에서는 정리 5.1보다 조금 날카롭지만 쓰이는 곳이 없다 |
| 명제 S1 | $n\ge301$의 먼 범위에서 $d_{n,k}\ge0$이면 (S$_R$) | rc693abe9의 `p-band-all-rows` (다)로 게시됨. 그 전제는 이제 게시된 주장이다(r69068ac5의 `p-single-crossing`) |
| 따름 13.5 (다), (마) | 구획 (X↓)가 창 안과 $k\ge10^8$에서 선다 | 본문의 정리 6.3의 특수한 경우 |
| 명제 13.6 | $k\ge1000$에서 r425e458e의 일차 부등식 (FO*)가 먼 범위의 엄격한 증가를 준다 | r69068ac5의 정리 G가 (FO*) 없이 $k\ge151$에서 준다 |
| 따름 13.7 | 「(Col$_1$) ⟹ (S$_R$)」; 「(C)와 $d_{2k,k}>0$ ($k\ge151$) ⟹ (X↓)」 | (Col$_1$)과 (C)의 진술, 한가운데의 양성이 모두 r69068ac5의 지지된 주장이다(`p-col1`, `p-chain-column`, `p-single-crossing`). 두 노드의 해는 개정 30에서 다섯째 상시 조건에 따라 내려졌고 주장의 지지는 그대로다 |

시도는 끝날 때 r69068ac5의 동료 세션이 보낸 조정 알림(정리 G의 진술)을 받았고, 그 후보를 읽거나 쓰지 않았다고 적었다. 이 기록은 그 정리를 게시된 주장으로 인용한다.
