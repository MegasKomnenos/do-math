# -*- coding: utf-8 -*-
"""Peer check of the base range (exact integers, from the definitions):
   (a) S_{n,k} > 0 at every site 1<=k<=n-2 of every row 3<=n<=NMAX (general definition of the cross product);
   (b) (Mono) instances for n<=NMAX; (c) rows unimodal, no zero differences; (d) list of right-half falling sites
       before the curve (the sites where Theorem 5.9 does not apply) -- for the reader's picture."""
import sys
from math import comb
from pf import weighted_table

NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 30
Z = {}   # Z[(n? no) y] -> table over n
def Ztab(y):
    if y not in Z:
        Z[y] = weighted_table(NMAX, (lambda j, y=y: min(j, y))) if y > 0 else [1] + [0] * NMAX
    return Z[y]
Kc = {}
def Ktab(k, y):
    if (k, y) not in Kc:
        Kc[(k, y)] = weighted_table(NMAX, (lambda j, k=k, y=y: j if j <= k else y))
    return Kc[(k, y)]

bad = 0; sites = 0; minrel = None; before_curve_falls = []
rows = {}
for n in range(1, NMAX + 1):
    rows[n] = [Ztab(l + 1)[n] - Ztab(l)[n] for l in range(n)]
for n in range(3, NMAX + 1):
    b = rows[n]
    d = [None] + [b[k] - b[k - 1] for k in range(1, n)]
    assert all(x != 0 for x in d[1:]), ("zero difference", n)
    # unimodal
    seen_neg = False
    for k in range(1, n):
        if d[k] < 0: seen_neg = True
        assert not (seen_neg and d[k] > 0), ("not unimodal", n)
    for k in range(1, n - 1):
        K = {y: Ktab(k, y)[n] for y in (k - 1, k, k + 1, k + 2)}
        Cm = K[k + 1] - 2 * K[k] + K[k - 1]; Cp = K[k + 2] - 2 * K[k + 1] + K[k]
        Bm = K[k - 1] - (Ztab(k - 1)[n] if k - 1 > 0 else 0); Bp = K[k + 2] - Ztab(k + 2)[n]
        assert Cm - Bm == d[k] and Cp - Bp == d[k + 1] and Bm > 0 and Bp > 0
        S = Bp * Cm - Bm * Cp
        sites += 1
        if S <= 0:
            bad += 1; print("S<=0 at", (n, k))
        rel = S / (Bp * Cm)
        if minrel is None or rel < minrel[0]: minrel = (rel, n, k)
        r = n - k
        if 2 * k >= n and d[k] <= 0 and r ** 3 > k * k:
            before_curve_falls.append((n, k))
# (Mono)
mono_inst = 0
for n in range(3, NMAX + 1):
    for k in range(1, n - 1):
        hyp = all(rows[j][k] - rows[j][k - 1] <= 0 for j in range(k + 1, n + 1))
        if hyp:
            mono_inst += 1
            assert rows[n][k + 1] - rows[n][k] <= 0, ("Mono fails", n, k)
print(f"n<= {NMAX}: sites {sites}, S<=0 at {bad}; min S/(B+C-) = {minrel}")
print(f"(Mono): {mono_inst} instances with true hypothesis, all hold; rows unimodal, no zero differences")
print(f"right-half falling sites before the curve (k^2 < (n-k)^3): {len(before_curve_falls)}; largest n: {max(before_curve_falls)[0] if before_curve_falls else None}")
print(before_curve_falls[:40], "...")
