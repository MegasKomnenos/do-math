# -*- coding: utf-8 -*-
"""
t16: for the remaining columns 265 <= k <= 728 (sample), compare
   R41(k)  = smallest R at which the explicit conditions of Lemma 4.1 (ra98af63d) hold   (explicit crossing bound),
   rG(k)   = largest r such that the explicit corrected criterion G~(r',k) >= 0 for all r_c(k) <= r' <= r  (Cor. 10.3),
   rM1(k)  = the same with the exact Upsilon (M1),
   rho(k)  = floor((3k/2)^{2/3})   (end of the strip of Theorem 10.1).
An overlap  R41(k) <= r(k)+1  would close the column by explicit formulas.  Explicit formulas only; not a proof step.
"""
from t14_K_at_strip_end import lemma41, rho
from t11_refined_criterion import rc, M1, D_r, mu0
from mpmath import mpf, sqrt
def mu0X(X, r):
    A = 4 + X
    return (sqrt(A * A + 12 * (r - 1)) - A) / 3
def Gt(r, k):
    X = mpf(r) ** 2 / k; Xh = mpf(r) * (r + 1) / (k - 1)
    return k * (mpf(1) / (2 * r) - mpf(1) / (3 * r * r)) - mpf(5) / 2 + mu0X(Xh, r) / 2 + 2 * (1 - mpf(1) / k) * mu0X(X, r) - mpf(k) / (k - 1) * D_r(r)
print("k | r_c | rho(k) | rG | rM1 | R41 | overlap with rG / rM1")
for k in (265, 300, 350, 400, 450, 500, 505, 550, 600, 650, 700, 728):
    r0 = rc(k)
    r = r0
    while Gt(r, k) >= 0: r += 1
    rG = r - 1
    r = r0
    while M1(r, k) >= 0: r += 1
    rM1 = r - 1
    R = r0
    while True:
        tlow, lhs, rhs = lemma41(k, R)
        if tlow >= 0 and lhs > rhs: break
        R += 1
        if R > k - 1: R = None; break
    print(f"{k} | {r0} | {rho(k)} | {rG} | {rM1} | {R} | {R is not None and R <= rG + 1} / {R is not None and R <= rM1 + 1}")
