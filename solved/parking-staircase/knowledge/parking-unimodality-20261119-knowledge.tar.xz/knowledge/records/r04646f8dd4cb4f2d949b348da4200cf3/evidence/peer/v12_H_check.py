# -*- coding: utf-8 -*-
"""Peer: independent re-computation of the producer's counterexample to the shape hypothesis (H)
   "j -> P_eta(J=j)/(j+1) is log-concave" for the threshold-profile law on compositions of r
   (weights  prod a_part * prod_{s in S} eta/(N-s),  a_j = j^{j-1}/j!).

   Coefficients c_m[j] = [y^j] Lambda_m(y;N) from the recursion
        Lambda_m = a_m + sum_{s=1}^{m-1} (y/(N-s)) Lambda_s a_{m-s},
   i.e.  c_m[0] = a_m,  c_m[j] = sum_{s=j}^{m-1} c_s[j-1] a_{m-s}/(N-s).
   P_eta(J=j) is proportional to c_r[j] eta^j.   60-digit floats (all terms are positive: no cancellation).
   This checks one specific example reported by the producer; it is not a scan.
"""
import mpmath as mp
mp.mp.dps = 60


def coeffs(N, r):
    a = [mp.mpf(0)] + [mp.mpf(j) ** (j - 1) / mp.factorial(j) for j in range(1, r + 1)]
    c = [None] * (r + 1)
    for m in range(1, r + 1):
        row = [a[m]] + [mp.mpf(0)] * (m - 1)
        for j in range(1, m):
            row[j] = mp.fsum(c[s][j - 1] * a[m - s] / (N - s) for s in range(j, m))
        c[m] = row
    return c[r]


def report(N, r, eta):
    cr = coeffs(N, r)
    p = [cr[j] * mp.mpf(eta) ** j for j in range(r)]
    tot = mp.fsum(p)
    v = [p[j] / tot / (j + 1) for j in range(r)]
    ratios = [v[j] ** 2 / (v[j - 1] * v[j + 1]) for j in range(1, 6)]
    bad = [j for j in range(1, r - 1) if v[j] ** 2 < v[j - 1] * v[j + 1]]
    mean = mp.fsum(j * p[j] for j in range(r)) / tot
    print(f"(N,r,eta)=({N},{r},{eta}):  E J = {mp.nstr(mean, 6)};  v_j^2/(v_(j-1) v_(j+1)) for j=1..5: "
          + ", ".join(mp.nstr(x, 6) for x in ratios) + f";  indices j where log-concavity of v fails: {bad}")
    # coefficient log-concavity (published: r3dc4f6e9 Cor D) as a sanity check of the recursion
    assert all(cr[j] ** 2 >= cr[j - 1] * cr[j + 1] for j in range(1, r - 1))


if __name__ == "__main__":
    report(201, 99, 101)     # (n,k) = (200,101): (H) holds
    report(401, 199, 201)    # (n,k) = (400,201): (H) fails at j = 1, 2
