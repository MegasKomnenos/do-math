# -*- coding: utf-8 -*-
"""Peer (after resumption): closed-form positivity of the criterion function G(r,k) where the record so far
quoted the published Theorem 5.9 (which inherits the finite computation C8):

 (1) a third instance of the strip template, u_b = 1 (behind the curve), for several r_0;
 (2) small deficits: for r_a <= r <= r_b and real k >= k0, G(r,k) > 0 by monotone bounds on sub-intervals:
        first term  f(r) = k0 (1/(2r) - 1/(3r^2)) - 5/2          (decreasing in r, increasing in k)
        mu_0(X; r)  = ( sqrt((4+X)^2 + 12(r-1)) - (4+X) ) / 3     (decreasing in X, increasing in r)
        X_- = r(r+1)/(k-1) <= r_b(r_b+1)/(k0-1),  X_mid = r(r+2)/(2k) <= r_b(r_b+2)/(2 k0)
        D_r <= D_{r_b} <= (3/2)(s_{r_b} - 1),  s_{r_b} <= sqrt(pi r_b/2) e^{1/(12 r_b)} - 1/3
     (published: D_m <= D_{m+1}, D_m <= (3/2)(s_m - 1); Lemma 3.3 of the record);
 (3) cross-check: the exact value of G(r,k0) (exact s_r) for every r in the range.
All constants with 50-digit arithmetic, rounded in the safe direction.
"""
import mpmath as mp
from fractions import Fraction as Fr
from v09_constants import strip, dn, up

mp.mp.dps = 50
F = mp.mpf


def s_exact(r):
    s = Fr(0); term = Fr(1)
    for j in range(1, r + 1):
        term = term * Fr(r - j + 1, r)
        s += term
    return s


def mu0(X, r):
    X = F(X)
    return (mp.sqrt((4 + X) ** 2 + 12 * (r - 1)) - (4 + X)) / 3


def G_exact(r, k):
    s = s_exact(r); s = F(s.numerator) / F(s.denominator)
    D = F(3) * ((r + 2) * s - 3 * r) / (2 * (r - s)) if r >= 2 else F(0)
    k = F(k)
    return k * (F(1) / (2 * r) - F(1) / (3 * r * r)) - F(5) / 2 + mu0(F(r) * (r + 1) / (k - 1), r) / 2 \
        + 2 * (1 - 1 / k) * mu0(F(r) * (r + 2) / (2 * k), r) - k / (k - 1) * D


def interval_bound(ra, rb, k0, use_mu=True):
    k0 = F(k0)
    f = dn(k0 * (F(1) / (2 * rb) - F(1) / (3 * rb * rb)) - F(5) / 2)
    Xm = up(F(rb) * (rb + 1) / (k0 - 1)); Xmid = up(F(rb) * (rb + 2) / (2 * k0))
    m1 = dn(mu0(Xm, ra)) if use_mu else F(0)
    m2 = dn(mu0(Xmid, ra)) if use_mu else F(0)
    sbar = up(mp.sqrt(mp.pi * rb / 2) * mp.e ** (F(1) / (12 * rb)) - F(1) / 3)
    Dbar = up(F(3) / 2 * (sbar - 1))
    kk = up(k0 / (k0 - 1))
    total = f + m1 / 2 + 2 * (1 - 1 / k0) * m2 - kk * Dbar
    print(f"   r in [{ra},{rb}], k>={k0}: f({rb}) >= {f};  X_- <= {Xm}, mu_0 >= {m1};  X_mid <= {Xmid}, mu_0 >= {m2};"
          f"  s_{rb} <= {sbar}, D <= {Dbar};  k/(k-1) <= {kk};  G >= {mp.nstr(dn(total), 7)}")
    assert total > 0
    # the bound must be below the exact values
    for r in range(ra, rb + 1):
        assert G_exact(r, k0) >= total, (r, G_exact(r, k0), total)
    return total


if __name__ == "__main__":
    print("(1) strip template with u_b = 1 (behind the curve):")
    for r0 in (10, 11, 12, 13):
        try:
            strip(F(1), r0, f"u_b=1, r_0={r0}")
        except AssertionError as e:
            print("   r_0 =", r0, "fails an assertion", e)
    print("(2) small deficits, k >= 83  (sites with n >= 95 and r <= 12 have k >= 83):")
    interval_bound(2, 5, 83, use_mu=False)
    interval_bound(6, 8, 83)
    interval_bound(9, 12, 83)
    print("    alternative split for r <= 9, k >= 86:")
    interval_bound(2, 5, 86, use_mu=False)
    interval_bound(6, 9, 86)
    print("(3) exact G(r,83), r=2..12:", ", ".join(mp.nstr(G_exact(r, 83), 5) for r in range(2, 13)))
    print("    exact G(r,265), r=2..41: min =", mp.nstr(min(G_exact(r, 265) for r in range(2, 42)), 6),
          " at r =", min(range(2, 42), key=lambda r: G_exact(r, 265)))
    print("    exact G(r, r^1.5) for r=13..60: min =", mp.nstr(min(G_exact(r, F(r) ** 1.5) for r in range(13, 61)), 6),
          "; for r=10,11,12:", ", ".join(mp.nstr(G_exact(r, F(r) ** 1.5), 5) for r in (10, 11, 12)),
          "; for r=2..9:", ", ".join(mp.nstr(G_exact(r, F(r) ** 1.5), 4) for r in range(2, 10)))
    print("(4) variant when only k >= 265 is needed (Corollary 4.3 (i); remark after its proof):")
    print("    2 <= r <= 13, k >= 265, without the mu_0 terms, one interval:")
    interval_bound(2, 13, 265, use_mu=False)
    print("    14 <= r (<= 41), k >= r^1.5: the template with r_0 = 14:")
    strip(F(1), 14, "u_b=1, r_0=14")
