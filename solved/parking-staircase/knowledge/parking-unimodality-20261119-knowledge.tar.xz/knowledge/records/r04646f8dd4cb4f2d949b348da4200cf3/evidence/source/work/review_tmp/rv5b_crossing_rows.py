# crossing row q_0(k) = min{n>k: d_{n,k}>0} from the forest formula, for k=264,265,266,300 (sanity for Thm 13.4:
# q_0(k) <= k + floor((11k/5)^(2/3)) + 1) -- uses rv5's forest series
import sys, time
from mpmath import mp, mpf
mp.dps = 120
t0 = time.time()
def forest_series(nmax, w):
    f = [mpf(1)]; c = [mpf(0)]
    for j in range(1, nmax + 1):
        c.append(w(j) * f[j - 1])
        s = mpf(0)
        for t in range(1, j + 1):
            s += t * c[t] * f[j - t]
        f.append(s / j)
    return f
def Zser(nmax, j):
    return forest_series(nmax, lambda t: mpf(1) if t <= j else mpf(j) / t)
def rho2(k):
    r = int(round((11 * k / 5) ** (2 / 3)))
    while 25 * r ** 3 > 121 * k * k: r -= 1
    while 25 * (r + 1) ** 3 <= 121 * k * k: r += 1
    return r
for k in (264, 265, 300):
    nmax = k + rho2(k) + 1
    Zm, Z0, Zp = Zser(nmax, k - 1), Zser(nmax, k), Zser(nmax, k + 1)
    # d_{n,k} / n! = Zp[n] - 2 Z0[n] + Zm[n]
    signs = [(n, Zp[n] - 2 * Z0[n] + Zm[n]) for n in range(k + 1, nmax + 1)]
    q0 = next((n for n, v in signs if v > 0), None)
    after = all(v > 0 for n, v in signs if q0 is not None and n >= q0)
    print("k=%d: q_0(k)=%s (deficit %s); bound k+rho_2(k)+1=%d; positive from q_0 up to the bound: %s" % (
        k, q0, None if q0 is None else q0 - k, nmax, after))
print("time %.1fs" % (time.time() - t0))
