import json, sys, io, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
base = "C:/math/.skill-workspace/parking-unimodality-20261119/knowledge/records"
want = {
 "ra98af63d956e4b288dd1550e0a4853df": ["c-crossing-criterion","c-explicit-bounds","c-entry-theorem","c-positive-window","p-ci-large","p-mono-instances","p-ci-reduction"],
 "r6af349eb6a0d4ed29b9650ff599e1e90": ["c12-positivity-persistence","c19-col-mono-root"],
 "r425e458e24d0488980f871f2046aceb5": ["p-eventual"],
}
for rec, ids in want.items():
    with open(os.path.join(base, rec, "record.json"), encoding="utf-8") as f:
        d = json.load(f)
    print("=== RECORD", rec, "keys:", list(d.keys()))
    claims = d.get("claims", [])
    print("n claims", len(claims), "ids:", [c.get("id") for c in claims])
    for c in claims:
        if c.get("id") in ids:
            print("--- CLAIM", c.get("id"), "keys:", list(c.keys()))
            print(c.get("statement"))
            print()
