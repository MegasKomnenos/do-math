# -*- coding: utf-8 -*-
"""
t06: exact decomposition of the diagonal step  Phi(k+1;r)/Phi(k;r) = E_C[omega*X]/E_B[X]   (report section 5.2)
by brute-force enumeration of chains (subsets of {1..r}); small r only.
omega(c) = alpha(k+j_q)/alpha(k) * lam_k(j_q) * (k+1)(k-1)^2/k^3 * rho_q(k) * ((k-1)/k)^(q-2)
X(c)     = prod_i [1 + (j_i+1)/((k-1)(k+1+j_i))]
Checks the identity against direct evaluation of Phi at k and k+1, and prints the averages.
"""
import sys, itertools
from mpmath import mp, mpf, exp, log, loggamma
mp.dps = 40
def bor(j):
    j = mpf(j); return exp(-j + (j - 1) * log(j) - loggamma(j + 1))
def alpha(t):  # a_{t+1}/a_t
    return (1 + mpf(1) / t) ** (t - 1)
def ell(k, j, A):  # light probability of a tree of size k+j : no root child larger than k  (Borel units)
    return 1 - sum(A[g] * A[k + j - g] for g in range(1, j)) / A[k + j]
def delta(q, k): return mpf(k + 1) ** q - 2 * mpf(k) ** q + mpf(k - 1) ** q

def terms(r, k):
    A = [mpf(0)] + [bor(j) for j in range(1, k + r + 3)]
    C = {}; B = {}
    for q in range(0, r + 1):
        for js in itertools.combinations(range(r, 0, -1), q):   # decreasing excesses j_1>...>j_q
            prev = r + 1; W = mpf(1)
            for j in js:
                W *= A[prev - j]; prev = j
            den = mpf(1)
            for j in js: den *= (k + j)
            if q >= 2:
                jq = js[-1]
                C[js] = W * A[k + jq] * ell(k, jq, A) * delta(q, k) / den
            last = js[-1] if q else r + 1
            B[js] = W * A[last] * (A[k] / k) * mpf(k - 1) ** q / den
    return C, B, A

def main(r, k):
    C, B, A = terms(r, k)
    C1, B1, A1 = terms(r, k + 1)
    Ck, Bk = sum(C.values()), sum(B.values())
    Ck1, Bk1 = sum(C1.values()), sum(B1.values())
    direct = (Ck1 / Bk1) / (Ck / Bk)
    def X(js):
        x = mpf(1)
        for j in js: x *= 1 + mpf(j + 1) / ((k - 1) * (k + 1 + j))
        return x
    def omega(js):
        q = len(js); jq = js[-1]
        lam = ell(k + 1, jq, A1) / ell(k, jq, A)
        rho = delta(q, k + 1) / delta(q, k)
        return alpha(k + jq) / alpha(k) * lam * mpf((k + 1) * (k - 1) ** 2) / k ** 3 * rho * (mpf(k - 1) / k) ** (q - 2), lam, rho * (mpf(k - 1) / k) ** (q - 2)
    EC_oX = sum(C[js] * omega(js)[0] * X(js) for js in C) / Ck
    EC_X = sum(C[js] * X(js) for js in C) / Ck
    EC_o = sum(C[js] * omega(js)[0] for js in C) / Ck
    EC_lam = sum(C[js] * omega(js)[1] for js in C) / Ck
    EC_rho = sum(C[js] * omega(js)[2] for js in C) / Ck
    EC_jq = sum(C[js] * js[-1] for js in C) / Ck
    EC_al = sum(C[js] * alpha(k + js[-1]) / alpha(k) for js in C) / Ck
    EB_X = sum(B[js] * X(js) for js in B) / Bk
    print(f"r={r} k={k} Phi={float(Ck/Bk):.5f}")
    print(f"  direct Phi(k+1)/Phi(k) = {float(direct):.10f} ; identity E_C[omega X]/E_B[X] = {float(EC_oX / EB_X):.10f}")
    print(f"  k*(E_C[omega]-1) = {float(k * (EC_o - 1)):.4f}   [pieces: k*(E_C[alpha ratio]-1)={float(k*(EC_al-1)):.4f}, k*(E_C[lam]-1)={float(k*(EC_lam-1)):.4f}, k*(E_C[rho-part]-1)={float(k*(EC_rho-1)):.4f}, prefactor k*((k+1)(k-1)^2/k^3-1)={float(k*(mpf((k+1)*(k-1)**2)/k**3-1)):.4f}]")
    print(f"  k*(E_C[X]-1) = {float(k * (EC_X - 1)):.4f}   k*(E_B[X]-1) = {float(k * (EB_X - 1)):.4f}   E_C[j_q] = {float(EC_jq):.3f}")
    print(f"  k*(ratio-1) = {float(k * (direct - 1)):.4f}")

if __name__ == "__main__":
    a = [int(x) for x in sys.argv[1:]]
    for i in range(0, len(a), 2):
        main(a[i], a[i + 1])
