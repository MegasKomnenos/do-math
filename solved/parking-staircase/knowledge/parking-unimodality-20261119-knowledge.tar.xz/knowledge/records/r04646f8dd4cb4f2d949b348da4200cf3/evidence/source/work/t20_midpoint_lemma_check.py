# t20: exact check, on small cases, of the steps of the "midpoint comparison" lemma (section 14).
# Compositions of m are identified with their cut sets S in {1..m-1}; parts t_1..t_{q+1} (q cuts).
# pi_q: law on compositions with q parts proportional to prod a_part, a_j = j^(j-1)/j!.
# lambda_s = y/(N-s).  W(S) = prod_{s in S} lambda_s.
# Checked (exact rationals):
#  (1) deletion rule (r496399b6 App. A.3) sends pi_{q+1} to pi_q;
#  (2) mean position of the deleted cut: sbar_D = m/2 + (1/(2 q m)) sum_p (q+2-2p) t_p^2   (q cuts, q+1 parts);
#  (3) E_{pi_q} W = E_{pi_{q+1}} [ W (N - sbar_D)/y ];
#  (4) E_{pi_{q+1}}[ W (t_p^2 - t_{p'}^2) ] >= 0 for p < p';
#  (5) E_{pi_{q+1}} W >= h E_{pi_q} W with h = y/(N - m/2), i.e. P_lambda(Q=q)/P_h(Q=q) nondecreasing.
import sys
from fractions import Fraction as Fr
from itertools import combinations
from math import factorial

def a(j):
    return Fr(j ** (j - 1), factorial(j))

def parts(S, m):
    pts = [0] + list(S) + [m]
    return [pts[i + 1] - pts[i] for i in range(len(pts) - 1)]

def run(m, N, y):
    N = Fr(N); y = Fr(y)
    lam = {s: y / (N - s) for s in range(1, m)}
    h = y / (N - Fr(m, 2))
    byq = {}
    for q1 in range(1, m + 1):          # q1 = number of parts
        lst = []
        for S in combinations(range(1, m), q1 - 1):
            t = parts(S, m)
            w = Fr(1)
            for x in t:
                w *= a(x)
            lst.append((S, t, w))
        byq[q1] = lst
    ok1 = ok2 = ok3 = ok4 = ok5 = True
    EW = {}
    for q1, lst in byq.items():
        Z = sum(w for S, t, w in lst)
        num = Fr(0)
        for S, t, w in lst:
            W = Fr(1)
            for s in S:
                W *= lam[s]
            num += w * W
        EW[q1] = num / Z
    for q1 in range(2, m + 1):          # compositions with q1 parts, q = q1-1 cuts
        q = q1 - 1
        lst = byq[q1]
        Z = sum(w for S, t, w in lst)
        image = {}
        acc3 = Fr(0)
        for S, t, w in lst:
            W = Fr(1)
            for s in S:
                W *= lam[s]
            # deletion probabilities
            sbar = Fr(0)
            for i in range(1, q + 1):
                al, be = t[i - 1], t[i]
                D = Fr((q + 1 - i) * al + i * be, q * m)
                S2 = tuple(x for x in S if x != S[i - 1])
                image[S2] = image.get(S2, Fr(0)) + w / Z * D
                sbar += D * S[i - 1]
            formula = Fr(m, 2) + Fr(1, 2 * q * m) * sum((q + 2 - 2 * p) * t[p - 1] ** 2 for p in range(1, q + 2))
            if sbar != formula:
                ok2 = False
            acc3 += w / Z * W * (N - sbar) / y
        # (1)
        Zq = sum(w for S, t, w in byq[q1 - 1])
        for S, t, w in byq[q1 - 1]:
            if image.get(S, Fr(0)) != w / Zq:
                ok1 = False
        if acc3 != EW[q1 - 1]:
            ok3 = False
        # (4)
        for p in range(1, q + 2):
            for p2 in range(p + 1, q + 2):
                val = Fr(0)
                for S, t, w in lst:
                    W = Fr(1)
                    for s in S:
                        W *= lam[s]
                    val += w * W * (t[p - 1] ** 2 - t[p2 - 1] ** 2)
                if val < 0:
                    ok4 = False
        if EW[q1] < h * EW[q1 - 1]:
            ok5 = False
    ratios = [float(EW[q1] / EW[q1 - 1] / h) for q1 in range(2, m + 1)]
    print("m=%d N=%s y=%s: (1)%s (2)%s (3)%s (4)%s (5)%s   min, max of [E_{q+1}W/E_qW]/h: %.6f %.6f" % (
        m, N, y, ok1, ok2, ok3, ok4, ok5, min(ratios), max(ratios)))

if __name__ == "__main__":
    # (m, N, y): N = k + m + 1 in the application (bottom chain: m = r), y in {k-1,...,k+2}
    cases = [(2, 5, 2), (3, 8, 4), (4, 10, 5), (5, 12, 6), (6, 13, 6), (6, 30, 23), (7, 20, 12),
             (8, 20, 11), (8, 20, 13), (9, 25, 15), (9, 12, 2), (10, 40, 29), (10, 14, 3)]
    for m, N, y in cases:
        run(m, N, y)
