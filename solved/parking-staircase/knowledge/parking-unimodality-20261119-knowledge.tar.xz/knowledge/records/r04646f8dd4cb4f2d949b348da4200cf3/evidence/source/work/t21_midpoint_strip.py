# -*- coding: utf-8 -*-
"""
t21: the strip criterion with the midpoint comparison (report section 14):
   G1(r,k) = k(1/(2r) - 1/(3r^2)) - 5/2 + (1/2) mu0(X_h) + 2(1-1/k) mu0(X_1) - (k/(k-1)) D_r,
   X_h = r(r+1)/(k-1),  X_1 = r(r+2)/(2k)   (section 10 had X = r^2/k in place of X_1).
 strip1(ua, rmin): linear lower bound of G1(r, r^{3/2}/ua) for r >= rmin (pattern of section 10.3).
 Then the crossing chain of t18_general.crossing(ub, kmin) at the same width.
Usage: python t21_midpoint_strip.py <ub_num> <ub_den> <rmin> <kmin>
Explicit elementary formulas only; arithmetic of hand derivations, not a proof step.
"""
import sys
from mpmath import mp, mpf, sqrt, exp, pi, floor
import t18_general as T
mp.dps = 30
a_ = sqrt(pi / 2)

def exactG1(r, k):
    X1 = mpf(r) * (r + 2) / (2 * k); Xh = mpf(r) * (r + 1) / (k - 1)
    return k * (mpf(1) / (2 * r) - mpf(1) / (3 * r * r)) - mpf(5) / 2 + T.mu0X(Xh, r) / 2 + 2 * (1 - mpf(1) / k) * T.mu0X(X1, r) - k / (k - 1) * T.D_of_s(r, T.s_r(r))

def strip1(ua, rmin, verbose=True):
    x0 = sqrt(mpf(rmin)); kstar0 = x0 ** 3 / ua; eps_k = 1 / kstar0
    fac_h = (1 + 1 / x0 ** 2) / (1 - eps_k); ch = ua * fac_h
    c1 = ua / 2 * (1 + 2 / x0 ** 2)
    A, B = c1 * c1 + 12, 8 * c1; Ah, Bh = ch * ch + 12, 8 * ch
    # sqrt(A x^2 + B x + 4) >= sqrt(A) x + beta for x >= x0, beta = B/(2 sqrt A) - max(0, B^2/(4A) - 4)/(2 sqrt(A) x0)
    def beta(A_, B_):
        ex = B_ * B_ / (4 * A_) - 4
        return B_ / (2 * sqrt(A_)) - (ex / (2 * sqrt(A_) * x0) if ex > 0 else 0)
    m_s, m_c = (sqrt(A) - c1) / 3, (beta(A, B) - 4) / 3
    h_s, h_c = (sqrt(Ah) - ch) / 3, (beta(Ah, Bh) - 4) / 3
    sb_s = a_ * exp(1 / (12 * mpf(rmin))); sb_c = -mpf(1) / 3
    q2, q1_, q0_ = sb_s ** 2, 2 * sb_s * sb_c + mpf(3) / 5 * sb_s, sb_c ** 2 + mpf(3) / 5 * sb_c
    assert q2 <= mpf(8) / 5 and q1_ <= 0 and q0_ <= 0
    d_s, d_c = mpf(3) / 2 * sb_s, mpf(3) / 2 * (sb_c - mpf(7) / 5)
    kk = 1 + 1 / (kstar0 - 1)
    first_s, first_c = 1 / (2 * ua), -1 / (3 * ua * x0) - mpf(5) / 2
    slope = first_s + h_s / 2 + 2 * (1 - eps_k) * m_s - kk * d_s
    const = first_c + h_c / 2 + 2 * (1 - eps_k) * m_c - kk * d_c
    if verbose:
        print("[strip1 u<= %.4f, r>= %d] x0=%.6f  k*>= %.3f 1/k*<= %.7f  X_h<= %.6f x  X_1<= %.6f x  k/(k-1)<= %.6f" % (float(ua), rmin, float(x0), float(kstar0), float(eps_k), float(ch), float(c1), float(kk)))
        print("   B^2/(4A): X_1: %.4f, X_h: %.4f" % (float(B * B / (4 * A)), float(Bh * Bh / (4 * Ah))))
        print("   mu0(X_1) >= %.6f x %+.6f; mu0(X_h) >= %.6f x %+.6f; sbar = %.6f x - 1/3; D_r <= %.6f x %+.6f" % (float(m_s), float(m_c), float(h_s), float(h_c), float(sb_s), float(d_s), float(d_c)))
        print("   (1/2)mu0h + 2(1-1/k*)mu0(X_1) >= %.6f x %+.6f;  D-term <= %.6f x %+.6f;  first: %.6f x %+.6f" % (float(h_s / 2 + 2 * (1 - eps_k) * m_s), float(h_c / 2 + 2 * (1 - eps_k) * m_c), float(kk * d_s), float(kk * d_c), float(first_s), float(first_c)))
        print("   sbar^2+(3/5)sbar = %.6f x^2 %+.6f x %+.6f" % (float(q2), float(q1_), float(q0_)))
        print("   Phi1(x) >= %.6f x %+.6f;  at x0: %.6f" % (float(slope), float(const), float(slope * x0 + const)))
    return slope, const, x0

def reach(k, crit):
    # largest r such that crit(r', k) >= 0 for all r_c(k) <= r' <= r
    rc = 1
    while rc ** 3 <= k * k: rc += 1
    r = rc
    if crit(r, k) < 0: return rc, None
    while r + 1 <= k - 2 and crit(r + 1, k) >= 0: r += 1
    return rc, r

if __name__ == "__main__":
    un, ud, rmin, kmin = [int(x) for x in sys.argv[1:5]]
    ub = mpf(un) / ud
    slope, const, x0 = strip1(ub, rmin)
    worst = None
    for r in list(range(rmin, 500)) + list(range(500, 3001, 50)):
        x = sqrt(mpf(r)); g = exactG1(r, x ** 3 / ub); lin = slope * x + const
        assert g >= lin, (r, g, lin)
        if worst is None or g < worst[1]: worst = (r, g)
    print("   exact G1 on the boundary, r=%d..3000: minimum %.6f at r=%d; always >= the linear bound" % (rmin, float(worst[1]), worst[0]))
    print("   reach at sample columns (k: r_c, last r with G~>=0 (sec.10), last r with G1>=0, u at that r, strip end floor((ub k)^(2/3)), smallest R of Lemma 4.1):")
    for k in (265, 300, 350, 400, 450, 500, 534, 700, 1000, 2000, 5000, 9999):
        rc, rg = reach(k, T.exactG); _, rg1 = reach(k, exactG1)
        R = 2
        while True:
            tl, br, th, ps = T.lemma41(k, R)
            if tl >= 0 and T.e1 * br > th * ps: break
            R += 1
        print("     %5d: %4d %4d %4d (u=%.3f) %4d %4d" % (k, rc, rg, rg1, float(mpf(rg1) ** 1.5 / k), T.rend(k, ub), R))
    T.crossing(ub, kmin)
