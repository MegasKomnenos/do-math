# -*- coding: utf-8 -*-
"""
t22: refined closed-form chain for Lemma 4.1 of ra98af63d at R = floor((ub k)^{2/3}) + 1, k >= kmin
(report section 14).  Differences from t18_general.crossing (sections 12, 13):
  * Psi = Hbar + (5/k) Gbar is bounded with one more term of the logarithmic series on each side;
  * the product Theta*Psi is kept as a full polynomial in eps = k^(-1/3), and the final inequality
    F(eps) > 0 on (0, eps1] is obtained from F'(eps) < 0 and F(eps1) > 0.
Usage: python t22_crossing_refined.py <ub_num> <ub_den> <kmin> [kcheck]
Explicit elementary formulas only; arithmetic of a hand derivation, not a proof step.
"""
import sys
from mpmath import mp, mpf, sqrt, exp, log, pi, zeta, cbrt
import t18_general as T
mp.dps = 30
c0 = T.c0; Z32 = T.Z32; e1 = T.e1

def chain(ub, kmin, kcheck=20000, verbose=True):
    nu = ub ** (mpf(2) / 3); w1 = cbrt(mpf(kmin)); eps1 = 1 / w1
    assert nu * eps1 <= 1 and eps1 ** 2 <= nu / 4
    eta1 = 1 + eps1 ** 2 / nu
    s0max = mpf(5) / 2 * eps1 * (nu + eps1 ** 2); q1 = (exp(s0max) - 1 - s0max) / s0max ** 2
    # bracket  L >= A_lin w + A_const + a1 eps - a2 eps^2
    A_lin = nu ** 2 - 2 * c0 * sqrt(nu)
    A_const = -nu ** 3 - 2 + c0 - mpf(5) / 3 * nu ** 1.5 * c0 * eta1 ** 1.5
    cS = mpf(5) * q1 / 2 * c0 * nu ** 2.5 * eta1 ** 2.5; cE = mpf(5) / 24 * nu ** 4 * eta1 ** 4
    a1 = nu + nu ** 4 - cS - cE; a2 = nu * (nu + nu ** 4)
    # Theta <= eps (th1 - th2 eps + th3 eps^2)
    a0 = 2 * e1 * c0 / sqrt(nu); kapA = ((1 - eps1 ** 2 / nu) ** -0.5 - 1) / eps1 ** 2
    B1 = e1 * mpf(5) / 2 * (1 - mpf(8) / 15 * eps1 ** 3)
    b_lin = B1 * 2 * c0 * sqrt(nu); b_quad = B1 * (2 - c0 * (2 + Z32 / 12))
    ea = exp(mpf(5) / 2 * eps1 ** 3); Cf = e1 * ea
    th1 = a0 + Cf * nu; th2 = b_lin + Cf * nu ** 2; th3 = a0 * kapA - b_quad + Cf * (nu ** 3 + 2)
    # Psi <= (nu^2/2) w + chi1 + psi1 eps + psi2 eps^2 + psi3 eps^3 + psi4 eps^4
    chi0 = nu ** 2 / 2; chi1 = mpf(4) / 3 * nu ** 3; psi1 = 2 * nu - nu ** 4
    psi2 = nu ** 2 * (mpf(17) / 2 + mpf(5) / 2 * eps1 ** 3) + nu ** 5; psi3 = 7 * nu ** 3; psi4 = 10 * nu + mpf(25) / 4 * nu ** 4
    chi = [chi0, chi1, psi1, psi2, psi3, psi4]            # coefficients of chi(eps) = eps * Psi-bound
    th = [th1, -th2, th3]
    Pi = [mpf(0)] * 8
    for i, a in enumerate(th):
        for j, b in enumerate(chi):
            Pi[i + j] += a * b
    def F(e):
        return e1 * (A_lin / e + A_const + a1 * e - a2 * e * e) - sum(Pi[i] * e ** i for i in range(8))
    # monotonicity: |e^-1 (a1 - 2 a2 eps) - Pi'(eps)| <= M on [0, eps1]
    M = e1 * max(abs(a1), abs(a1 - 2 * a2 * eps1)) + sum(i * abs(Pi[i]) * eps1 ** (i - 1) for i in range(1, 8))
    lead = e1 * A_lin / eps1 ** 2
    # t_low
    t0 = a0; t2a = a0 * 13 / (12 * nu); s_e1 = e1 * mpf(5) / 2 * 2 * c0 * sqrt(nu); s_e2 = e1 * mpf(5) / 2 * (ea + 1 - c0)
    u_e2 = e1 * q1 * mpf(25) / 4 * c0 * mpf(2) / 3 * nu ** 1.5 * eta1 ** 1.5; u_e4 = e1 * q1 * mpf(25) / 4 * 2 * c0 * sqrt(nu); u_e5 = e1 * q1 * mpf(25) / 4 * (1 - c0)
    tl = lambda e: t0 - s_e1 * e - (t2a + s_e2 + u_e2) * e ** 2 - u_e4 * e ** 4 - u_e5 * e ** 5
    if verbose:
        f = lambda x: "%.7f" % float(x)
        print("[refined crossing u_b=%s, k>=%d] nu=%s w1=%s eps1=%s eta1=%s s0max=%s q1=%s" % (f(ub), kmin, f(nu), f(w1), f(eps1), f(eta1), f(s0max), f(q1)))
        print("   nu^2=%s nu^3=%s nu^4=%s nu^5=%s sqrt(nu)=%s nu^1.5=%s nu^2.5=%s" % (f(nu ** 2), f(nu ** 3), f(nu ** 4), f(nu ** 5), f(sqrt(nu)), f(nu ** 1.5), f(nu ** 2.5)))
        print("   bracket >= %s w %+.7f + %s eps - %s eps^2   [cS=%s cE=%s nu+nu^4=%s; (5/3)c0 nu^1.5 eta1^1.5=%s]" % (f(A_lin), float(A_const), f(a1), f(a2), f(cS), f(cE), f(nu + nu ** 4), f(mpf(5) / 3 * nu ** 1.5 * c0 * eta1 ** 1.5)))
        print("   e^-1 bracket >= %s w %+.7f + %s eps - %s eps^2" % (f(e1 * A_lin), float(e1 * A_const), f(e1 * a1), f(e1 * a2)))
        print("   Theta/eps <= %s - %s eps + %s eps^2   [a0=%s a0*kapA=%s b_lin=%s b_quad=%s Cf=%s Cf nu=%s Cf nu^2=%s Cf(nu^3+2)=%s]" % (f(th1), f(th2), f(th3), f(a0), f(a0 * kapA), f(b_lin), f(b_quad), f(Cf), f(Cf * nu), f(Cf * nu ** 2), f(Cf * (nu ** 3 + 2))))
        print("   Psi <= %s w + %s %+.7f eps + %s eps^2 + %s eps^3 + %s eps^4" % (f(chi0), f(chi1), float(psi1), f(psi2), f(psi3), f(psi4)))
        print("   Pi(eps) coefficients:", [round(float(x), 7) for x in Pi])
        print("   F(eps1) = %s   [e^-1 bracket at w1: %s ; Pi(eps1): %s]" % (f(F(eps1)), f(e1 * (A_lin * w1 + A_const + a1 * eps1 - a2 * eps1 ** 2)), f(sum(Pi[i] * eps1 ** i for i in range(8)))))
        print("   monotonicity: e^-1 A_lin/eps1^2 = %s  >  M = %s : %s" % (f(lead), f(M), lead > M))
        print("   t_low/eps >= %s - %s eps - %s eps^2 - %s eps^4 - %s eps^5 ; at eps1: %s   [parts of the eps^2 coefficient: %s, %s, %s; e^abar<=%s]" % (f(t0), f(s_e1), f(t2a + s_e2 + u_e2), f(u_e4), f(u_e5), f(tl(eps1)), f(t2a), f(s_e2), f(u_e2), f(ea)))
    ok_struct = F(eps1) > 0 and lead > M and tl(eps1) > 0
    bad = 0; worst = None
    ks = list(range(kmin, kcheck + 1)) + [10 ** j for j in range(5, 13)] + [3 * 10 ** j for j in range(5, 12)]
    for k in ks:
        w = cbrt(mpf(k)); eps = 1 / w; R = T.rend(k, ub) + 1
        tlow, bracket, Theta, Psi = T.lemma41(k, R)
        cb = A_lin * w + A_const + a1 * eps - a2 * eps * eps
        ct = eps * (th1 - th2 * eps + th3 * eps ** 2)
        cp = chi0 * w + chi1 + psi1 * eps + psi2 * eps ** 2 + psi3 * eps ** 3 + psi4 * eps ** 4
        good = (2 <= R <= k - 1 and bracket >= cb and 0 <= Theta <= ct and 0 <= Psi <= cp and tlow >= eps * tl(eps) > 0 and F(eps) > 0
                and e1 * bracket > Theta * Psi)
        if not good: bad += 1
        m = e1 * cb - ct * cp
        if worst is None or m < worst[0]: worst = (m, k, R)
    if verbose:
        print("   structural conditions ok: %s;  checked %d k against Lemma 4.1, failures: %d;  smallest closed-form margin %.6f at k=%d (R=%d)" % (ok_struct, len(ks), bad, float(worst[0]), worst[1], worst[2]))
    return ok_struct and bad == 0

if __name__ == "__main__":
    un, ud, kmin = [int(x) for x in sys.argv[1:4]]
    kcheck = int(sys.argv[4]) if len(sys.argv) > 4 else 20000
    chain(mpf(un) / ud, kmin, kcheck)
