# Independent check of Theorem 13.4 (bound on Psi, the final comparison) from the
# definitions in claim c-explicit-bounds (Lemma 4.1 of ra98af63d).
import math, time
from mpmath import mp, mpf, log, sqrt, exp, zeta, floor, cbrt, pi, log1p
mp.dps = 50
t0 = time.time()

nu = (mpf(11) / 5) ** (mpf(2) / 3)
c0 = 1 / sqrt(2 * pi)
w1 = cbrt(mpf(265))
eps1 = 1 / w1
print("nu=%s  nu^2=%s nu^3=%s nu^4=%s nu^5=%s sqrt(nu)=%s nu^2.5=%s" % tuple(
    mp.nstr(v, 12) for v in (nu, nu ** 2, nu ** 3, nu ** 4, nu ** 5, sqrt(nu), nu ** 2.5)))
print("w1=%s eps1=%s  (claimed eps1<0.1556868: %s)" % (mp.nstr(w1, 12), mp.nstr(eps1, 12), eps1 < mpf("0.1556868")))
print("checks: nu*eps1<=1 %s ; eps1^2<=nu/4 %s ; 6 eps1^3<=1 %s" % (nu * eps1 <= 1, eps1 ** 2 <= nu / 4, 6 * eps1 ** 3 <= 1))

def rho2(k):
    # largest integer r with 5 r^{3/2} <= 11 k  <=> 25 r^3 <= 121 k^2
    r = int(round((11 * k / 5) ** (2 / 3)))
    while 25 * r ** 3 > 121 * k * k:
        r -= 1
    while 25 * (r + 1) ** 3 <= 121 * k * k:
        r += 1
    return r

# ------------------------------------------------------------------ coefficient check (collected polynomial)
coef_true = {
    "w": nu ** 2 / 2,
    "1": mpf(4) / 3 * nu ** 3,
    "e": 2 * nu - nu ** 4,
    "e2": nu ** 2 * (mpf(17) / 2 + mpf(5) / 2 * eps1 ** 3) + nu ** 5,
    "e3": 7 * nu ** 3,
    "e4": 10 * nu + mpf(25) / 4 * nu ** 4,
}
coef_stated = {"w": mpf("1.430651"), "1": mpf("6.453334"), "e": mpf("-4.803968"), "e2": mpf("38.196752"),
               "e3": mpf("33.88"), "e4": mpf("68.084410")}
print("collected coefficients (true / stated / stated>=true):")
for key in coef_true:
    print("   %-3s %s  %s  %s" % (key, mp.nstr(coef_true[key], 12), mp.nstr(coef_stated[key], 10), coef_stated[key] >= coef_true[key]))

def psi_stated(w):
    e = 1 / w
    return (coef_stated["w"] * w + coef_stated["1"] + coef_stated["e"] * e + coef_stated["e2"] * e ** 2
            + coef_stated["e3"] * e ** 3 + coef_stated["e4"] * e ** 4)

def lemma41(k, R, hp=True):
    """All quantities of Lemma 4.1 (c-explicit-bounds) in mp arithmetic."""
    k = mpf(k); R = mpf(R)
    N = k + R
    abar = 5 / (2 * k)
    alow = 5 / (2 * k) - 4 / (3 * k * k)
    s0 = abar * R
    q = (exp(s0) - 1 - s0) / s0 ** 2
    Sbar = 1 + c0 * (2 * sqrt(R - 1) - 1 + (2 * abar / 3) * R ** mpf(1.5) + (2 * q * abar ** 2 / 5) * R ** mpf(2.5))
    Ebar = 5 * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * log((k + R + 1) / (k + 2))
    Gbar = (R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * log((k + R) / (k + 1))
    tlow = (2 * exp(-1) * c0 * (1 - 1 / (12 * R)) / sqrt(R + 1)
            - exp(-1) * abar * (exp(abar) + 1 + c0 * (2 * sqrt(R - 1) - 1))
            - exp(-1) * q * abar ** 2 * (1 + c0 * (mpf(2) / 3 * R ** mpf(1.5) + 2 * sqrt(R - 1) - 1)))
    tbar = 2 * exp(-1) * c0 / sqrt(R - 1) - exp(-1) * alow * (2 + c0 * (2 * sqrt(R) - 2 - zeta(mpf(1.5)) / 12))
    L = R * (R + 1) / N - 1 - Sbar - Ebar
    Theta = tbar + exp(-1) * exp(abar) * (R + 1) / N
    Psi = Hbar + 5 / k * Gbar
    return dict(L=L, Theta=Theta, Psi=Psi, tlow=tlow, tbar=tbar, Hbar=Hbar, Gbar=Gbar, Sbar=Sbar, Ebar=Ebar, q=q, s0=s0)

# ------------------------------------------------------------------ the handful of k requested + the quoted numbers
print("\n k        R        Psi(true)        stated bound     slack")
for k in [265, 266, 267, 300, 605, 1000, 10 ** 5, 10 ** 7, 605 * 10 ** 6, 10 ** 12, 605 * 10 ** 12]:
    R = rho2(k) + 1
    d = lemma41(k, R)
    w = cbrt(mpf(k))
    b = psi_stated(w)
    print(" %-8g %-8d %s   %s   %s   ok=%s" % (k, R, mp.nstr(d["Psi"], 12), mp.nstr(b, 12), mp.nstr(b - d["Psi"], 6), d["Psi"] <= b))

# ------------------------------------------------------------------ nine term-by-term bounds + everything, mp, samples
def term_checks(k, R):
    k = mpf(k); R = mpf(R)
    w = cbrt(k); e = 1 / w
    x = (R - 1) / (k + 2); z = (R - 1) / (k + 1)
    ok = []
    ok.append(nu * w * w < R <= nu * w * w + 1)
    ok.append(2 <= R <= k - 1)
    # log sandwiches
    for t in (x, z):
        lo = t - t ** 2 / 2 + t ** 3 / 3 - t ** 4 / 4
        ok.append(lo <= log1p(t) <= lo + t ** 5 / 5)
    Hb = (R - 1) - k * log1p(x)
    Gb = (R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * log1p(z)
    ok.append(Hb <= 2 * x + k * x ** 2 / 2 - k * x ** 3 / 3 + k * x ** 4 / 4)
    ok.append(Gb <= 2 * z + (3 * k + 1) / 2 * z ** 2 + k * (k - 1) * (z ** 3 / 3 - z ** 4 / 4 + z ** 5 / 5))
    # identities used
    ok.append(abs((R - 1) - k * x - 2 * x) < mpf(10) ** (-35) * (1 + R))
    ok.append(2 * x <= 2 * nu * e)
    ok.append(k * x ** 2 / 2 <= nu ** 2 / 2 * w)
    ok.append(k * x ** 3 / 3 >= nu ** 3 / 3 * (1 - 3 * e ** 2 / nu - 6 * e ** 3))
    ok.append(k * x ** 4 / 4 <= nu ** 4 / 4 * e)
    ok.append(10 * z / k <= 10 * nu * e ** 4)
    ok.append(5 * (3 * k + 1) / (2 * k) * z ** 2 <= mpf(15) / 2 * (1 + eps1 ** 3 / 3) * nu ** 2 * e ** 2)
    ok.append(5 * (k - 1) * z ** 3 / 3 <= mpf(5) / 3 * nu ** 3)
    ok.append(5 * (k - 1) * z ** 4 / 4 >= mpf(5) / 4 * nu ** 4 * e * (1 - 4 * e ** 2 / nu - 5 * e ** 3))
    ok.append((k - 1) * z ** 5 <= nu ** 5 * e ** 2)
    return ok

def closed_forms(k, R):
    d = lemma41(k, R)
    w = cbrt(mpf(k)); e = 1 / w
    out = {}
    out["Psi"] = d["Psi"] <= psi_stated(w) and d["Psi"] >= 0
    Llow = mpf("1.823579") * w - mpf("7.935400") + mpf("5.639857") * e - mpf("16.709999") * e ** 2
    out["L"] = d["L"] >= Llow
    out["e-1L"] = exp(-1) * d["L"] >= mpf("0.670857") * w - mpf("2.919271") + mpf("2.074787") * e - mpf("6.147266") * e ** 2
    tl = mpf("0.225686") - mpf("0.954392") * e - mpf("2.495254") * e ** 2 - mpf("1.509538") * e ** 4 - mpf("0.874338") * e ** 5
    out["tlow"] = d["tlow"] / e >= tl and d["tlow"] > 0
    Th = e * (mpf("0.853867") - mpf("2.015061") * e + mpf("1.583938") * e ** 2)
    out["Theta"] = d["Theta"] <= Th and d["Theta"] >= 0
    out["Theta/eps lin"] = d["Theta"] / e <= mpf("0.853867") - mpf("1.768462") * e
    out["eps*Psi"] = e * d["Psi"] <= mpf("1.430651") + mpf("6.453334") * e + mpf("2.220882") * e ** 2
    prod = mpf("1.221586") + mpf("2.980238") * e - mpf("9.516138") * e ** 2 - mpf("3.927545") * e ** 3
    out["ThetaPsi"] = d["Theta"] * d["Psi"] <= prod
    g = mpf("0.670857") / e - mpf("4.140857") - mpf("0.905451") * e + mpf("3.368872") * e ** 2
    out["final>=g"] = exp(-1) * d["L"] - d["Theta"] * d["Psi"] >= g
    out["g>=0.1088"] = g >= mpf("0.1088")
    out["(4.1)"] = exp(-1) * d["L"] > d["Theta"] * d["Psi"]
    out["s0"] = d["s0"] <= mpf("0.6678088")
    out["q"] = d["q"] <= mpf("0.6326704")
    return out, d

sample = list(range(265, 2001)) + list(range(2001, 20001, 37)) + [int(10 ** (4.3 + i * 0.05)) for i in range(0, 235)]
sample += [605 * b ** 3 for b in range(1, 200, 7)] + [605 * b ** 3 + s for b in range(1, 60, 5) for s in (-1, 1)]
sample = sorted(set(k for k in sample if k >= 265))
nfail_terms = 0; nfail_cf = {}
minslack = None
for k in sample:
    R = rho2(k) + 1
    tc = term_checks(k, R)
    if not all(tc):
        nfail_terms += 1
        if nfail_terms < 5:
            print("TERM FAIL", k, R, tc)
    cf, d = closed_forms(k, R)
    for key, v in cf.items():
        if not v:
            nfail_cf[key] = nfail_cf.get(key, 0) + 1
            if nfail_cf[key] < 3:
                print("CLOSED FORM FAIL", key, k, R)
    sl = psi_stated(cbrt(mpf(k))) - d["Psi"]
    if minslack is None or sl < minslack[0]:
        minslack = (sl, k, R)
print("\nmp sample: %d values of k in [%d, %.3g]; term-check failures %d; closed-form failures %s" % (
    len(sample), sample[0], sample[-1], nfail_terms, nfail_cf))
print("smallest slack (stated Psi bound - true Psi) on the sample: %s at k=%d R=%d" % (mp.nstr(minslack[0], 6), minslack[1], minslack[2]))

# ------------------------------------------------------------------ final-argument arithmetic
e1 = eps1
print("\nfinal argument:")
print("  2.015061 - 1.583938*eps1 = %s  (stated 1.768462 must be <= this: %s)" % (
    mp.nstr(mpf("2.015061") - mpf("1.583938") * e1, 10), mpf("1.768462") <= mpf("2.015061") - mpf("1.583938") * e1))
v = -mpf("4.803968") + mpf("38.196752") * e1 + mpf("33.88") * e1 ** 2 + mpf("68.084410") * e1 ** 3
print("  -4.803968+38.196752 e1+33.88 e1^2+68.084410 e1^3 = %s  (stated <= 2.220882: %s)" % (mp.nstr(v, 10), v <= mpf("2.220882")))
A0, A1 = mpf("0.853867"), mpf("-1.768462")
B0, B1, B2 = mpf("1.430651"), mpf("6.453334"), mpf("2.220882")
pc = [A0 * B0, A0 * B1 + A1 * B0, A0 * B2 + A1 * B1, A1 * B2]
st = [mpf("1.221586"), mpf("2.980238"), mpf("-9.516138"), mpf("-3.927545")]
for i in range(4):
    print("  product coeff eps^%d: true %s stated %s  stated>=true %s" % (i, mp.nstr(pc[i], 10), mp.nstr(st[i], 10), st[i] >= pc[i]))
print("  positivity of the two factors at eps1: %s , %s" % (mp.nstr(A0 + A1 * e1, 6), mp.nstr(B0 + B1 * e1 + B2 * e1 ** 2, 6)))
gc = [mpf("0.670857"), -mpf("2.919271") - st[0], mpf("2.074787") - st[1], -mpf("6.147266") - st[2], -st[3]]
print("  g coefficients: 1/eps: %s ; const %s (stated -4.140857) ; eps %s (stated -0.905451) ; eps^2 %s (stated 3.368872) ; eps^3 %s (dropped, >=0)" % tuple(
    mp.nstr(c, 10) for c in gc))
g = lambda e: mpf("0.670857") / e - mpf("4.140857") - mpf("0.905451") * e + mpf("3.368872") * e ** 2
gp = lambda e: -mpf("0.670857") / e ** 2 - mpf("0.905451") + mpf("6.737744") * e
print("  g(eps1) = %s ; g'(eps1) = %s ; 6.737744*eps1 = %s" % (mp.nstr(g(e1), 8), mp.nstr(gp(e1), 8), mp.nstr(mpf("6.737744") * e1, 8)))
tl = lambda e: mpf("0.225686") - mpf("0.954392") * e - mpf("2.495254") * e ** 2 - mpf("1.509538") * e ** 4 - mpf("0.874338") * e ** 5
print("  t_low/eps closed form at eps1 = %s" % mp.nstr(tl(e1), 8))

# ------------------------------------------------------------------ quoted numbers
d = lemma41(265, 70)
print("\nk=265,R=70: Psi=%s  stated bound=%s" % (mp.nstr(d["Psi"], 6), mp.nstr(psi_stated(w1), 6)))
d = lemma41(267, rho2(267) + 1)
print("k=267,R=%d: t_low*w=%s" % (rho2(267) + 1, mp.nstr(d["tlow"] * cbrt(mpf(267)), 6)))
print("time %.1fs" % (time.time() - t0))
