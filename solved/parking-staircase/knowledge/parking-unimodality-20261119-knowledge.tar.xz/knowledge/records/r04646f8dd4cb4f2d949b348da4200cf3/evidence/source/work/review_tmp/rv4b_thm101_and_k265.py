# (a) piecewise closed forms in the proof of Theorem 10.1 (used by Cor 13.5 (ga)) -- numeric sanity only
# (b) for k=265: for which R do the hypotheses of Lemma 4.1 (t_low>=0 and (4.1)) hold?  (commentary in 13.6)
# (c) Lemma 13.1 via DP for larger m and extreme N (exact rationals)
import math, time
from fractions import Fraction as F
from math import factorial
t0 = time.time()
def s_r(r):
    s = 0.0; p = 1.0
    for j in range(1, r + 1):
        p *= (r - j + 1) / r
        s += p
        if p < 1e-18: break
    return s
def D_r(r):
    s = s_r(r)
    return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))
def mu0(X, r):
    return (math.sqrt((4 + X) ** 2 + 12 * (r - 1)) - (4 + X)) / 3
viol = 0
for r in range(42, 6001):
    x = math.sqrt(r); k = (2 / 3) * x ** 3
    p1 = k * (1 / (2 * r) - 1 / (3 * r * r)) - 2.5
    X = r * r / k; Xh = r * (r + 1) / (k - 1)
    tot = p1 + 0.5 * mu0(Xh, r) + 2 * (1 - 1 / k) * mu0(X, r) - k / (k - 1) * D_r(r)
    checks = [p1 >= x / 3 - 2.534291, Xh <= 1.544225 * x, mu0(X, r) >= 0.758306 * x - 0.803520,
              mu0(Xh, r) >= 0.749494 * x - 0.790459,
              0.5 * mu0(Xh, r) + 2 * (1 - 1 / k) * mu0(X, r) >= 1.883001 * x - 1.993415,
              D_r(r) <= 1.883705 * x - 2.6, k / (k - 1) * D_r(r) <= 1.894145 * x - 2.614409,
              tot >= 0.322189 * x - 1.913297, k >= r + 2]
    if not all(checks):
        viol += 1
        if viol < 4: print("viol", r, checks)
print("(a) Thm 10.1 piecewise closed forms: violations over 42<=r<=6000:", viol)

# (b)
Z32 = 2.6123753486854883
C0 = 1 / math.sqrt(2 * math.pi); EM1 = math.exp(-1)
def lemma41_ok(k, R):
    N = k + R
    abar = 5 / (2 * k); alow = abar - 4 / (3 * k * k)
    s0 = abar * R
    q = (math.expm1(s0) - s0) / s0 ** 2
    Sbar = 1 + C0 * (2 * math.sqrt(R - 1) - 1 + (2 * abar / 3) * R ** 1.5 + (2 * q * abar ** 2 / 5) * R ** 2.5)
    Ebar = 5 * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * math.log1p((R - 1) / (k + 2))
    Gbar = (R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * math.log1p((R - 1) / (k + 1))
    tlow = (2 * EM1 * C0 * (1 - 1 / (12 * R)) / math.sqrt(R + 1) - EM1 * abar * (math.exp(abar) + 1 + C0 * (2 * math.sqrt(R - 1) - 1))
            - EM1 * q * abar ** 2 * (1 + C0 * (2 / 3 * R ** 1.5 + 2 * math.sqrt(R - 1) - 1)))
    tbar = 2 * EM1 * C0 / math.sqrt(R - 1) - EM1 * alow * (2 + C0 * (2 * math.sqrt(R) - 2 - Z32 / 12))
    L = R * (R + 1) / N - 1 - Sbar - Ebar
    Theta = tbar + EM1 * math.exp(abar) * (R + 1) / N
    Psi = Hbar + 5 / k * Gbar
    return tlow >= 0, EM1 * L > Theta * Psi
for k in (265,):
    okR = [R for R in range(2, k) if all(lemma41_ok(k, R))]
    tpos = [R for R in range(2, k) if lemma41_ok(k, R)[0]]
    c41 = [R for R in range(2, k) if lemma41_ok(k, R)[1]]
    print("(b) k=%d: R with both hypotheses of Lemma 4.1: %s..%s (contiguous: %s); t_low>=0 for R<=%d; (4.1) for R in %d..%d" % (
        k, okR[0], okR[-1], okR == list(range(okR[0], okR[-1] + 1)), max(tpos), min(c41), max(c41)))

# (c) Lemma 13.1 by DP, m up to 40
_a = {}
def a(j):
    if j not in _a: _a[j] = F(j ** (j - 1), factorial(j))
    return _a[j]
def law_Q(m, lam):
    G = [dict() for _ in range(m + 1)]
    G[0] = {0: F(1)}
    for j in range(1, m):
        d = {}
        for i in range(j):
            for c, v in G[i].items():
                d[c + 1] = d.get(c + 1, F(0)) + v * a(j - i)
        G[j] = {c: v * lam[j] for c, v in d.items()}
    out = {}
    for i in range(m):
        for c, v in G[i].items():
            out[c + 1] = out.get(c + 1, F(0)) + v * a(m - i)
    return out
def T(m, q):
    return F(q, m) * F(m ** (m - q), factorial(m - q))
bad = 0; n = 0
for m in (10, 13, 17, 24, 31, 40):
    for d in (F(1, 10 ** 9), F(1, 7), F(1), F(5, 2), F(m), F(100 * m) + F(1, 3)):
        N = F(m - 1) + d
        y = F(1)                       # the ratio does not depend on y
        lam = {s: y / (N - s) for s in range(1, m)}
        P = law_Q(m, lam)
        h = y / (N - F(m, 2))
        ratios = [P[q] / (T(m, q) * h ** (q - 1)) for q in range(1, m + 1)]
        n += 1
        if any(ratios[i + 1] < ratios[i] for i in range(m - 1)):
            bad += 1
            print("VIOLATION m=%d N=%s" % (m, N))
        # top step must be an equality
        assert ratios[m - 1] == ratios[m - 2]
print("(c) Lemma 13.1 via DP: cases %d, violations %d" % (n, bad))
print("time %.1fs" % (time.time() - t0))
