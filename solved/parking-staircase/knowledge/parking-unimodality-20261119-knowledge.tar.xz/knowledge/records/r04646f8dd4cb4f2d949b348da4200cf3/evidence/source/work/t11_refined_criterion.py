# -*- coding: utf-8 -*-
"""
t11: the explicit cross-product criterion of r496399b6 (Prop. 8.1) with the published intermediate bound
     Lambda_{r+1}(k-1) <= Upsilon_r(h) Lambda_r(k),  h=(k-1)/(k+r),  kept instead of relaxed to (1+1/r)^r.
   M0(r,k) = k(1/(2r)-1/(3r^2)) - 5/2 + 2(1-1/k) mu0 - (k/(k-1)) D_r            (published form)
   M1(r,k) = k[(k-2)log(1+1/k) - log Upsilon_r(h)] + k mu0 log(1+2/k) - k D_r/(k-1)   (refined; exact logs)
   Upsilon_r(h) = tau_{r+1}(h)/tau_r(h),  tau_m(h) = sum_q T_{m,q} h^{q-1},  T_{m,q} = q m^{m-q-1}/(m-q)!
 For the sample columns of ra98af63d (p-two-criteria-overlap) prints r_c, the last r with M0>=0 from r_c on
 (to reproduce the published r_M), and the same for M1, next to the published thresholds R of the crossing criteria.
 Explicit formulas only (no parking tables); mpmath 30 digits.  A test of one step, not a proof step.
"""
import sys
from mpmath import mp, mpf, log, sqrt, exp, loggamma
mp.dps = 30

def rc(k):
    r = 1
    while r ** 3 <= k * k: r += 1
    return r

def s_r(r):
    s = mpf(0); t = mpf(1)
    for j in range(1, r + 1):
        t *= mpf(r - j + 1) / r
        s += t
    return s

def D_r(r):
    s = s_r(r)
    return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))

def mu0(r, k):
    a = 4 + mpf(r) ** 2 / k
    return (sqrt(a * a + 12 * (r - 1)) - a) / 3

def log_tau(m, h):
    # tau_m(h) = sum_{q=1}^m q m^{m-q-1} h^{q-1}/(m-q)!   computed in the Borel normalisation e^{-m}
    tot = mpf(0)
    lm = log(mpf(m)); lh = log(h)
    for q in range(1, m + 1):
        tot += exp(log(mpf(q)) + (m - q - 1) * lm + (q - 1) * lh - loggamma(m - q + 1) - m)
    return log(tot) + m

def M0(r, k):
    return k * (mpf(1) / (2 * r) - mpf(1) / (3 * r * r)) - mpf(5) / 2 + 2 * (1 - mpf(1) / k) * mu0(r, k) - mpf(k) / (k - 1) * D_r(r)

def M1(r, k, parts=False):
    h = mpf(k - 1) / (k + r)
    lU = log_tau(r + 1, h) - log_tau(r, h)
    g1 = k * ((k - 2) * log(1 + mpf(1) / k) - lU)
    g2 = k * mu0(r, k) * log(1 + mpf(2) / k)
    d = k * D_r(r) / (k - 1)
    return (g1, g2, d) if parts else g1 + g2 - d

if __name__ == "__main__":
    pub = {265: (43, 48), 400: (59, 59), 535: (73, 68), 700: (89, 79), 1000: (114, 96), 1500: (153, 121),
           2000: (187, 144), 5000: (353, 250), 9999: (568, 384)}
    print("k r_c | last r with M0>=0 (published r_M) | last r with M1>=0 | published R of the crossing criterion (joined) | floor(27k/100)-1")
    for k in sorted(pub):
        r0 = rc(k)
        r = r0
        while M0(r, k) >= 0: r += 1
        rM0 = r - 1
        r = max(r0, rM0)
        while M1(r, k) >= 0: r += 1
        rM1 = r - 1
        ok_start = all(M1(rr, k) >= 0 for rr in range(r0, min(rM0, r0 + 3) + 1))
        g1, g2, d = M1(rM1, k, parts=True)
        print(f"{k} {r0} | {rM0} (pub {pub[k][0]}) | {rM1}  u={rM1**1.5/k:.2f}  [at that r: g1>={float(g1):.2f} g2>={float(g2):.2f} D<={float(d):.2f}] | {pub[k][1]} | {27*k//100-1}   (M1>=0 on r_c..r_c+3: {ok_start})")
        sys.stdout.flush()
