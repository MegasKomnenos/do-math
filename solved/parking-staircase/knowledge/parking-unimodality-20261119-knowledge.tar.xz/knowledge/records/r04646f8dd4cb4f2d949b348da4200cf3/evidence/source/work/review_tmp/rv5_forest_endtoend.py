# End-to-end sanity check, independent of the chain sums: compute K_{n,k}(y), Z_n(j) from the forest formula
#   K_{n,k}(y) = sum over rooted labelled forests F on [n] of prod_{v: t_v>k} y/t_v ,  Z_n(j) = K_{n,j}(j)
# (statement of claim c-prop-5-8 / p-general-identities), then B_-, B_+, C_-, C_+, S_{n,k}, d_{n,k},
# and compare k*log(B_+C_-/(B_-C_+)) with the right-hand side of Corollary 13.2.
import sys, time, itertools, math
from fractions import Fraction as F
from math import factorial
from mpmath import mp, mpf, log
mp.dps = 120
t0 = time.time()

def forest_series(nmax, w):
    """coefficients f_j = [z^j] exp(T(z)), T = sum_t c_t z^t, c_t = w(t) f_{t-1}  (weighted rooted forests / j!)."""
    f = [mpf(1)]
    c = [mpf(0)]
    for j in range(1, nmax + 1):
        c.append(w(j) * f[j - 1])
        s = mpf(0)
        for t in range(1, j + 1):
            s += t * c[t] * f[j - t]
        f.append(s / j)
    return f

def Kser(nmax, k, y):
    return forest_series(nmax, lambda t: mpf(1) if t <= k else mpf(y) / t)
def Zser(nmax, j):
    return Kser(nmax, j, j)

# ---- validation against brute force for small n
def brute_b(n):
    cnt = [0] * n
    for pref in itertools.product(range(1, n + 1), repeat=n):
        occ = [False] * (n + 2)
        ok = True; mx = 0
        for a in pref:
            s = a
            while s <= n and occ[s]:
                s += 1
            if s > n:
                ok = False; break
            occ[s] = True
            mx = max(mx, s - a)
        if ok:
            cnt[mx] += 1
    return cnt
for n in (4, 5, 6):
    b = brute_b(n)
    A = [sum(b[:l + 1]) for l in range(n)]            # A_{n,l} = # with max displacement <= l
    for j in range(1, n + 1):
        z = Zser(n, j)[n] * factorial(n)              # Z_n(j) = A_{n,j-1}
        assert abs(z - A[j - 1]) < mpf(10) ** (-80), (n, j, z, A[j - 1])
print("forest formula Z_n(j)=A_{n,j-1} agrees with brute-force parking counts for n=4,5,6")
# the example of claim c-prop-5-8: (n,k)=(5,3): C_-=C_+=32, B_-=156, B_+=160, S=128
def site(n, k, need_series=None):
    fac = mp.factorial(n)
    Km1 = Kser(n, k, k - 1)[n] * fac
    K0 = Kser(n, k, k)[n] * fac
    Kp1 = Kser(n, k, k + 1)[n] * fac
    Kp2 = Kser(n, k, k + 2)[n] * fac
    Zm1 = Zser(n, k - 1)[n] * fac
    Zp2 = Zser(n, k + 2)[n] * fac
    Z0 = Zser(n, k)[n] * fac
    Zp1 = Zser(n, k + 1)[n] * fac
    Cm = Kp1 - 2 * K0 + Km1
    Cp = Kp2 - 2 * Kp1 + K0
    Bm = Km1 - Zm1
    Bp = Kp2 - Zp2
    d_k = Zp1 - 2 * Z0 + Zm1                # b_{n,k}-b_{n,k-1}
    d_k1 = Zp2 - 2 * Zp1 + Z0               # b_{n,k+1}-b_{n,k}
    return dict(Cm=Cm, Cp=Cp, Bm=Bm, Bp=Bp, S=Bp * Cm - Bm * Cp, d_k=d_k, d_k1=d_k1,
                idK=(abs(K0 - Z0) / Z0, abs(Kp1 - Zp1) / Zp1))
s = site(5, 3)
print("(5,3): C_-=%s C_+=%s B_-=%s B_+=%s S=%s (published: 32, 32, 156, 160, 128)" % tuple(
    mp.nstr(s[x], 12) for x in ("Cm", "Cp", "Bm", "Bp", "S")))

# ---- right-hand side of Corollary 13.2 (exact mu_1, mu_h, D_r)
def T(m, q):
    return F(q, m) * F(m ** (m - q), factorial(m - q))
def mean_cuts(r, h):
    w = [T(r, q) * h ** (q - 1) for q in range(1, r + 1)]
    return float(sum(w[j] * j for j in range(r)) / sum(w))
def s_r(r):
    s = 0.0; p = 1.0
    for j in range(1, r + 1):
        p *= (r - j + 1) / r; s += p
    return s
def D_r(r):
    s = s_r(r)
    return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))
def mu0(X, r):
    return (math.sqrt((4 + X) ** 2 + 12 * (r - 1)) - (4 + X)) / 3
def rhs132(k, r):
    mu1 = mean_cuts(r, F(k) / (k + 1 + F(r, 2)))
    muh = mean_cuts(r, F(k - 1, k + r))
    base = k * (1 / (2 * r) - 1 / (3 * r * r)) - 2.5 - k / (k - 1) * D_r(r)
    first = base + 2 * (1 - 1 / k) * mu1 + k / (2 * (k - 1)) * muh + 1 / k
    G1 = base + 0.5 * mu0(r * (r + 1) / (k - 1), r) + 2 * (1 - 1 / k) * mu0(r * (r + 2) / (2 * k), r)
    return first, G1

sites = [(8, 4), (21, 10), (46, 14), (60, 20), (100, 25), (100, 34), (265, 42), (265, 55), (265, 62), (265, 69), (265, 70)]
print("\n  k   r   u     true k*log(B+C-/(B-C+))   Cor13.2 bound (exact mu)   G~_1    S>0   d_{n,k}>0?  d_{n,k+1}>0?  first-layer identities(rel.err)")
for (k, r) in sites:
    n = k + r
    s = site(n, k)
    val = k * log(s["Bp"] * s["Cm"] / (s["Bm"] * s["Cp"]))
    first, G1 = rhs132(k, r)
    print(" %4d %3d %.2f   %10.4f                %8.4f                 %7.3f  %s   %s   %s   %s" % (
        k, r, r ** 1.5 / k, float(val), first, G1, s["S"] > 0, s["d_k"] > 0, s["d_k1"] > 0,
        mp.nstr(max(s["idK"]), 3)))
    assert float(val) >= first
print("time %.1fs" % (time.time() - t0))
