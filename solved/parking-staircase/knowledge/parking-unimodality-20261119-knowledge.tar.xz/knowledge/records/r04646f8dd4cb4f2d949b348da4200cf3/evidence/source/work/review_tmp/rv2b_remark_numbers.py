# Check the numbers quoted in remark (da) after Lemma 13.1: (r,k)=(57,265) and (20,60).
from fractions import Fraction as F
from math import factorial
import sys
sys.path.insert(0, ".")
from rv2_cor132 import Lambda_poly, homog_law, T, aa

def mean_parts_h(r, h):
    P = homog_law(r, h)
    return float(sum(P[j] * (j + 1) for j in range(r)))

for (k, r) in [(265, 57), (60, 20)]:
    N = k + r + 1
    print("(k,r)=", (k, r))
    for name, h in [("k/(k+r/2)", F(k) / (k + F(r, 2))), ("k/(k+1+r/2) [lemma h_1]", F(k) / (k + 1 + F(r, 2))),
                    ("k/(k+r) [min]", F(k, k + r)), ("1 [free]", F(1))]:
        print("   mean parts under homogeneous", name, "= %.4f" % mean_parts_h(r, h))
    lam = {s: F(k, N - s) for s in range(1, r)}
    mass = Lambda_poly(r, lam)
    Z = sum(mass.values())
    print("   mean parts under threshold profile = %.4f" % float(sum(v * q for q, v in mass.items()) / Z))
    # effective factor per step: P_lam(Q=q+1)/P_lam(Q=q) = T_{r,q+1}/T_{r,q} * E_{pi_{q+1}}W / E_{pi_q}W
    # E_{pi_q}W/E_{pi_{q+1}}W = (N - shat_{q+1})/y ; effective factor = y/(N - shat) =: k/(k + c r)
    cs = []
    for q in range(1, r):
        eff = (mass[q + 1] / T(r, q + 1)) / (mass[q] / T(r, q))     # = y/(N - shat)
        # eff = k/(k + c r)  ->  c = (k/eff - k)/r
        c = (F(k) / eff - k) / r
        cs.append(float(c))
    print("   c range over q: min %.4f max %.4f ; lemma value (r+2)/(2r) = %.4f ; c nonincreasing in q? %s" % (
        min(cs), max(cs), (r + 2) / (2 * r), all(cs[i + 1] <= cs[i] + 1e-15 for i in range(len(cs) - 1))))
    print("   all c <= (r+2)/(2r)?", all(c <= (r + 2) / (2 * r) + 1e-12 for c in cs), " first few c:", [round(c, 4) for c in cs[:4]], " last:", round(cs[-1], 4))
