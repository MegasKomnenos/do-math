# -*- coding: utf-8 -*-
"""
t08: small exact sanity checks of the steps proved in report sections 3 and 4 (guards against sign slips).
  (a) Proposition 3.2 at two small first-layer positions: rho_2 <= ... <= rho_r and C+/C- <= rho_r,
      with K built from (5.5) of r496399b6 and, independently, C+/C- from the weighted last-car recursion.
  (b) (F3): Lambda_{r+1}(y;N) = Lambda_r(y;N) * ( y/(N-r) + E_y[alpha(gamma)] ).
  (c) Lemma 4.1 on the coefficient sequence of y*Lambda_r (log-concave by Cor. D of r3dc4f6e9).
  (d) Proposition 4.2: log(C+/C-) <= log rho_r <= D_cal  and  log(B+/B-) >= G_cal.
Exact rationals; only the final logs are floats.
"""
from fractions import Fraction as Fr
from math import comb, factorial, log
from itertools import combinations

def a(j):
    return Fr(j ** (j - 1), factorial(j))

def comps(m):
    """cut sets of compositions of m"""
    for q in range(0, m):
        for S in combinations(range(1, m), q):
            yield S

def weight(m, S):
    pts = (0,) + S + (m,)
    w = Fr(1)
    for i in range(1, len(pts)):
        w *= a(pts[i] - pts[i - 1])
    return w

def Lam_coeffs(m, N):
    """coefficients c[j] of y^j in Lambda_m(y;N)"""
    c = [Fr(0)] * m
    for S in comps(m):
        w = weight(m, S)
        for s in S:
            w /= (N - s)
        c[len(S)] += w
    return c

def poly(c, y):
    return sum(cj * Fr(y) ** j for j, cj in enumerate(c))

def kappa(k, t):
    return a(t) - sum(a(i) * a(t - i) for i in range(k + 1, t))

def zrec(n, cfun):
    Z = [1]
    for m in range(1, n + 1):
        Z.append(sum(comb(m - 1, j) * cfun(j) * Z[j] * Z[m - 1 - j] for j in range(m)))
    return Z[n]

def check(n, k):
    N, r = n + 1, n - k
    L = {m: Lam_coeffs(m, N) for m in range(1, r + 2)}
    def u(m, y):
        return Fr(y, N - m) * poly(L[m], y)
    def d2u(m, x):
        return u(m, x + 1) - 2 * u(m, x) + u(m, x - 1)
    rho = [d2u(m, k + 1) / d2u(m, k) for m in range(2, r + 1)]
    Cm = sum(kappa(k, N - m) * d2u(m, k) for m in range(2, r + 1))
    Cp = sum(kappa(k, N - m) * d2u(m, k + 1) for m in range(2, r + 1))
    # independent: frozen polynomial from the recursion  (t_v = j+1 > k gets factor y/(j+1))
    def K(y):
        return zrec(n, lambda j: (j + 1) if j + 1 <= k else y)
    Cm2 = K(k + 1) - 2 * K(k) + K(k - 1)
    Cp2 = K(k + 2) - 2 * K(k + 1) + K(k)
    assert Fr(Cp2, Cm2) == Cp / Cm, "frozen polynomial mismatch"
    mono = all(rho[i] <= rho[i + 1] for i in range(len(rho) - 1))
    print(f"(n,k)=({n},{k}) r={r}: rho_2..rho_r = {[round(float(x), 5) for x in rho]}  nondecreasing: {mono}")
    print(f"   C+/C- = {float(Cp / Cm):.6f} <= rho_r = {float(rho[-1]):.6f}: {Cp / Cm <= rho[-1]}   rho_2 == 1: {rho[0] == 1}")
    # (b) F3 at y = k-1
    y = k - 1
    num = Fr(0); tot = Fr(0)
    for S in comps(r):
        w = weight(r, S)
        for s in S:
            w *= Fr(y, N - s)
        g = r - max(S + (0,))
        tot += w
        num += w * a(g + 1) / a(g)
    lhs = poly(L[r + 1], y)
    rhs = tot * (Fr(y, N - r) + num / tot)
    assert tot == poly(L[r], y)
    print(f"   (F3) Lambda_(r+1)(k-1) == Lambda_r(k-1)*(y/(N-r)+E[alpha(gamma)]): {lhs == rhs}")
    # (c) Lemma 4.1 for p_q = [y^q] y*Lambda_r, tilted at eta = k+2
    p = [Fr(0)] + [L[r][j] * Fr(k + 2) ** (j + 1) for j in range(r)]
    lc = all(p[q] ** 2 >= p[q - 1] * p[q + 1] for q in range(2, r))
    b = [sum(comb(q, j) * p[q] for q in range(len(p))) for j in range(r + 2)]
    lcb = all(b[j] ** 2 >= b[j - 1] * b[j + 1] for j in range(1, r + 1))
    print(f"   coefficients of y*Lambda_r log-concave: {lc};  binomial moments log-concave: {lcb}")
    # (d) Proposition 4.2
    def moments(eta):
        pq = [Fr(0)] + [L[r][j] * Fr(eta) ** (j + 1) for j in range(r)]
        Z = sum(pq)
        EJ = sum((q - 1) * pq[q] for q in range(len(pq))) / Z
        e2 = sum(q * (q - 1) * pq[q] for q in range(len(pq)))
        e3 = sum(q * (q - 1) * (q - 2) * pq[q] for q in range(len(pq)))
        return EJ, e3 / e2, e2 / sum(q * pq[q] for q in range(len(pq)))
    EJk, _, _ = moments(k)
    EJk1, _, _ = moments(k - 1)
    _, Dk2, Esb = moments(k + 2)
    Ealpha = num / tot
    Dcal = float(Dk2) * log(k / (k - 1))
    Gcal = (k - 2) * log(1 + 1 / k) - log(float(Fr(k - 1, k + 1) + Ealpha)) + float(EJk1) * log(k / (k - 1)) + float(EJk) * log(1 + 2 / k)
    Bm = a(k) / k * poly(L[r + 1], k - 1)
    Bp = a(k + 1) / (k + 1) * poly(L[r], k + 2)
    lc_, lr_, lb_ = log(float(Cp / Cm)), log(float(rho[-1])), log(float(Bp / Bm))
    print(f"   log(C+/C-)={lc_:.6f} <= log rho_r={lr_:.6f} <= D_cal={Dcal:.6f};  G_cal={Gcal:.6f} <= log(B+/B-)={lb_:.6f}")
    print(f"   two-moment bound (3/2)E[Q(Q-1)]/E[Q]*log(k/(k-1)) = {1.5 * float(Esb) * log(k / (k - 1)):.6f}  (>= D_cal: {1.5 * float(Esb) * log(k / (k - 1)) >= Dcal})")

if __name__ == "__main__":
    check(12, 8)
    check(15, 9)
