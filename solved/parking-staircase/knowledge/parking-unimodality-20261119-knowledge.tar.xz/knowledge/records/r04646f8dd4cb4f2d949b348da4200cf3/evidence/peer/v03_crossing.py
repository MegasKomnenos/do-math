# -*- coding: utf-8 -*-
"""Peer check (independent code) of the producer's Theorem 13.4 / 12.1:
   for every k>=265, R = floor((11k/5)^(2/3)) + 1 satisfies  t_low >= 0  and (4.1) of Lemma 4.1 of ra98af63d.

 mode 'scan'  : evaluate Lemma 4.1's closed quantities in double precision for ALL k in [265, KMAX] and a
                geometric sample up to 1e15; report the minimum of t_low*k^(1/3) and of LHS(4.1)-RHS(4.1);
                also evaluate the producer's closed-form minorants (proof of Thm 13.4) and check they are
                on the safe side of the Lemma 4.1 quantities.
 mode 'mp'    : the same at selected k with 50-digit arithmetic (to validate the double-precision scan).
 mode 'trueK' : the criterion (K) of Prop 3.1 itself (true sums) at R = rho2(k)+1, 265<=k<=3000.
"""
import math, sys
import mpmath as mp

C0 = 1 / math.sqrt(2 * math.pi)
ZETA32 = 2.6123753486854883
E1 = math.exp(-1)


def rho2(k):
    """largest integer r with 5 r^{3/2} <= 11 k  <=>  25 r^3 <= 121 k^2"""
    r = int((11 * k / 5) ** (2 / 3))
    while 25 * (r + 1) ** 3 <= 121 * k * k:
        r += 1
    while 25 * r ** 3 > 121 * k * k:
        r -= 1
    return r


def rho32(k):
    """largest integer r with 2 r^{3/2} <= 3 k  <=> 4 r^3 <= 9 k^2"""
    r = int((3 * k / 2) ** (2 / 3))
    while 4 * (r + 1) ** 3 <= 9 * k * k:
        r += 1
    while 4 * r ** 3 > 9 * k * k:
        r -= 1
    return r


def rc(k):
    r = int(k ** (2 / 3))
    while r ** 3 <= k * k:
        r += 1
    while (r - 1) ** 3 > k * k:
        r -= 1
    return r


def lemma41(k, R):
    N = k + R
    abar = 5 / (2 * k)
    alow = 5 / (2 * k) - 4 / (3 * k * k)
    s0 = abar * R
    q = (math.expm1(s0) - s0) / (s0 * s0)
    Sbar = 1 + C0 * (2 * math.sqrt(R - 1) - 1 + 2 * abar / 3 * R ** 1.5 + 2 * q * abar ** 2 / 5 * R ** 2.5)
    Ebar = 5 * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * math.log1p((R - 1) / (k + 2))
    Gbar = (R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * math.log1p((R - 1) / (k + 1))
    tlow = (2 * E1 * C0 * (1 - 1 / (12 * R)) / math.sqrt(R + 1)
            - E1 * abar * (math.exp(abar) + 1 + C0 * (2 * math.sqrt(R - 1) - 1))
            - E1 * q * abar ** 2 * (1 + C0 * (2 / 3 * R ** 1.5 + 2 * math.sqrt(R - 1) - 1)))
    tbar = 2 * E1 * C0 / math.sqrt(R - 1) - E1 * alow * (2 + C0 * (2 * math.sqrt(R) - 2 - ZETA32 / 12))
    L = R * (R + 1) / N - 1 - Sbar - Ebar
    Theta = tbar + E1 * math.exp(abar) * (R + 1) / N
    Psi = Hbar + 5 / k * Gbar
    return dict(tlow=tlow, lhs=E1 * L, Theta=Theta, Psi=Psi, rhs=Theta * Psi, L=L)


def lemma41_mp(k, R):
    mp.mp.dps = 50
    k = mp.mpf(k); R = mp.mpf(R)
    N = k + R
    c0 = 1 / mp.sqrt(2 * mp.pi)
    e1 = mp.e ** -1
    abar = 5 / (2 * k)
    alow = 5 / (2 * k) - 4 / (3 * k * k)
    s0 = abar * R
    q = (mp.e ** s0 - 1 - s0) / s0 ** 2
    Sbar = 1 + c0 * (2 * mp.sqrt(R - 1) - 1 + 2 * abar / 3 * R ** 1.5 + 2 * q * abar ** 2 / 5 * R ** 2.5)
    Ebar = 5 * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * mp.log((k + R + 1) / (k + 2))
    Gbar = (R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * mp.log((k + R) / (k + 1))
    tlow = (2 * e1 * c0 * (1 - 1 / (12 * R)) / mp.sqrt(R + 1)
            - e1 * abar * (mp.e ** abar + 1 + c0 * (2 * mp.sqrt(R - 1) - 1))
            - e1 * q * abar ** 2 * (1 + c0 * (mp.mpf(2) / 3 * R ** 1.5 + 2 * mp.sqrt(R - 1) - 1)))
    tbar = 2 * e1 * c0 / mp.sqrt(R - 1) - e1 * alow * (2 + c0 * (2 * mp.sqrt(R) - 2 - mp.zeta(mp.mpf(3) / 2) / 12))
    L = R * (R + 1) / N - 1 - Sbar - Ebar
    Theta = tbar + e1 * mp.e ** abar * (R + 1) / N
    Psi = Hbar + 5 / k * Gbar
    return dict(tlow=tlow, lhs=e1 * L, Theta=Theta, Psi=Psi, rhs=Theta * Psi, L=L)


NU = (11 / 5) ** (2 / 3)


def closed_forms_13_4(k):
    """the producer's closed-form bounds in the proof of Theorem 13.4, as functions of eps=k^(-1/3)"""
    w = k ** (1 / 3)
    e = 1 / w
    e1L_low = 0.670857 * w - 2.919271 + 2.074786 * e - 6.147266 * e * e
    tlow_over_eps = 0.225686 - 0.954392 * e - 2.495255 * e ** 2 - 1.509538 * e ** 4 - 0.874338 * e ** 5
    Theta_up = e * (0.853867 - 2.015061 * e + 1.583938 * e * e)
    Psi_up = 1.430651 * w + 6.453334 - 4.803968 * e + 38.196752 * e ** 2 + 33.88 * e ** 3 + 68.084410 * e ** 4
    g = 0.670857 / e - 4.140857 - 0.905452 * e + 3.368872 * e * e
    return dict(e1L_low=e1L_low, tlow_over_eps=tlow_over_eps, Theta_up=Theta_up, Psi_up=Psi_up, g=g)


def true_K(k, R, dps=40):
    """criterion (K) of Prop 3.1 with its true sums (mpmath)"""
    mp.mp.dps = dps
    N = k + R
    x = (mp.mpf(k) / (k + 1)) ** (k - 2)
    gam = lambda m: (1 + mp.mpf(1) / m) ** (m - 2)
    # kappa_m = x^m (m-1)^(m-1)/m!
    Ksum = mp.mpf(0)
    S_R = mp.mpf(0)
    for i in range(0, R):
        term = mp.mpf(1) if i == 0 else mp.e ** (i * mp.log(i * x) - mp.loggamma(i + 1))
        S_R += term            # (i x)^i / i!
    for m in range(1, R + 1):
        Ksum += x * (mp.mpf(1) if m == 1 else mp.e ** ((m - 1) * mp.log((m - 1) * x) - mp.loggamma(m + 1)))  # x^m (m-1)^(m-1)/m!
    kbar = 1 - x - Ksum
    # pi_n ratios: pi_{n+1}/pi_n = x*gamma_n ; e_j = sum_{n=k}^{j+1} (1 - pi_n/pi_{j+1})
    # build log pi relative to pi_k
    lp = {k: mp.mpf(0)}
    for n in range(k, N):
        lp[n + 1] = lp[n] + mp.log(x * gam(n))
    def e_j(j):
        return sum(1 - mp.e ** (lp[n] - lp[j + 1]) for n in range(k, j + 2))
    E = sum(e_j(j) / (j + 1) for j in range(k, N - 1))
    eN1 = e_j(N - 1)
    Som = sum((i - k + 1) * (1 - i / ((i + 1) * x * gam(i))) for i in range(k + 1, N))
    Theta1 = kbar + x * (R + 1) / mp.mpf(N)
    lhs = x * (mp.mpf(R) * (R + 1) / N - 1 - S_R - E)
    rhs = Theta1 * (eN1 + Som)
    return dict(kbar=kbar, lhs=lhs, rhs=rhs, S_R=S_R, E=E, eN1=eN1, Som=Som, Theta1=Theta1, x=x)


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "scan":
        KMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 3000000
        mins = dict(tw=(1e9, None), diff=(1e9, None), sl_L=(1e9, None), sl_t=(1e9, None), sl_Th=(1e9, None), sl_Ps=(1e9, None), g=(1e9, None))
        bad = 0
        ks = list(range(265, KMAX + 1))
        kk = KMAX
        while kk < 10 ** 15:
            kk = int(kk * 1.37) + 1
            ks += [kk, kk + 1]
        # also k near perfect cubes / where (11k/5)^(2/3) is close to an integer
        for m in range(7, 2000, 13):
            ks += [m ** 3 - 1, m ** 3, m ** 3 + 1]
        for k in ks:
            R = rho2(k) + 1
            assert 2 <= R <= k - 1
            assert NU * k ** (2 / 3) < R + 1e-9 and R <= NU * k ** (2 / 3) + 1 + 1e-9
            v = lemma41(k, R)
            c = closed_forms_13_4(k)
            w = k ** (1 / 3)
            if not (v["tlow"] > 0 and v["lhs"] > v["rhs"]):
                bad += 1
                print("FAIL", k, R, v)
            # safe-side checks of the closed forms (they must bound the Lemma 4.1 quantities)
            sl_L = v["lhs"] - c["e1L_low"]
            sl_t = v["tlow"] * w - c["tlow_over_eps"]
            sl_Th = c["Theta_up"] - v["Theta"]
            sl_Ps = c["Psi_up"] - v["Psi"]
            for name, val in (("tw", v["tlow"] * w), ("diff", v["lhs"] - v["rhs"]), ("sl_L", sl_L), ("sl_t", sl_t), ("sl_Th", sl_Th), ("sl_Ps", sl_Ps), ("g", c["g"])):
                if val < mins[name][0]:
                    mins[name] = (val, k)
        print("number of k tested:", len(ks), " failures:", bad)
        for name, (val, k) in mins.items():
            print(f"  min {name:6s} = {val:.6g} at k = {k}")
    elif mode == "mp":
        for k in [265, 266, 267, 300, 504, 505, 728, 729, 1000, 9999, 10 ** 5, 10 ** 6, 10 ** 9, 10 ** 12]:
            R = rho2(k) + 1
            v = lemma41_mp(k, R)
            d = lemma41(k, R)
            c = closed_forms_13_4(k)
            w = mp.mpf(k) ** (mp.mpf(1) / 3)
            print(f"k={k:>14d} R={R:>10d} tlow*w={mp.nstr(v['tlow'] * w, 8)} (dbl {d['tlow'] * float(w):.8f}; closed {c['tlow_over_eps']:.6f})  "
                  f"lhs={mp.nstr(v['lhs'], 9)} rhs={mp.nstr(v['rhs'], 9)} diff={mp.nstr(v['lhs'] - v['rhs'], 8)} (dbl {d['lhs'] - d['rhs']:.8f}; closed g={c['g']:.6f})  "
                  f"Psi={mp.nstr(v['Psi'], 8)} (closed {c['Psi_up']:.6f}) Theta={mp.nstr(v['Theta'], 8)} (closed {c['Theta_up']:.8f}) e^-1L={mp.nstr(v['lhs'], 8)} (closed {c['e1L_low']:.6f})")
    elif mode == "trueK":
        lo = int(sys.argv[2]); hi = int(sys.argv[3]); step = int(sys.argv[4]) if len(sys.argv) > 4 else 1
        print(f"true (K) at R = rho2(k)+1 for k = {lo}, {lo + step}, ..., <= {hi} (step {step})")
        worst = None
        for k in range(lo, hi + 1, step):
            R = rho2(k) + 1
            t = true_K(k, R)
            v = lemma41(k, R)
            ok = t["kbar"] >= 0 and t["lhs"] > t["rhs"]
            ratio = t["lhs"] / t["rhs"]
            if worst is None or ratio < worst[0]:
                worst = (ratio, k)
            # Lemma 4.1 must bound the true quantities
            assert v["tlow"] <= t["kbar"] + 1e-12, (k, "tlow")
            assert v["lhs"] <= t["lhs"] + 1e-9 and v["rhs"] >= t["rhs"] - 1e-9, (k, "bounds")
            if k in (265, 266, 267, 300, 400, 505, 729, 1000, 2000, 3000) or not ok:
                print(f"k={k} R={R}: kbar_R={mp.nstr(t['kbar'], 6)} (Lemma4.1 tlow {v['tlow']:.6f})  (K): lhs={mp.nstr(t['lhs'], 7)} rhs={mp.nstr(t['rhs'], 7)} ratio={mp.nstr(ratio, 5)}  [Lemma 4.1: {v['lhs']:.5f} vs {v['rhs']:.5f}]  {'OK' if ok else 'FAIL'}")
        print("smallest lhs/rhs of the true (K):", mp.nstr(worst[0], 6), "at k =", worst[1])
