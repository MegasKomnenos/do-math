# -*- coding: utf-8 -*-
"""
t12: sanity check (small examples, 40-digit floats / exact rationals for the birthday law) of the new step in
report section 11:
   (N)  Upsilon_r(h) <= (1+1/r)^r * (1 - E_h[J]/(2(k-1))),   h=(k-1)/(k+r),
and of the resulting bound
   k*log(B+C-/(B-C+)) >= M(r,k) + (k/(2(k-1)))*E_h[J] + 1/k,
   M(r,k) = k(1/(2r)-1/(3r^2)) - 5/2 + 2(1-1/k) E_rho[J] - (k/(k-1)) D_r        (published Prop. 8.1 form, exact means)
at a few first-layer positions.  E_h[J], E_rho[J] are exact means of the homogeneous laws (weights T_{r,q} h^{q-1}).
True left side from the chain formulas (5.5),(5.6) of r496399b6 (Borel normalisation).  Not a proof step.
"""
import sys
from mpmath import mp, mpf, exp, log, loggamma
mp.dps = 40

def bor(j):
    j = mpf(j); return exp(-j + (j - 1) * log(j) - loggamma(j + 1))

def Tm(m):  # T_{m,q}, q=1..m, exact-ish in mp:  q m^{m-q-1}/(m-q)!
    return [None] + [exp(log(mpf(q)) + (m - q - 1) * log(mpf(m)) - loggamma(m - q + 1)) for q in range(1, m + 1)]

def hom_mean(r, h):
    T = Tm(r)
    w = [T[q] * mpf(h) ** (q - 1) for q in range(1, r + 1)]
    return sum((q - 1) * w[q - 1] for q in range(1, r + 1)) / sum(w)

def Ups(r, h):
    T1 = Tm(r + 1); T0 = Tm(r)
    return sum(T1[q] * mpf(h) ** (q - 1) for q in range(1, r + 2)) / sum(T0[q] * mpf(h) ** (q - 1) for q in range(1, r + 1))

def s_r(r):
    s = mpf(0); t = mpf(1)
    for j in range(1, r + 1):
        t *= mpf(r - j + 1) / r; s += t
    return s

def true_lhs(k, r):
    N = k + r + 1
    A = [mpf(0)] + [bor(j) for j in range(1, N + 1)]
    def u_list(y, top):
        u = [mpf(1)]
        for m in range(1, top + 1):
            acc = mpf(0)
            for s in range(m): acc += u[s] * A[m - s]
            u.append(mpf(y) / (N - m) * acc)
        return u
    kap = [A[N - m] - sum(A[mm - m] * A[N - mm] for mm in range(m + 1, r + 1)) for m in range(r + 1)]
    def K(y):
        u = u_list(y, r); return sum(kap[m] * u[m] for m in range(r + 1))
    Kv = {y: K(y) for y in (k - 1, k, k + 1, k + 2)}
    Cm = Kv[k + 1] - 2 * Kv[k] + Kv[k - 1]; Cp = Kv[k + 2] - 2 * Kv[k + 1] + Kv[k]
    Lr_k2 = mpf(N - r) / (k + 2) * u_list(k + 2, r)[r]
    Lr1_km1 = mpf(N - r - 1) / (k - 1) * u_list(k - 1, r + 1)[r + 1]
    lB = (k - 2) * log(1 + mpf(1) / k) + log(Lr_k2) - log(Lr1_km1) - 1     # Borel factor e restored
    return k * (lB - log(Cp / Cm))

print("k r u | Ups_r(h)  (1+1/r)^r(1-E_h[J]/(2(k-1)))  (N) holds | true k*log(B+C-/(B-C+))  bound M+extra+1/k  (M, extra) | holds")
for (k, r) in [(8, 4), (21, 10), (46, 14), (76, 18), (100, 25), (265, 42), (265, 47), (265, 54), (400, 62)]:
    h = mpf(k - 1) / (k + r); rho = mpf(k) / (k + r)
    Eh = hom_mean(r, h); Er = hom_mean(r, rho)
    U = Ups(r, h); bound = (1 + mpf(1) / r) ** r * (1 - Eh / (2 * (k - 1)))
    s = s_r(r); D = 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))
    M = k * (mpf(1) / (2 * r) - mpf(1) / (3 * r * r)) - mpf(5) / 2 + 2 * (1 - mpf(1) / k) * Er - mpf(k) / (k - 1) * D
    extra = mpf(k) / (2 * (k - 1)) * Eh
    lhs = true_lhs(k, r)
    print(f"{k} {r} {r**1.5/k:.2f} | {float(U):.6f} {float(bound):.6f} {U <= bound} | {float(lhs):.4f}  {float(M + extra + mpf(1)/k):.4f}  ({float(M):.3f}, {float(extra):.3f}) | {lhs >= M + extra + mpf(1)/k}")
    sys.stdout.flush()
