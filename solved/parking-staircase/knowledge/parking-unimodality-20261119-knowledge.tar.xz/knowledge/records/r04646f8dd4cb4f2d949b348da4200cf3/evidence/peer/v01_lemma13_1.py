# -*- coding: utf-8 -*-
"""Peer check of the producer's Lemma 13.1 (midpoint comparison) and of its proof steps, by brute force
over all compositions (exact rationals).  Independent of the producer's scripts.

For m, y, N (N > m-1) and lambda_s = y/(N-s):
  (a) identity (13.2): mean position of the deleted cut point under the erase rule;
  (b) erase rule maps pi_{q+1} to pi_q  (published Thm 4.3 direction) -- recheck by brute force;
  (c) identity (13.3): E_{pi_q} W = (1/y) E_{pi_{q+1}}[ W (N - sbar) ];
  (d) inequality (13.1): E_{pi_{q+1}} W >= h E_{pi_q} W, h = y/(N - m/2);
  (e) likelihood-ratio monotonicity P_lambda(Q=q)/P_h(Q=q) nondecreasing;
  (f) the same with a general increasing lambda whose reciprocal is concave (remark (나)) and a
      NON-example: lambda increasing but 1/lambda convex -> does the midpoint comparison fail?
"""
from fractions import Fraction as Fr
from itertools import combinations
from math import factorial
import random, sys


def a(j):
    return Fr(j ** (j - 1), factorial(j))


def compositions(m):
    for q1 in range(0, m):
        for S in combinations(range(1, m), q1):
            yield S


def parts(S, m):
    pts = (0,) + tuple(S) + (m,)
    return [pts[i + 1] - pts[i] for i in range(len(pts) - 1)]


def cayley(S, m):
    w = Fr(1)
    for t in parts(S, m):
        w *= a(t)
    return w


def erase_distribution(S, m):
    """distribution of the deleted cut point for a composition with cut set S (|S|=q>=1):
    cell c in {1..m}, index I in {1..q} uniform independent; delete the first cut point met going from the
    cell towards s_I."""
    q = len(S)
    dist = {}
    for c in range(1, m + 1):
        # cell c is the interval [c-1,c]; it lies in part p (1-based) iff s_{p-1} < c <= s_p
        pts = (0,) + tuple(S) + (m,)
        p = next(i for i in range(1, len(pts)) if pts[i - 1] < c <= pts[i])
        for I in range(1, q + 1):
            sI = S[I - 1]
            if sI >= c:      # go right: first cut point >= c
                tgt = pts[p]
            else:            # go left
                tgt = pts[p - 1]
            assert tgt in S
            dist[tgt] = dist.get(tgt, Fr(0)) + Fr(1, q * m)
    return dist


def check(m, y, N, lam=None, verbose=False):
    if lam is None:
        lam = lambda s: Fr(y) / (N - s)
    byq = {}
    for S in compositions(m):
        byq.setdefault(len(S) + 1, []).append(S)
    T = {q: sum(cayley(S, m) for S in L) for q, L in byq.items()}
    W = lambda S: __import__("functools").reduce(lambda u, s: u * lam(s), S, Fr(1))
    EW = {q: sum(cayley(S, m) * W(S) for S in L) / T[q] for q, L in byq.items()}
    ok = True
    res = []
    for q in range(1, m):
        # (b) push-forward of pi_{q+1}
        push = {}
        Esbar_W = Fr(0)
        for S in byq[q + 1]:
            w = cayley(S, m) / T[q + 1]
            dist = erase_distribution(S, m)
            sbar = sum(s * pr for s, pr in dist.items())
            # (a) formula (13.2)
            t = parts(S, m)
            form = Fr(m, 2) + Fr(1, 2 * q * m) * sum((q + 2 - 2 * p) * t[p - 1] ** 2 for p in range(1, q + 2))
            assert sbar == form, (S, sbar, form)
            Esbar_W += w * W(S) * sbar
            for s, pr in dist.items():
                S2 = tuple(x for x in S if x != s)
                push[S2] = push.get(S2, Fr(0)) + w * pr
        for S2 in byq[q]:
            assert push.get(S2, 0) == cayley(S2, m) / T[q], "erase rule does not map pi_{q+1} to pi_q"
        # (c) identity (13.3) -- only valid when 1/lambda is affine, lambda_s = y/(N-s)
        if lam.__name__ == "<lambda>" and getattr(lam, "affine", True):
            lhs = EW[q]
            rhs = (N * EW[q + 1] - Esbar_W) / y
            assert lhs == rhs, ("13.3", lhs, rhs)
        res.append((q, EW[q + 1] / EW[q]))
    return res, EW, T


if __name__ == "__main__":
    random.seed(20261120)
    cases = []
    for m in range(2, 10):
        for _ in range(4):
            N = m - 1 + Fr(random.randint(1, 400), random.randint(1, 20))
            y = Fr(random.randint(1, 300), random.randint(1, 7))
            cases.append((m, y, N))
    # extreme cases: N just above m-1 (lambda very steep), N huge (flat), integer parking values
    cases += [(8, Fr(5), Fr(701, 100)), (8, Fr(1, 1000), Fr(7001, 1000)), (9, Fr(50), Fr(10 ** 6)),
              (9, Fr(12), Fr(22)), (10, Fr(30), Fr(41)), (10, Fr(3), Fr(91, 10))]
    worst = None
    for (m, y, N) in cases:
        res, EW, T = check(m, y, N)
        h = y / (N - Fr(m, 2))
        hmin = y / (N - 1)
        hmax = y / (N - m + 1)
        for q, ratio in res:
            assert ratio >= h, ("FAIL (13.1)", m, y, N, q, ratio, h)
            assert hmin <= ratio <= hmax
            slack = float(ratio / h)
            if worst is None or slack < worst[0]:
                worst = (slack, m, y, N, q)
        # effective c: ratio = y/(N - shat)  ->  shat = N - y/ratio ; compare with m/2
        shat = [float(N - y / ratio) for q, ratio in res]
        print(f"m={m:2d} y={float(y):9.4f} N={float(N):12.4f}  h_mid={float(h):.5f}  eff.ratios/h: "
              + " ".join(f"{float(r / h):.4f}" for q, r in res) + "   shat-m/2: " + " ".join(f"{s - m / 2:+.3f}" for s in shat))
    print("all cases pass; smallest ratio/h =", worst)

    # (f) general increasing lambda. (i) 1/lambda concave decreasing: expect comparison with h=lambda(m/2)... test.
    #     (ii) 1/lambda convex decreasing (e.g. lambda_s = exp(c s)): the midpoint comparison may fail.
    print("\ngeneral profiles (comparison of E_{pi_{q+1}}W / E_{pi_q}W with lambda at the midpoint):")
    for name, lamf, mid in [
        ("1/lam = 10 - s^2/20 (concave)", lambda s: 1 / (Fr(10) - Fr(s * s, 20)), lambda m: 1 / (Fr(10) - Fr(m * m, 80))),
        ("1/lam = 1/(1+s) (convex, lam=1+s)", lambda s: Fr(1 + s), lambda m: Fr(2 + m, 2)),
        ("lam = 2^s (1/lam convex)", lambda s: Fr(2) ** s, None),
    ]:
        for m in (6, 8):
            byq = {}
            for S in compositions(m):
                byq.setdefault(len(S) + 1, []).append(S)
            T = {q: sum(cayley(S, m) for S in L) for q, L in byq.items()}
            import functools
            Wf = lambda S: functools.reduce(lambda u, s: u * lamf(s), S, Fr(1))
            EW = {q: sum(cayley(S, m) * Wf(S) for S in L) / T[q] for q, L in byq.items()}
            ratios = [EW[q + 1] / EW[q] for q in range(1, m)]
            if mid is not None:
                hm = mid(m)
            else:
                hm = Fr(2) ** (m // 2) if m % 2 == 0 else None
            print(f"  {name:36s} m={m}: ratios/lam(mid) = " + " ".join(f"{float(r / hm):.4f}" for r in ratios))
