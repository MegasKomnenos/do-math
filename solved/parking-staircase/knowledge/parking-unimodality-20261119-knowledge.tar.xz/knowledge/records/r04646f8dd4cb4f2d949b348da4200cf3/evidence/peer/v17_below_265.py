# -*- coding: utf-8 -*-
"""Peer check for the condition-5 assessment (exposition 8.4): where does the crossing bound of Theorem 5.1 stop
   below k = 265 -- in the criterion (K) of ra98af63d (Prop. 3.1) itself, or in the explicit bounds of its Lemma 4.1?
   For a few columns k < 265 (and k = 265 for reference) evaluate, at R = rho(k)+1 (rho(k) = floor((11k/5)^(2/3))):
     - the true quantities of (K): kbar_R, lhs, rhs   (true sums, 40 digits);
     - Lemma 4.1's explicit t_low, lhs, rhs.
   Not a proof step and not a range scan: eight sample columns.  Uses v03_crossing.py (same folder)."""
import mpmath as mp
from v03_crossing import rho2, lemma41, true_K

print("k, R=rho(k)+1 | true (K): kbar_R, lhs, rhs, lhs/rhs | Lemma 4.1: t_low, lhs, rhs")
for k in (40, 60, 80, 100, 150, 200, 240, 264, 265):
    R = rho2(k) + 1
    t = true_K(k, R)
    v = lemma41(k, R)
    print(f"k={k:4d} R={R:3d} | kbar={mp.nstr(t['kbar'], 5):>10s} lhs={mp.nstr(t['lhs'], 6):>9s} rhs={mp.nstr(t['rhs'], 6):>9s} "
          f"ratio={mp.nstr(t['lhs'] / t['rhs'], 4):>6s} | t_low={v['tlow']:+.5f} lhs={v['lhs']:.4f} rhs={v['rhs']:.4f}")
