# Independent brute-force test of Lemma 13.1 (midpoint comparison), exact rationals.
# Written from the definitions in appendix A.1 / A.3 only.
from fractions import Fraction as F
from math import factorial
from itertools import combinations
import sys, time

t0 = time.time()

def a(j):
    return F(j ** (j - 1), factorial(j))

def parts_of(S, m):
    pts = [0] + sorted(S) + [m]
    return [pts[i + 1] - pts[i] for i in range(len(pts) - 1)]

def base_weight(S, m):
    w = F(1)
    for t in parts_of(S, m):
        w *= a(t)
    return w

def all_cutsets(m):
    for size in range(0, m):
        for S in combinations(range(1, m), size):
            yield S

viol = 0
ntests = 0
min_slack = None

def test_statement(m, N, y, hfun=None, quiet=True):
    """returns list of ratios P_lambda(Q=q)/P_h(Q=q) (unnormalised, q=1..m)"""
    lam = {s: y / (N - s) for s in range(1, m)}
    h = y / (N - F(m, 2)) if hfun is None else hfun(m, N, y)
    A = [F(0)] * (m + 1)
    B = [F(0)] * (m + 1)
    for S in all_cutsets(m):
        bw = base_weight(S, m)
        w = bw
        for s in S:
            w *= lam[s]
        q = len(S) + 1
        A[q] += w
        B[q] += bw * h ** (q - 1)
    ZA = sum(A[1:])
    ZB = sum(B[1:])
    ratios = [(A[q] / ZA) / (B[q] / ZB) for q in range(1, m + 1)]
    return ratios

cases = 0
bad = []
tight = []
for m in range(2, 10):
    Ns = []
    for d in [F(1, 10 ** 9), F(1, 10 ** 6), F(1, 1000), F(1, 10), F(1, 3), F(1, 2), F(9, 10), 1, F(3, 2), F(22, 7),
              10, F(1001, 10), 10 ** 3, 10 ** 6, 10 ** 12]:
        Ns.append(F(m - 1) + d)
    ys = [F(1, 10 ** 9), F(1, 1000), F(1, 3), F(1), F(5, 2), F(10), F(10 ** 6)]
    for N in Ns:
        for y in ys:
            r = test_statement(m, N, y)
            cases += 1
            for q in range(len(r) - 1):
                if r[q + 1] < r[q]:
                    bad.append((m, N, y, q + 1, r[q], r[q + 1]))
                if r[q + 1] == r[q]:
                    tight.append((m, N, y, q + 1))
print("statement: cases tested", cases, "violations", len(bad))
for b in bad[:10]:
    print("  VIOLATION", b)
# where is equality attained?
eqsteps = sorted(set((m, q) for (m, N, y, q) in tight))
print("steps with exact equality r_{q+1}=r_q (m,q):", eqsteps)

# sanity: the test detects failure if h is taken slightly larger than the midpoint factor
def hbig(m, N, y):
    return y / (N - F(m, 2) - F(1, 100))
r = test_statement(6, F(6) + F(1, 3), F(2), hfun=hbig)
print("with h slightly too large (m=6): monotone?", all(r[i + 1] >= r[i] for i in range(len(r) - 1)),
      [float(x) for x in r])
# and with the minimal factor (published Lemma 4.5(b)) it must hold as well
def hmin(m, N, y):
    return y / (N - 1)
r = test_statement(6, F(6) + F(1, 3), F(2), hfun=hmin)
print("with h = min factor (m=6): monotone?", all(r[i + 1] >= r[i] for i in range(len(r) - 1)))
# and with the factor at s = m/2 + 1/2 (too large) on several cases
cnt = 0
for m in range(2, 9):
    r = test_statement(m, F(m) + F(1, 2), F(1), hfun=lambda m, N, y: y / (N - F(m + 1, 2)))
    if not all(r[i + 1] >= r[i] for i in range(len(r) - 1)):
        cnt += 1
print("h at (m+1)/2: number of m in 2..8 for which monotonicity FAILS:", cnt, "(expected: all 7, top step is an equality for m/2)")

# ---------------------------------------------------------------------------
# step checks: Theorem 4.3 (deletion rule pushes pi_{q+1} to pi_q), (13.2), (13.3), (iii), (iv)
# ---------------------------------------------------------------------------
def deleted_cut(S, m, c, I):
    """S sorted tuple of cuts (len q), cell c in 1..m (interval [c-1,c]), I in 1..q.
    Delete the first cut met when going from the cell toward the chosen cut s_I."""
    target = S[I - 1]
    if target >= c:          # chosen cut is to the right of the cell (position >= c)
        # first cut at position >= c
        for s in S:
            if s >= c:
                return s
    else:                    # chosen cut is to the left: position <= c-1
        for s in reversed(S):
            if s <= c - 1:
                return s
    raise RuntimeError

errs = {"thm43": 0, "13.2": 0, "13.3": 0, "iii": 0, "iv": 0, "13.1": 0}
for m in range(2, 10):
    # masses by q
    comps = {q: [] for q in range(1, m + 1)}
    for S in all_cutsets(m):
        comps[len(S) + 1].append(S)
    T = {q: sum(base_weight(S, m) for S in comps[q]) for q in comps}
    # check T_{m,q} closed form (A.2.1)
    for q in range(1, m + 1):
        assert T[q] == F(q, m) * F(m ** (m - q), factorial(m - q)), (m, q)
    for q in range(1, m):
        # push-forward of pi_{q+1}
        push = {}
        for S in comps[q + 1]:
            bw = base_weight(S, m) / T[q + 1]
            for c in range(1, m + 1):
                for I in range(1, q + 1):
                    sd = deleted_cut(S, m, c, I)
                    S2 = tuple(s for s in S if s != sd)
                    push[S2] = push.get(S2, F(0)) + bw / (q * m)
        for S2 in comps[q]:
            if push.get(S2, F(0)) != base_weight(S2, m) / T[q]:
                errs["thm43"] += 1
        # (13.2)
        sbar = {}
        for S in comps[q + 1]:
            tot = F(0)
            for c in range(1, m + 1):
                for I in range(1, q + 1):
                    tot += deleted_cut(S, m, c, I)
            sb = tot / (q * m)
            t = parts_of(S, m)
            formula = F(m, 2) + F(1, 2 * q * m) * sum((q + 2 - 2 * p) * t[p - 1] ** 2 for p in range(1, q + 2))
            if sb != formula:
                errs["13.2"] += 1
            sbar[S] = sb
        # (13.3), (iii), (iv), (13.1) for a few (N,y)
        for N in [F(m - 1) + F(1, 1000), F(m) + F(1, 2), F(3 * m), F(2 * m) + F(2, 7)]:
            for y in [F(1, 2), F(3)]:
                lam = {s: y / (N - s) for s in range(1, m)}
                def W(S):
                    w = F(1)
                    for s in S:
                        w *= lam[s]
                    return w
                EW_q = sum(base_weight(S, m) * W(S) for S in comps[q]) / T[q]
                EW_q1 = sum(base_weight(S, m) * W(S) for S in comps[q + 1]) / T[q + 1]
                EWs = sum(base_weight(S, m) * W(S) * (sbar[S] - F(m, 2)) for S in comps[q + 1]) / T[q + 1]
                rhs = (N - F(m, 2)) / y * EW_q1 - EWs / y
                if EW_q != rhs:
                    errs["13.3"] += 1
                if EWs < 0:
                    errs["iv"] += 1
                h = y / (N - F(m, 2))
                if EW_q1 < h * EW_q:
                    errs["13.1"] += 1
                # (iii): E[W (t_p^2 - t_p'^2)] >= 0 for p<p'
                for p in range(1, q + 2):
                    for p2 in range(p + 1, q + 2):
                        val = F(0)
                        for S in comps[q + 1]:
                            t = parts_of(S, m)
                            val += base_weight(S, m) * W(S) * (t[p - 1] ** 2 - t[p2 - 1] ** 2)
                        if val < 0:
                            errs["iii"] += 1
print("step checks (number of failures):", errs)
print("time %.1fs" % (time.time() - t0))
