# -*- coding: utf-8 -*-
"""Peer check for the remark in exposition 8.4 (another route to the crossing bound):
   the published row-wise lower bound  L(k,N) <= C_-/B_-  of r69068ac5 (Theorem E', claim p-curvature-lower-bound)
   evaluated at the END OF THE STRIP, N = k + R + 1 with R = rho(k)+1, for a few columns, next to the true ratio
   C_-/B_- (exact rationals from pf.py).  L is computed by the published record's own script e01_Lbound.py
   (double precision; its path is argument 1).  Observation only: seven columns, not a proof step."""
import sys, importlib.util, os
import numpy as np
P = sys.argv[1] if len(sys.argv) > 1 else ('C:/math/.skill-workspace/parking-unimodality-20261119/knowledge/records/'
                                          'r69068ac5755e47bf83611f535d8af02c/evidence/peer/e01_Lbound.py')
spec = importlib.util.spec_from_file_location('e01_Lbound', P)
e01 = importlib.util.module_from_spec(spec); spec.loader.exec_module(e01)
from pf import first_layer_exact


def rho(k):
    r = int((11 * k / 5) ** (2 / 3))
    while 25 * (r + 1) ** 3 <= 121 * k * k: r += 1
    while 25 * r ** 3 > 121 * k * k: r -= 1
    return r


ks = [200, 265, 300, 400, 537, 1000, 3000]
consts = e01.kernel_consts_direct(max(rho(k) for k in ks) + 4)
print("k, R = rho(k)+1 | L(k, k+R+1) (published explicit lower bound, version with the kappa-term) | true C_-/B_- at (k+R, k)")
for k in ks:
    R = rho(k) + 1
    L1 = e01.L_bound(k, k + R + 1, 1, consts)
    true = None
    if k <= 1000:
        f = first_layer_exact(k + R, k)
        true = float(f['Cm'] / f['Bm'])
    print(f"k={k:5d} R={R:4d}: L = {L1:.4f}   C_-/B_- = {'%.4f' % true if true else '   -  '}")
