# -*- coding: utf-8 -*-
"""Peer bookkeeping for exposition 8.4 (standing condition 5): on how many claims does a claim stand?

 Reads the `dependencies` fields of
   - this candidate's record.json (path: argument 1, default ../../record.json relative to this file), and
   - every published record  <records>/<id>/record.json  (path: argument 2, default the instance's
     knowledge/records folder at research revision 30),
 and follows them to the end (transitive closure).  A dependency that points to a claim id that does not exist
 in the published record is reported as MISSING and not followed.

 Output: for the main claims of this candidate, the number of own claims and of published claims (by record)
 in the closure; for some published claims that the exposition compares with, the size of their closure and
 how many of its claims are not already in the closure of this candidate's c-precrossing-columns.

 This is a count over declared dependencies, not a proof step and not a judgement of how hard the claims are."""
import json, io, os, sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
HERE = os.path.dirname(os.path.abspath(__file__))
REC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..', '..', 'record.json')
K = sys.argv[2] if len(sys.argv) > 2 else 'C:/math/.skill-workspace/parking-unimodality-20261119/knowledge/records'

recs = {}
for d in sorted(os.listdir(K)):
    p = os.path.join(K, d, 'record.json')
    if os.path.exists(p):
        recs[d] = json.load(open(p, encoding='utf-8'))
me = json.load(open(REC, encoding='utf-8'))
mine = {c['id']: c for c in me['claims']}
pub = {(rid, c['id']): c for rid, r in recs.items() for c in r['claims']}


def full(rid):
    if rid in recs:
        return rid
    c = [r for r in recs if r.startswith(rid)]
    assert len(c) == 1, (rid, c)
    return c[0]


def deps_of(key):
    rid, cid = key
    c = mine[cid] if rid == 'self' else pub[(rid, cid)]
    out = []
    for d in c.get('dependencies', []) or []:
        out.append((rid, d['claim']) if d['record'] == 'self' else (full(d['record']), d['claim']))
    return out


def closure(start):
    seen, st = set(), [start]
    while st:
        k = st.pop()
        if k in seen:
            continue
        if k[0] != 'self' and k not in pub:
            print('  MISSING', k)
            continue
        seen.add(k)
        st.extend(deps_of(k))
    return seen


print('published records read:', len(recs), '| published claims:', len(pub))
print()
base = None
for target in ('c-precrossing-columns', 'c-mono', 'c-precrossing', 'p-xdown', 'p-sr-from-mono265'):
    cl = closure(('self', target))
    own = sorted(k[1] for k in cl if k[0] == 'self')
    ext = sorted(k for k in cl if k[0] != 'self')
    byrec = {}
    for r, c in ext:
        byrec.setdefault(r, []).append(c)
    print(f'== {target}: own claims {len(own)}, published claims {len(ext)} in {len(byrec)} records')
    print('   own:', ', '.join(own))
    for r in sorted(byrec):
        print(f'   {r[:9]} ({len(byrec[r])}):', ', '.join(byrec[r]))
    if target == 'c-precrossing-columns':
        base = set(ext)
    print()

print('published claims compared with in the exposition (closure includes the claim itself):')
for rid, cid in (('rc693abe9', 'c-ci-node'), ('rc693abe9', 'c-ci-537'), ('r69068ac5', 'c-computation-free-region'),
                 ('r69068ac5', 'p-single-crossing'), ('r69068ac5', 'p-mono-right-half'), ('r496399b6', 'c-thm-5-9'),
                 ('ra98af63d', 'c-entry-theorem')):
    cl = closure((full(rid), cid))
    nrec = len({k[0] for k in cl})
    print(f'   {rid}/{cid}: {len(cl)} claims in {nrec} records; not in the closure of c-precrossing-columns: {len(cl - base)}')
