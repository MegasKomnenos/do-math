# -*- coding: utf-8 -*-
"""Peer (after resumption): the upper side of the midpoint lemma made explicit.

For compositions of m with q+1 parts (pi_{q+1} ~ prod a_part), threshold profile lambda_s = y/(N-s):
   shat_{q+1} = mean, under pi_{q+1} reweighted by W = prod_{s in S} lambda_s, of the mean erased position sbar.
Claims checked here:
 (c) kappa_3(q) := E_pi[t_1^3 - t_1^2 t_2] = (3M/(q+1)) * sum_{i=0}^{M-1} C(i+3,3) prod_{j=1}^{i} (1 - (q+1+j)/m),  M = m-q-1;
     kappa_3(q) <= m^3/(q+1);
 (b) 0 <= shat_{q+1} - m/2 <= ((N-1)/(N-m+1))^q * (q+1)(q+2) kappa_3(q) / (12 m (N-m+1));
 (d) N (shat_{q+1} - m/2) -> (q+1)(q+2) kappa_3(q)/(12 m)  as N -> infinity.
Part A: exact rationals, brute force over all compositions, m <= 10.
Part B: (m,N) = (57,323) (the first-layer site (r,k)=(57,265)) by the coefficient recursion (60-digit floats):
        shat_{q+1} = N - (T_{m,q+1}/T_{m,q}) p_q/p_{q+1},  p_q = [y^{q-1}] Lambda_m(y;N).
Part C: the first-order profile  tau*I_3(tau)/24,  I_3(tau) = int_0^oo x^3 exp(-tau x - x^2/2) dx.
"""
from fractions import Fraction as Fr
from itertools import combinations
from math import factorial, comb
import mpmath as mp


def a(j):
    return Fr(j ** (j - 1), factorial(j))


def kappa3_closed(m, q):
    M = m - q - 1
    tot = Fr(0)
    prod = Fr(1)
    for i in range(0, M):
        if i >= 1:
            prod *= Fr(M - i, m)          # prod_{j=1}^{i} (M-j)/m = prod (1-(q+1+j)/m)
        tot += comb(i + 3, 3) * prod
    return Fr(3 * M, q + 1) * tot


def brute(m, q, N):
    """returns (shat - m/2, kappa3) for q cut points; N a Fraction"""
    numW = Fr(0); denW = Fr(0); k3 = Fr(0); Z = Fr(0)
    for S in combinations(range(1, m), q):
        pts = (0,) + S + (m,)
        t = [pts[i + 1] - pts[i] for i in range(q + 1)]
        w = Fr(1)
        for x in t:
            w *= a(x)
        W = Fr(1)
        for s in S:
            W /= (N - s)
        sbar = Fr(m, 2) + Fr(1, 2 * q * m) * sum((q + 2 - 2 * p) * t[p - 1] ** 2 for p in range(1, q + 2))
        numW += w * W * (sbar - Fr(m, 2)); denW += w * W
        k3 += w * (t[0] ** 3 - t[0] ** 2 * t[1]); Z += w
    return numW / denW, k3 / Z


def partA():
    worst = None
    cases = 0
    for m in range(3, 11):
        for q in range(1, m):
            k3c = kappa3_closed(m, q)
            for N in (Fr(m) - Fr(1, 2), Fr(m), Fr(3 * m, 2), Fr(2 * m), Fr(5 * m), Fr(40 * m), Fr(10 ** 6)):
                sh, k3 = brute(m, q, N)
                assert k3 == k3c, (m, q, k3, k3c)
                assert k3 <= Fr(m ** 3, q + 1)
                bound = (Fr(N - 1) / (N - m + 1)) ** q * Fr((q + 1) * (q + 2)) * k3 / (12 * m * (N - m + 1))
                assert 0 <= sh <= bound, (m, q, N, float(sh), float(bound))
                cases += 1
                if N == 10 ** 6:
                    lim = Fr((q + 1) * (q + 2)) * k3 / (12 * m)
                    rel = abs(float(N * sh / lim) - 1) if lim != 0 else 0.0
                    worst = max(worst or 0.0, rel)
    print(f"Part A: {cases} cases (m<=10, all q, 7 values of N): closed form of kappa_3, kappa_3 <= m^3/(q+1), "
          f"two-sided bound hold exactly; at N=10^6, |N(shat-m/2)/limit - 1| <= {worst:.2e}")


def partB(m=57, N=323):
    mp.mp.dps = 60
    aa = [mp.mpf(0)] + [mp.mpf(j) ** (j - 1) / mp.factorial(j) for j in range(1, m + 1)]
    c = [None] * (m + 1)
    for mm in range(1, m + 1):
        row = [aa[mm]] + [mp.mpf(0)] * (mm - 1)
        for j in range(1, mm):
            row[j] = mp.fsum(c[s][j - 1] * aa[mm - s] / (N - s) for s in range(j, mm))
        c[mm] = row
    p = c[m]                                   # p[q-1] = [y^{q-1}] Lambda_m
    T = lambda q: mp.mpf(q) / m * mp.mpf(m) ** (m - q) / mp.factorial(m - q)
    print(f"Part B: (m,N)=({m},{N}):  q | (shat_(q+1)-m/2)/m | first-order value C_q/N | conjectured bound C_q(N-m/2)/((N-1)(N-m+1)) | proved bound (tilt factor) | same with kappa_3<=m^3/(q+1)   [all divided by m]")
    for q in list(range(1, 13)) + [15, 20, 30, 40, 56]:
        sh = N - T(q + 1) / T(q) * p[q - 1] / p[q]
        k3 = kappa3_closed(m, q); k3 = mp.mpf(k3.numerator) / k3.denominator
        first = (q + 1) * (q + 2) * k3 / (12 * m * N)
        tilt = (mp.mpf(N - 1) / (N - m + 1)) ** q
        b1 = tilt * (q + 1) * (q + 2) * k3 / (12 * m * (N - m + 1))
        b2 = tilt * (q + 2) * mp.mpf(m) ** 2 / (12 * (N - m + 1))
        tol = mp.mpf(10) ** -40
        assert -tol <= sh - mp.mpf(m) / 2 <= b1 + tol and b1 <= b2 * (1 + tol) + tol
        conj = k3 * (q + 1) * (q + 2) / (12 * m) * (N - mp.mpf(m) / 2) / ((N - 1) * (N - m + 1))
        assert sh - mp.mpf(m) / 2 <= conj + tol
        print(f"   {q:3d} | {mp.nstr((sh - mp.mpf(m) / 2) / m, 5):>9s} | {mp.nstr(first / m, 5):>9s} | {mp.nstr(conj / m, 5):>9s} | {mp.nstr(b1 / m, 5):>9s} | {mp.nstr(b2 / m, 5):>9s}")


def partC():
    mp.mp.dps = 30
    I3 = lambda tau: mp.quad(lambda x: x ** 3 * mp.e ** (-tau * x - x * x / 2), [0, mp.inf])
    g = lambda tau: tau * I3(tau) / 24
    tstar = mp.findroot(lambda t: mp.diff(g, t), 0.7)
    print("Part C: I_3(0) =", mp.nstr(I3(0), 8), "; tau*I_3(tau)/24 at tau = 0.25, 0.5, 0.75, 1, 1.5, 2, 3:",
          ", ".join(mp.nstr(g(t), 5) for t in (0.25, 0.5, 0.75, 1, 1.5, 2, 3)),
          "; maximum", mp.nstr(g(tstar), 6), "at tau =", mp.nstr(tstar, 5))


if __name__ == "__main__":
    partA()
    partB()
    partC()


def partD():
    """exact pair formula:  shat - m/2 = sum_{p<p'} (q+2-2p)/(q m) * E_W[(t_p+t_p') * j * theta_pp'],
       j=(t_p-t_p')/2, theta = (W(S)-W(S#))/(W(S)+W(S#)) = tanh(sum_l artanh(j/B_l)), B_l = N - s_l + j (l=p..p'-1)."""
    cases = 0
    for m in range(3, 10):
        for q in range(1, m):
            for N in (Fr(m) - Fr(1, 2), Fr(3 * m, 2), Fr(7 * m)):
                num = Fr(0); den = Fr(0); numW = Fr(0)
                for S in combinations(range(1, m), q):
                    pts = (0,) + S + (m,)
                    t = [pts[i + 1] - pts[i] for i in range(q + 1)]
                    w = Fr(1)
                    for x in t:
                        w *= a(x)
                    W = Fr(1)
                    for s in S:
                        W /= (N - s)
                    tot = Fr(0)
                    for p in range(1, q + 2):
                        pp = q + 2 - p
                        if p >= pp:
                            break
                        jj = Fr(t[p - 1] - t[pp - 1], 2)
                        # theta via the product form  prod (B_l + j)/(B_l - j)
                        ratio = Fr(1)
                        for l in range(p, pp):          # cut index l = p..p'-1  (1-based), position S[l-1]
                            B = N - S[l - 1] + jj
                            ratio *= (B + jj) / (B - jj)
                        theta = (ratio - 1) / (ratio + 1)
                        tot += Fr(q + 2 - 2 * p, q * m) * (t[p - 1] + t[pp - 1]) * jj * theta
                        assert jj * theta >= 0
                    num += w * W * tot; den += w * W
                    sbar = Fr(m, 2) + Fr(1, 2 * q * m) * sum((q + 2 - 2 * p) * t[p - 1] ** 2 for p in range(1, q + 2))
                    numW += w * W * (sbar - Fr(m, 2))
                assert num == numW, (m, q, N)
                cases += 1
    print(f"Part D: exact pair formula (tanh form) verified in {cases} cases (m<=9), exact rationals")


if __name__ == "__main__":
    partD()
