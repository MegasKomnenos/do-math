# -*- coding: utf-8 -*-
"""Peer check (exact rationals, independent code) of the producer's sections 3-4 at a few first-layer sites:
   rho_2=1 <= rho_3 <= ... <= rho_r and C_+/C_- <= rho_r (Prop 3.2); Lemma 3.1 (TP2 of delta_q);
   (F3): Lambda_{r+1}(y) = Lambda_r(y) (y/(N-r) + E_y alpha(gamma));  Prop 4.2's two bounds;  Cor 4.3;
   Brenti's criterion (Lemma 4.1) on the coefficient sequences."""
from fractions import Fraction as Fr
from itertools import combinations
from math import factorial, log
from pf import a_frac as a, first_layer_exact

def poly_mul_lin(p, c):      # p(y) * (c*y)  -> shift
    return [Fr(0)] + [c * x for x in p]
def Lambda_polys(mmax, N):
    """coefficient lists of Lambda_m(y;N) in y, m=1..mmax"""
    L = [None] * (mmax + 1)
    for m in range(1, mmax + 1):
        p = [a(m)]
        for s in range(1, m):
            q = poly_mul_lin(L[s], Fr(1, N - s) * a(m - s))
            p = [ (p[i] if i < len(p) else 0) + (q[i] if i < len(q) else 0) for i in range(max(len(p), len(q)))]
        L[m] = p
    return L
def ev(p, y): return sum(c * Fr(y) ** i for i, c in enumerate(p))
def d2(p, x): return ev(p, x + 1) - 2 * ev(p, x) + ev(p, x - 1)
def delta(q, x): return Fr(x + 1) ** q - 2 * Fr(x) ** q + Fr(x - 1) ** q

# Lemma 3.1
for x in range(1, 12):
    for q in range(2, 12):
        for qq in range(q + 1, 13):
            assert delta(q, x + 1) * delta(qq, x) <= delta(q, x) * delta(qq, x + 1)
print("Lemma 3.1 (integer x<=11, q<=12): ok")
for (n, k) in [(20, 13), (30, 21), (45, 33), (60, 46)]:
    N = n + 1; r = n - k
    L = Lambda_polys(r + 1, N)
    # u_m(y) = y/(N-m) * Lambda_m(y)
    u = {m: poly_mul_lin(L[m], Fr(1, N - m)) for m in range(1, r + 1)}
    rho = [d2(u[m], k + 1) / d2(u[m], k) for m in range(2, r + 1)]
    assert rho[0] == 1 and all(rho[i] <= rho[i + 1] for i in range(len(rho) - 1))
    f = first_layer_exact(n, k)
    assert 1 <= f["Cp"] / f["Cm"] <= rho[-1]
    # coefficient array property (3.1) and log-concavity of coefficients (Cor D of r3dc4f6e9, used as published)
    for m in range(2, r):
        cm = u[m]; cm1 = u[m + 1]
        for q in range(1, m + 1):
            for qq in range(q + 1, m + 2):
                lhs = cm[q] * cm1[qq]; rhs = (cm[qq] if qq < len(cm) else 0) * cm1[q]
                assert lhs >= rhs
    # (F3) at y = k-1
    y = k - 1
    num = Fr(0); den = Fr(0)
    for q1 in range(0, r):
        for S in combinations(range(1, r), q1):
            pts = (0,) + S + (r,)
            wgt = Fr(1)
            for i in range(len(pts) - 1): wgt *= a(pts[i + 1] - pts[i])
            for s in S: wgt *= Fr(y, N - s)
            g = r - pts[-2]
            num += wgt * a(g + 1) / a(g); den += wgt
        if r > 16: break
    if r <= 16:
        assert den == ev(L[r], y) and ev(L[r + 1], y) == den * (Fr(y, N - r) + num / den)
    # Prop 4.2: D(y) = y P'''/P'' with P = y Lambda_r ; bounds
    P = [Fr(0)] + L[r]
    def Dfun(yv):
        P2 = sum(i * (i - 1) * c * Fr(yv) ** (i - 2) for i, c in enumerate(P))
        P3 = sum(i * (i - 1) * (i - 2) * c * Fr(yv) ** (i - 3) for i, c in enumerate(P))
        return yv * P3 / P2
    Dk2 = Dfun(k + 2)
    logrho = log(rho[-1]); DD = float(Dk2) * log(k / (k - 1))
    logCC = log(f["Cp"] / f["Cm"]); logBB = log(f["Bp"] / f["Bm"])
    # Cor 4.3: D(y) <= 1.5 E Q(Q-1)/E Q under P_y
    EQ = sum(i * c * Fr(k + 2) ** i for i, c in enumerate(P)); EQQ = sum(i * (i - 1) * c * Fr(k + 2) ** i for i, c in enumerate(P))
    assert Dk2 <= Fr(3, 2) * EQQ / EQ
    # Brenti: binomial moments of the (log-concave) coefficient sequence of Lambda_r are log-concave
    from math import comb
    b = [sum(comb(q, j) * c for q, c in enumerate(L[r])) for j in range(len(L[r]) + 1)]
    assert all(b[j] ** 2 >= b[j - 1] * b[j + 1] for j in range(1, len(b) - 1))
    assert all(L[r][j] ** 2 >= L[r][j - 1] * L[r][j + 1] for j in range(1, len(L[r]) - 1))
    print(f"({n},{k}): rho_m nondecreasing, C+/C- = {float(f['Cp']/f['Cm']):.6f} <= rho_r = {float(rho[-1]):.6f};"
          f" log(C+/C-) = {logCC:.5f} <= log rho_r = {logrho:.5f} <= D(k+2)log(k/(k-1)) = {DD:.5f};  log(B+/B-) = {logBB:.5f};  S>0: {f['S'] > 0}")
