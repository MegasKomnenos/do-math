# -*- coding: utf-8 -*-
"""t11b: sizes of the three parts of the refined explicit criterion M1 (see t11) near the curve,
at u = r^{3/2}/k close to 1 and 1.25, for a few columns.  Also the scaled forms theta = r*(1-log Upsilon)
and the published relaxation (theta=1/2 side).  Explicit formulas only."""
from t11_refined_criterion import *
from mpmath import mpf, log
print("k r u | g1_lb (theta=r(1-logUps)) | g2_lb | D_ub | M1 | M0 | M1/D_ub")
for k in (265, 300, 369, 400, 535, 675, 1000, 3000, 9999):
    r0 = rc(k)
    for r in (r0, int((1.25 * k) ** (2 / 3)), int((1.5 * k) ** (2 / 3))):
        h = mpf(k - 1) / (k + r)
        lU = log_tau(r + 1, h) - log_tau(r, h)
        g1, g2, d = M1(r, k, parts=True)
        print(f"{k} {r} {r**1.5/k:.3f} | {float(g1):.3f} ({float(r*(1-lU)):.3f}) | {float(g2):.3f} | {float(d):.3f} | {float(g1+g2-d):.3f} | {float(M0(r,k)):.3f} | {float((g1+g2-d)/d):.3f}")
