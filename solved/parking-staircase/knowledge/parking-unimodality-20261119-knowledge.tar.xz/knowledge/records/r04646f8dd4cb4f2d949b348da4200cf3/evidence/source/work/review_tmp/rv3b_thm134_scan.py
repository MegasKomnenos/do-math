# (a) precise values of the constants entering the closed forms for L, t_low, Theta in the proof of Thm 13.4
# (b) full scan 265 <= k <= 300000 (floats) of Lemma 4.1 quantities at R = rho2(k)+1 against the closed forms
import math, time
from mpmath import mp, mpf, log, sqrt, exp, zeta, cbrt, pi
mp.dps = 40
t0 = time.time()
nu = (mpf(11) / 5) ** (mpf(2) / 3)
c0 = 1 / sqrt(2 * pi)
eps1 = 1 / cbrt(mpf(265))
E1 = mpf("0.1556868")   # the rounded-up eps_1 used in the text
em1 = exp(-1)
for label, e1 in (("exact eps1", eps1), ("eps1:=0.1556868", E1)):
    print("----", label)
    eta1 = 1 + e1 ** 2 / nu
    s0max = mpf(5) / 2 * e1 * (nu + e1 ** 2)
    q1 = (exp(s0max) - 1 - s0max) / s0max ** 2
    print(" eta1=%s (stated <=1.0143293: %s)  s0<=%s (stated 0.6678088: %s)  q1=%s (stated 0.6326704: %s)" % (
        mp.nstr(eta1, 10), eta1 <= mpf("1.0143293"), mp.nstr(s0max, 10), s0max <= mpf("0.6678088"),
        mp.nstr(q1, 10), q1 <= mpf("0.6326704")))
    # use the stated rounded-up values as the text does
    eta1s = mpf("1.0143293"); q1s = mpf("0.6326704")
    Lw = nu ** 2 - 2 * c0 * sqrt(nu)
    Lc = -nu ** 3 - 2 + c0 - mpf(11) / 3 * c0 * eta1s ** mpf(1.5)
    Le = (nu + nu ** 4) - c0 * 5 * q1s / 2 * nu ** mpf(2.5) * eta1s ** mpf(2.5) - mpf(5) / 24 * nu ** 4 * eta1s ** 4
    Le2 = -nu * (nu + nu ** 4)
    print(" L coefficients (true lower-bound coefficient / stated / stated<=true):")
    for nm, tv, sv in (("w", Lw, "1.823579"), ("1", Lc, "-7.935400"), ("eps", Le, "5.639857"), ("eps^2", Le2, "-16.709999")):
        print("    %-6s %s  %s  %s" % (nm, mp.nstr(tv, 10), sv, mpf(sv) <= tv))
    print(" e^-1 * stated L coefficients (true / stated / stated<=true):")
    for nm, lv, sv in (("w", "1.823579", "0.670857"), ("1", "-7.935400", "-2.919271"), ("eps", "5.639857", "2.074787"), ("eps^2", "-16.709999", "-6.147266")):
        tv = em1 * mpf(lv)
        print("    %-6s %s  %s  %s" % (nm, mp.nstr(tv, 10), sv, mpf(sv) <= tv))
    # t_low
    a0 = 2 * em1 * c0 / sqrt(nu)
    eabar = exp(mpf(5) / 2 * e1 ** 3)
    print(" a0=%s  e^abar<=%s (stated 1.009479: %s)" % (mp.nstr(a0, 10), mp.nstr(eabar, 10), eabar <= mpf("1.009479")))
    t_e1 = 5 * em1 * c0 * sqrt(nu)
    p1 = mpf(13) / (12 * nu) * a0
    p2 = mpf(5) / 2 * em1 * (mpf("1.009479") + 1 - c0)
    p3 = mpf(25) / 4 * em1 * q1s * c0 * mpf(2) / 3 * nu ** mpf(1.5) * eta1s ** mpf(1.5)
    t_e4 = mpf(25) / 4 * em1 * q1s * 2 * c0 * sqrt(nu)
    t_e5 = mpf(25) / 4 * em1 * q1s * (1 - c0)
    print(" t_low/eps: const a0=%s (stated 0.225686 <= : %s); eps coeff %s (stated 0.954392 >= : %s)" % (
        mp.nstr(a0, 10), mpf("0.225686") <= a0, mp.nstr(t_e1, 10), mpf("0.954392") >= t_e1))
    print("            eps^2 pieces %s + %s + %s = %s (stated 2.495254 >= : %s)" % (
        mp.nstr(p1, 9), mp.nstr(p2, 9), mp.nstr(p3, 9), mp.nstr(p1 + p2 + p3, 10), mpf("2.495254") >= p1 + p2 + p3))
    print("            eps^4 %s (stated 1.509538 >= : %s); eps^5 %s (stated 0.874338 >= : %s)" % (
        mp.nstr(t_e4, 10), mpf("1.509538") >= t_e4, mp.nstr(t_e5, 10), mpf("0.874338") >= t_e5))
    # Theta
    kA = ((1 - e1 ** 2 / nu) ** mpf(-0.5) - 1) / e1 ** 2
    red = 1 - mpf(8) / 15 * e1 ** 3
    b1 = 5 * em1 * c0 * sqrt(nu) * red
    b2 = mpf(5) / 2 * em1 * red * (2 - c0 * (2 + zeta(mpf(1.5)) / 12))
    Cf = em1 * exp(mpf(5) / 2 * e1 ** 3)
    T0 = a0 + Cf * nu
    T1 = b1 + Cf * nu ** 2
    T2 = a0 * kA - b2 + Cf * (nu ** 3 + 2)
    print(" Theta: a0*kA=%s b1=%s b2=%s Cf=%s" % (mp.nstr(a0 * kA, 9), mp.nstr(b1, 9), mp.nstr(b2, 9), mp.nstr(Cf, 9)))
    print("        coefficients: %s (stated 0.853867 >= : %s) ; %s (stated 2.015061 <= : %s) ; %s (stated 1.583938 >= : %s)" % (
        mp.nstr(T0, 10), mpf("0.853867") >= T0, mp.nstr(T1, 10), mpf("2.015061") <= T1, mp.nstr(T2, 10), mpf("1.583938") >= T2))

# ---------------------------------------------------------------- float scan
Z32 = float(zeta(mpf(1.5)))
C0 = 1 / math.sqrt(2 * math.pi)
EM1 = math.exp(-1)
def rho2(k):
    r = int(round((11 * k / 5) ** (2 / 3)))
    while 25 * r ** 3 > 121 * k * k:
        r -= 1
    while 25 * (r + 1) ** 3 <= 121 * k * k:
        r += 1
    return r
def quantities(k, R):
    N = k + R
    abar = 5 / (2 * k); alow = abar - 4 / (3 * k * k)
    s0 = abar * R
    q = (math.expm1(s0) - s0) / s0 ** 2
    Sbar = 1 + C0 * (2 * math.sqrt(R - 1) - 1 + (2 * abar / 3) * R ** 1.5 + (2 * q * abar ** 2 / 5) * R ** 2.5)
    Ebar = 5 * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * math.log1p((R - 1) / (k + 2))
    Gbar = (R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * math.log1p((R - 1) / (k + 1))
    tlow = (2 * EM1 * C0 * (1 - 1 / (12 * R)) / math.sqrt(R + 1) - EM1 * abar * (math.exp(abar) + 1 + C0 * (2 * math.sqrt(R - 1) - 1))
            - EM1 * q * abar ** 2 * (1 + C0 * (2 / 3 * R ** 1.5 + 2 * math.sqrt(R - 1) - 1)))
    tbar = 2 * EM1 * C0 / math.sqrt(R - 1) - EM1 * alow * (2 + C0 * (2 * math.sqrt(R) - 2 - Z32 / 12))
    L = R * (R + 1) / N - 1 - Sbar - Ebar
    Theta = tbar + EM1 * math.exp(abar) * (R + 1) / N
    Psi = Hbar + 5 / k * Gbar
    return L, Theta, Psi, tlow
bad = {}
mins = {"(4.1) margin": (1e9, 0), "tlow*w": (1e9, 0), "Psi slack": (1e9, 0), "L slack": (1e9, 0), "Theta slack": (1e9, 0), "tlow slack": (1e9, 0),
        "final-g": (1e9, 0)}
first_ok_41 = None
for k in range(265, 300001):
    R = rho2(k) + 1
    L, Theta, Psi, tlow = quantities(k, R)
    w = k ** (1 / 3); e = 1 / w
    vals = {
        "(4.1) margin": EM1 * L - Theta * Psi,
        "tlow*w": tlow * w,
        "Psi slack": 1.430651 * w + 6.453334 - 4.803968 * e + 38.196752 * e ** 2 + 33.88 * e ** 3 + 68.084410 * e ** 4 - Psi,
        "L slack": L - (1.823579 * w - 7.935400 + 5.639857 * e - 16.709999 * e ** 2),
        "Theta slack": e * (0.853867 - 2.015061 * e + 1.583938 * e ** 2) - Theta,
        "tlow slack": tlow / e - (0.225686 - 0.954392 * e - 2.495254 * e ** 2 - 1.509538 * e ** 4 - 0.874338 * e ** 5),
        "final-g": EM1 * L - Theta * Psi - (0.670857 / e - 4.140857 - 0.905451 * e + 3.368872 * e ** 2),
    }
    for key, v in vals.items():
        if v < mins[key][0]:
            mins[key] = (v, k)
        if v <= 0:
            bad[key] = bad.get(key, 0) + 1
    if not (2 <= R <= k - 1) or Theta < 0 or Psi < 0:
        bad["range/sign"] = bad.get("range/sign", 0) + 1
print("\nfloat scan 265..300000 at R=rho2(k)+1: violations:", bad)
for key, (v, k) in mins.items():
    print("   min %-14s = %.6g at k=%d (R=%d)" % (key, v, k, rho2(k) + 1))
# what happens just below 265 (not claimed by the theorem; for information)
for k in (200, 240, 260, 264, 265, 266, 267, 268, 270):
    R = rho2(k) + 1
    L, Theta, Psi, tlow = quantities(k, R)
    print("   k=%d R=%d: tlow=%.5g  (4.1) margin=%.5g" % (k, R, tlow, EM1 * L - Theta * Psi))
print("time %.1fs" % (time.time() - t0))
