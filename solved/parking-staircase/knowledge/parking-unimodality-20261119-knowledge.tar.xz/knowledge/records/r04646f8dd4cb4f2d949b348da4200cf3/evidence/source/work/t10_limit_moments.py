# -*- coding: utf-8 -*-
"""
t10: arithmetic behind report section 10 (limit form of the section).
 (a) exact joint moments E[M^j A^l] (M = max of BM on [0,1], A = integral of the running max) from the
     closed formula of Lemma 10.3:  (-1)^l l! (j+l)! h_{j,j+l} gamma^{-(j+l)} / Gamma((j+3l)/2+1),
     h_{j,i} = [w^i] ((1+w)^{2/3}-1)^j (1+w)^{-2/3},  gamma = 2*sqrt(2)/3     (exact rationals times sqrt/pi factors)
 (b) the moments of (T,V) from Lemma 10.4
 (c) the grid verification of  P1(u) P2(u) <= 2 exp(-(11/5) c u)  on [0, 4/5]
 (d) a crude Monte Carlo sanity check of four of the moments (random walk with 4000 steps; bias ~1%)
"""
from fractions import Fraction as Fr
from math import gamma, sqrt, pi, exp, factorial
import sys

def binom_series(a, n):
    """coefficients of (1+w)^a up to w^n, exact"""
    out = [Fr(1)]
    for i in range(1, n + 1):
        out.append(out[-1] * (a - (i - 1)) / i)
    return out

def mul(p, q, n):
    r = [Fr(0)] * (n + 1)
    for i, pi_ in enumerate(p):
        if pi_ == 0: continue
        for j, qj in enumerate(q):
            if i + j > n: break
            r[i + j] += pi_ * qj
    return r

def h(j, n):
    g = binom_series(Fr(2, 3), n); g[0] = Fr(0)
    e = binom_series(Fr(-2, 3), n)
    out = e
    for _ in range(j):
        out = mul(out, g, n)
    return out

G = 2 * sqrt(2) / 3
def EMA(j, l):
    hh = h(j, j + l)[j + l]
    return float((-1) ** l * factorial(l) * factorial(j + l) * hh) * G ** (-(j + l)) / gamma((j + 3 * l) / 2 + 1), hh

c = sqrt(2 / pi)
print("c = sqrt(2/pi) =", c)
for (j, l) in [(1,0),(2,0),(3,0),(0,1),(0,2),(0,3),(1,1),(1,2),(2,1),(3,1),(3,2)]:
    v, hh = EMA(j, l)
    print(f"E[M^{j} A^{l}] = {v:.9f}   (h = {hh})   ratio to c: {v/c:.9f}")
def ETV(j, l):
    if l == 0: return EMA(j, 0)[0]
    return (1 + 3 * l / j) * EMA(j, l)[0] - (2 * l / j) * EMA(j + 1, l - 1)[0]
for (j, l) in [(1,0),(2,0),(1,1),(2,1),(1,2)]:
    print(f"E[T^{j} V^{l}] = {ETV(j,l):.9f}   ratio to c: {ETV(j,l)/c:.9f}")

P1 = lambda u: 2*c - 1.75*u + (86/63)*c*u*u
P2 = lambda u: c - 0.5*u + (4/15)*c*u*u
U = lambda u: P1(u)*P2(u)
L = lambda u: 2*exp(-(11/5)*c*u)
grid = [0, 0.257, 0.40, 0.5585, 0.70, 0.78, 0.80]
print("grid check  U(u_i) <= L(u_{i+1}):")
for a, b in zip(grid[:-1], grid[1:]):
    print(f"  [{a},{b}]: U({a})={U(a):.6f} <= L({b})={L(b):.6f}: {U(a) <= L(b)}   (P1,P2 at right end: {P1(b):.6f},{P2(b):.6f})")
print("bound on the (Y) ratio U/L at u = 0, 0.2, 0.4654, 0.5585, 0.8:", [round(U(u)/L(u),4) for u in (0,0.2,0.4654,0.5585,0.8)])
print("P1 decreasing up to u =", 1.75/(2*(86/63)*c), "; P2 decreasing up to u =", 0.5/(2*(4/15)*c))

if len(sys.argv) > 1 and sys.argv[1] == "mc":
    import numpy as np
    rng = np.random.default_rng(12345)
    n, paths = 4000, 40000
    acc = {k: 0.0 for k in ("MA", "M2A", "M3A", "M3A2", "M", "A")}
    done = 0
    for _ in range(10):
        dB = rng.standard_normal((paths // 10, n)) * (1.0 / n) ** 0.5
        Bp = np.cumsum(dB, axis=1)
        run = np.maximum.accumulate(np.maximum(Bp, 0.0), axis=1)
        M = run[:, -1]; A = run.mean(axis=1)
        acc["M"] += M.sum(); acc["A"] += A.sum(); acc["MA"] += (M*A).sum(); acc["M2A"] += (M*M*A).sum()
        acc["M3A"] += (M**3*A).sum(); acc["M3A2"] += (M**3*A*A).sum(); done += len(M)
    for k in acc: print(f"  MC E[{k}] ~ {acc[k]/done:.4f}")
