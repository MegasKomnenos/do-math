# -*- coding: utf-8 -*-
"""Peer: the explicit constants of the two closed-form proofs, computed with 50-digit arithmetic and rounded in
the SAFE direction (lower bounds down, upper bounds up), plus an independent test of each displayed constant.

 strip(ub, r0)       : the strip theorem  "r >= r0 and r^{3/2} <= ub*k  ==>  Gtilde_1(r,k) > 0"  (section 4)
 crossing(beta, k1)  : the crossing theorem "k >= k1 ==> R = floor((beta k)^{2/3})+1 satisfies t_low>=0 and (4.1)
                        of Lemma 4.1 of ra98af63d"  (section 5)
The printed tables are the ones quoted in the exposition.  Every assertion below re-derives the inequality it
encodes from the displayed (rounded) constants, so the chain in the text is implied by the displayed digits.
"""
import mpmath as mp, sys
mp.mp.dps = 50
F = mp.mpf


def dn(x, d=6):   # round down
    return mp.floor(x * 10 ** d) / 10 ** d


def up(x, d=6):   # round up
    return mp.ceil(x * 10 ** d) / 10 ** d


def strip(ub, r0, label):
    ub = F(ub)
    x0 = mp.sqrt(r0)
    kap = up(ub / x0 ** 3, 7)                 # 1/k_* <= kap for x >= x0
    assert ub / x0 ** 3 <= kap
    # first layer: k >= x^3/ub >= r+2 for r>=r0  (x^3/ub - x^2 - 2 increasing in x when 3x/ub > 2)
    assert x0 ** 3 / ub >= r0 + 2 and 3 * x0 / ub > 2
    c1 = up(ub / 2 * (1 + F(2) / r0), 6)       # X_1 <= c1 x
    ch = up(ub * (1 + F(1) / r0) / (1 - kap), 6)   # X_h <= ch x
    assert ub / 2 * (1 + F(2) / r0) <= c1 and ub * (1 + F(1) / r0) / (1 - kap) <= ch
    def lin(c):
        A = c * c + 12; B = 8 * c
        beta = B / (2 * mp.sqrt(A)) - max(F(0), B * B / (4 * A) - 4) / (2 * mp.sqrt(A) * x0)
        m = dn((mp.sqrt(A) - c) / 3, 6)
        n = up((4 - beta) / 3, 6)
        return m, n, B * B / (4 * A)
    m1, n1, t1 = lin(c1)
    mh, nh, th = lin(ch)
    assert m1 * x0 - n1 > 0 and mh * x0 - nh > 0
    # s_r <= sqrt(pi r/2) e^{1/(12r)} - 1/3  (published: rc693abe9 Lemma 6 upper bound + r790d81e5 c-stirling);
    # for r >= r0 this is <= sig*x - 1/3 with sig = sqrt(pi/2) e^{1/(12 r0)}
    sig = up(mp.sqrt(mp.pi / 2) * mp.e ** (F(1) / (12 * r0)), 6)
    assert sig ** 2 <= F(8) / 5
    Dm = up(F(3) / 2 * sig, 6)                # D_r <= Dm x - 13/5
    inv = up(1 / (1 - kap), 6)                # k/(k-1) <= inv
    a_first = dn(1 / (2 * ub), 6)
    b_first = up(1 / (3 * ub * x0) + F(5) / 2, 6)
    mu_m = dn(mh / 2 + 2 * (1 - kap) * m1, 6)
    mu_n = up(nh / 2 + 2 * (1 - kap) * n1, 6)
    D_m = up(inv * Dm, 6)
    D_n = dn(inv * F(13) / 5, 6)
    A = dn(a_first + mu_m - D_m, 6)
    Bc = up(b_first + mu_n - D_n, 6)
    val = A * x0 - Bc
    print(f"--- strip theorem instance {label}: u_b = {ub}, r_0 = {r0}, x_0 = {mp.nstr(x0, 9)}")
    print(f"  1/k_* <= {kap};  c_1 = {c1} (B^2/4A = {mp.nstr(t1, 5)}),  c_h = {ch} (B^2/4A = {mp.nstr(th, 5)})")
    print(f"  (ga)  >= {a_first} x - {b_first}")
    print(f"  (na)  mu_0(X_1) >= {m1} x - {n1};  mu_0(X_h) >= {mh} x - {nh};  sum >= {mu_m} x - {mu_n}")
    print(f"  (da)  sigma = {sig};  D_r <= {Dm} x - 2.6;  k/(k-1) <= {inv};  (k/(k-1)) D_r <= {D_m} x - {D_n}")
    print(f"  (ra)  Phi(x) >= {A} x - {Bc};  at x_0: {mp.nstr(val, 6)}")
    assert A > 0 and val > 0
    return dict(A=A, B=Bc, x0=x0, sig=sig, kap=kap, c1=c1, ch=ch, m1=m1, n1=n1, mh=mh, nh=nh, Dm=Dm, inv=inv)


def crossing(beta, k1, label):
    beta = F(beta)
    nu = beta ** (F(2) / 3)
    w1 = F(k1) ** (F(1) / 3)
    e1 = 1 / w1                                  # eps <= e1
    c0 = 1 / mp.sqrt(2 * mp.pi)
    em1 = mp.e ** -1
    zeta = mp.zeta(F(3) / 2)
    eta1 = 1 + e1 ** 2 / nu
    s0 = F(5) / 2 * e1 * (nu + e1 ** 2)
    q1 = (mp.e ** s0 - 1 - s0) / s0 ** 2
    E1 = mp.e ** (F(5) / 2 * e1 ** 3)            # e^{abar} <= E1
    Cf = em1 * E1
    assert nu * e1 <= 1 and e1 ** 2 <= nu / 4 and 6 * e1 ** 3 <= 1
    # R in (nu w^2, nu w^2 + 1], need 2 <= R <= k-1 for k >= k1:  nu w^2 + 1 <= w^3 - 1
    assert nu * w1 ** 2 + 2 <= w1 ** 3 and 3 * w1 > 2 * nu
    # ---- L := R(R+1)/N - 1 - Sbar - Ebar >= L1 w - L0 + L2 eps - L3 eps^2
    L1 = nu ** 2 - 2 * c0 * mp.sqrt(nu)
    L0 = nu ** 3 + 2 - c0 + c0 * F(5) / 3 * beta * eta1 ** (F(3) / 2)
    L2 = (nu + nu ** 4) - c0 * F(5) / 2 * q1 * nu ** (F(5) / 2) * eta1 ** (F(5) / 2) - F(5) / 24 * nu ** 4 * eta1 ** 4
    L3 = nu * (nu + nu ** 4)
    l1, l0, l2, l3 = dn(em1 * L1), up(em1 * L0), dn(em1 * L2), up(em1 * L3)
    # ---- t_low/eps >= a0 - t1 eps - t2 eps^2 - t4 eps^4 - t5 eps^5
    a0 = 2 * em1 * c0 / mp.sqrt(nu)
    t1 = 5 * em1 * c0 * mp.sqrt(nu)
    t2 = a0 * 13 / (12 * nu) + F(5) / 2 * em1 * (E1 + 1 - c0) + F(25) / 4 * em1 * q1 * c0 * F(2) / 3 * beta * eta1 ** (F(3) / 2)
    t4 = F(25) / 4 * em1 * q1 * 2 * c0 * mp.sqrt(nu)
    t5 = F(25) / 4 * em1 * q1 * (1 - c0)
    A0, T1, T2, T4, T5 = dn(a0), up(t1), up(t2), up(t4), up(t5)
    tval = A0 - T1 * e1 - T2 * e1 ** 2 - T4 * e1 ** 4 - T5 * e1 ** 5
    # ---- Theta <= eps [th0 - th1 eps + th2 eps^2]
    kapA = ((1 - e1 ** 2 / nu) ** (-F(1) / 2) - 1) / e1 ** 2
    low = 1 - F(8) / 15 * e1 ** 3
    b1 = F(5) / 2 * em1 * low * 2 * c0 * mp.sqrt(nu)
    b2 = F(5) / 2 * em1 * low * (2 - c0 * (2 + zeta / 12))
    assert 2 - c0 * (2 + zeta / 12) > 0
    th0 = up(a0 + Cf * nu); th1 = dn(b1 + Cf * nu ** 2); th2 = up(a0 * kapA - b2 + Cf * (nu ** 3 + 2))
    assert th2 >= 0
    th1p = dn(th1 - th2 * e1)                   # Theta/eps <= th0 - th1p eps on (0, e1]
    assert th0 - th1p * e1 > 0
    # ---- Psi <= p0 w + p1 + p2 eps + p3 eps^2 + p4 eps^3 + p5 eps^4
    p0 = up(nu ** 2 / 2); p1 = up(F(4) / 3 * nu ** 3); p2 = up(2 * nu - nu ** 4)
    # Hbar <= phi(x), phi(x) = 2x + k(x^2/2 - x^3/3 + x^4/4) increasing, x = (R-1)/(k+2) <= nu*eps;
    # Gbar <= psi(z), psi(z) = 2z + (3k+1)/2 z^2 + k(k-1)(z^3/3 - z^4/4 + z^5/5) increasing, z = (R-1)/(k+1) <= nu*eps;
    # 5(k-1)(...) <= 5k(...) because the bracket is positive.
    p3 = up(nu ** 2 * (F(15) / 2 + F(5) / 2 * e1 ** 3) + nu ** 5); p4 = F(0); p5 = up(10 * nu)
    assert p3 >= 0 and p4 >= 0 and p5 >= 0
    p2p = up(p2 + p3 * e1 + p4 * e1 ** 2 + p5 * e1 ** 3)   # eps*Psi <= p0 + p1 eps + p2p eps^2
    # ---- product and the final function g(eps) = g_m1/eps - g0 + g1 eps + g2 eps^2 (+ nonneg. eps^3 term dropped if >=0)
    c_0 = up(th0 * p0); c_1 = up(th0 * p1 - th1p * p0); c_2 = up(th0 * p2p - th1p * p1); c_3 = up(-th1p * p2p)
    gm1 = l1; g0 = up(l0 + c_0); g1 = dn(l2 - c_1); g2 = dn(-l3 - c_2); g3 = dn(-c_3)
    g = lambda e: gm1 / e - g0 + g1 * e + g2 * e * e + (g3 * e ** 3 if g3 < 0 else 0)
    gp = lambda e: -gm1 / e ** 2 + g1 + 2 * g2 * e + (3 * g3 * e * e if g3 < 0 else 0)
    # g decreasing on (0,e1]:  -gm1/e^2 + g1 + 2 g2 e (+...) < 0 ; crude sufficient test: max over the interval of the
    # polynomial part is below gm1/e1^2
    poly_max = max(g1, g1 + 2 * g2 * e1) + (0 if g3 >= 0 else max(F(0), 3 * g3 * e1 ** 2))
    assert poly_max < gm1 / e1 ** 2
    print(f"--- crossing theorem instance {label}: beta = {beta}, nu = beta^(2/3) = {mp.nstr(nu, 9)}, k >= {k1}, w_1 = {mp.nstr(w1, 9)}, eps_1 = {mp.nstr(e1, 9)}")
    print(f"  eta_1 = {mp.nstr(eta1, 9)}, s_0 <= {mp.nstr(s0, 8)}, q_1 = {mp.nstr(q1, 8)}, e^abar <= {mp.nstr(E1, 8)}, C_f = {mp.nstr(Cf, 8)}, kappa_A = {mp.nstr(kapA, 8)}")
    print(f"  e^-1 L >= {l1} w - {l0} + {l2} eps - {l3} eps^2          [L1={mp.nstr(L1, 9)}, L0={mp.nstr(L0, 9)}, L2={mp.nstr(L2, 9)}, L3={mp.nstr(L3, 9)}]")
    print(f"  t_low/eps >= {A0} - {T1} eps - {T2} eps^2 - {T4} eps^4 - {T5} eps^5;   at eps_1: {mp.nstr(tval, 6)}")
    print(f"  Theta <= eps [{th0} - {th1} eps + {th2} eps^2]  <= eps [{th0} - {th1p} eps]")
    print(f"  Psi <= {p0} w + {p1} + ({p2}) eps + {p3} eps^2 + {p4} eps^3 + {p5} eps^4;   eps Psi <= {p0} + {p1} eps + ({p2p}) eps^2")
    print(f"  Theta Psi <= {c_0} + ({c_1}) eps + ({c_2}) eps^2 + ({c_3}) eps^3")
    print(f"  e^-1 L - Theta Psi >= g(eps) = {gm1}/eps - {g0} + ({g1}) eps + ({g2}) eps^2" + (f" + ({g3}) eps^3" if g3 < 0 else "  [eps^3 coefficient >= 0 dropped]") + f";   g(eps_1) = {mp.nstr(g(e1), 6)}")
    assert tval > 0 and g(e1) > 0
    return dict(nu=nu, e1=e1, l=(l1, l0, l2, l3), t=(A0, T1, T2, T4, T5), th=(th0, th1, th2, th1p), p=(p0, p1, p2, p3, p4, p5, p2p), g=(gm1, g0, g1, g2, g3))


def lemma41(k, R):
    k = F(k); R = F(R)
    N = k + R
    c0 = 1 / mp.sqrt(2 * mp.pi); e1 = mp.e ** -1
    abar = 5 / (2 * k); alow = 5 / (2 * k) - 4 / (3 * k * k)
    s0 = abar * R; q = (mp.e ** s0 - 1 - s0) / s0 ** 2
    Sbar = 1 + c0 * (2 * mp.sqrt(R - 1) - 1 + 2 * abar / 3 * R ** 1.5 + 2 * q * abar ** 2 / 5 * R ** 2.5)
    Ebar = 5 * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * mp.log((k + R + 1) / (k + 2))
    Gbar = (R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * mp.log((k + R) / (k + 1))
    tlow = (2 * e1 * c0 * (1 - 1 / (12 * R)) / mp.sqrt(R + 1) - e1 * abar * (mp.e ** abar + 1 + c0 * (2 * mp.sqrt(R - 1) - 1))
            - e1 * q * abar ** 2 * (1 + c0 * (F(2) / 3 * R ** 1.5 + 2 * mp.sqrt(R - 1) - 1)))
    tbar = 2 * e1 * c0 / mp.sqrt(R - 1) - e1 * alow * (2 + c0 * (2 * mp.sqrt(R) - 2 - mp.zeta(F(3) / 2) / 12))
    return dict(tlow=tlow, e1L=e1 * (R * (R + 1) / N - 1 - Sbar - Ebar), Theta=tbar + e1 * mp.e ** abar * (R + 1) / N, Psi=Hbar + 5 / k * Gbar)


def floor_strip(beta_num, beta_den, k):
    """largest integer r with beta_den * r^{3/2} <= beta_num * k"""
    r = int((beta_num * k / beta_den) ** (2 / 3))
    while (beta_den ** 2) * (r + 1) ** 3 <= (beta_num ** 2) * k * k:
        r += 1
    while (beta_den ** 2) * r ** 3 > (beta_num ** 2) * k * k:
        r -= 1
    return r


def test_crossing(con, bn, bd, k1, ks):
    """the displayed closed forms must bound Lemma 4.1's quantities (50 digits) at every tested k"""
    mins = [F(10)] * 5
    for k in ks:
        R = floor_strip(bn, bd, k) + 1
        v = lemma41(k, R)
        w = F(k) ** (F(1) / 3); e = 1 / w
        l1, l0, l2, l3 = con["l"]; A0, T1, T2, T4, T5 = con["t"]; th0, th1, th2, th1p = con["th"]; p0, p1, p2, p3, p4, p5, p2p = con["p"]
        s = [v["e1L"] - (l1 * w - l0 + l2 * e - l3 * e * e),
             v["tlow"] * w - (A0 - T1 * e - T2 * e ** 2 - T4 * e ** 4 - T5 * e ** 5),
             e * (th0 - th1 * e + th2 * e * e) - v["Theta"],
             (p0 * w + p1 + p2 * e + p3 * e ** 2 + p4 * e ** 3 + p5 * e ** 4) - v["Psi"],
             v["e1L"] - v["Theta"] * v["Psi"]]
        assert all(x >= 0 for x in s[:4]) and s[4] > 0 and v["tlow"] > 0, (k, R, [mp.nstr(x, 6) for x in s])
        mins = [min(a, b) for a, b in zip(mins, s)]
    return mins


if __name__ == "__main__":
    sA = strip(F(3) / 2, 42, "(a)")
    sB = strip(F(11) / 5, 55, "(b)")
    cB = crossing(F(11) / 5, 265, "beta=11/5")
    cA = crossing(F(3) / 2, 729, "beta=3/2")
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        import random
        random.seed(7)
        ks = list(range(265, 3001)) + [random.randint(3001, 10 ** 7) for _ in range(1500)] + [10 ** j for j in range(4, 16)] \
             + [605 * b ** 3 for b in range(1, 40)] + [605 * b ** 3 + d for b in range(1, 12) for d in (-1, 1)]
        m = test_crossing(cB, 11, 5, 265, ks)
        print("beta=11/5: tested", len(ks), "values of k; smallest slacks [e^-1 L, t_low*w, Theta, Psi] and smallest (4.1) margin:", [mp.nstr(x, 5) for x in m])
        ks = list(range(729, 3001)) + [random.randint(3001, 10 ** 7) for _ in range(1500)] + [10 ** j for j in range(4, 16)] \
             + [96 * b ** 3 for b in range(2, 40)]
        m = test_crossing(cA, 3, 2, 729, ks)
        print("beta=3/2 : tested", len(ks), "values of k; smallest slacks [e^-1 L, t_low*w, Theta, Psi] and smallest (4.1) margin:", [mp.nstr(x, 5) for x in m])
        # strip: displayed linear minorants vs the exact Gtilde_1 on the boundary
        from v05_strip_scan import s_r, D_of, Gt1
        import math
        for con, ub, r0 in ((sA, 1.5, 42), (sB, 2.2, 55)):
            worst = 1e9
            for r in list(range(r0, 5001)) + [10 ** 4, 10 ** 5, 10 ** 6]:
                x = math.sqrt(r); s = s_r(r); D = D_of(r, s)
                val = Gt1(r, x ** 3 / ub, D)
                lin = float(con["A"]) * x - float(con["B"])
                assert val >= lin > 0, (r, val, lin)
                assert D <= float(con["Dm"]) * x - 2.6 + 1e-12
                worst = min(worst, val - lin)
            print(f"strip u_b={ub}: Gtilde_1 on the boundary >= displayed linear minorant for r0<=r<=5000 and samples; smallest slack {worst:.5f}")
