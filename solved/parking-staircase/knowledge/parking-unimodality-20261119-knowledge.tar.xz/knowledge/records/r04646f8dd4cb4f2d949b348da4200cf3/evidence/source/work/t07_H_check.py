# -*- coding: utf-8 -*-
"""
t07: one targeted test of the shape hypothesis (H) used in report section 4.4:
    "v_j := P_lambda(J=j)/(j+1) is log-concave in j"   (J = number of cuts of the bridge 0->r,
    threshold profile lambda_s = y/(N-s), y = k, N = n+1, r = n-k).
t03 flagged (H) as failing at (n,k) = (400,201).  This prints where it fails and by how much,
and the same ratios at (200,101) where t03 found (H) to hold.
Printed: j, p_j = P(J=j), and  v_j^2/(v_{j-1} v_{j+1})  (>= 1 means log-concave at j).
40-digit floats; the failing ratios are far from 1 on the scale of the precision.
"""
import sys
from mpmath import mp, mpf, exp, log, loggamma
mp.dps = 40

def bor(j):
    j = mpf(j)
    return exp(-j + (j - 1) * log(j) - loggamma(j + 1))

def bridge_law(n, k):
    N = n + 1
    r = n - k
    y = mpf(k)
    A = [mpf(0)] + [bor(j) for j in range(1, r + 1)]
    # U[m][q]: chains 0 -> m with q points (incl. m); factor y/(N-c) at interior points only
    U = [dict() for _ in range(r + 1)]
    U[0][0] = mpf(1)
    for m in range(1, r + 1):
        acc = {}
        for s in range(0, m):
            g = A[m - s]
            fac = (y / (N - s)) if s > 0 else mpf(1)
            for q, w in U[s].items():
                acc[q + 1] = acc.get(q + 1, mpf(0)) + w * g * fac
        U[m] = acc
    tot = sum(U[r].values())
    return {q - 1: w / tot for q, w in U[r].items()}

if __name__ == "__main__":
    args = [int(x) for x in sys.argv[1:]]
    for i in range(0, len(args), 2):
        n, k = args[i], args[i + 1]
        p = bridge_law(n, k)
        js = sorted(p)
        v = {j: p[j] / (j + 1) for j in js}
        mean = sum(j * p[j] for j in js)
        print(f"--- (n,k)=({n},{k}) r={n-k}  E[J]={float(mean):.4f}")
        bad = [j for j in js[1:-1] if v[j] ** 2 < v[j - 1] * v[j + 1]]
        print("   indices where v is not log-concave:", bad[:20])
        for j in js[:9]:
            if j >= 1 and j + 1 in v:
                print(f"   j={j} p_j={float(p[j]):.6f}  v_j^2/(v_(j-1) v_(j+1))={float(v[j]**2/(v[j-1]*v[j+1])):.6f}"
                      f"   p_j^2/(p_(j-1) p_(j+1))={float(p[j]**2/(p[j-1]*p[j+1])):.6f}")
            elif j == 0:
                print(f"   j=0 p_0={float(p[0]):.6f}")
