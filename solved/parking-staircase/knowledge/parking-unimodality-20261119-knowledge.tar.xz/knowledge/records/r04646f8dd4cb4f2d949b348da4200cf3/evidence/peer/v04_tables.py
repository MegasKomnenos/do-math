# -*- coding: utf-8 -*-
"""Peer check against the actual rows (independent code; 70-digit decimal arithmetic, not exact integers).

 mode 'cross KLO KHI' : for each column k in [KLO,KHI] compute d_{n,k}/n! for k<=n<=k+floor(0.45k)+3 from the
     last-car recursion  n*g_n = sum_{j=1}^n min(j,k+1) g_{j-1} g_{n-j},  g_n = A_{n,k}/n!,
     and report q_0(k) = first n with d_{n,k}>0, against r_c(k), rho(k)+1=floor((3k/2)^(2/3))+1,
     rho2(k)+1=floor((11k/5)^(2/3))+1, floor(27k/100).  Checks:  q_0(k) <= k+rho2(k)+1 (Theorem 13.4),
     d>0 on [q_0, k+floor(2k/5)+1] (published Cor P1), no zero differences.
 mode 'strip k1 k2 ...' : for the listed k and every 2<=r<=rho2(k), the cross product S_{n,k} from the first-layer
     formulas (Prop 5.8), its sign, k*log(B+C-/(B-C+)) and the criterion values Gtilde_1 (Cor 13.2).
"""
import sys
from decimal import Decimal as D, getcontext
from math import factorial
getcontext().prec = 70
sys.path.insert(0, ".")
from v03_crossing import rho2, rho32, rc


def column(k, nmax):
    """g[n] = A_{n,k}/n! for n=0..nmax (Decimal)"""
    g = [D(1)] * (nmax + 1)
    # closed form for n<=k+1: A_{n,k} = (n+1)^(n-1)
    for n in range(1, min(k + 1, nmax) + 1):
        g[n] = D((n + 1) ** (n - 1)) / D(factorial(n))
    c = [D(0)] * (nmax + 2)          # c[j] = min(j,k+1) g[j-1]
    for j in range(1, min(k + 2, nmax + 1) + 1):
        c[j] = min(j, k + 1) * g[j - 1]
    for n in range(k + 2, nmax + 1):
        s = D(0)
        for j in range(1, n + 1):
            s += c[j] * g[n - j]
        g[n] = s / n
        c[n + 1] = (k + 1) * g[n]
    return g


def mode_cross(klo, khi):
    cols = {}
    nmax_of = lambda k: k + (45 * k) // 100 + 3
    out = []
    viol = 0
    for k in range(klo - 2, khi + 1):
        cols[k] = column(k, nmax_of(khi) if False else nmax_of(k + 2))
        if k - 3 in cols:
            del cols[k - 3]
        if k < klo:
            continue
        nm = nmax_of(k)
        q0 = None
        zeros = 0
        signs = []
        for n in range(k, nm + 1):
            d = cols[k][n] - 2 * cols[k - 1][n] + cols[k - 2][n]
            b = cols[k][n] - cols[k - 1][n]
            if d == 0:
                zeros += 1
            rel = d / b if b != 0 else D(0)
            signs.append((n, d > 0, rel))
            if q0 is None and d > 0:
                q0 = n
        # persistence in the window
        win_end = k + (2 * k) // 5 + 1
        pers = all(pos for (n, pos, rel) in signs if q0 <= n <= win_end)
        neg_before = all((not pos) for (n, pos, rel) in signs if n < q0)
        ok134 = q0 <= k + rho2(k) + 1
        ok121 = q0 <= k + rho32(k) + 1
        minrel = min(abs(rel) for (n, pos, rel) in signs if n > k)
        out.append((k, q0 - k, rc(k), rho32(k) + 1, rho2(k) + 1, (27 * k) // 100, ok134, ok121, pers, neg_before, zeros, float(minrel)))
        if not (ok134 and pers and neg_before and zeros == 0):
            viol += 1
            print("VIOLATION", out[-1])
    print("# k  q0-k  r_c(k)  rho(k)+1  rho2(k)+1  floor(27k/100)  q0<=k+rho2+1  q0<=k+rho+1  d>0 on [q0,k+2k/5+1]  d<=0 before q0  zeros  min|d/b|")
    for row in out:
        if row[0] % 5 == 0 or row[0] in (265, 266, 267, 268, 269):
            print(*row)
    print("columns", klo, "..", khi, " violations:", viol)
    print("max over k of (q0-k)/k^(2/3):", max(r[1] / r[0] ** (2 / 3) for r in out), " min:", min(r[1] / r[0] ** (2 / 3) for r in out))
    print("number of k with q0-k < r_c(k) (crossing strictly behind the curve position):", sum(1 for r in out if r[1] < r[2]),
          "; with q0-k == r_c(k):", sum(1 for r in out if r[1] == r[2]), "; with q0-k > r_c(k) [(CI) fails]:", sum(1 for r in out if r[1] > r[2]))
    print("min over k of (rho2(k)+1) - (q0-k):", min(r[4] - r[1] for r in out), "; min of (rho(k)+1)-(q0-k):", min(r[3] - r[1] for r in out))


def a_dec(j, _cache={}):
    if j not in _cache:
        _cache[j] = D(j ** (j - 1)) / D(factorial(j))
    return _cache[j]


def Lambda_dec(mmax, y, N):
    L = [None] * (mmax + 1)
    for m in range(1, mmax + 1):
        v = a_dec(m)
        for s in range(1, m):
            v += D(y) / D(N - s) * L[s] * a_dec(m - s)
        L[m] = v
    return L


def site(n, k):
    N = n + 1
    r = n - k
    kap = [a_dec(N - m) - sum(a_dec(mp - m) * a_dec(N - mp) for mp in range(m + 1, r + 1)) for m in range(0, r + 1)]
    Ls = {y: Lambda_dec(r + 1, y, N) for y in (k - 1, k, k + 1, k + 2)}
    K = {y: kap[0] + sum(kap[m] * D(y) / D(N - m) * Ls[y][m] for m in range(1, r + 1)) for y in Ls}
    Bm = a_dec(k) / k * Ls[k - 1][r + 1]
    Bp = a_dec(k + 1) / (k + 1) * Ls[k + 2][r]
    Cm = K[k + 1] - 2 * K[k] + K[k - 1]
    Cp = K[k + 2] - 2 * K[k + 1] + K[k]
    return dict(Cm=Cm, Cp=Cp, Bm=Bm, Bp=Bp, S=Bp * Cm - Bm * Cp, d0=Cm - Bm, d1=Cp - Bp)


def mode_strip(ks):
    import mpmath as mp
    from v02_criteria import Gt1, Gt
    for k in ks:
        R2 = rho2(k)
        worst = None
        firstfall = None
        nneg = 0
        rows = []
        for r in range(2, R2 + 1):
            n = k + r
            s = site(n, k)
            if not (s["S"] > 0 and s["Cm"] > 0 and s["Cp"] > 0 and s["Bm"] > 0 and s["Bp"] > 0):
                nneg += 1
                print("  S<=0 or sign problem at", (n, k))
            val = float(k * ((s["Bp"] * s["Cm"]) / (s["Bm"] * s["Cp"])).ln())
            g1 = float(Gt1(r, mp.mpf(k)))
            rows.append((r, val, g1, s["d0"] > 0))
            if r >= 42 and (worst is None or val - g1 < worst[0]):
                worst = (val - g1, r)
        fall = [r for (r, val, g1, pos) in rows if not pos]
        print(f"k={k}: rho2(k)={R2}, r_c(k)={rc(k)}; sites r=2..rho2: S>0 at all: {nneg == 0}; falling sites (d<=0): r<= {max(fall) if fall else None};"
              f" k*log(B+C-/(B-C+)) at r=rho2: {rows[-1][1]:.4f} vs Gt1 {rows[-1][2]:.4f}; min over r of the true value: {min(v for (_, v, _, _) in rows):.4f} (r={min(rows, key=lambda t: t[1])[0]});"
              f" min of (true - Gt1) over r>=42: {worst}")
        for (r, val, g1, pos) in rows:
            if r in (2, 10, 20, 30, 42, 50, 55, 60, 70, R2) or (r % 20 == 0):
                print(f"     r={r:4d} u={r ** 1.5 / k:6.3f}  true={val:8.4f}  Gt1={g1:8.4f}  d_(n,k)>0: {pos}")


if __name__ == "__main__":
    if sys.argv[1] == "cross":
        mode_cross(int(sys.argv[2]), int(sys.argv[3]))
    elif sys.argv[1] == "strip":
        mode_strip([int(x) for x in sys.argv[2:]])
