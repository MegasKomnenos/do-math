# t25: two small exact checks for report section 8.6.
# (A) First part under the threshold profile.  r-compositions with cut factors lambda'_i = (k-1)/(N-i-1), 1<=i<=r-1
#     (N = k+r+1), gamma_0 = first part (the part adjacent to position 0), phi(g) = a_{g+1}/a_g.
#     Compare E_{lambda'}[phi(gamma_0)] with the homogeneous laws of factor h_min = (k-1)/(N-2) (smallest factor),
#     h_mid = (k-1)/(N-1-r/2) (factor at the midpoint) and with the published comparison factor h = (k-1)/(N-1).
#     Question: is E_{lambda'} <= E_{h_mid}?  (It is not; the first part is governed by the factors next to position 0.)
# (B) The pairing of a composition with its reversal does not give a signed product for three cuts:
#     (W(S)-W(S'))*(sbar(S)-m/2) < 0 for S = {1,12,16}, m = 20, lambda_s = y/(N-s).
import sys
from fractions import Fraction as Fr
from math import factorial

def a(j): return Fr(j ** (j - 1), factorial(j))

def first_part_mean(r, lam):
    # F[e] = total weight of compositions of the segment [e, r] (cuts strictly inside, factors lam[s] at cut s)
    # with weights a_part; G[e] = same total; we need sum over first part g: a_g * lam[g] * F[g] (g<r) or a_r (g=r)
    F = {r: Fr(1)}
    for e in range(r - 1, -1, -1):
        tot = a(r - e)
        for s in range(e + 1, r):
            tot += a(s - e) * lam[s] * F[s]
        F[e] = tot
    Z = F[0]
    num = a(r) * (a(r + 1) / a(r))
    for g in range(1, r):
        num += a(g) * lam[g] * F[g] * (a(g + 1) / a(g))
    return num / Z

def runA(r, k):
    N = k + r + 1
    lam = {i: Fr(k - 1, N - i - 1) for i in range(1, r)}
    hmin = Fr(k - 1, N - 2); hmid = Fr(k - 1) / (Fr(N - 1) - Fr(r, 2)); hpub = Fr(k - 1, N - 1)
    vals = [first_part_mean(r, lam)] + [first_part_mean(r, {i: h for i in range(1, r)}) for h in (hpub, hmin, hmid)]
    print("(A) r=%d k=%d: E_lambda'[phi(gamma_0)] = %.6f ; homogeneous: h=(k-1)/(N-1): %.6f, smallest factor: %.6f, midpoint factor: %.6f ;  E_lambda' <= E_mid ? %s" % (
        r, k, float(vals[0]), float(vals[1]), float(vals[2]), float(vals[3]), vals[0] <= vals[3]))

def runB():
    m, N, y = 20, 60, 30
    lam = lambda s: Fr(y, N - s)
    S = (1, 12, 16); S2 = tuple(sorted(m - s for s in S))
    W = lambda T: lam(T[0]) * lam(T[1]) * lam(T[2])
    def sbar(T):
        q = 3; pts = [0] + list(T) + [m]; t = [pts[i + 1] - pts[i] for i in range(q + 1)]
        return Fr(m, 2) + Fr(1, 2 * q * m) * sum((q + 2 - 2 * p) * t[p - 1] ** 2 for p in range(1, q + 2))
    print("(B) S=%s S'=%s: W(S)-W(S') = %.6e, sbar(S)-m/2 = %.4f, product negative: %s" % (S, S2, float(W(S) - W(S2)), float(sbar(S) - Fr(m, 2)), (W(S) - W(S2)) * (sbar(S) - Fr(m, 2)) < 0))

if __name__ == "__main__":
    for r, k in ((10, 30), (20, 60), (30, 120), (54, 265)):
        runA(r, k)
    runB()
