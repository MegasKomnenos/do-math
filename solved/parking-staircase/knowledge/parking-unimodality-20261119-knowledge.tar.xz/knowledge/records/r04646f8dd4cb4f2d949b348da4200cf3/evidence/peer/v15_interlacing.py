# -*- coding: utf-8 -*-
"""Peer (after resumption): test of a real-rootedness / interlacing property.

For fixed m let  Pi_q(N) := (N-1)(N-2)...(N-m+1) * [y^q] Lambda_m(y;N)
                          = sum_{S subset {1..m-1}, |S|=q} prod(a_parts) * prod_{s not in S} (N - s),
a polynomial in N of degree m-1-q (q = 0..m-1).  Then  (N - shat_{q+1}) = (T_{m,q+1}/T_{m,q}) * Pi_{q-1}(N)/Pi_q(N).
Question: are all zeros of Pi_q real, in [1, m-1], and do the zeros of Pi_q interlace those of Pi_{q-1}?
If so, Pi_q/Pi_{q-1} is (a constant times) the Stieltjes transform of a positive measure on [1,m-1], symmetric
about m/2, and the two-sided bound on shat_{q+1} - m/2 follows as in the case q=1.

Exact integer/rational coefficients via the recursion on the length
   Pi^{(m)}(y,N) = a_m (N-1)...(N-m+1) + y * sum_{s=1}^{m-1} a_{m-s} Pi^{(s)}(y,N) * (N-s-1)...(N-m+1);
zeros with mpmath.polyroots at high precision.
"""
from fractions import Fraction as Fr
from math import factorial
import mpmath as mp
import sys

mp.mp.dps = 60


def a(j):
    return Fr(j ** (j - 1), factorial(j))


def pmul(p, q):
    r = [Fr(0)] * (len(p) + len(q) - 1)
    for i, x in enumerate(p):
        if x:
            for j, y in enumerate(q):
                r[i + j] += x * y
    return r


def padd(p, q):
    n = max(len(p), len(q))
    return [(p[i] if i < len(p) else Fr(0)) + (q[i] if i < len(q) else Fr(0)) for i in range(n)]


def falling(lo, hi):
    """prod_{s=lo}^{hi} (N - s) as coefficient list (ascending powers of N)"""
    p = [Fr(1)]
    for s in range(lo, hi + 1):
        p = pmul(p, [Fr(-s), Fr(1)])
    return p


def build(mmax):
    """Pi[m][q] = coefficient list (ascending) of Pi_q for length m"""
    Pi = {}
    for m in range(1, mmax + 1):
        rows = [[Fr(0)] for _ in range(m)]
        rows[0] = [a(m) * c for c in falling(1, m - 1)]
        for s in range(1, m):
            tail = falling(s + 1, m - 1)
            for q in range(0, s):               # Pi^{(s)}_q contributes to q+1
                term = [a(m - s) * c for c in pmul(Pi[s][q], tail)]
                rows[q + 1] = padd(rows[q + 1], term)
        Pi[m] = rows
    return Pi


def roots(p):
    p = [c for c in p]
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    if len(p) <= 1:
        return []
    coeffs = [mp.mpf(c.numerator) / c.denominator for c in reversed(p)]
    return mp.polyroots(coeffs, maxsteps=2000, extraprec=400)


if __name__ == "__main__":
    mmax = int(sys.argv[1]) if len(sys.argv) > 1 else 14
    Pi = build(mmax)
    allok = True
    for m in range(3, mmax + 1):
        prev = None
        okm = True
        for q in range(0, m - 1):
            rt = roots(Pi[m][q])
            real = all(abs(mp.im(z)) < mp.mpf(10) ** -30 for z in rt)
            xs = sorted(mp.re(z) for z in rt)
            inside = all(1 - mp.mpf(10) ** -20 <= x <= m - 1 + mp.mpf(10) ** -20 for x in xs)
            simple = all(xs[i + 1] - xs[i] > mp.mpf(10) ** -20 for i in range(len(xs) - 1))
            inter = True
            if prev is not None:
                # zeros of Pi_q (deg d) must strictly interlace zeros of Pi_{q-1} (deg d+1): prev[i] < xs[i] < prev[i+1]
                inter = len(prev) == len(xs) + 1 and all(prev[i] < xs[i] < prev[i + 1] for i in range(len(xs)))
            sym = all(abs(xs[i] + xs[len(xs) - 1 - i] - m) < mp.mpf(10) ** -20 for i in range(len(xs)))
            if not (real and inside and simple and inter and sym):
                okm = False
                print(f"   m={m} q={q}: real={real} inside={inside} simple={simple} interlace={inter} symmetric={sym}")
                print("      zeros:", [mp.nstr(z, 8) for z in rt])
            prev = xs
        allok = allok and okm
        if m <= 8 or not okm:
            print(f"m={m}: {'all Pi_q real-rooted in [1,m-1], simple, symmetric about m/2, consecutive ones interlace' if okm else 'FAILS'}")
            if m in (5, 8) and okm:
                for q in range(0, m - 1):
                    print("     q=%d zeros:" % q, " ".join(mp.nstr(mp.re(z), 6) for z in sorted(roots(Pi[m][q]), key=lambda z: mp.re(z))))
    print("ALL OK up to m =", mmax if allok else "(failures above)")
