# -*- coding: utf-8 -*-
"""
t14: the explicit crossing criterion of ra98af63d (Lemma 4.1: conditions  t_low >= 0  and (4.1)) evaluated at
     R = rho(k)+1,  rho(k) = floor((3k/2)^{2/3})   (the first deficit beyond the strip of Theorem 10.1).
Purpose: to see from which k the published explicit criterion holds at this R (design of a closed-form proof
in the pattern of that record's Theorem 6.1).  Only the closed formulas of Lemma 4.1 are evaluated.
"""
import sys
from mpmath import mp, mpf, sqrt, exp, log, pi, zeta, floor
mp.dps = 30
c0 = 1 / sqrt(2 * pi)
Z32 = zeta(mpf(3) / 2)

def rho(k):
    r = int(floor((mpf(3) * k / 2) ** (mpf(2) / 3)))
    while 2 * mpf(r + 1) ** 1.5 <= 3 * k: r += 1
    while 2 * mpf(r) ** 1.5 > 3 * k: r -= 1
    return r

def lemma41(k, R):
    k = mpf(k); N = k + R
    abar = 5 / (2 * k); alow = 5 / (2 * k) - 4 / (3 * k * k)
    s0 = abar * R; q = (exp(s0) - 1 - s0) / s0 ** 2
    Sbar = 1 + c0 * (2 * sqrt(R - 1) - 1 + 2 * abar / 3 * mpf(R) ** 1.5 + 2 * q * abar ** 2 / 5 * mpf(R) ** 2.5)
    Ebar = mpf(5) * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * log((k + R + 1) / (k + 2))
    Gbar = mpf(R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * log((k + R) / (k + 1))
    tlow = 2 * exp(-1) * c0 * (1 - mpf(1) / (12 * R)) / sqrt(R + 1) - exp(-1) * abar * (exp(abar) + 1 + c0 * (2 * sqrt(R - 1) - 1)) \
           - exp(-1) * q * abar ** 2 * (1 + c0 * (mpf(2) / 3 * mpf(R) ** 1.5 + 2 * sqrt(R - 1) - 1))
    tbar = 2 * exp(-1) * c0 / sqrt(R - 1) - exp(-1) * alow * (2 + c0 * (2 * sqrt(R) - 2 - Z32 / 12))
    lhs = exp(-1) * (mpf(R) * (R + 1) / N - 1 - Sbar - Ebar)
    rhs = (tbar + exp(-1) * exp(abar) * (R + 1) / N) * (Hbar + 5 / k * Gbar)
    return tlow, lhs, rhs

if __name__ == "__main__":
    last_fail = None
    for k in range(265, 20001):
        R = rho(k) + 1
        tlow, lhs, rhs = lemma41(k, R)
        if not (tlow >= 0 and lhs > rhs): last_fail = k
    print("last k in [265,20000] where Lemma 4.1's conditions fail at R = rho(k)+1:", last_fail)
    for k in (265, 400, 535, 600, 650, 700, 750, 800, 900, 1000, 2000, 5000, 9999, 20000):
        R = rho(k) + 1
        tlow, lhs, rhs = lemma41(k, R)
        print(f"k={k} R={R} w={k**(1/3):.3f}: t_low={float(tlow):.5f}  lhs={float(lhs):.5f}  rhs={float(rhs):.5f}  lhs-rhs={float(lhs-rhs):+.5f}")
