import json, sys, io, os
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
base = "C:/math/.skill-workspace/parking-unimodality-20261119/knowledge/records"
want = {
 "r496399b680604ffda982aedf9ac9b480": ["p-X-evidence", "c-evidence", "p-general-identities", "c-thm-5-9", "c-prop-5-8", "p-composition-laws", "p-criterion-region"],
 "ra98af63d956e4b288dd1550e0a4853df": ["p-mono-cross-region", "p-two-criteria-overlap"],
}
for rec, ids in want.items():
    with open(os.path.join(base, rec, "record.json"), encoding="utf-8") as f:
        d = json.load(f)
    claims = d.get("claims", [])
    print("=== RECORD", rec, "n claims", len(claims), "ids:", [c.get("id") for c in claims])
    for c in claims:
        if c.get("id") in ids:
            print("--- CLAIM", c.get("id"))
            print(c.get("statement"))
            print()
