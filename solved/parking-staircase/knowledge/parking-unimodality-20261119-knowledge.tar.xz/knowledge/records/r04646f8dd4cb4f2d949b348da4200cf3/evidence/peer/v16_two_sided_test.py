# -*- coding: utf-8 -*-
"""Peer (after resumption): direct test, for lengths m up to MMAX (exact rationals), of

   (U)  shat_{q+1} - m/2  <=  C_q (N - m/2)/((N-1)(N-m+1))       [Conjecture 3.5 of the record]
   (L)  shat_{q+1} - m/2  >=  C_q/(N - m/2)                       [its natural companion; FALSE for m >= 40]

C_q = (q+1)(q+2) kappa_3(q)/(12 m),  N - shat_{q+1} = (T_{m,q+1}/T_{m,q}) * Pi_{q-1}(N)/Pi_q(N)
(polynomials of v15_interlacing.py).  All 1 <= q <= m-2 and nine values of N > m-1 for each m.
"""
from fractions import Fraction as Fr
from math import factorial
import sys
from v15_interlacing import build
from v14_shift_explicit import kappa3_closed


def T(m, q):
    return Fr(q, m) * Fr(m ** (m - q), factorial(m - q))


def peval(p, x):
    r = Fr(0)
    for c in reversed(p):
        r = r * x + c
    return r


if __name__ == "__main__":
    mmax = int(sys.argv[1]) if len(sys.argv) > 1 else 30
    Pi = build(mmax)
    lo = (10.0, None); hi = (0.0, None); badU = []; badL = []; cases = 0
    for m in range(3, mmax + 1):
        for q in range(1, m - 1):
            C = Fr((q + 1) * (q + 2)) * kappa3_closed(m, q) / (12 * m)
            for N in (Fr(m) - Fr(99, 100), Fr(m) - Fr(9, 10), Fr(m) - Fr(1, 2), Fr(m), Fr(11 * m, 10), Fr(3 * m, 2), Fr(2 * m), Fr(5 * m), Fr(50 * m)):
                Nm = T(m, q + 1) / T(m, q) * peval(Pi[m][q - 1], N) / peval(Pi[m][q], N)   # N - shat
                eps = (N - Fr(m, 2)) - Nm
                assert eps >= 0                      # Lemma 3.2
                r1 = eps * (N - Fr(m, 2)) / C
                r2 = eps * (N - 1) * (N - m + 1) / ((N - Fr(m, 2)) * C)
                cases += 1
                if r2 > 1:
                    badU.append((m, q, float(N), float(r2)))
                if r1 < 1:
                    badL.append((m, q, float(N), float(r1)))
                if float(r1) < lo[0]: lo = (float(r1), (m, q, float(N)))
                if float(r2) > hi[0]: hi = (float(r2), (m, q, float(N)))
    print("lengths 3 <= m <=", mmax, ";", cases, "cases (m, q, N)")
    print("  (U): violations:", len(badU), badU[:5], ";  largest ratio  eps*(N-1)(N-m+1)/((N-m/2) C_q) =", hi)
    print("  (L): violations:", len(badL), "; smallest m with a violation:", min((b[0] for b in badL), default=None),
          "; first few:", badL[:4], ";  smallest ratio  eps*(N-m/2)/C_q =", lo)
