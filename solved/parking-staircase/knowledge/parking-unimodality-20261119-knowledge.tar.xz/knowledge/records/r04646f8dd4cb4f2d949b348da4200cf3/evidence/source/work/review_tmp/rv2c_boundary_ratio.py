# Cor 13.2, boundary side: check
#   log(Lambda_r(k+2;N)/Lambda_{r+1}(k-1;N)) >= - r log(1+1/r) + mu_h/(2(k-1)) + mu_1 log(1+2/k)
# with N=k+r+1, exact rational chain sums (own DP), on first-layer sites.
from fractions import Fraction as F
from math import factorial, log
import time
t0 = time.time()
_a = {}
def a(j):
    if j not in _a:
        _a[j] = F(j ** (j - 1), factorial(j))
    return _a[j]
def Lam(m, y, N):
    """sum over compositions of m of prod a_gamma * prod_{cuts s} y/(N-s)  (total mass only)"""
    G = [F(0)] * (m + 1)
    G[0] = F(1)
    for j in range(1, m):
        G[j] = sum(G[i] * a(j - i) for i in range(j)) * F(y) / (N - j)
    return sum(G[i] * a(m - i) for i in range(m))
def T(m, q):
    return F(q, m) * F(m ** (m - q), factorial(m - q))
def mean_cuts(r, h):
    w = [T(r, q) * h ** (q - 1) for q in range(1, r + 1)]
    return sum(w[j] * j for j in range(r)) / sum(w)
sites = [(k, r) for k in range(3, 34) for r in range(2, k) if (k * 7 + r) % 5 == 0 or r == k - 1 or r == 2]
sites += [(60, 20), (100, 30), (150, 45), (265, 42), (265, 57), (265, 69)]
nbad = 0; worst = None
for (k, r) in sites:
    N = k + r + 1
    lhs = log(float(Lam(r, k + 2, N) / Lam(r + 1, k - 1, N)))
    h1 = F(k) / (k + 1 + F(r, 2)); h = F(k - 1, k + r)
    mu1 = float(mean_cuts(r, h1)); muh = float(mean_cuts(r, h))
    rhs = -r * log(1 + 1 / r) + muh / (2 * (k - 1)) + mu1 * log(1 + 2 / k)
    old = -r * log(1 + 1 / r) + float(mean_cuts(r, F(k, k + r))) * log(1 + 2 / k)      # published (A.4) form
    if lhs < rhs:
        nbad += 1
        print("VIOLATION", k, r, lhs, rhs)
    if worst is None or lhs - rhs < worst[0]:
        worst = (lhs - rhs, k, r)
    if (k, r) in [(60, 20), (265, 42), (265, 57), (265, 69)]:
        print((k, r), "k*(lhs-rhs)=%.4f   k*(lhs - published bound)=%.4f" % (k * (lhs - rhs), k * (lhs - old)))
print("sites:", len(sites), "violations:", nbad, "smallest slack lhs-rhs: %.3e at (k,r)=(%d,%d)" % worst)
print("time %.1fs" % (time.time() - t0))
