# -*- coding: utf-8 -*-
"""
t13: arithmetic of the proof of Theorem 11.1 (report section 11): explicit lower bound of
   G~(r,k) = k(1/(2r)-1/(3r^2)) - 5/2 + (1/2) mu0h(r,k) + 2(1-1/k) mu0(r,k) - (k/(k-1)) D_r
on the boundary k = r^{3/2}/u_a, for u_a = 4/3 and 3/2, r >= 42.
 (a) recomputes the constants of the hand derivation (linear bounds) with 30-digit arithmetic,
 (b) evaluates the exact G~ (with exact s_r) on r = 42..3000 and compares with the linear lower bound,
 (c) checks the auxiliary inequalities used (s_r <= sqrt(pi r/2) e^{1/(12r)} - 1/3;  D_r <= (3/2)(s_r - 7/5)).
Explicit elementary functions only.  The proof is the hand derivation in the report; this is its arithmetic check.
"""
from mpmath import mp, mpf, sqrt, pi, exp, log
mp.dps = 30
a = sqrt(pi / 2)

def s_r(r):
    s = mpf(0); t = mpf(1)
    for j in range(1, r + 1):
        t *= mpf(r - j + 1) / r; s += t
    return s
def D_of_s(r, s): return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))
def mu0X(X, r): 
    A = 4 + X
    return (sqrt(A * A + 12 * (r - 1)) - A) / 3

def exactG(r, k, s=None):
    s = s_r(r) if s is None else s
    X = mpf(r) ** 2 / k; Xh = mpf(r) * (r + 1) / (k - 1)
    return k * (mpf(1) / (2 * r) - mpf(1) / (3 * r * r)) - mpf(5) / 2 + mu0X(Xh, r) / 2 + 2 * (1 - mpf(1) / k) * mu0X(X, r) - k / (k - 1) * D_of_s(r, s)

x0 = sqrt(mpf(42))
print("x0 = sqrt(42) =", x0)
for ua, name in ((mpf(4) / 3, "4/3"), (mpf(3) / 2, "3/2")):
    print(f"=== u_a = {name}:  k* = x^3/u_a")
    kstar0 = x0 ** 3 / ua
    eps_k = 1 / kstar0                       # 1/k* at x0 (decreasing in x)
    fac_h = (1 + 1 / x0 ** 2) / (1 - eps_k)  # X_h <= ua * fac_h * x
    c = ua; ch = ua * fac_h
    A, B = c * c + 12, 8 * c
    Ah, Bh = ch * ch + 12, 8 * ch
    print(f"  1/k* <= {float(eps_k):.6f};  X_h <= {float(ch):.6f} x;  checks B^2/(4A) <= 4: {float(B*B/(4*A)):.4f}, {float(Bh*Bh/(4*Ah)):.4f}")
    m_s, m_c = (sqrt(A) - c) / 3, (B / (2 * sqrt(A)) - 4) / 3          # mu0  >= m_s x + m_c
    h_s, h_c = (sqrt(Ah) - ch) / 3, (Bh / (2 * sqrt(Ah)) - 4) / 3      # mu0h >= h_s x + h_c
    print(f"  mu0 >= {float(m_s):.6f} x {float(m_c):+.6f};   mu0h >= {float(h_s):.6f} x {float(h_c):+.6f}")
    e12 = exp(1 / (12 * mpf(42)))
    sbar_s, sbar_c = a * e12, -mpf(1) / 3                               # s_r <= sbar_s x + sbar_c
    d_s, d_c = mpf(3) / 2 * sbar_s, mpf(3) / 2 * (sbar_c - mpf(7) / 5)  # D_r <= d_s x + d_c
    kk = 1 + 1 / (kstar0 - 1)
    first_s, first_c = 1 / (2 * ua), -1 / (3 * ua * x0) - mpf(5) / 2    # k(1/(2r)-1/(3r^2)) - 5/2 at k = x^3/ua
    slope = first_s + h_s / 2 + 2 * (1 - eps_k) * m_s - kk * d_s
    const = first_c + h_c / 2 + 2 * (1 - eps_k) * m_c - kk * d_c
    print(f"  D_r <= {float(d_s):.6f} x {float(d_c):+.6f};  k/(k-1) <= {float(kk):.6f}")
    print(f"  linear lower bound:  Phi(x) >= {float(slope):.6f} x {float(const):+.6f};  at x0: {float(slope*x0+const):.6f}")
    worst = None
    for r in list(range(42, 400)) + list(range(400, 3001, 50)):
        x = sqrt(mpf(r)); k = x ** 3 / ua
        g = exactG(r, k); lin = slope * x + const
        assert g >= lin, (r, g, lin)
        if worst is None or g < worst[1]: worst = (r, g)
    print(f"  exact G~ on the boundary, r=42..3000: minimum {float(worst[1]):.6f} at r={worst[0]};  always >= linear bound")
print("auxiliary inequalities for r = 42..3000 (sampled):")
ok1 = ok2 = True
for r in list(range(42, 400)) + list(range(400, 3001, 50)):
    s = s_r(r); x = sqrt(mpf(r))
    ok1 &= (s <= a * x * exp(1 / (12 * mpf(r))) - mpf(1) / 3)
    ok2 &= (D_of_s(r, s) <= mpf(3) / 2 * (s - mpf(7) / 5))
print("  s_r <= sqrt(pi r/2) e^{1/(12r)} - 1/3 :", ok1, ";  D_r <= (3/2)(s_r - 7/5):", ok2)
