# -*- coding: utf-8 -*-
"""
t09: one targeted test of a statement made in report section 2 (reading) and 9.1:
     "the bottom-chain criterion (3.2) is expected to hold on the finite set
      G = {(n,k): 265<=k<=9999, r_c(k) <= n-k < floor(27k/100)}".
Tested only at the two edges of G in a few columns (near edge r=r_c(k), far edge r=floor(27k/100)-1).
Printed: k, r, k/r^1.5, log rho_r, log(B+/B-), ratio  (criterion (3.2) holds iff ratio < 1).
Chain formulas of r496399b6 (Prop. 5.8), Borel normalisation, 40-digit floats.  Not a proof step.
"""
import sys
from mpmath import mp, mpf, exp, log, loggamma
mp.dps = 40

def bor(j):
    j = mpf(j)
    return exp(-j + (j - 1) * log(j) - loggamma(j + 1))

def rc(k):
    r = 1
    while r ** 3 <= k * k:
        r += 1
    return r

def test(k, r):
    N = k + r + 1
    A = [mpf(0)] + [bor(j) for j in range(1, r + 2)]
    def u_top(y, top):
        u = [mpf(1)]
        y = mpf(y)
        for m in range(1, top + 1):
            acc = mpf(0)
            for s in range(m):
                acc += u[s] * A[m - s]
            u.append(y / (N - m) * acc)
        return u
    ur = {y: u_top(y, r)[r] for y in (k, k + 1, k + 2)}
    ukm1 = u_top(k - 1, r + 1)
    ur[k - 1] = ukm1[r]
    rho = (ur[k + 2] - 2 * ur[k + 1] + ur[k]) / (ur[k + 1] - 2 * ur[k] + ur[k - 1])
    Lam_r_k2 = mpf(N - r) / (k + 2) * ur[k + 2]
    Lam_r1_km1 = mpf(N - r - 1) / (k - 1) * ukm1[r + 1]
    # B+/B- = (1+1/k)^(k-2) * Lam_r(k+2)/Lam_{r+1}(k-1); the Borel factor e^{-r}/e^{-(r+1)} = e is restored
    lB = (k - 2) * log(1 + mpf(1) / k) + log(Lam_r_k2) - log(Lam_r1_km1) - 1
    lr = log(rho)
    print(f"k={k} r={r} k/r^1.5={k / r ** 1.5:.3f}  log rho_r={float(lr):.6e}  log(B+/B-)={float(lB):.6e}  ratio={float(lr / lB):.4f}")
    sys.stdout.flush()

if __name__ == "__main__":
    ks = [int(x) for x in sys.argv[1:]] or [265, 1000, 3000]
    for k in ks:
        test(k, rc(k))
        test(k, (27 * k) // 100 - 1)
