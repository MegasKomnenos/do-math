# -*- coding: utf-8 -*-
"""
t04: the tie/block ratio  Phi(k;r) = C_-(k+r,k)/B_-(k+r,k)  along a diagonal (fixed deficit r).

Tests one step of the argument in report section 5:  if Phi(k;r) <= 1 then Phi(k+1;r) <= Phi(k;r),
and the size of  k*(Phi(k+1)/Phi(k) - 1)  against the prediction  -1 + (T_C - T_B)/k.

First-layer chain formulas (published r496399b6, Prop. 5.8), N = k+r+1:
  K(y)/n!  = sum_{m=0}^r kappa(m) u_m(y),   u_m(y) = (y/(N-m)) sum_{s<m} u_s(y) a_{m-s},  u_0 = 1
  kappa(m) = a_{N-m} - sum_{m<m'<=r} a_{m'-m} a_{N-m'}
  B_-/n!   = (a_k/k) * Lambda_{r+1}(k-1),   Lambda_m(y) = ((N-m)/y) u_m(y)
To avoid overflow everything is carried in the Borel normalisation  (multiply a_j by e^{-j}).
"""
import sys
from mpmath import mp, mpf, exp, log, loggamma
mp.dps = 40

def bor(j):
    # e^{-j} j^{j-1}/j!
    j = mpf(j)
    return exp(-j + (j - 1) * log(j) - loggamma(j + 1))

def pieces(r, k):
    N = k + r + 1
    A = [mpf(0)] + [bor(j) for j in range(1, N + 1)]
    def u_list(y, top):
        u = [mpf(1)]
        for m in range(1, top + 1):
            u.append(mpf(y) / (N - m) * sum(u[s] * A[m - s] for s in range(m)))
        return u
    kap = [A[N - m] - sum(A[mm - m] * A[N - mm] for mm in range(m + 1, r + 1)) for m in range(r + 1)]
    def K(y):
        u = u_list(y, r)
        return sum(kap[m] * u[m] for m in range(r + 1))
    Cm = K(k + 1) - 2 * K(k) + K(k - 1)
    u = u_list(k - 1, r + 1)
    Lam = (mpf(N - r - 1) / (k - 1)) * u[r + 1]          # Lambda_{r+1}(k-1), Borel-normalised (e^{-(r+1)})
    Bm = (A[k] / k) * Lam                                # e^{-N} n!^{-1} B_-
    return Cm, Bm

if __name__ == "__main__":
    rs = [int(x) for x in sys.argv[1:]] or [5, 10, 18, 30]
    for r in rs:
        print(f"--- r = {r}")
        prev = None
        kmax = int(6 * r ** 1.5) + 12
        firstfall = None
        worst = None
        for k in range(r + 1, kmax + 1):
            Cm, Bm = pieces(r, k)
            phi = Cm / Bm
            if prev is not None:
                kk, pphi = prev
                step = kk * (phi / pphi - 1)
                if pphi <= 1:
                    if firstfall is None:
                        firstfall = kk
                    if worst is None or step > worst[1]:
                        worst = (kk, step)
                if kk in (r + 1, r + 2) or abs(pphi - 1) < 0.08 or kk % max(1, kmax // 12) == 0:
                    print(f"  k={kk:5d} k/r^1.5={kk / r ** 1.5:6.3f} Phi={float(pphi):9.5f}  k*(Phi(k+1)/Phi(k)-1)={float(step):8.4f}")
            prev = (k, phi)
        print(f"  first k with Phi<=1: {firstfall};  max of k*(Phi(k+1)/Phi(k)-1) over Phi(k)<=1: {worst}")
