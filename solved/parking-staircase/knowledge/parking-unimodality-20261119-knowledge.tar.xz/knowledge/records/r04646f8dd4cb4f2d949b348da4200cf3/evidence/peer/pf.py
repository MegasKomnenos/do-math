# -*- coding: utf-8 -*-
"""Peer's own implementation of the basic objects (independent of the producer's scripts).

Exact objects (Python integers / Fractions):
  A_table(nmax, k)        : list A[n] = #{PF of length n, max displacement <= k}, n=0..nmax   (last-car recursion)
  K_values(n, k, ys)      : frozen polynomial K_{n,k}(y) evaluated at the integers ys           (weighted last-car recursion)
  cross_exact(n, k)       : (d_{n,k}, d_{n,k+1}, C_-, C_+, B_-, B_+, S) from the definitions
First-layer chain formulas (Prop 5.8 of r496399b6), rationals or mpmath:
  Lambda(m, y, N, a)      : chain sum Lambda_m(y;N)
"""
from fractions import Fraction
from math import comb, factorial
from functools import lru_cache


def A_table(nmax, k):
    """A[n] = number of parking functions of length n with all displacements <= k (k>=0). A[0]=1."""
    A = [1] * (nmax + 1)
    for n in range(1, nmax + 1):
        s = 0
        for j in range(1, n + 1):
            s += comb(n - 1, j - 1) * min(j, k + 1) * A[j - 1] * A[n - j]
        A[n] = s
    return A


def weighted_table(nmax, w):
    """Z[n] = sum over PF of length n of prod of weights, where the last-car factor at spot j is w(j)
    (w(j) = j*g(j) in forest language).  Z[0]=1."""
    Z = [1] * (nmax + 1)
    for n in range(1, nmax + 1):
        s = 0
        for j in range(1, n + 1):
            s += comb(n - 1, j - 1) * w(j) * Z[j - 1] * Z[n - j]
        Z[n] = s
    return Z


def K_value(n, k, y):
    """Frozen polynomial K_{n,k}(y) = sum_F prod_{v: t_v>k} y/t_v, at a number y (int or Fraction)."""
    return weighted_table(n, lambda j: j if j <= k else y)[n]


def Z_value(n, y):
    """Z_n(y) = sum_F prod_v min(1, y/t_v) at an integer y>=0  (= A_{n,y-1})."""
    if y <= 0:
        return 0
    return weighted_table(n, lambda j: min(j, y))[n]


def cross_exact(n, k):
    """All quantities of the cross product at (n,k), 1<=k<=n-2, straight from the definitions."""
    Km1, K0, K1, K2 = (K_value(n, k, y) for y in (k - 1, k, k + 1, k + 2))
    Cm = K1 - 2 * K0 + Km1
    Cp = K2 - 2 * K1 + K0
    Bm = Km1 - Z_value(n, k - 1)
    Bp = K2 - Z_value(n, k + 2)
    # b_{n,l} = Z_n(l+1) - Z_n(l)
    b = lambda l: Z_value(n, l + 1) - Z_value(n, l)
    d0 = b(k) - b(k - 1)
    d1 = b(k + 1) - b(k)
    S = Bp * Cm - Bm * Cp
    return dict(d0=d0, d1=d1, Cm=Cm, Cp=Cp, Bm=Bm, Bp=Bp, S=S)


@lru_cache(maxsize=None)
def a_frac(j):
    """Cayley coefficient a_j = j^{j-1}/j!  (exact)."""
    return Fraction(j ** (j - 1), factorial(j))


def Lambda_list(mmax, y, N, a=a_frac, one=Fraction(1)):
    """[Lambda_0.., Lambda_mmax](y;N): Lambda_m = sum over compositions of m of prod a_part * prod_{cuts s} y/(N-s).
    Recursion on the last part: Lambda_m = a_m + sum_{s=1}^{m-1} (y/(N-s)) Lambda_s a_{m-s}.  (Lambda_0 unused.)"""
    L = [None] * (mmax + 1)
    for m in range(1, mmax + 1):
        v = a(m) * one
        for s in range(1, m):
            v += (y / (N - s) if not isinstance(y, int) else Fraction(y, N - s)) * L[s] * a(m - s)
        L[m] = v
    return L


def first_layer_exact(n, k):
    """Prop 5.8 quantities (exact rationals, divided by n!): K(y)/n! at y in {k-1..k+2}, B_-/n!, B_+/n!."""
    N = n + 1
    r = n - k
    assert k >= 3 and k + 2 <= n <= 2 * k - 1
    a = a_frac
    kap = {}
    for m in range(0, r + 1):
        kap[m] = a(N - m) - sum(a(mp - m) * a(N - mp) for mp in range(m + 1, r + 1))
    out = {}
    for y in (k - 1, k, k + 1, k + 2):
        L = Lambda_list(r + 1, y, N)
        K = kap[0] + sum(kap[m] * Fraction(y, N - m) * L[m] for m in range(1, r + 1))
        out[y] = (K, L)
    Bm = a(k) / k * out[k - 1][1][r + 1]
    Bp = a(k + 1) / (k + 1) * out[k + 2][1][r]
    Cm = out[k + 1][0] - 2 * out[k][0] + out[k - 1][0]
    Cp = out[k + 2][0] - 2 * out[k + 1][0] + out[k][0]
    return dict(Cm=Cm, Cp=Cp, Bm=Bm, Bp=Bp, S=Bp * Cm - Bm * Cp, kap=kap)


if __name__ == "__main__":
    # sanity: root table
    for n in range(1, 8):
        row = []
        prev = 0
        for l in range(n):
            A = A_table(n, l)[n]
            row.append(A - prev)
            prev = A
        print(n, row)
    # definitions vs Prop 5.8 at a few first-layer sites
    for (n, k) in [(7, 4), (9, 5), (12, 8), (15, 9), (20, 13), (26, 15)]:
        e = cross_exact(n, k)
        f = first_layer_exact(n, k)
        nf = factorial(n)
        ok = all(Fraction(e[x], nf) == f[x] for x in ("Cm", "Cp", "Bm", "Bp"))
        assert e["d0"] == e["Cm"] - e["Bm"] and e["d1"] == e["Cp"] - e["Bp"]
        print((n, k), "defs == Prop5.8:", ok, " S>0:", e["S"] > 0, " d0,d1 signs:", (e["d0"] > 0) - (e["d0"] < 0), (e["d1"] > 0) - (e["d1"] < 0))
