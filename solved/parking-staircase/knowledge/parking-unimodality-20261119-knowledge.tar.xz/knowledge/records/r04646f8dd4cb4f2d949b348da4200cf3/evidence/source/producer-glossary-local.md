# 이 보고 안의 용어

게시된 기록의 정의(얼린 다항식 $K_{n,k}$, $C_\mp$, $B_\mp$, 교차곱 $\mathcal S_{n,k}$, 첫 층, 곡선, 사슬 합 $\Lambda_m(y;N)$, 사슬 무게 $u_m$, 절단 인자를 가진 Cayley 합성의 법칙 $\mathbb P_\lambda$, 문턱 윤곽)는 다시 정의하지 않는다. r496399b680604ffda982aedf9ac9b480의 2절, 3절과 r3dc4f6e9f36d435d8ad1f57fd92ec352의 정의를 그대로 쓴다. 아래는 이 보고가 새로 들인 이름이고 모두 이 보고 안의 용어다. 전역 용어로 제안하는 것은 없다.

## 구획 (X↓)

노드 (X)의 진술을 $\lceil n/2\rceil\le k\le n-2$이고 $d_{n,k}=b_{n,k}-b_{n,k-1}\le0$인 자리로 제한한 것. 「모든 정수 $n\ge3$과 그런 모든 $k$에서 $\mathcal S_{n,k}>0$」. 이 세션이 등록한 구획이다.

## $r_c(k)$, 집합 $\mathcal G$, (CI$_{\rm mid}$)

$r_c(k)$는 $r^3>k^2$인 가장 작은 양의 정수 $r$(전선의 노드 (CI)의 기호). $\mathcal G:=\{(n,k):\ 265\le k\le9999,\ r_c(k)\le n-k<\lfloor27k/100\rfloor\}$. (CI$_{\rm mid}$)는 「$265\le k\le9999$인 모든 정수 $k$에 대해 $n=k+r_c(k)$일 때 $d_{n,k}>0$」. 둘 다 ra98af63d956e4b288dd1550e0a4853df의 주장 `p-ci-reduction`의 것을 그대로 쓴다.

## 열의 창, 먼 범위, (F$^{>}$)

자리 $(n,k)$가 **열의 창 안**에 있다는 것은 $n-k\le\lfloor2k/5\rfloor+1$이라는 것이고(r6af349eb…의 따름 P1이 닿는 행), **먼 범위**는 $\lceil n/2\rceil\le k$이고 $n-k\ge\lfloor2k/5\rfloor+2$인 자리다. (F$^{>}$)는 「모든 정수 $n\ge301$과, $\lceil n/2\rceil\le k\le n-2$이고 $n-k\ge\lfloor2k/5\rfloor+2$인 모든 정수 $k$에서 $d_{n,k}>0$」. 따름 S4의 가정으로만 쓴다. 전선의 노드 (T$_R$)에 다른 세션이 등록한 「먼 범위」의 구획($5(n-k)>2k$에서 $d_{n,k}\ge0$)의 엄격한 꼴에서 한 행($n-k=\lfloor2k/5\rfloor+1$)을 뺀 것이다. **(T$_R$-먼)**은 그 등록된 구획의 진술 그대로, 곧 「모든 정수 $n\ge301$과, $\lceil n/2\rceil\le k\le n-1$이고 $5(n-k)>2k$인 모든 정수 $k$에서 $d_{n,k}\ge0$」이고 따름 S5의 가정으로만 쓴다.

## 둘째 차분 $\Delta^2$와 $\delta_q$

함수 $u$에 대해 $\Delta^2u(x):=u(x+1)-2u(x)+u(x-1)$. 실수 $x\ge1$, $q\ge2$에 대해 $\delta_q(x):=(x+1)^q-2x^q+(x-1)^q$, 곧 $y\mapsto y^q$의 둘째 차분.

## 사슬 하나의 곡률의 비 $\rho_m$, 맨 아래 사슬

첫 층의 자리 $(n,k)$, $N=n+1$, $r=n-k$, $2\le m\le r$에 대해 $\rho_m:=\Delta^2u_m(k+1)/\Delta^2u_m(k)$, 여기서 $u_m(y)=\frac y{N-m}\Lambda_m(y;N)$. r496399b6…의 7.6절의 기호와 같다. **맨 아래 사슬**은 $m=r$의 사슬, 곧 크기 $k+1$의 꼭짓점에서 끝나는 무거운 사슬이고 그 비가 $\rho_r$이다.

## 맨 아래 사슬의 판정

첫 층의 자리에서의 부등식 $\rho_r<B_+/B_-$, 곧 보고의 (3.2): $\dfrac{\Delta^2[y\Lambda_r](k+1)}{\Delta^2[y\Lambda_r](k)}<\bigl(1+\frac1k\bigr)^{k-2}\dfrac{\Lambda_r(k+2;N)}{\Lambda_{r+1}(k-1;N)}$. r496399b6…의 7.6절이 「항별 우위」라 부른 것과 같다. **((3.2)$|_{\mathcal G}$)**는 「집합 $\mathcal G$의 모든 자리에서 이 부등식이 성립한다」는 진술이고 따름 S5의 가정으로만 쓴다.

## $\mathbf P_\eta$, $\mathbf E_\eta$, $J$, $Q$, 끝 부분 $\gamma$, $\alpha$

첫 층의 자리 $(n,k)$를 고정하고 $N=n+1$, $r=n-k$로 둔다. 실수 $\eta>0$에 대해 $\mathbf P_\eta$는 절단 집합 $S\subseteq\{1,\dots,r-1\}$ 위의 확률측도로, $\mathbf P_\eta(S)$가 $\prod_{\text{부분}}a_{\text{부분}}\prod_{s\in S}\frac\eta{N-s}$에 비례한다(부분은 $S$가 정하는 $r$의 합성의 부분, $a_j=j^{j-1}/j!$). 곧 길이 $r$의 합성 위에서 문턱 윤곽 $\lambda_s=\eta/(N-s)$를 준 법칙 $\mathbb P_\lambda$다. $\mathbf E_\eta$는 그 평균. $J:=|S|$(절단 수), $Q:=J+1$(부분의 수), $\gamma:=r-\max(S\cup\{0\})$(**끝 부분**: 자리 $r$ 쪽 끝에 놓인 부분의 크기), $\alpha(g):=a_{g+1}/a_g=(1+\frac1g)^{g-1}$.

## $D(y)$

$P(y):=y\Lambda_r(y;N)$에 대해 $D(y):=y\,P'''(y)/P''(y)=\mathbf E_y\,Q(Q-1)(Q-2)/\mathbf E_y\,Q(Q-1)$ ($y>0$, $r\ge2$).

## 판정 함수 $\mathcal D$, $\mathcal B$

첫 층의 자리 $(n,k)$에 대해
$\mathcal D(n,k):=D(k+2)\log\frac k{k-1}$,
$\mathcal B(n,k):=(k-2)\log(1+\frac1k)-\log\bigl(\frac{k-1}{k+1}+\mathbf E_{k-1}\alpha(\gamma)\bigr)+\mathbf E_{k-1}J\cdot\log\frac k{k-1}+\mathbf E_kJ\cdot\log(1+\frac2k)$.
명제 4.2: $\log(C_+/C_-)\le\mathcal D$, $\log(B_+/B_-)\ge\mathcal B$.

## $g_1$, $g_2$

$g_1:=k\log\dfrac{B_-(n,k+1)}{B_-(n,k)}$, $g_2:=k\log\dfrac{B_+(n,k)}{B_-(n,k+1)}$. 합이 $k\log(B_+/B_-)$다. r496399b6…의 따름 2.5의 $(\mathrm Z_d)$가 $g_1>0$이고, $(\mathrm Y_d)$가 $k\log(C_+/C_-)\le g_2$다.

## 모양 가정 (H)

「$j\mapsto\mathbf P_\eta(J=j)/(j+1)$이 로그오목이다.」 r3dc4f6e9…의 9.1절이 작은 길이에서 관찰한 「$\mathbb P_\lambda(Q=q)/q$가 로그오목」과 같은 진술. 일반으로는 거짓이다(보고 4.4절의 반례 $(N,r,\eta)=(401,199,201)$).

## 초과, 꼭대기 무리, 창 무리, (A)족, (B)족, 포화 법칙 (5절의 어림에서만 쓴다)

첫 층의 자리에서 무거운 꼭짓점의 **초과**는 (크기)$-k$. **꼭대기 무리**는 가상 뿌리 가까이(여크기가 $r$보다 훨씬 작은 곳)에 있는 무거운 꼭짓점들, **창 무리**는 초과가 $k^{2/3}$의 차수 이하인 무거운 꼭짓점들. 얼린 다항식의 사슬 가운데 맨 아래 무거운 꼭짓점이 창 무리에 있는 것들이 **(A)족**, 꼭대기 무리에 있는 것들(무거운 꼭짓점이 없는 것 포함)이 **(B)족**이다. **포화 법칙**은 밀도가 $e^{-\beta\ell^{3/2}}$($\ell>0$, $\beta=2\sqrt2/3$)에 비례하는 법칙이고, 벌크에서 맨 아래가 고정된 사슬의 창 무리의 점의 수를 $k^{1/3}$으로 나눈 것의 선두 차수 법칙으로 나온다. 이 이름들은 증명 없는 어림을 적는 데만 쓰였다.

## $\Phi(k;r)$, $\mathbf E_C$, $\mathbf E_B$, $X$, $\omega$ (6절)

결손 $r\ge2$와 $k\ge\max(r+1,3)$에 대해 $\Phi(k;r):=C_-(k+r,k)/B_-(k+r,k)$. rbc6a3c2f…의 $\Theta_q(k)$와 $\Theta_{r+1}(k)=k\,\Phi(k;r)$로 이어진다. 사슬을 초과의 열 $\mathbf c=(j_1>\dots>j_q)$로 적을 때, $\mathbf E_C$와 $\mathbf E_B$는 명제 5.8의 $C_-$와 $B_-$의 합에서 $\mathbf c$의 항에 비례하는 확률측도, $X(\mathbf c):=\prod_i\frac{k(k+j_i)}{(k-1)(k+1+j_i)}$, $\omega(\mathbf c):=\frac{(k+1)(k-1)^2}{k^3}\cdot\frac{\alpha(k+j_q)}{\alpha(k)}\cdot\frac{\ell_{k+1}(j_q)}{\ell_k(j_q)}\cdot\frac{\delta_q(k+1)}{\delta_q(k)}\bigl(\frac{k-1}k\bigr)^{q-2}$, 여기서 $\ell_k(j):=\kappa_k(k+j)/a_{k+j}$.

## $\tau_m(h)$, $\Upsilon_r(h)$, $\mu$, $\mu_h$, $\mu_0(X)$ (10절)

$T_{m,q}$는 부분이 $q$개인 $m$의 합성들의 $\prod_{\text{부분}}a_{\text{부분}}$의 합(r496399b6…의 기호; $T_{m,q}=q\,m^{m-q-1}/(m-q)!$). $\tau_m(h):=\sum_{q=1}^mT_{m,q}h^{q-1}$, $\Upsilon_r(h):=\tau_{r+1}(h)/\tau_r(h)$(r496399b6… 부록 B.2의 $\Upsilon(h)$). $\mathbb P_h$는 $r$의 합성 위에서 모든 절단 인자가 $h$인 법칙이고 $\mu_h:=\mathbb E_h[Q-1]$. 첫 층의 자리 $(n,k)$, $r=n-k$에서는 $h=\frac{k-1}{k+r}$, $\rho=\frac k{k+r}$, $\mu:=\mathbb E_\rho[Q-1]$(게시된 $\mu(r,k)$)로 쓴다. $\mu_0(X):=\frac13\bigl(\sqrt{(4+X)^2+12(r-1)}-(4+X)\bigr)$이고 $X=\frac{r^2}k$, $X_h=\frac{r(r+1)}{k-1}$이다($\mu_0(X)$가 게시된 $\mu_0(r,k)$).

## 고친 판정식, $M_0$, $M_1$, $\tilde G$ (10절)

**고친 판정식**은 따름 10.3의 부등식 $k(\frac1{2r}-\frac1{3r^2})-\frac52+\frac12\mu_0(X_h)+2(1-\frac1k)\mu_0(X)-\frac k{k-1}D_r\ge0$이고 그 좌변이 $\tilde G(r,k)$다. $M_0(r,k)$는 게시된 명제 8.1의 판정식의 좌변($\tilde G$에서 $\frac12\mu_0(X_h)$를 뺀 것). $M_1(r,k):=k[(k-2)\log(1+\frac1k)-\log\Upsilon_r(h)]+k\mu_0(X)\log(1+\frac2k)-\frac{k}{k-1}D_r$는 $\Upsilon_r(h)$의 정확한 값을 넣은 꼴이고 표 4에서만 쓴다.

## $\varrho(k)$, $\mathcal G_2$, (C″) (10.6절)

$\varrho(k):=\lfloor(3k/2)^{2/3}\rfloor$, 곧 $2r^{3/2}\le3k$인 가장 큰 정수 $r$. $\mathcal G_2:=\{(n,k):\ 265\le k\le9999,\ \varrho(k)<n-k<\lfloor27k/100\rfloor\}$. (C″)는 「$265\le k\le9999$인 모든 정수 $k$에 대해, $k<n\le k+\varrho(k)+1$이고 $d_{n,k}>0$인 정수 $n$이 있다」. 따름 S4′, S5′의 가정으로만 쓴다.

## 극한 대상의 기호 (11절)

r496399b6…의 주장 `p-limit-form`의 기호를 그대로 쓴다($B$, $\bar B$, $\mathcal A_z$, $\psi$, $f$, $m_j$, $\beta_j$, $T$, $V$, $W$, $\lambda_C$, $\gamma$, $E(p,b)$, 부등식 (Y)). 이 보고가 더한 것은 $M:=\bar B_1$, $A:=\mathcal A_1$, $c:=\sqrt{2/\pi}$, $u:=z^{3/2}$, $\mu_j(u):=\mathbb E[M^je^{-uA}]$, $\nu_j(u):=\mathbb E[M^jAe^{-uA}]$, $h_{j,i}:=[w^i]((1+w)^{2/3}-1)^j(1+w)^{-2/3}$, $P_1(u):=2c-\frac74u+\frac{86}{63}cu^2$, $P_2(u):=c-\frac12u+\frac4{15}cu^2$, $L(u):=2e^{-\frac{11}5cu}$뿐이다. (11절의 $\mu_j$는 10절의 $\mu$, $\mu_h$, $\mu_0$과 다른 양이다.)

## $q_0(k)$, $\mathcal G_3$, (C‴) (12절)

$q_0(k):=\min\{n\ge k:\ d_{n,k}>0\}$(열 $k$의 교차 행; ra98af63d…와 r6af349eb…의 기호). $\mathcal G_3:=\{(n,k):\ 265\le k\le728,\ \varrho(k)<n-k<\lfloor27k/100\rfloor\}$($\mathcal G_2$ 가운데 $k\le728$인 부분). (C‴)는 「$265\le k\le728$인 모든 정수 $k$에 대해, $k<n\le k+\varrho(k)+1$이고 $d_{n,k}>0$인 정수 $n$이 있다」, 곧 (C″)의 $k\le728$의 몫. 따름 12.3의 가정으로만 쓴다. 12.2절의 $w=k^{1/3}$, $\varepsilon=1/w$, $\nu=(3/2)^{2/3}$, $\eta_1$, $q_1$, $\Theta$, $\Psi$는 그 증명 안에서만 쓰는 기호이고, ra98af63d…의 보조정리 4.1의 기호($\bar a$, $\underline a$, $s_0$, $q$, $c_0$, $\bar S$, $\bar{\mathsf E}$, $\bar H$, $\bar G$, $\underline t$, $\bar t$)는 그 기록의 것을 그대로 쓴다.

## 가운데 인자, $h_1$, $\mu_1$, $X_1$, $\tilde G_1$, $\bar s$, $\hat s_{q+1}$ (13절)

$m$의 합성 위의 문턱 윤곽 $\lambda_s=y/(N-s)$ ($1\le s\le m-1$)에 대해 **가운데 인자**는 $h:=y/(N-\frac m2)$, 곧 선분의 가운데 $s=\frac m2$에서의 인자다. 보조정리 13.1(가운데 인자의 견줌)은 $\mathbb P_\lambda$ 아래 토막 수 $Q$의 법칙이 인자 $h$의 균질한 법칙 $\mathbb P_h$의 것을 우도비 순서로 지배한다는 진술이다. 토막이 $q+1$개인 합성(자르는 점 $s_1<\dots<s_q$, 토막의 길이 $t_1,\dots,t_{q+1}$)에 대해 $\bar s$는 r496399b6…의 지우기 규칙이 지우는 점의 자리의 평균이고 $\bar s=\frac m2+\frac1{2qm}\sum_{p=1}^{q+1}(q+2-2p)t_p^2$이다. $\hat s_{q+1}$은 $\pi_{q+1}$을 $\prod_{s\in S}\lambda_s$로 다시 무게 준 법칙 아래 $\bar s$의 평균이다. 첫 층의 자리 $(n,k)$, $r=n-k$에서는 $m=r$, $y=k$, $N=n+1$로 써서 $h_1:=\frac k{k+1+r/2}$, $\mu_1:=\mathbb E_{h_1}[Q-1]$($r$의 합성 위), $X_1:=\frac{r(r+2)}{2k}=r(\frac1{h_1}-1)$이다. $\tilde G_1(r,k):=k(\frac1{2r}-\frac1{3r^2})-\frac52+\frac12\mu_0(X_h)+2(1-\frac1k)\mu_0(X_1)-\frac k{k-1}D_r$는 따름 13.2의 판정식의 좌변이고, 10절의 $\tilde G$에서 $X=\frac{r^2}k$를 $X_1$로 바꾼 것이다. 전역 용어로 제안하지 않는다(보조정리의 이름 「가운데 인자의 견줌」은 뒤의 연구가 보조정리 4.5와 구별해 가리킬 때 쓸 수 있다).

## $\varrho_2(k)$, $\mathcal F$ (13절)

$\varrho_2(k):=\lfloor(11k/5)^{2/3}\rfloor$, 곧 $5r^{3/2}\le11k$인 가장 큰 정수 $r$. $\mathcal F:=\{(n,k):\ n\ge301,\ \lceil n/2\rceil\le k\le10^8-1,\ n-k\ge\lfloor2k/5\rfloor+2\}$는 구획 (X↓)가 증명되지 않은 자리를 담는 유한 집합이다(따름 13.5 (마)). 13.4절의 $w$, $\varepsilon$, $\nu=(11/5)^{2/3}$, $\eta_1$, $q_1$, $L$, $\Theta$, $\Psi$, $g$, $x$, $z$와 13.3절의 $x$, $k_*$, $\Phi_1$, $\beta$는 그 증명 안에서만 쓰는 기호다(12.2절의 $\nu$, 10.3절의 $x$, $k_*$와 값이 다르다). 13절이 서면 $\mathcal G_2$, $\mathcal G_3$, (C″), (C‴)는 중간 단계의 기호로만 남는다.
