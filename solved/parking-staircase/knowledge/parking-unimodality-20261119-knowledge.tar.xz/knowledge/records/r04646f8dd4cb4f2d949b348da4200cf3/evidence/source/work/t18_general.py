# -*- coding: utf-8 -*-
"""
t18: the two closed-form chains of report sections 10 and 12 for a general strip width u_b:
  strip(ub, rmin):    linear lower bound of  G~(r, r^{3/2}/ub)  for r >= rmin        (pattern of section 10.3)
  crossing(ub, kmin): closed-form chain for Lemma 4.1 of ra98af63d at R = floor((ub k)^{2/3})+1, k >= kmin
                      (pattern of section 12.2), with a check against Lemma 4.1 itself on a range of k.
Usage:  python t18_general.py  <ub_num> <ub_den> <rmin> <kmin>
Explicit elementary formulas only; this is the arithmetic of hand derivations, not a proof step.
"""
import sys
from mpmath import mp, mpf, sqrt, exp, log, pi, zeta, floor, cbrt
mp.dps = 30
c0 = 1 / sqrt(2 * pi); Z32 = zeta(mpf(3) / 2); e1 = exp(-1); a_ = sqrt(pi / 2)

def s_r(r):
    s = mpf(0); t = mpf(1)
    for j in range(1, r + 1):
        t *= mpf(r - j + 1) / r; s += t
    return s
def D_of_s(r, s): return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))
def mu0X(X, r):
    A = 4 + X
    return (sqrt(A * A + 12 * (r - 1)) - A) / 3
def exactG(r, k):
    X = mpf(r) ** 2 / k; Xh = mpf(r) * (r + 1) / (k - 1)
    return k * (mpf(1) / (2 * r) - mpf(1) / (3 * r * r)) - mpf(5) / 2 + mu0X(Xh, r) / 2 + 2 * (1 - mpf(1) / k) * mu0X(X, r) - k / (k - 1) * D_of_s(r, s_r(r))

def strip(ua, rmin, verbose=True):
    x0 = sqrt(mpf(rmin)); kstar0 = x0 ** 3 / ua; eps_k = 1 / kstar0
    fac_h = (1 + 1 / x0 ** 2) / (1 - eps_k); c = ua; ch = ua * fac_h
    A, B = c * c + 12, 8 * c; Ah, Bh = ch * ch + 12, 8 * ch
    assert B * B / (4 * A) <= 4 and Bh * Bh / (4 * Ah) <= 4
    m_s, m_c = (sqrt(A) - c) / 3, (B / (2 * sqrt(A)) - 4) / 3
    h_s, h_c = (sqrt(Ah) - ch) / 3, (Bh / (2 * sqrt(Ah)) - 4) / 3
    sb_s = a_ * exp(1 / (12 * mpf(rmin))); sb_c = -mpf(1) / 3
    q2, q1_, q0_ = sb_s ** 2, 2 * sb_s * sb_c + mpf(3) / 5 * sb_s, sb_c ** 2 + mpf(3) / 5 * sb_c
    assert q2 <= mpf(8) / 5 and q1_ <= 0 and q0_ <= 0
    d_s, d_c = mpf(3) / 2 * sb_s, mpf(3) / 2 * (sb_c - mpf(7) / 5)
    kk = 1 + 1 / (kstar0 - 1)
    first_s, first_c = 1 / (2 * ua), -1 / (3 * ua * x0) - mpf(5) / 2
    slope = first_s + h_s / 2 + 2 * (1 - eps_k) * m_s - kk * d_s
    const = first_c + h_c / 2 + 2 * (1 - eps_k) * m_c - kk * d_c
    if verbose:
        print("[strip u<= %.4f, r>= %d] x0=%.6f  1/k*<= %.7f  X_h<= %.6f x  k/(k-1)<= %.6f" % (float(ua), rmin, float(x0), float(eps_k), float(ch), float(kk)))
        print("   mu0 >= %.6f x %+.6f; mu0h >= %.6f x %+.6f; sbar = %.6f x - 1/3; D_r <= %.6f x %+.6f" % (float(m_s), float(m_c), float(h_s), float(h_c), float(sb_s), float(d_s), float(d_c)))
        print("   (1/2)mu0h + 2(1-1/k*)mu0 >= %.6f x %+.6f;  D-term <= %.6f x %+.6f;  first: %.6f x %+.6f" % (float(h_s / 2 + 2 * (1 - eps_k) * m_s), float(h_c / 2 + 2 * (1 - eps_k) * m_c), float(kk * d_s), float(kk * d_c), float(first_s), float(first_c)))
        print("   Phi(x) >= %.6f x %+.6f;  at x0: %.6f" % (float(slope), float(const), float(slope * x0 + const)))
    return slope, const, x0

def rend(k, ub):
    r = int(floor((ub * k) ** (mpf(2) / 3)))
    while mpf(r + 1) ** 1.5 <= ub * k: r += 1
    while mpf(r) ** 1.5 > ub * k: r -= 1
    return r

def lemma41(k, R):
    k = mpf(k); N = k + R
    abar = 5 / (2 * k); alow = 5 / (2 * k) - 4 / (3 * k * k)
    s0 = abar * R; q = (exp(s0) - 1 - s0) / s0 ** 2
    Sbar = 1 + c0 * (2 * sqrt(R - 1) - 1 + 2 * abar / 3 * mpf(R) ** 1.5 + 2 * q * abar ** 2 / 5 * mpf(R) ** 2.5)
    Ebar = mpf(5) * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * log((k + R + 1) / (k + 2))
    Gbar = mpf(R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * log((k + R) / (k + 1))
    tlow = 2 * e1 * c0 * (1 - mpf(1) / (12 * R)) / sqrt(R + 1) - e1 * abar * (exp(abar) + 1 + c0 * (2 * sqrt(R - 1) - 1)) \
           - e1 * q * abar ** 2 * (1 + c0 * (mpf(2) / 3 * mpf(R) ** 1.5 + 2 * sqrt(R - 1) - 1))
    tbar = 2 * e1 * c0 / sqrt(R - 1) - e1 * alow * (2 + c0 * (2 * sqrt(R) - 2 - Z32 / 12))
    return tlow, mpf(R) * (R + 1) / N - 1 - Sbar - Ebar, tbar + e1 * exp(abar) * (R + 1) / N, Hbar + 5 / k * Gbar

def crossing(ub, kmin, kcheck=20000, verbose=True):
    nu = ub ** (mpf(2) / 3); w1 = cbrt(mpf(kmin)); eps1 = 1 / w1
    eta1 = 1 + eps1 ** 2 / nu; eta2 = 1 + 2 * eps1 ** 2 / nu
    s0max = mpf(5) / 2 * eps1 * (nu + eps1 ** 2); q1 = (exp(s0max) - 1 - s0max) / s0max ** 2
    A_lin = nu ** 2 - 2 * c0 * sqrt(nu)
    A_const = -nu ** 3 - 2 + c0 - mpf(5) / 3 * nu ** 1.5 * c0 * eta1 ** 1.5
    cA = mpf(5) * q1 / 2 * c0 * nu ** 2.5 * eta1 ** 2.5 + mpf(5) / 24 * nu ** 4 * eta1 ** 4
    eps_coef = (nu + nu ** 4 - cA) - nu * (nu + nu ** 4) * eps1
    a0 = 2 * e1 * c0 / sqrt(nu); kapA = ((1 - eps1 ** 2 / nu) ** -0.5 - 1) / eps1 ** 2
    B1 = e1 * mpf(5) / 2 * (1 - mpf(8) / 15 * eps1 ** 3)
    b_lin = B1 * 2 * c0 * sqrt(nu); b_quad = B1 * (2 - c0 * (2 + Z32 / 12))
    Cf = e1 * exp(mpf(5) / 2 * eps1 ** 3)
    th1 = a0 + Cf * nu; th2 = b_lin + Cf * nu ** 2; th3 = a0 * kapA - b_quad + Cf * (nu ** 3 + 2)
    g_eps = 2 * nu + nu ** 4 / 4 * eta2 ** 4; k3 = (eta1 ** 3 - 1) / eps1 ** 2
    psi_c = -nu ** 3 / 3 + mpf(5) / 3 * nu ** 3; psi_e2 = mpf(5) / 3 * nu ** 3 * k3 + mpf(5) / 2 * nu ** 2 * eta1 ** 2
    P = [th1 * nu ** 2 / 2, th1 * psi_c - th2 * nu ** 2 / 2, th1 * g_eps - th2 * psi_c + th3 * nu ** 2 / 2,
         th1 * psi_e2 - th2 * g_eps + th3 * psi_c, -th2 * psi_e2 + th3 * g_eps, th3 * psi_e2]
    L_lin, L_const, L_eps = e1 * A_lin, e1 * A_const, e1 * eps_coef
    ea = exp(mpf(5) / 2 * eps1 ** 3)
    t0 = a0; t2a = a0 * 13 / (12 * nu); s_e1 = e1 * mpf(5) / 2 * 2 * c0 * sqrt(nu); s_e2 = e1 * mpf(5) / 2 * (ea + 1 - c0)
    u_e2 = e1 * q1 * mpf(25) / 4 * c0 * mpf(2) / 3 * nu ** 1.5 * eta1 ** 1.5; u_e4 = e1 * q1 * mpf(25) / 4 * 2 * c0 * sqrt(nu); u_e5 = e1 * q1 * mpf(25) / 4 * (1 - c0)
    tl = lambda e: t0 - s_e1 * e - (t2a + s_e2 + u_e2) * e ** 2 - u_e4 * e ** 4 - u_e5 * e ** 5
    fin = lambda w: L_lin * w + (L_const - P[0]) + (L_eps - P[1]) / w
    if verbose:
        print("[crossing u_b=%.4f, k>= %d] nu=%.7f w1=%.6f eps1=%.7f eta1=%.7f eta2=%.7f q1=%.7f s0max=%.7f" % (float(ub), kmin, float(nu), float(w1), float(eps1), float(eta1), float(eta2), float(q1), float(s0max)))
        print("   nu^2=%.7f nu^3=%.7f nu^4=%.7f sqrt(nu)=%.7f nu^1.5=%.7f nu^2.5=%.7f" % (float(nu ** 2), float(nu ** 3), float(nu ** 4), float(sqrt(nu)), float(nu ** 1.5), float(nu ** 2.5)))
        print("   bracket >= %.6f w %+.6f %+.6f eps   (cA=%.6f, nu+nu^4=%.7f, nu(nu+nu^4)=%.7f)" % (float(A_lin), float(A_const), float(eps_coef), float(cA), float(nu + nu ** 4), float(nu * (nu + nu ** 4))))
        print("   Theta/eps <= %.6f - %.6f eps + %.6f eps^2   [a0=%.6f, a0*kapA=%.6f, b_lin=%.6f, b_quad=%.6f, Cf=%.6f, Cf*nu=%.6f, Cf*nu^2=%.6f, Cf*(nu^3+2)=%.6f]" % (float(th1), float(th2), float(th3), float(a0), float(a0 * kapA), float(b_lin), float(b_quad), float(Cf), float(Cf * nu), float(Cf * nu ** 2), float(Cf * (nu ** 3 + 2))))
        print("   Psi <= %.6f w + %.6f + %.6f eps + %.6f eps^2   [nu^4/4*eta2^4=%.6f]" % (float(nu ** 2 / 2), float(psi_c), float(g_eps), float(psi_e2), float(nu ** 4 / 4 * eta2 ** 4)))
        print("   product coefficients:", [round(float(x), 6) for x in P], " groups at eps1: %.4f, %.4f" % (float(P[2] + P[3] * eps1), float(P[4] + P[5] * eps1)))
        print("   e^-1 bracket >= %.6f w %+.6f %+.6f eps" % (float(L_lin), float(L_const), float(L_eps)))
        print("   final: %.6f w %+.6f %+.6f/w ; at w1: %.6f" % (float(L_lin), float(L_const - P[0]), float(L_eps - P[1]), float(fin(w1))))
        print("   t_low/eps >= %.6f - %.6f eps - %.6f eps^2 - %.6f eps^4 - %.6f eps^5 ; at eps1: %.6f   [parts: %.6f, %.6f, %.6f]" % (float(t0), float(s_e1), float(t2a + s_e2 + u_e2), float(u_e4), float(u_e5), float(tl(eps1)), float(t2a), float(s_e2), float(u_e2)))
    ok_struct = (P[2] + P[3] * eps1 <= 0) and (P[4] + P[5] * eps1 <= 0) and (L_eps - P[1] <= 0) and fin(w1) > 0 and tl(eps1) > 0
    bad = 0
    ks = list(range(kmin, kcheck + 1)) + [10 ** j for j in range(5, 13)] + [3 * 10 ** j for j in range(5, 12)]
    for k in ks:
        w = cbrt(mpf(k)); eps = 1 / w; R = rend(k, ub) + 1
        tlow, bracket, Theta, Psi = lemma41(k, R)
        cb = A_lin * w + A_const + eps_coef * eps
        ct = eps * (th1 - th2 * eps + th3 * eps ** 2)
        cp = nu ** 2 / 2 * w + psi_c + g_eps * eps + psi_e2 * eps ** 2
        if not (bracket >= cb and Theta <= ct and Psi <= cp and tlow >= eps * tl(eps) > 0 and Theta >= 0 and Psi >= 0 and ct * cp <= P[0] + P[1] * eps and e1 * cb > P[0] + P[1] * eps):
            bad += 1
    if verbose: print("   structural conditions ok: %s;  checked %d k against Lemma 4.1, failures: %d" % (ok_struct, len(ks), bad))
    return ok_struct and bad == 0

if __name__ == "__main__":
    un, ud, rmin, kmin = [int(x) for x in sys.argv[1:5]]
    ub = mpf(un) / ud
    slope, const, x0 = strip(ub, rmin)
    worst = None
    for r in list(range(rmin, 500)) + list(range(500, 3001, 50)):
        x = sqrt(mpf(r)); g = exactG(r, x ** 3 / ub); lin = slope * x + const
        assert g >= lin
        if worst is None or g < worst[1]: worst = (r, g)
    print("   exact G~ on the boundary, r=%d..3000: minimum %.6f at r=%d; always >= the linear bound" % (rmin, float(worst[1]), worst[0]))
    crossing(ub, kmin)
