# -*- coding: utf-8 -*-
"""t15b: closed-form lower bound of t_low/eps used in the proof of Theorem 12.1, and its check against Lemma 4.1."""
from mpmath import mp, mpf, sqrt, exp, pi, cbrt, floor
mp.dps = 30
c0 = 1 / sqrt(2 * pi); e1 = exp(-1); nu = (mpf(3) / 2) ** (mpf(2) / 3); eps1 = mpf(1) / 9
eta1 = 1 + eps1 ** 2 / nu
s0max = mpf(5) / 2 * eps1 * (nu + eps1 ** 2); q1 = (exp(s0max) - 1 - s0max) / s0max ** 2
a0 = 2 * e1 * c0 / sqrt(nu)
t_c0 = a0; t_e2a = a0 * 13 / (12 * nu)
ea = exp(mpf(5) / 2 * eps1 ** 3)
s_e1 = e1 * mpf(5) / 2 * 2 * c0 * sqrt(nu); s_e2 = e1 * mpf(5) / 2 * (ea + 1 - c0)
u_e2 = e1 * q1 * mpf(25) / 4 * c0 * mpf(2) / 3 * nu ** 1.5 * eta1 ** 1.5
u_e4 = e1 * q1 * mpf(25) / 4 * 2 * c0 * sqrt(nu); u_e5 = e1 * q1 * mpf(25) / 4 * (1 - c0)
print(f"t_low/eps >= {float(t_c0):.6f} - {float(s_e1):.6f} eps - {float(t_e2a + s_e2 + u_e2):.6f} eps^2 - {float(u_e4):.6f} eps^4 - {float(u_e5):.6f} eps^5")
f = lambda e: t_c0 - s_e1 * e - (t_e2a + s_e2 + u_e2) * e ** 2 - u_e4 * e ** 4 - u_e5 * e ** 5
print("value at eps=1/9:", float(f(eps1)))
def tlow(k, R):
    k = mpf(k); abar = 5 / (2 * k); s0 = abar * R; q = (exp(s0) - 1 - s0) / s0 ** 2
    return 2 * e1 * c0 * (1 - mpf(1) / (12 * R)) / sqrt(R + 1) - e1 * abar * (exp(abar) + 1 + c0 * (2 * sqrt(R - 1) - 1)) \
           - e1 * q * abar ** 2 * (1 + c0 * (mpf(2) / 3 * mpf(R) ** 1.5 + 2 * sqrt(R - 1) - 1))
def rho(k):
    r = int(floor((mpf(3) * k / 2) ** (mpf(2) / 3)))
    while 2 * mpf(r + 1) ** 1.5 <= 3 * k: r += 1
    while 2 * mpf(r) ** 1.5 > 3 * k: r -= 1
    return r
ok = True
for k in list(range(729, 6000)) + [10 ** j for j in range(4, 13)]:
    w = cbrt(mpf(k)); e = 1 / w; R = rho(k) + 1
    ok &= (tlow(k, R) >= e * f(e))
print("closed form <= t_low for all tested k:", ok)
