# The two coefficients that came out on the unsafe side when the *displayed rounded* constants
# (eta_1 <= 1.0143293, q_1 := 0.6326704, e^abar <= 1.009479) are used: recompute with exact sup values at eps_1.
from mpmath import mp, mpf, sqrt, exp, cbrt, pi
mp.dps = 40
nu = (mpf(11) / 5) ** (mpf(2) / 3)
c0 = 1 / sqrt(2 * pi)
e1 = 1 / cbrt(mpf(265))
em1 = exp(-1)
eta_exact = 1 + e1 ** 2 / nu
s0 = mpf(5) / 2 * e1 * (nu + e1 ** 2)
q_exact = (exp(s0) - 1 - s0) / s0 ** 2
eab_exact = exp(mpf(5) / 2 * e1 ** 3)
def Le(eta, q):
    return (nu + nu ** 4) - c0 * 5 * q / 2 * nu ** mpf(2.5) * eta ** mpf(2.5) - mpf(5) / 24 * nu ** 4 * eta ** 4
def Lc(eta):
    return -nu ** 3 - 2 + c0 - mpf(11) / 3 * c0 * eta ** mpf(1.5)
def te2(eta, q, eab):
    a0 = 2 * em1 * c0 / sqrt(nu)
    return mpf(13) / (12 * nu) * a0 + mpf(5) / 2 * em1 * (eab + 1 - c0) + mpf(25) / 4 * em1 * q * c0 * mpf(2) / 3 * nu ** mpf(1.5) * eta ** mpf(1.5)
print("L eps-coefficient: exact eta_1,q -> %s ; exact eta_1, q_1:=0.6326704 -> %s ; rounded eta_1, q_1 -> %s ; stated 5.639857" % (
    mp.nstr(Le(eta_exact, q_exact), 10), mp.nstr(Le(eta_exact, mpf("0.6326704")), 10), mp.nstr(Le(mpf("1.0143293"), mpf("0.6326704")), 10)))
print("L const: exact eta_1 -> %s ; rounded -> %s ; stated -7.935400" % (mp.nstr(Lc(eta_exact), 10), mp.nstr(Lc(mpf("1.0143293")), 10)))
print("t_low eps^2-coefficient: exact -> %s ; exact eta_1 & e^abar, q_1:=0.6326704 -> %s ; all rounded -> %s ; stated 2.495254" % (
    mp.nstr(te2(eta_exact, q_exact, eab_exact), 10), mp.nstr(te2(eta_exact, mpf("0.6326704"), eab_exact), 10),
    mp.nstr(te2(mpf("1.0143293"), mpf("0.6326704"), mpf("1.009479")), 10)))
# effect on the conclusions if the 'all rounded' values are used instead
gshift = em1 * (mpf("5.639857") - Le(mpf("1.0143293"), mpf("0.6326704"))) * e1
print("effect on g(eps_1) if the rounded-constant value were used: -%s  (margin 0.1088)" % mp.nstr(gshift, 3))
tshift = (te2(mpf("1.0143293"), mpf("0.6326704"), mpf("1.009479")) - mpf("2.495254")) * e1 ** 2
print("effect on t_low/eps bound at eps_1: -%s (margin 0.0156)" % mp.nstr(tshift, 3))
