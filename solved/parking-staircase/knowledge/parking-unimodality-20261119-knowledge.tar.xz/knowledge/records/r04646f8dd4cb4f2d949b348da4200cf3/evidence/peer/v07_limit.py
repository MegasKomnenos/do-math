# -*- coding: utf-8 -*-
"""Peer check of the producer's section 11 (limit form):
 (1) the coefficients h_{j,i} and the moment formula of Lemma 11.3 (sympy, exact), the listed values;
 (2) Lemma 11.4's values;  (3) the grid inequality of Theorem 11.1 (mpmath);
 (4) an independent Monte-Carlo estimate of a few mixed moments E[M^j A^l] (M = max of BM on [0,1], A = area under
     the running maximum), with the standard half-step correction for the discretised maximum."""
import sympy as sp, mpmath as mp, sys
w = sp.symbols('w')
def h(j, i):
    expr = ((1 + w) ** sp.Rational(2, 3) - 1) ** j * (1 + w) ** sp.Rational(-2, 3)
    return sp.series(expr, w, 0, i + 1).removeO().coeff(w, i)
gam = 2 * sp.sqrt(2) / 3
def EMA(j, l):
    return sp.simplify((-1) ** l * sp.factorial(l) * sp.factorial(j + l) * h(j, j + l) / (gam ** (j + l) * sp.gamma(sp.Rational(j + 3 * l, 2) + 1)))
c = sp.sqrt(2 / sp.pi)
vals = {(1,0): c, (2,0): 1, (3,0): 2*c, (1,1): sp.Rational(5,8), (2,1): sp.Rational(6,5)*c, (1,2): sp.Rational(16,21)*c,
        (3,1): sp.Rational(7,4), (3,2): sp.Rational(172,63)*c, (0,1): sp.Rational(2,3)*c, (0,2): sp.Rational(5,12), (0,3): sp.Rational(32,63)*c}
ok = True
for (j,l), v in vals.items():
    e = EMA(j,l)
    good = sp.simplify(e - v) == 0
    ok &= good
    print(f"E[M^{j} A^{l}] = {e}   listed {v}   {'OK' if good else 'MISMATCH'}")
print("h coefficients:", {(j,i): h(j,i) for (j,i) in [(1,1),(1,2),(1,3),(2,2),(2,3),(3,3),(3,4),(3,5)]})
# Lemma 11.4
ETV = (1 + 3) * EMA(1,1) - 2 * EMA(2,0)
ET2V = (1 + sp.Rational(3,2)) * EMA(2,1) - 1 * EMA(3,0)
ETV2 = (1 + 6) * EMA(1,2) - 4 * EMA(2,1)
print("E[TV] =", sp.simplify(ETV), " E[T^2 V] =", sp.simplify(ET2V), "(c =", c, ")  E[T V^2] =", sp.simplify(ETV2))
# Theorem 11.1 grid
mp.mp.dps = 30
cc = mp.sqrt(2 / mp.pi)
P1 = lambda u: 2*cc - mp.mpf(7)/4*u + mp.mpf(86)/63*cc*u*u
P2 = lambda u: cc - u/2 + mp.mpf(4)/15*cc*u*u
L = lambda u: 2*mp.e**(-mp.mpf(11)/5*cc*u)
grid = [0, 0.25, 0.40, 0.55, 0.70, 0.78, 0.80]
for a, b in zip(grid, grid[1:]):
    U = P1(a)*P2(a)
    print(f"  u in [{a},{b}]: U({a}) = {mp.nstr(U,7)} < L({b}) = {mp.nstr(L(b),7)} : {U < L(b)}")
    ok &= bool(U < L(b))
print("P1 decreasing until u =", mp.nstr((mp.mpf(7)/4)/(2*mp.mpf(86)/63*cc),6), "; P2 until", mp.nstr(mp.mpf(1)/2/(2*mp.mpf(4)/15*cc),6))
# direct fine check of the final inequality P1 P2 < L on (0,0.8]
worst = max((P1(mp.mpf(i)/2000)*P2(mp.mpf(i)/2000)/L(mp.mpf(i)/2000), i) for i in range(1, 1601))
print("max of P1*P2/L on (0,0.8] (grid 1/2000):", mp.nstr(worst[0], 8), "at u =", worst[1]/2000)
print("ALL OK" if ok else "PROBLEM")
if len(sys.argv) > 1 and sys.argv[1] == "mc":
    import numpy as np
    rng = np.random.default_rng(20261120)
    n = 4096; reps = 40000; batch = 2000
    acc = {k: 0.0 for k in [(1,1),(2,1),(3,1),(1,2),(3,2),(0,2)]}
    for _ in range(reps // batch):
        steps = rng.standard_normal((batch, n)) * np.sqrt(1.0 / n)
        B = np.cumsum(steps, axis=1)
        M = np.maximum.accumulate(np.maximum(B, 0), axis=1)
        # correction for discrete maximum: E(max_cont - max_disc) ~ 0.5826*sqrt(dt)
        Mc = M + 0.5826 * np.sqrt(1.0 / n)
        A = Mc.mean(axis=1)
        M1 = Mc[:, -1]
        for (j, l) in acc:
            acc[(j, l)] += float(np.sum(M1 ** j * A ** l))
    for (j, l), s in acc.items():
        print(f"  MC E[M^{j} A^{l}] ~ {s / reps:.4f}   formula {float(EMA(j, l)):.4f}")
