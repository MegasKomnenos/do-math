# -*- coding: utf-8 -*-
"""
t15: arithmetic check of the closed-form chain in the proof of Theorem 12.1 (report section 12):
     for k >= 729, R = rho(k)+1 satisfies the conditions of Lemma 4.1 of ra98af63d.
 (a) recomputes the constants of the hand derivation (30 digits),
 (b) for k = 729..20000 and samples up to 10^12 checks that every closed-form bound dominates the
     corresponding quantity of Lemma 4.1, and that the final inequality holds.
Only explicit elementary formulas.  The proof is the hand derivation; this guards its arithmetic.
"""
import sys
from mpmath import mp, mpf, sqrt, exp, log, pi, zeta, floor, cbrt
mp.dps = 30
c0 = 1 / sqrt(2 * pi); Z32 = zeta(mpf(3) / 2); e1 = exp(-1)
nu = (mpf(3) / 2) ** (mpf(2) / 3)
eps1 = mpf(1) / 9

def rho(k):
    r = int(floor((mpf(3) * k / 2) ** (mpf(2) / 3)))
    while 2 * mpf(r + 1) ** 1.5 <= 3 * k: r += 1
    while 2 * mpf(r) ** 1.5 > 3 * k: r -= 1
    return r

# ---- constants of the hand derivation
eta1 = 1 + eps1 ** 2 / nu
s0max = mpf(5) / 2 * eps1 * (nu + eps1 ** 2)
q1 = (exp(s0max) - 1 - s0max) / s0max ** 2
A_lin = nu ** 2 - 2 * c0 * sqrt(nu)                                  # coefficient of w in the left bracket
A_const = -nu ** 3 - 2 + c0 - mpf(5) / 2 * c0 * eta1 ** 1.5
cA = mpf(5) * q1 / 2 * c0 * nu ** 2.5 * eta1 ** 2.5 + mpf(5) / 24 * nu ** 4 * eta1 ** 4
pos1, pos2 = nu + nu ** 4, nu * (nu + nu ** 4)                        # (nu+nu^4)eps(1-nu eps)
eps_coef = (pos1 - cA) - pos2 * eps1
a0 = 2 * e1 * c0 / sqrt(nu)
kapA = ((1 - eps1 ** 2 / nu) ** -0.5 - 1) / eps1 ** 2
B1 = e1 * mpf(5) / 2 * (1 - mpf(8) / 15 * eps1 ** 3)
b_lin = B1 * 2 * c0 * sqrt(nu); b_quad = B1 * (2 - c0 * (2 + Z32 / 12))
Cf = e1 * exp(mpf(5) / 2 * eps1 ** 3)
th1 = a0 + Cf * nu; th2 = b_lin + Cf * nu ** 2; th3 = a0 * kapA - b_quad + Cf * (nu ** 3 + 2)
eta2 = 1 + 2 * eps1 ** 2 / nu
g_eps = 2 * nu + nu ** 4 / 4 * eta2 ** 4
k3 = (eta1 ** 3 - 1) / eps1 ** 2
psi_c = -nu ** 3 / 3 + mpf(5) / 3 * nu ** 3
psi_e2 = mpf(5) / 3 * nu ** 3 * k3 + mpf(5) / 2 * nu ** 2 * eta1 ** 2
P = [th1 * nu ** 2 / 2,
     th1 * psi_c - th2 * nu ** 2 / 2,
     th1 * g_eps - th2 * psi_c + th3 * nu ** 2 / 2,
     th1 * psi_e2 - th2 * g_eps + th3 * psi_c,
     -th2 * psi_e2 + th3 * g_eps,
     th3 * psi_e2]
print("nu =", nu, " q1 =", q1, " eta1 =", eta1)
print(f"left bracket >= {float(A_lin):.6f} w {float(A_const):+.6f} + {float(eps_coef):.6f} eps     (cA={float(cA):.6f})")
print(f"Theta/eps <= {float(th1):.6f} - {float(th2):.6f} eps + {float(th3):.6f} eps^2")
print(f"Psi <= {float(nu**2/2):.6f} w + {float(psi_c):.6f} + {float(g_eps):.6f} eps + {float(psi_e2):.6f} eps^2")
print("product coefficients (eps^0..eps^5):", [float(x) for x in P])
print(f"  eps^2+eps^3 part at eps1: {float(P[2] + P[3]*eps1):.6f} (<0 needed);  eps^4+eps^5 part: {float(P[4] + P[5]*eps1):.6f} (<0 needed)")
L_lin, L_const, L_eps = e1 * A_lin, e1 * A_const, e1 * eps_coef
print(f"final: {float(L_lin):.6f} w {float(L_const - P[0]):+.6f} {float(L_eps - P[1]):+.6f}/w > 0 ;  at w=9: {float(L_lin*9 + L_const - P[0] + (L_eps - P[1])/9):.6f}")

def lemma41(k, R):
    k = mpf(k); N = k + R
    abar = 5 / (2 * k); alow = 5 / (2 * k) - 4 / (3 * k * k)
    s0 = abar * R; q = (exp(s0) - 1 - s0) / s0 ** 2
    Sbar = 1 + c0 * (2 * sqrt(R - 1) - 1 + 2 * abar / 3 * mpf(R) ** 1.5 + 2 * q * abar ** 2 / 5 * mpf(R) ** 2.5)
    Ebar = mpf(5) * (R - 2) * (R - 1) * R * (R + 1) / (24 * k ** 3)
    Hbar = (R - 1) - k * log((k + R + 1) / (k + 2))
    Gbar = mpf(R * R - 1) / 2 - (k - 1) * (R - 1) + k * (k - 1) * log((k + R) / (k + 1))
    tlow = 2 * e1 * c0 * (1 - mpf(1) / (12 * R)) / sqrt(R + 1) - e1 * abar * (exp(abar) + 1 + c0 * (2 * sqrt(R - 1) - 1)) \
           - e1 * q * abar ** 2 * (1 + c0 * (mpf(2) / 3 * mpf(R) ** 1.5 + 2 * sqrt(R - 1) - 1))
    tbar = 2 * e1 * c0 / sqrt(R - 1) - e1 * alow * (2 + c0 * (2 * sqrt(R) - 2 - Z32 / 12))
    bracket = mpf(R) * (R + 1) / N - 1 - Sbar - Ebar
    Theta = tbar + e1 * exp(abar) * (R + 1) / N
    Psi = Hbar + 5 / k * Gbar
    return tlow, bracket, Theta, Psi

ks = list(range(729, 20001)) + [10 ** j for j in range(5, 13)] + [3 * 10 ** j for j in range(5, 12)]
bad = 0; worst = None
for k in ks:
    w = cbrt(mpf(k)); eps = 1 / w; R = rho(k) + 1
    assert nu * w * w < R <= nu * w * w + 1 + mpf(10) ** -20
    tlow, bracket, Theta, Psi = lemma41(k, R)
    cb = A_lin * w + A_const + eps_coef * eps
    ct = eps * (th1 - th2 * eps + th3 * eps ** 2)
    cp = nu ** 2 / 2 * w + psi_c + g_eps * eps + psi_e2 * eps ** 2
    ok = (bracket >= cb) and (Theta <= ct) and (Psi <= cp) and (tlow > 0) and (Theta >= 0) and (Psi >= 0) and (ct * cp <= P[0] + P[1] * eps) \
         and (e1 * cb > P[0] + P[1] * eps)
    if not ok:
        bad += 1
        if bad < 5: print("FAIL", k, float(bracket - cb), float(ct - Theta), float(cp - Psi), float(tlow))
    m = e1 * bracket - Theta * Psi
    if worst is None or m < worst[1]: worst = (k, m)
print(f"checked {len(ks)} values of k; failures: {bad};  smallest (4.1)-margin of Lemma 4.1 itself: {float(worst[1]):.5f} at k={worst[0]}")
