# -*- coding: utf-8 -*-
"""Peer sanity scan (double precision) for Theorems 10.1 and 13.3 of the producer:
   Gtilde(r, (2/3) r^{3/2}) > 0 for r>=42 and Gtilde_1(r, (5/11) r^{3/2}) > 0 for r>=55,
   together with the stated linear minorants and the monotonicity in k (spot check).
   Also the peer's elementary bound  s_r <= sqrt(pi r/2)(1+1/(12r)) - 1/3  (all r in the range).
"""
import math, sys


def s_r(r):
    s = 0.0
    P = 1.0
    for j in range(1, r + 1):
        P *= (r - j + 1) / r
        s += P
        if P < 1e-18:
            break
    return s


def D_of(r, s):
    return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))


def mu0(X, r):
    return (math.sqrt((4 + X) ** 2 + 12 * (r - 1)) - (4 + X)) / 3


def Gt(r, k, D):
    X = r * r / k
    Xh = r * (r + 1) / (k - 1)
    return k * (1 / (2 * r) - 1 / (3 * r * r)) - 2.5 + mu0(Xh, r) / 2 + 2 * (1 - 1 / k) * mu0(X, r) - k / (k - 1) * D


def Gt1(r, k, D):
    X1 = r * (r + 2) / (2 * k)
    Xh = r * (r + 1) / (k - 1)
    return k * (1 / (2 * r) - 1 / (3 * r * r)) - 2.5 + mu0(Xh, r) / 2 + 2 * (1 - 1 / k) * mu0(X1, r) - k / (k - 1) * D


if __name__ == "__main__":
    RMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 30000
    m10 = (1e9, None); m13 = (1e9, None); sl10 = (1e9, None); sl13 = (1e9, None); gap = (1e9, None)
    rs = list(range(2, RMAX + 1)) + [10 ** 5, 3 * 10 ** 5, 10 ** 6]
    for r in rs:
        s = s_r(r)
        bound = math.sqrt(math.pi * r / 2) * (1 + 1 / (12 * r)) - 1 / 3
        assert s <= bound + 1e-12, ("elementary bound fails", r, s, bound)
        if bound - s < gap[0]:
            gap = (bound - s, r)
        D = D_of(r, s)
        # D_r <= 1.5 (s_r - 1)   (published Lemma 4.4)
        assert D <= 1.5 * (s - 1) + 1e-9
        x = math.sqrt(r)
        if r >= 42:
            v = Gt(r, 2 / 3 * x ** 3, D)
            lin = 0.322189 * x - 1.913297
            assert v >= lin > 0, ("Thm 10.1", r, v, lin)
            if v < m10[0]: m10 = (v, r)
            if v - lin < sl10[0]: sl10 = (v - lin, r)
        if r >= 55:
            v = Gt1(r, 5 / 11 * x ** 3, D)
            lin = 0.309746 * x - 2.034856
            assert v >= lin > 0, ("Thm 13.3", r, v, lin)
            if v < m13[0]: m13 = (v, r)
            if v - lin < sl13[0]: sl13 = (v - lin, r)
            # monotone in k (spot): larger k gives larger value
            assert Gt1(r, 5 / 11 * x ** 3 * 1.3, D) > v and Gt1(r, 5 / 11 * x ** 3 + 1, D) > v
    print("range r <=", RMAX, "+ samples")
    print("  elementary bound s_r <= sqrt(pi r/2)(1+1/(12r)) - 1/3 holds; smallest gap", gap)
    print("  min Gtilde(r,(2/3)r^1.5), r>=42:", m10, "; smallest (value - linear minorant):", sl10)
    print("  min Gtilde_1(r,(5/11)r^1.5), r>=55:", m13, "; smallest (value - linear minorant):", sl13)
    # how far does Gtilde_1 stay positive along a column? (k fixed)
    for k in (265, 400, 534, 1000, 9999):
        last = None
        r = 2
        while True:
            if r + 2 > k:
                break
            s = s_r(r); D = D_of(r, s)
            if Gt1(r, k, D) < 0 and r * r * r > k * k:
                break
            last = r
            r += 1
        print(f"  k={k}: Gtilde_1(r,k) >= 0 continuously up to r = {last}  (u = {last ** 1.5 / k:.3f}); rho2(k) = {int((11 * k / 5) ** (2 / 3))}")
    # for small r (2..54): at which u does Gtilde_1(r, r^1.5/u) change sign?  (shows why r>=55 is needed for u=11/5)
    print("  r : largest u (grid 0.05) with Gtilde_1(r, r^1.5/u) > 0")
    for r in (10, 20, 30, 42, 50, 54, 55, 60, 80, 120, 200, 500, 2000, 10000):
        s = s_r(r); D = D_of(r, s)
        u = 0.05; best = None
        while u < 6:
            k = r ** 1.5 / u
            if k > r + 2 and Gt1(r, k, D) > 0:
                best = u
            u += 0.05
        print(f"     r={r:6d}: {best}")
