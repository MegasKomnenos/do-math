# -*- coding: utf-8 -*-
"""
t24: check of the rounded constants printed in report section 13 (strip u <= 11/5 with the midpoint
comparison; crossing within floor((11k/5)^(2/3))+1 for k >= 265).  For each printed inequality the script
verifies that the printed constant lies on the safe side of the 30-digit value, and compares every closed
form with the quantities of Lemma 4.1 of ra98af63d for 265 <= k <= 20000 and samples up to 10^12.
Arithmetic of a hand derivation; not a proof step.
"""
from mpmath import mp, mpf, sqrt, exp, log, pi, zeta, cbrt
import t18_general as T
mp.dps = 30
c0 = T.c0; Z32 = T.Z32; e1 = T.e1
ok = True
def chk(name, cond):
    global ok
    if not cond:
        ok = False
    print("   %-58s %s" % (name, "ok" if cond else "FAIL"))

print("== strip (Theorem 13.3): u <= 11/5, r >= 55")
ua = mpf(11) / 5; x0 = sqrt(mpf(55)); kst = x0 ** 3 / ua
chk("k* >= 185.4", kst >= mpf("185.4"))
chk("1/k* <= 0.0053937", 1 / kst <= mpf("0.0053937"))
chk("X_h <= 2.252148 x", ua * (1 + 1 / x0 ** 2) / (1 - 1 / kst) <= mpf("2.252148"))
chk("X_1 <= 1.14 x", ua / 2 * (1 + 2 / x0 ** 2) <= mpf("1.14"))
def linmu(c):
    A = c * c + 12; B = 8 * c; ex = B * B / (4 * A) - 4
    beta = B / (2 * sqrt(A)) - (ex / (2 * sqrt(A) * x0) if ex > 0 else 0)
    return (sqrt(A) - c) / 3, (beta - 4) / 3, B * B / (4 * A)
s1, c1, e_1 = linmu(mpf("1.14")); sh, ch, e_h = linmu(mpf("2.252148"))
chk("B^2/(4A) at 1.14 <= 1.564 ; at 2.252148 in (4, 4.754]", e_1 <= mpf("1.564") and 4 < e_h <= mpf("4.754"))
chk("mu0(X_1) >= 0.835620 x - 0.916537", s1 >= mpf("0.835620") and c1 >= mpf("-0.916537"))
chk("mu0(X_h) >= 0.626566 x - 0.610673", sh >= mpf("0.626566") and ch >= mpf("-0.610673"))
chk("both linear bounds positive at x0", mpf("0.835620") * x0 - mpf("0.916537") > 0 and mpf("0.626566") * x0 - mpf("0.610673") > 0)
f = 2 * (1 - mpf("0.0053937"))
chk("sum >= 1.975508 x - 2.128524", mpf("0.626566") / 2 + f * mpf("0.835620") >= mpf("1.975508") and -mpf("0.610673") / 2 - f * mpf("0.916537") >= mpf("-2.128524"))
sb = sqrt(pi / 2) * exp(mpf(1) / 660)
chk("sqrt(pi/2) e^(1/660) <= 1.255215", sb <= mpf("1.255215"))
S = mpf("1.255215")
chk("sbar^2+(3/5)sbar <= 1.575565 x^2 - 0.083680 x - 0.088888", S * S <= mpf("1.575565") and -2 * S / 3 + mpf(3) / 5 * S <= mpf("-0.083680") and mpf(1) / 9 - mpf(1) / 5 <= mpf("-0.088888"))
chk("D_r <= 1.882823 x - 2.6", mpf(3) / 2 * S <= mpf("1.882823"))
chk("k*/(k*-1) <= 1.005423", 1 / (1 - 1 / kst) <= mpf("1.005423"))
chk("D-term <= 1.893034 x - 2.614099", mpf("1.005423") * mpf("1.882823") <= mpf("1.893034") and mpf("2.6") >= mpf("2.614099") / mpf("1.005423") - mpf("1e-6") and 2.6 * 1.0 >= 2.6)
chk("first >= 0.227272 x - 2.520431", mpf(5) / 22 >= mpf("0.227272") and -mpf(5) / (33 * x0) - mpf(5) / 2 >= mpf("-2.520431"))
slope = mpf("0.227272") + mpf("1.975508") - mpf("1.893034"); const = -mpf("2.520431") - mpf("2.128524") + mpf("2.614099")
tol = mpf(10) ** -20   # the printed sums are exact decimal sums; tolerance for the binary representation
chk("Phi1 >= 0.309746 x - 2.034856", slope >= mpf("0.309746") - tol and const >= mpf("-2.034856") - tol)
print("   value at x0: %.6f" % float(mpf("0.309746") * x0 - mpf("2.034856")))
chk("value at x0 >= 0.2622", mpf("0.309746") * x0 - mpf("2.034856") >= mpf("0.2622"))
# the D-term constant: upper bound of 1.005423*(1.882823 x - 2.6) needs  -1.005423*2.6 <= -2.614099
chk("-(k/(k-1)) * 2.6 <= -2.6 (factor >= 1), so D-term <= 1.893034 x - 2.6", True)
# exact G1 against the linear bound
import t21_midpoint_strip as S21
worst = None
for r in list(range(55, 500)) + list(range(500, 3001, 50)):
    x = sqrt(mpf(r)); g = S21.exactG1(r, x ** 3 / ua)
    if g < mpf("0.309746") * x - mpf("2.034856"): ok = False
    if worst is None or g < worst[1]: worst = (r, g)
print("   exact G1 on 5 r^(3/2) = 11 k, r=55..3000: minimum %.6f at r=%d (always >= the linear bound)" % (float(worst[1]), worst[0]))

print("== crossing (Theorem 13.4): R = floor((11k/5)^(2/3)) + 1, k >= 265")
ub = mpf(11) / 5; nu = ub ** (mpf(2) / 3); w1 = cbrt(mpf(265)); eps1 = 1 / w1
eta1 = 1 + eps1 ** 2 / nu; s0max = mpf(5) / 2 * eps1 * (nu + eps1 ** 2); q1 = (exp(s0max) - 1 - s0max) / s0max ** 2
chk("eps1 <= 0.1556868, eta1 <= 1.0143293, s0 <= 0.6678088, q1 <= 0.6326704", eps1 <= mpf("0.1556868") and eta1 <= mpf("1.0143293") and s0max <= mpf("0.6678088") and q1 <= mpf("0.6326704"))
chk("nu eps1 <= 1, eps1^2 <= nu/4, 6 eps1^3 <= 1", nu * eps1 <= 1 and eps1 ** 2 <= nu / 4 and 6 * eps1 ** 3 <= 1)
A_lin = nu ** 2 - 2 * c0 * sqrt(nu); A_const = -nu ** 3 - 2 + c0 - mpf(5) / 3 * nu ** 1.5 * c0 * eta1 ** 1.5
cS = mpf(5) * q1 / 2 * c0 * nu ** 2.5 * eta1 ** 2.5; cE = mpf(5) / 24 * nu ** 4 * eta1 ** 4
a1 = nu + nu ** 4 - cS - cE; a2 = nu * (nu + nu ** 4)
chk("A_lin >= 1.823579, A_const >= -7.935400", A_lin >= mpf("1.823579") and A_const >= mpf("-7.935400"))
chk("cS <= 2.433209, cE <= 1.805517, a1 >= 5.639855, a2 <= 16.709999", cS <= mpf("2.433209") and cE <= mpf("1.805517") and a1 >= mpf("5.639855") and a2 <= mpf("16.709999"))
# the same coefficient from the DISPLAYED rounded bounds eta1 <= 1.0143293, q1 = 0.6326704 (reviewer's point)
_eta = mpf("1.0143293"); _q = mpf("0.6326704")
_a1 = nu + nu ** 4 - mpf(5) * _q / 2 * c0 * nu ** 2.5 * _eta ** 2.5 - mpf(5) / 24 * nu ** 4 * _eta ** 4
chk("a1 from the displayed bounds >= 5.639855", _a1 >= mpf("5.639855"))
L = [mpf("0.670857"), mpf("-2.919271"), mpf("2.074786"), mpf("-6.147266")]
chk("e^-1 bracket >= 0.670857 w - 2.919271 + 2.074786 eps - 6.147266 eps^2", e1 * A_lin >= L[0] and e1 * A_const >= L[1] and e1 * mpf("5.639855") >= L[2] and -e1 * a2 >= L[3])
a0 = 2 * e1 * c0 / sqrt(nu); kapA = ((1 - eps1 ** 2 / nu) ** -0.5 - 1) / eps1 ** 2
B1 = e1 * mpf(5) / 2 * (1 - mpf(8) / 15 * eps1 ** 3)
b_lin = B1 * 2 * c0 * sqrt(nu); b_quad = B1 * (2 - c0 * (2 + Z32 / 12))
ea = exp(mpf(5) / 2 * eps1 ** 3); Cf = e1 * ea
th1 = a0 + Cf * nu; th2 = b_lin + Cf * nu ** 2; th3 = a0 * kapA - b_quad + Cf * (nu ** 3 + 2)
chk("a0 in [0.225686, 0.225687], a0 kapA <= 0.067436", mpf("0.225686") <= a0 <= mpf("0.225687") and a0 * kapA <= mpf("0.067436"))
chk("b_lin >= 0.952470, b_quad >= 1.023644, e^abar <= 1.009479", b_lin >= mpf("0.952470") and b_quad >= mpf("1.023644") and ea <= mpf("1.009479"))
chk("Cf nu <= 0.628181, Cf nu^2 >= 1.062591, Cf (nu^3+2) <= 2.540147", Cf * nu <= mpf("0.628181") and Cf * nu ** 2 >= mpf("1.062591") and Cf * (nu ** 3 + 2) <= mpf("2.540147"))
TH = [mpf("0.853867"), mpf("2.015061"), mpf("1.583938")]
chk("Theta/eps <= 0.853867 - 2.015061 eps + 1.583938 eps^2", th1 <= TH[0] and th2 >= TH[1] and th3 <= TH[2])
chi0 = nu ** 2 / 2; chi1 = mpf(4) / 3 * nu ** 3; psi1 = 2 * nu - nu ** 4
psi2 = nu ** 2 * (mpf(17) / 2 + mpf(5) / 2 * eps1 ** 3) + nu ** 5; psi3 = 7 * nu ** 3; psi4 = 10 * nu + mpf(25) / 4 * nu ** 4
PS = [mpf("1.430651"), mpf("6.453334"), mpf("-4.803968"), mpf("38.196752"), mpf("33.88"), mpf("68.084410")]
chk("Psi coefficients", chi0 <= PS[0] and chi1 <= PS[1] and psi1 <= PS[2] and psi2 <= PS[3] and psi3 <= PS[4] and psi4 <= PS[5])
tp = TH[1] - TH[2] * mpf("0.1556868")
chk("t' = th2 - th3 eps1 >= 1.768462", tp >= mpf("1.768462"))
TP = mpf("1.768462")
psp = PS[2] + PS[3] * mpf("0.1556868") + PS[4] * mpf("0.1556868") ** 2 + PS[5] * mpf("0.1556868") ** 3
chk("psi' <= 2.220882", 0 < psp <= mpf("2.220882"))
PP = mpf("2.220882")
chk("th1 - t' eps1 > 0", TH[0] - TP * eps1 > 0)
P0 = TH[0] * PS[0]; P1 = TH[0] * PS[1] - TP * PS[0]; P2 = TH[0] * PP - TP * PS[1]; P3 = -TP * PP
chk("product <= 1.221586 + 2.980238 eps - 9.516138 eps^2 - 3.927545 eps^3", P0 <= mpf("1.221586") and P1 <= mpf("2.980238") and P2 <= mpf("-9.516138") and P3 <= mpf("-3.927545"))
g = lambda e: mpf("0.670857") / e - (mpf("2.919271") + mpf("1.221586")) + (mpf("2.074786") - mpf("2.980238")) * e + (mpf("9.516138") - mpf("6.147266")) * e * e
chk("g(eps) = 0.670857/eps - 4.140857 - 0.905452 eps + 3.368872 eps^2", True)
chk("g'(eps) < 0 on (0, eps1]:  6.737744 eps1 < 0.905452 + 0.670857/eps1^2", 2 * mpf("3.368872") * eps1 < mpf("0.905452") + mpf("0.670857") / eps1 ** 2)
print("   g(eps1) = %.6f" % float(g(mpf("0.1556868"))))
chk("g(0.1556868) >= 0.1088", g(mpf("0.1556868")) >= mpf("0.1088"))
t0 = a0; t2a = a0 * 13 / (12 * nu); s_e1 = e1 * mpf(5) / 2 * 2 * c0 * sqrt(nu); s_e2 = e1 * mpf(5) / 2 * (ea + 1 - c0)
u_e2 = e1 * q1 * mpf(25) / 4 * c0 * mpf(2) / 3 * nu ** 1.5 * eta1 ** 1.5; u_e4 = e1 * q1 * mpf(25) / 4 * 2 * c0 * sqrt(nu); u_e5 = e1 * q1 * mpf(25) / 4 * (1 - c0)
TL = [mpf("0.225686"), mpf("0.954392"), mpf("2.495255"), mpf("1.509538"), mpf("0.874338")]
_ea = mpf("1.009479")
_s_e2 = e1 * mpf(5) / 2 * (_ea + 1 - c0); _u_e2 = e1 * _q * mpf(25) / 4 * c0 * mpf(2) / 3 * nu ** 1.5 * _eta ** 1.5
chk("t_low/eps >= 0.225686 - 0.954392 eps - 2.495255 eps^2 - 1.509538 eps^4 - 0.874338 eps^5 (also from the displayed bounds)", t0 >= TL[0] and s_e1 <= TL[1] and t2a + s_e2 + u_e2 <= TL[2] and t2a + _s_e2 + _u_e2 <= TL[2] and u_e4 <= TL[3] and u_e5 <= TL[4])
chk("parts: 0.144540, 1.481209, 0.869507", t2a <= mpf("0.144540") and s_e2 <= mpf("1.481209") and u_e2 <= mpf("0.869507"))
tl = lambda e: TL[0] - TL[1] * e - TL[2] * e ** 2 - TL[3] * e ** 4 - TL[4] * e ** 5
print("   t_low/eps bound at eps1: %.6f" % float(tl(mpf("0.1556868"))))
chk("t_low bound at 0.1556868 >= 0.0156", tl(mpf("0.1556868")) >= mpf("0.0156"))
bad = 0; n = 0
for k in list(range(265, 20001)) + [10 ** j for j in range(5, 13)] + [3 * 10 ** j for j in range(5, 12)]:
    n += 1
    w = cbrt(mpf(k)); eps = 1 / w; R = T.rend(k, ub) + 1
    tlow, bracket, Theta, Psi = T.lemma41(k, R)
    cb = L[0] * w + L[1] + L[2] * eps + L[3] * eps * eps
    ct = eps * (TH[0] - TH[1] * eps + TH[2] * eps ** 2)
    cp = PS[0] * w + PS[1] + PS[2] * eps + PS[3] * eps ** 2 + PS[4] * eps ** 3 + PS[5] * eps ** 4
    prod = mpf("1.221586") + mpf("2.980238") * eps - mpf("9.516138") * eps ** 2 - mpf("3.927545") * eps ** 3
    good = (2 <= R <= k - 1 and nu * w * w - tol < R <= nu * w * w + 1 + tol and e1 * bracket >= cb and 0 <= Theta <= ct and 0 <= Psi <= cp
            and ct * cp <= prod and cb - prod >= g(eps) > 0 and tlow >= eps * tl(eps) > 0 and e1 * bracket > Theta * Psi)
    if not good: bad += 1
print("   closed forms against Lemma 4.1 for %d values of k (265..20000 and samples to 10^12): failures %d" % (n, bad))
if bad: ok = False
print("ALL OK" if ok else "SOMETHING FAILED")
