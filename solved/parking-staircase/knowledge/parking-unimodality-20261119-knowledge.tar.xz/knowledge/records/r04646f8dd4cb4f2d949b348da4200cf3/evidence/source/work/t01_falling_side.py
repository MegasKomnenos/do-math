# -*- coding: utf-8 -*-
"""
t01: exact check tied to one step of the argument (see output/report.md, section 3).

Question tested: at first-layer positions (n,k) with d_{n,k} <= 0, how do the two
log-ratios of the cross product compare, and how large is the "gain" term
g1 = k*log[(1+1/k)^(k-2) * Lam_r(k)/Lam_{r+1}(k-1)]  relative to k/(2r) and to chain statistics?

All integers are exact (weighted last-car recursion); logs are floats at the end.
"""
import sys
from math import comb, log
from fractions import Fraction

def zrec(nmax, cfun):
    """Z_0..Z_nmax with Z_n = sum_j C(n-1,j) c_j Z_j Z_{n-1-j}."""
    Z = [1]
    for n in range(1, nmax + 1):
        s = 0
        for j in range(n):
            s += comb(n - 1, j) * cfun(j) * Z[j] * Z[n - 1 - j]
        Z.append(s)
    return Z

def true_Z(nmax, y):
    # Z_n(y) = #PF with all displacements < y
    return zrec(nmax, lambda j: min(j + 1, y))

def frozen_K(nmax, k, y):
    # K_{n,k}(y): weight 1 for t<=k, y/t for t>k
    return zrec(nmax, lambda j: (j + 1) if (j + 1) <= k else y)

def chain_stats(N, m, y):
    """Law of Q (number of parts) for compositions of m with weight
       prod a_gamma * prod_{cuts s} y/(N-s);  returns (Lambda_m(y), list P(Q=q), q=1..m).
       a_j = j^(j-1)/j!  (exact Fractions)."""
    from math import factorial
    a = [Fraction(0)] + [Fraction(j ** (j - 1), factorial(j)) for j in range(1, m + 1)]
    # W[s][q] = weight of compositions of s into q parts, including factor y/(N-s) at s if s is a cut (s<m)
    W = [dict() for _ in range(m + 1)]
    W[0][0] = Fraction(1)
    for s in range(1, m + 1):
        fac = Fraction(y, N - s) if s < m else Fraction(1)
        acc = {}
        for t in range(0, s):
            for q, w in W[t].items():
                acc[q + 1] = acc.get(q + 1, 0) + w * a[s - t]
        W[s] = {q: w * fac for q, w in acc.items()}
    tot = sum(W[m].values())
    return tot, {q: w / tot for q, w in W[m].items()}

def main(nlist):
    nmax = max(nlist) + 1
    Zc = {}
    def Zt(y):
        if y not in Zc:
            Zc[y] = true_Z(nmax, y)
        return Zc[y]
    print("n k r k/r^1.5 | d<=0 | D=k*log(C+/C-) G=k*log(B+/B-) D/G | g1 g2 | k/(2r) | mu=E_r[Q-1] Dt Esb")
    for n in nlist:
        N = n + 1
        for k in range(n // 2 + 1, n - 1):      # first layer: k+2<=n<=2k-1
            if not (k + 2 <= n <= 2 * k - 1):
                continue
            r = n - k
            Kk = {y: frozen_K(n, k, y)[n] for y in (k - 1, k, k + 1, k + 2)}
            Cm = Kk[k + 1] - 2 * Kk[k] + Kk[k - 1]
            Cp = Kk[k + 2] - 2 * Kk[k + 1] + Kk[k]
            Bm = Kk[k - 1] - Zt(k - 1)[n]
            Bp = Kk[k + 2] - Zt(k + 2)[n]
            d = Cm - Bm
            d1 = Cp - Bp
            assert d == Zt(k + 1)[n] - 2 * Zt(k)[n] + Zt(k - 1)[n]
            if d > 0:
                continue
            S = Bp * Cm - Bm * Cp
            D = k * (log(Cp) - log(Cm))
            G = k * (log(Bp) - log(Bm))
            L_r_k, lawr = chain_stats(N, r, k)
            L_r1_km1, _ = chain_stats(N, r + 1, k - 1)
            L_r_k2, _ = chain_stats(N, r, k + 2)
            g1 = k * ((k - 2) * log(1 + 1 / k) + log(L_r_k) - log(L_r1_km1))
            g2 = k * (log(L_r_k2) - log(L_r_k))
            mu = float(sum((q - 1) * p for q, p in lawr.items()))
            e2 = float(sum(q * (q - 1) * p for q, p in lawr.items()))
            e3 = float(sum(q * (q - 1) * (q - 2) * p for q, p in lawr.items()))
            e1 = float(sum(q * p for q, p in lawr.items()))
            Dt = e3 / e2 if e2 > 0 else 0.0
            Esb = e2 / e1
            print(f"{n} {k} {r} {k / r ** 1.5:.3f} | d1<0:{d1 < 0} S>0:{S > 0} | {D:.3f} {G:.3f} {D / G:.3f} | {g1:.3f} {g2:.3f} | {k / (2 * r):.3f} | {mu:.3f} {Dt:.3f} {Esb:.3f}")
        sys.stdout.flush()

if __name__ == "__main__":
    nlist = [int(x) for x in sys.argv[1:]] or [31, 40, 50, 60, 70, 80, 94]
    main(nlist)
