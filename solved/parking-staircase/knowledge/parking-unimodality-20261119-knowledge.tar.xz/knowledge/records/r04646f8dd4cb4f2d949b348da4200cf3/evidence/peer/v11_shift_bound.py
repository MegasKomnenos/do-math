# -*- coding: utf-8 -*-
"""Peer: brute-force check (exact rationals) of the two-sided statement on the mean position of the erased point
under the threshold profile lambda_s = y/(N-s) (remark after the midpoint lemma):

   0 <= E_{pi_{q+1}}[ W (sbar - m/2) ]
     <= 1/(2 q m (N-m+1)) * sum_{p<(q+2)/2} (q+2-2p)^2 E_{pi_{q+1}}[ W (t_p - t_{q+2-p})_+^2 (t_p + t_{q+2-p}) ],

W(S) = prod_{s in S} lambda_s.  The upper bound comes from the same swap of two parts as the lower bound:
for t_p > t_{p'} the swap moves p'-p cut points down by delta=t_p-t_{p'} and W(S^swap) >= W(S)(1 - delta (p'-p)/(N-m+1))."""
from fractions import Fraction as Fr
from itertools import combinations
from math import factorial
import random
def a(j): return Fr(j ** (j - 1), factorial(j))
def run(m, y, N):
    out = []
    for q in range(1, m):
        num = Fr(0); ub = Fr(0); den = Fr(0)
        for S in combinations(range(1, m), q):
            pts = (0,) + S + (m,)
            t = [pts[i + 1] - pts[i] for i in range(q + 1)]
            w = Fr(1)
            for x in t: w *= a(x)
            for s in S: w *= Fr(y) / (N - s)
            sb = Fr(1, 2 * q * m) * sum((q + 2 - 2 * p) * t[p - 1] ** 2 for p in range(1, q + 2))
            num += w * sb
            den += w
            for p in range(1, q + 2):
                pp = q + 2 - p
                if 2 * p < q + 2:
                    dlt = t[p - 1] - t[pp - 1]
                    if dlt > 0:
                        ub += w * (q + 2 - 2 * p) ** 2 * dlt * dlt * (t[p - 1] + t[pp - 1])
        ub = ub / (2 * q * m * (N - m + 1))
        assert 0 <= num <= ub, (m, y, N, q)
        out.append((q, float(num / den), float(ub / den)))
    return out
random.seed(3)
for (m, y, N) in [(6, Fr(20), Fr(27)), (8, Fr(30), Fr(39)), (9, Fr(12), Fr(22)), (10, Fr(60), Fr(71)), (10, Fr(3), Fr(91, 10)), (9, Fr(50), Fr(10 ** 4))]:
    res = run(m, y, N)
    print(f"m={m} y={float(y)} N={float(N)}: (q, shat-m/2, upper bound) =", " ".join(f"({q},{s:.4f},{u:.4f})" for q, s, u in res))
print("two-sided inequality holds in all cases")
