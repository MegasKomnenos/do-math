# Checks for Corollary 13.5 (case analysis / arithmetic) and sanity evaluation of the criteria of
# Theorems 10.1 and 13.3 on the boundary of their ranges (floats; D_r from the exact birthday sum).
import math, time
from math import isqrt
t0 = time.time()

def icbrt_floor(n):
    r = int(round(n ** (1 / 3)))
    while r ** 3 > n:
        r -= 1
    while (r + 1) ** 3 <= n:
        r += 1
    return r

def r_c(k):                 # smallest positive integer r with r^3 > k^2
    return icbrt_floor(k * k) + 1
def rA(k):                  # largest r with r^3 <= k^2  (k >= r^{3/2})
    return icbrt_floor(k * k)
def rB(k):                  # largest r with 2 r^{3/2} <= 3k  <=> 4 r^3 <= 9 k^2   (= rho(k))
    return icbrt_floor(9 * k * k // 4)
def rC(k):                  # largest r with 5 r^{3/2} <= 11k <=> 25 r^3 <= 121 k^2 (= rho_2(k))
    return icbrt_floor(121 * k * k // 25)

print("r_c(265) =", r_c(265), " 41^3=%d 42^3=%d 265^2=%d" % (41 ** 3, 42 ** 3, 265 ** 2))
print("54^{3/2} = %.4f < 397.5 = 3*265/2 ; 55^{3/2} = %.4f" % (54 ** 1.5, 55 ** 1.5))
print("rho(265) = %d, rho_2(265) = %d, floor(27*265/100) = %d, floor(2*265/5) = %d" % (rB(265), rC(265), 27 * 265 // 100, 2 * 265 // 5))

# (ga): every (k, r) with k>=265, 2<=r<=rho_2(k) is covered by Thm 5.9 [r<=rA], Thm 10.1 [42<=r<=rB] or Thm 13.3 [55<=r<=rC]
bad = 0
bad_window = 0
bad_27 = 0
for k in list(range(265, 2000001)):
    a, b, c = rA(k), rB(k), rC(k)
    # union of [2,a], [42,b], [55,c] must contain [2,c]
    ok = True
    top = a                                  # covered [2, top]
    if top < c:
        if 42 <= top + 1 and b >= top + 1:   # [42,b] takes over without a gap only if 42 <= top+1
            top = max(top, b)
        if top < c:
            if 55 <= top + 1:
                top = c
        if top < c:
            ok = False
    if not ok:
        bad += 1
        if bad < 5:
            print("  NOT COVERED", k, a, b, c)
    if c + 1 > 2 * k // 5 + 1:
        bad_window += 1
    if c + 1 > 27 * k // 100:
        bad_27 += 1
    if not (a < r_c(k) == a + 1):
        bad += 1
print("coverage failures for 265<=k<=2e6:", bad, "; rho_2(k)+1 > floor(2k/5)+1 for", bad_window, "values of k; rho_2(k)+1 > floor(27k/100) for", bad_27, "values")

# G = {265<=k<=9999, r_c(k) <= n-k < floor(27k/100)}: every site of G with n-k <= rho_2(k) is covered by (ga) (k>=265, r>=2): trivial.
# count of G as a consistency check with the published 10,701,339
cnt = 0
for k in range(265, 10000):
    lo, hi = r_c(k), 27 * k // 100 - 1
    if hi >= lo:
        cnt += hi - lo + 1
print("|G| =", cnt, "(published: 10,701,339)")

# ---------------------------------------------------------------- criteria on the boundary
def s_r(r):
    s = 0.0; p = 1.0
    for j in range(1, r + 1):
        p *= (r - j + 1) / r
        s += p
        if p < 1e-18:
            break
    return s
def D_r(r):
    s = s_r(r)
    return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))
def mu0(X, r):
    return (math.sqrt((4 + X) ** 2 + 12 * (r - 1)) - (4 + X)) / 3
def Gt(r, k):               # section 10 criterion
    X = r * r / k; Xh = r * (r + 1) / (k - 1)
    return k * (1 / (2 * r) - 1 / (3 * r * r)) - 2.5 + 0.5 * mu0(Xh, r) + 2 * (1 - 1 / k) * mu0(X, r) - k / (k - 1) * D_r(r)
def Gt1(r, k):              # section 13 criterion
    X1 = r * (r + 2) / (2 * k); Xh = r * (r + 1) / (k - 1)
    return k * (1 / (2 * r) - 1 / (3 * r * r)) - 2.5 + 0.5 * mu0(Xh, r) + 2 * (1 - 1 / k) * mu0(X1, r) - k / (k - 1) * D_r(r)

# (10.1): s_r <= sqrt(pi r/2) e^{1/(12 r)} - 1/3
worst = min(math.sqrt(math.pi * r / 2) * math.exp(1 / (12 * r)) - 1 / 3 - s_r(r) for r in range(1, 6001))
print("(10.1) check: min over 1<=r<=6000 of [rhs - s_r] = %.3e (must be >= 0)" % worst)

m10 = min((Gt(r, (2 / 3) * r ** 1.5), r) for r in range(42, 6001))
m13 = min((Gt1(r, (5 / 11) * r ** 1.5), r) for r in range(55, 6001))
print("Thm 10.1: min of G~(r, (2/3) r^1.5) over 42<=r<=6000: %.4f at r=%d ; value at r=42: %.4f" % (m10[0], m10[1], Gt(42, (2 / 3) * 42 ** 1.5)))
print("Thm 13.3: min of G~_1(r, (5/11) r^1.5) over 55<=r<=6000: %.4f at r=%d ; value at r=55: %.4f (text: 0.3594)" % (m13[0], m13[1], Gt1(55, (5 / 11) * 55 ** 1.5)))
x0 = math.sqrt(55)
print("linear lower bound at x0: 0.309746*x0-2.034856 = %.4f" % (0.309746 * x0 - 2.034856))
print("G~_1 at r in 42..54 on the line 5 r^1.5 = 11 k:", ["%d:%.3f" % (r, Gt1(r, (5 / 11) * r ** 1.5)) for r in range(42, 55)])

# pieces of the proof of Thm 13.3 at sample x (each closed-form piece vs. the true piece)
viol = 0
for r in range(55, 6001):
    x = math.sqrt(r); k = (5 / 11) * x ** 3
    p1 = k * (1 / (2 * r) - 1 / (3 * r * r)) - 2.5
    X1 = r * (r + 2) / (2 * k); Xh = r * (r + 1) / (k - 1)
    if not (p1 >= 0.227272 * x - 2.520431): viol += 1
    if not (Xh <= 2.252148 * x and X1 <= 1.14 * x): viol += 1
    if not (mu0(X1, r) >= 0.835620 * x - 0.916537): viol += 1
    if not (mu0(Xh, r) >= 0.626566 * x - 0.610673): viol += 1
    if not (0.5 * mu0(Xh, r) + 2 * (1 - 1 / k) * mu0(X1, r) >= 1.975508 * x - 2.128524): viol += 1
    if not (D_r(r) <= 1.882823 * x - 2.6): viol += 1
    if not (k / (k - 1) * D_r(r) <= 1.893034 * x - 2.614099): viol += 1
    if not (Gt1(r, k) >= 0.309746 * x - 2.034856): viol += 1
print("Thm 13.3 piecewise closed forms: violations over 55<=r<=6000:", viol)

# scaling remark after Cor 13.2
def lead(u):
    return 1 / (2 * u) + (math.sqrt(u * u + 12) - u) / 6 + (2 / 3) * (math.sqrt(u * u / 4 + 12) - u / 2) - 1.5 * math.sqrt(math.pi / 2)
def lead10(u):
    return 1 / (2 * u) + (5 / 6) * (math.sqrt(u * u + 12) - u) - 1.5 * math.sqrt(math.pi / 2)
print("leading-order criterion/sqrt(r): u=2: %.4f (text 0.44) ; u=2.2: %.4f ; u=3: %.4f (text 0.20) ; section-10 form at u=2.05: %.4f" % (
    lead(2), lead(2.2), lead(3), lead10(2.05)))
lo, hi = 2.0, 6.0
for _ in range(60):
    mid = (lo + hi) / 2
    if lead(mid) > 0: lo = mid
    else: hi = mid
print("   zero of the leading-order form of G~_1: u = %.4f" % lo)

# last deficit r for which the criterion holds continuously from the curve
for k in (265, 400, 534, 1000, 9999):
    def last(G):
        r = r_c(k)
        if G(r, k) < 0:
            return None
        while r + 1 <= k - 1 and G(r + 1, k) >= 0:
            r += 1
        return r
    l1, l0 = last(Gt1), last(Gt)
    print("k=%d: last r with G~_1>=0 from the curve: %s (u=%.2f) ; with section-10 G~: %s ; rho_2(k)=%d" % (k, l1, l1 ** 1.5 / k, l0, rC(k)))
print("time %.1fs" % (time.time() - t0))
