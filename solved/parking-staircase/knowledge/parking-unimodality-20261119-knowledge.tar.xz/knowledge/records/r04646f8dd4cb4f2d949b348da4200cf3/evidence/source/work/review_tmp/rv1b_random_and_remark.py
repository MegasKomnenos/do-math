# (a) Lemma 13.1 on random rational N (m<=9); (b) remark (na): 1/lambda_s positive, decreasing, concave
#     => same conclusion with h = lambda at the midpoint; (c) a NON-concave decreasing 1/lambda (convex) may fail.
from fractions import Fraction as F
from math import factorial
from itertools import combinations
import random, time
random.seed(20261120)
t0 = time.time()
_a = {}
def a(j):
    if j not in _a: _a[j] = F(j ** (j - 1), factorial(j))
    return _a[j]
def masses(m, lam):
    A = [F(0)] * (m + 1)
    for size in range(m):
        for S in combinations(range(1, m), size):
            pts = (0,) + S + (m,)
            w = F(1)
            for i in range(len(pts) - 1):
                w *= a(pts[i + 1] - pts[i])
            for s in S:
                w *= lam[s]
            A[size + 1] += w
    return A
def T(m, q):
    return F(q, m) * F(m ** (m - q), factorial(m - q))
def monotone(m, lam, h):
    A = masses(m, lam)
    r = [A[q] / (T(m, q) * h ** (q - 1)) for q in range(1, m + 1)]
    return all(r[i + 1] >= r[i] for i in range(m - 1))
bad = 0; n = 0
for m in range(2, 10):
    for _ in range(12):
        d = F(random.randint(1, 10 ** 6), random.randint(1, 10 ** 6))
        if random.random() < 0.3:
            d = F(1, random.randint(10 ** 3, 10 ** 9))
        N = F(m - 1) + d
        y = F(random.randint(1, 1000), random.randint(1, 1000))
        lam = {s: y / (N - s) for s in range(1, m)}
        n += 1
        if not monotone(m, lam, y / (N - F(m, 2))):
            bad += 1; print("VIOLATION", m, N, y)
print("(a) random rational N: cases %d violations %d" % (n, bad))
# (b) concave decreasing positive g(s)=1/lambda_s : g(s) = c - s^2 (c > (m-1)^2), g(s)=sqrt(c-s), g(s)=c-s-s^3/50
bad = 0; n = 0
import math
for m in range(3, 9):
    for c in (F((m - 1) ** 2) + F(1, 10), F(2 * m * m), F(100 * m * m)):
        g = lambda s, c=c: c - F(s) * F(s)
        lam = {s: 1 / g(s) for s in range(1, m)}
        h = 1 / g(F(m, 2))
        n += 1
        if not monotone(m, lam, h): bad += 1; print("VIOLATION concave", m, c)
    for c in (F(m * m * m), F(3 * m * m * m)):
        g = lambda s, c=c: c - F(s) - F(s) ** 3 / 50
        if g(m - 1) <= 0: continue
        lam = {s: 1 / g(s) for s in range(1, m)}
        h = 1 / g(F(m, 2))
        n += 1
        if not monotone(m, lam, h): bad += 1; print("VIOLATION concave2", m, c)
print("(b) concave decreasing 1/lambda: cases %d violations %d" % (n, bad))
# (c) convex decreasing g: g(s) = 1/(s+1)  (lambda_s = s+1, increasing): expect failures (shows concavity matters for the midpoint value)
fails = 0; n = 0
for m in range(3, 9):
    lam = {s: F(s + 1) for s in range(1, m)}
    h = F(m, 2) + 1
    n += 1
    if not monotone(m, lam, h): fails += 1
print("(c) convex example lambda_s=s+1, h=lambda(m/2): monotonicity fails in %d of %d cases (no claim in the text; for information)" % (fails, n))
print("time %.1fs" % (time.time() - t0))
