# -*- coding: utf-8 -*-
"""
t05: the "area" statistics behind the diagonal step (report section 5).

Fixed deficit r, level k, N = k+r+1.  Chains: heavy points at co-sizes 0<c_1<...<c_q<=r,
excess j_i = r+1-c_i (size k+j_i).  Area A+(c) = sum_i (j_i+1).
Pair measure   E_C : weight  W(c) * kappa_k(N-c_q) * delta_q(k) / prod(k+j_i),  delta_q(k)=(k+1)^q-2k^q+(k-1)^q
Thresh measure E_B : weight  W(c) * a_{j_q} * (k-1)^q / prod(k+j_i)             (threshold vertex of size k below c_q)
Reported:
  Phi = C/B, kPhi = k*C/B,
  EC_A = E_C[A+],  EB_A = E_B[A+],  ratio c* = EC_A/(k*Phi),  (EC_A-EB_A)/k,
  theta1 = E_C[A+]/(r*E_C[q]),  theta2 = r*rho_thr/A1 with rho_thr = B-mass / K-mass * k  (density of the threshold vertex),
  step = k*(Phi(k+1)/Phi(k)-1)   (exact, from t04)
Borel normalisation throughout.  Floats; a shape test for the inequality (AREA), not a proof step.
"""
import sys
from mpmath import mp, mpf, exp, log, loggamma
mp.dps = 40

def bor(j):
    j = mpf(j)
    return exp(-j + (j - 1) * log(j) - loggamma(j + 1))

def run(r, k):
    N = k + r + 1
    A = [mpf(0)] + [bor(j) for j in range(1, N + 1)]
    kap = [A[N - m] - sum(A[mm - m] * A[N - mm] for mm in range(m + 1, r + 1)) for m in range(r + 1)]
    # DP over chains with factor 1/(k+j) per point (parameter-free), keeping q and area moment
    # S[m][q] = (w, wa): chains ending with a point at m (q points), w = prod a_gap / prod (k+j_i), wa = w*area
    S = [dict() for _ in range(r + 1)]
    S[0][0] = (mpf(1), mpf(0))
    for m in range(1, r + 1):
        j = r + 1 - m
        acc = {}
        for s in range(0, m):
            g = A[m - s]
            for q, (w, wa) in S[s].items():
                w2 = w * g / (k + j)
                wa2 = (wa + w * (j + 1)) * g / (k + j)
                o = acc.get(q + 1, (mpf(0), mpf(0)))
                acc[q + 1] = (o[0] + w2, o[1] + wa2)
        S[m] = acc
    def delta(q, kk):
        return mpf(kk + 1) ** q - 2 * mpf(kk) ** q + mpf(kk - 1) ** q
    C = Cq = CA = mpf(0)
    B = BA = mpf(0)
    Kmass = K1 = mpf(0)
    for m in range(0, r + 1):
        j = r + 1 - m
        for q, (w, wa) in S[m].items():
            # K-measure at y=k
            Kmass += w * mpf(k) ** q * kap[m]
            K1 += q * w * mpf(k) ** q * kap[m]
            if q >= 2:
                c = w * kap[m] * delta(q, k)
                C += c
                Cq += q * c
                CA += wa * kap[m] * delta(q, k)
            # threshold vertex (size k) hanging below the point at m: gap j = r+1-m to excess 0
            b = w * A[j] * mpf(k - 1) ** q * (A[k] / k)
            B += b
            BA += wa * A[j] * mpf(k - 1) ** q * (A[k] / k)
    Phi = C / B
    out = dict(Phi=Phi, kPhi=k * Phi, EC_A=CA / C, EB_A=BA / B, ECq=Cq / C, A1=K1 / Kmass,
               rho_thr=k * B / Kmass)
    return out

if __name__ == "__main__":
    args = [int(x) for x in sys.argv[1:]]
    print("r k | Phi | E_C[A+] E_B[A+] | c*=E_C[A+]/(k Phi)  (E_C-E_B)/k | theta1=E_C[A+]/(r E_C[q])  theta2=r*rho_thr/A1 | E_C[q] A1")
    for i in range(0, len(args), 2):
        r, k = args[i], args[i + 1]
        o = run(r, k)
        print(f"{r} {k} | {float(o['Phi']):.4f} | {float(o['EC_A']):.3f} {float(o['EB_A']):.3f} | {float(o['EC_A'] / o['kPhi']):.3f} {float((o['EC_A'] - o['EB_A']) / k):.3f} | "
              f"{float(o['EC_A'] / (r * o['ECq'])):.3f} {float(r * o['rho_thr'] / o['A1']):.3f} | {float(o['ECq']):.3f} {float(o['A1']):.3f}")
