# -*- coding: utf-8 -*-
"""
t17: choosing the width u_b of a wider strip so that, for all k >= 535,
   (a) the explicit crossing bound (Lemma 4.1 of ra98af63d) holds at R = floor((u_b k)^{2/3}) + 1, and
   (b) the explicit corrected cross-product criterion G~(r,k) >= 0 holds for r_c(k) <= r <= floor((u_b k)^{2/3}).
Prints the smallest margins of (a) over k in [535, 20000] and of (b) on the boundary k = r^{3/2}/u_b, and checks
coverage directly for k in [535, 3000].  Explicit formulas only; design of a closed-form proof, not a proof step.
"""
from t14_K_at_strip_end import lemma41
from t11_refined_criterion import rc, D_r
from mpmath import mp, mpf, sqrt, floor
def mu0X(X, r):
    A = 4 + X
    return (sqrt(A * A + 12 * (r - 1)) - A) / 3
_D = {}
def Dr(r):
    if r not in _D: _D[r] = D_r(r)
    return _D[r]
def Gt(r, k):
    X = mpf(r) ** 2 / k; Xh = mpf(r) * (r + 1) / (k - 1)
    return k * (mpf(1) / (2 * r) - mpf(1) / (3 * r * r)) - mpf(5) / 2 + mu0X(Xh, r) / 2 + 2 * (1 - mpf(1) / k) * mu0X(X, r) - mpf(k) / (k - 1) * Dr(r)
def rend(k, ub):
    r = int(floor((ub * k) ** (mpf(2) / 3)))
    while mpf(r + 1) ** 1.5 <= ub * k: r += 1
    while mpf(r) ** 1.5 > ub * k: r -= 1
    return r
for ub in (mpf(8) / 5, mpf(33) / 20, mpf(17) / 10, mpf(7) / 4):
    worstL = None
    for k in range(535, 20001):
        R = rend(k, ub) + 1
        tlow, lhs, rhs = lemma41(k, R)
        m = lhs - rhs if tlow >= 0 else mpf(-9)
        if worstL is None or m < worstL[1]: worstL = (k, m, R)
    worstG = None
    for k in range(535, 3001):
        for r in range(rc(k), rend(k, ub) + 1):
            g = Gt(r, k)
            if worstG is None or g < worstG[2]: worstG = (k, r, g)
    print(f"u_b={float(ub):.3f}: min Lemma-4.1 margin over k in [535,20000]: {float(worstL[1]):+.4f} at k={worstL[0]} (R={worstL[2]});"
          f"  min G~ over k in [535,3000], r_c<=r<=end: {float(worstG[2]):+.4f} at (k,r)=({worstG[0]},{worstG[1]})")
