# -*- coding: utf-8 -*-
"""
t03: chain statistics behind the comparison  D~ <= 2*Jbar(r)  (report section 4).

First layer position (n,k), N=n+1, r=n-k.  Frozen at k, parameter y=k.
K-measure: chains 0<c_1<...<c_q<=r with weight prod a_gap * prod y/(N-c_i) * kappa(c_q)
   (q>=0; q=0 has weight kappa(0)).
Bridge 0->r : compositions of r with cut factors y/(N-s).
Quantities:
  A1 = E_K[chi], Esb = E_K[chi(chi-1)]/E_K[chi], Dt = E_K[chi(chi-1)(chi-2)]/E_K[chi(chi-1)]
  Jr = mean number of cuts of bridge 0->r,  c_r = E[J(J-1)]/Jr^2 for that bridge
  logconc: is the K-law of chi log-concave?  is p_j/(j+1) log-concave for the bridge law of J?
Floats (mpmath) are enough here; this is a test of the shape of an inequality, not a proof step.
"""
import sys
from mpmath import mp, mpf, factorial
mp.dps = 40

def a(j):
    return mpf(j) ** (j - 1) / factorial(j)

def stats(n, k, y=None):
    N = n + 1
    r = n - k
    if y is None:
        y = k
    y = mpf(y)
    A = [mpf(0)] + [a(j) for j in range(1, N + 1)]
    # U[m][q]: weight of chains from 0 to a point at m with q points (including m), factors y/(N-c)
    U = [dict() for _ in range(r + 2)]
    U[0][0] = mpf(1)
    for m in range(1, r + 2):
        fac = y / (N - m)
        acc = {}
        for s in range(0, m):
            for q, w in U[s].items():
                acc[q + 1] = acc.get(q + 1, mpf(0)) + w * A[m - s]
        U[m] = {q: w * fac for q, w in acc.items()}
    # kappa(m) = a_{N-m} - sum_{m<m'<=r} a_{m'-m} a_{N-m'}
    def kappa(m):
        return A[N - m] - sum(A[mp_ - m] * A[N - mp_] for mp_ in range(m + 1, r + 1))
    lawK = {}
    for m in range(0, r + 1):
        km = kappa(m)
        for q, w in U[m].items():
            lawK[q] = lawK.get(q, mpf(0)) + w * km
    tot = sum(lawK.values())
    lawK = {q: w / tot for q, w in lawK.items()}
    e1 = sum(q * p for q, p in lawK.items())
    e2 = sum(q * (q - 1) * p for q, p in lawK.items())
    e3 = sum(q * (q - 1) * (q - 2) * p for q, p in lawK.items())
    # bridge 0->r: number of cuts J = q-1 where q = number of points incl. r
    totr = sum(U[r].values())
    lawJ = {q - 1: w / totr for q, w in U[r].items()}
    Jr = sum(j * p for j, p in lawJ.items())
    J2 = sum(j * (j - 1) * p for j, p in lawJ.items())
    # log-concavity checks
    qs = sorted(lawK)
    lcK = all(lawK[q] ** 2 >= lawK[q - 1] * lawK[q + 1] * (1 - mpf(10) ** -30) for q in qs[1:-1])
    js = sorted(lawJ)
    v = {j: lawJ[j] / (j + 1) for j in js}
    lcJ = all(v[j] ** 2 >= v[j - 1] * v[j + 1] * (1 - mpf(10) ** -30) for j in js[1:-1])
    # density at r (rho(r)) and at r+1 for frozen-(k-1) structure are not needed here
    return dict(A1=e1, Esb=e2 / e1, Dt=e3 / e2, Jr=Jr, cr=J2 / Jr ** 2 if Jr > 0 else mpf(0), lcK=lcK, lcJ=lcJ)

if __name__ == "__main__":
    pos = []
    args = sys.argv[1:]
    for i in range(0, len(args), 2):
        pos.append((int(args[i]), int(args[i + 1])))
    print("n k r | A1=E_K[chi] Esb=E_K[chi(chi-1)]/E_K[chi] Dt | Jr c_r | Dt/(2Jr) Esb/Jr Dt/(1.5Esb) | logconc K-law, bridge p_j/(j+1)")
    for n, k in pos:
        s = stats(n, k)
        r = n - k
        print(f"{n} {k} {r} | {float(s['A1']):.3f} {float(s['Esb']):.3f} {float(s['Dt']):.3f} | {float(s['Jr']):.3f} {float(s['cr']):.3f} | "
              f"{float(s['Dt'] / (2 * s['Jr'])):.3f} {float(s['Esb'] / s['Jr']):.3f} {float(s['Dt'] / (1.5 * s['Esb'])):.3f} | {s['lcK']} {s['lcJ']}")
