# -*- coding: utf-8 -*-
"""Peer's elementary proof of  s_r <= sqrt(pi r/2) (1 + 1/(12 r)) - 1/3   (r >= 1), check of every step.

 s_r = sum_{j=1}^r r!/((r-j)! r^j) = int_0^oo e^{-t} (1+t/r)^{r-1} dt
     = r int_0^oo e^{-r w^2/2} (w/v(w)) dw,   where v=v(w)>=0 solves v - log(1+v) = w^2/2.
 Claim: w/v(w) <= 1 - w/3 + w^2/12 for all w>0.  Equivalent: F(w) := w^2/2 - V + log(1+V) >= 0 with
 V(w) = w/(1 - w/3 + w^2/12) = 12 w/(w^2 - 4 w + 12);  F(0)=0 and
 F'(w) = w^4 (w^3 - 12 w + 128) / ((w^2-4w+12)^2 (w^2+8w+12)) >= 0.
"""
import sympy as sp, mpmath as mp
w = sp.symbols('w', positive=True)
V = 12 * w / (w**2 - 4*w + 12)
F = w**2 / 2 - V + sp.log(1 + V)
Fp = sp.simplify(sp.diff(F, w))
target = w**4 * (w**3 - 12*w + 128) / ((w**2 - 4*w + 12)**2 * (w**2 + 8*w + 12))
print("F'(w) - claimed closed form =", sp.simplify(Fp - target))
print("1+V =", sp.factor(sp.together(1 + V)))
print("discriminant of w^2-4w+12:", sp.discriminant(w**2 - 4*w + 12, w), "(negative: denominator never vanishes)")
# minimum of w^3 - 12 w + 128 on w>=0 is at w=2: value
print("min of w^3-12w+128 on w>=0:", (w**3 - 12*w + 128).subs(w, 2))
# integral representation: exact check for small r
from fractions import Fraction as Fr
from math import factorial, comb
for r in range(1, 9):
    s = sum(Fr(factorial(r), factorial(r - j) * r**j) for j in range(1, r + 1))
    integral = sum(Fr(comb(r - 1, i) * factorial(i), r**i) for i in range(0, r))   # int e^{-t} (1+t/r)^{r-1} dt, termwise
    assert s == integral
print("integral representation s_r = int_0^oo e^{-t}(1+t/r)^{r-1} dt: exact for r<=8")
# numeric check of the pointwise inequality and of the final bound
mp.mp.dps = 30
def v_of_w(wv):
    # solve v - log(1+v) = w^2/2, v>=0
    f = lambda v: v - mp.log(1 + v) - wv**2 / 2
    return mp.findroot(f, wv + wv**2 / 3 + mp.mpf('1e-30'))
worst = None
for i in range(1, 4001):
    wv = mp.mpf(i) / 100
    v = v_of_w(wv)
    gap = (1 - wv/3 + wv**2/12) - wv / v
    assert gap >= 0, (wv, gap)
    if worst is None or gap < worst[0]:
        worst = (gap, wv)
print("pointwise inequality w/v <= 1 - w/3 + w^2/12 holds on w in (0,40]; smallest gap", mp.nstr(worst[0], 5), "at w =", worst[1])
for r in (1, 2, 5, 42, 55, 1000):
    s = mp.mpf(0); P = mp.mpf(1)
    for j in range(1, r + 1):
        P *= mp.mpf(r - j + 1) / r; s += P
    quad = r * mp.quad(lambda x: mp.e**(-r * x**2 / 2) * (x / v_of_w(x)) if x > 0 else mp.mpf(1), [0, 0.5, 2, 10, 60])
    bound = mp.sqrt(mp.pi * r / 2) * (1 + mp.mpf(1) / (12 * r)) - mp.mpf(1) / 3
    print(f"r={r}: s_r = {mp.nstr(s, 12)}, via w-integral {mp.nstr(quad, 12)}, bound {mp.nstr(bound, 12)}, gap {mp.nstr(bound - s, 5)}")
    assert s <= bound
