# -*- coding: utf-8 -*-
"""
t23: sanity check (small examples; 40-digit floats) of the criterion with the midpoint comparison (report section 14):
   Lambda_r(k+2)/Lambda_r(k) >= (1+2/k)^{mu1},  mu1 = E_{h1}[Q-1],  h1 = k/(k+1+r/2)   (r-compositions)
   k*log(B+C-/(B-C+)) >= M1(r,k) + (k/(2(k-1))) E_h[J] + 1/k,
   M1(r,k) = k(1/(2r)-1/(3r^2)) - 5/2 + 2(1-1/k) mu1 - (k/(k-1)) D_r,   h = (k-1)/(k+r).
True values from the chain formulas (5.5),(5.6) of r496399b6 (as in t12).  Not a proof step.
"""
import sys
from mpmath import mp, mpf, log
import t12_improved_criterion_check as P   # reuses bor, Tm, hom_mean, s_r, true_lhs (its table is printed again on import)
mp.dps = 40

def lam_ratio(k, r):
    N = k + r + 1
    A = [mpf(0)] + [P.bor(j) for j in range(1, N + 1)]
    def u_list(y, top):
        u = [mpf(1)]
        for m in range(1, top + 1):
            acc = mpf(0)
            for s in range(m): acc += u[s] * A[m - s]
            u.append(mpf(y) / (N - m) * acc)
        return u
    # Lambda_r(y) = (N-r)/y * u_r(y)
    return (mpf(N - r) / (k + 2) * u_list(k + 2, r)[r]) / (mpf(N - r) / k * u_list(k, r)[r])

print()
print("k r u | Lambda_r(k+2)/Lambda_r(k)  (1+2/k)^mu1  (1+2/k)^mu(rho)  holds | true k*log(B+C-/(B-C+))  new bound  old bound | holds")
for (k, r) in [(8, 4), (21, 10), (46, 14), (100, 25), (100, 34), (265, 42), (265, 54), (265, 62), (265, 70), (400, 62), (400, 92)]:
    h = mpf(k - 1) / (k + r); rho = mpf(k) / (k + r); h1 = mpf(k) / (k + 1 + mpf(r) / 2)
    Eh = P.hom_mean(r, h); Er = P.hom_mean(r, rho); E1 = P.hom_mean(r, h1)
    s = P.s_r(r); D = 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))
    base = k * (mpf(1) / (2 * r) - mpf(1) / (3 * r * r)) - mpf(5) / 2 - mpf(k) / (k - 1) * D + mpf(k) / (2 * (k - 1)) * Eh + mpf(1) / k
    new = base + 2 * (1 - mpf(1) / k) * E1; old = base + 2 * (1 - mpf(1) / k) * Er
    lr = lam_ratio(k, r); b1 = (1 + mpf(2) / k) ** E1; b0 = (1 + mpf(2) / k) ** Er
    lhs = P.true_lhs(k, r)
    print(f"{k} {r} {r**1.5/k:.2f} | {float(lr):.6f} {float(b1):.6f} {float(b0):.6f} {lr >= b1} | {float(lhs):.4f}  {float(new):.4f}  {float(old):.4f} | {lhs >= new}")
    sys.stdout.flush()
