# -*- coding: utf-8 -*-
"""Peer check (independent code) of:
 (1) Lemma 10.2  (birthday-law inequality)                       -- exact rationals
 (2) the homogeneous moment identity  E J^2 + (3+X) mu = 2(r-1) and E J(J-1) <= 1.5 mu^2 -- exact rationals
 (3) Cor 10.3 / Cor 13.2: the lower bounds for k*log(B+C-/(B-C+)) against the true value at first-layer sites
 (4) Theorem 10.1 / 13.3: sign of Gtilde(r, 2/3 r^{3/2}) and Gtilde_1(r, 5/11 r^{3/2}) for all r in a long range,
     and the stated linear minorants
 (5) inequality (10.1): s_r <= sqrt(pi r/2) e^{1/(12r)} - 1/3, and theta(r) in (1/3,1/2)
"""
from fractions import Fraction as Fr
from math import factorial, comb
import mpmath as mp
import sys

mp.mp.dps = 40


def T(m, q):
    """T_{m,q} = [z^m] T(z)^q = (q/m) m^{m-q}/(m-q)!"""
    return Fr(q, m) * Fr(m ** (m - q), factorial(m - q))


def hom_law(r, h):
    """law of J=Q-1 under P_h on compositions of r: prob prop. to T_{r,j+1} h^j"""
    w = [T(r, j + 1) * h ** j for j in range(r)]
    s = sum(w)
    return [x / s for x in w]


def moments(p):
    mu = sum(j * x for j, x in enumerate(p))
    m2 = sum(j * j * x for j, x in enumerate(p))
    return mu, m2


def tau(m, h):
    return sum(T(m, q) * h ** (q - 1) for q in range(1, m + 1))


def s_r(r):
    """s_r = E Q under the birthday law = sum_{j=1}^r (r)_j / r^j   (exact)"""
    s = Fr(0)
    P = Fr(1)
    for j in range(1, r + 1):
        P *= Fr(r - j + 1, r)
        s += P
    return s


def D_r_exact(r):
    s = s_r(r)
    return Fr(3) * ((r + 2) * s - 3 * r) / (2 * (r - s))


def s_r_mp(r):
    s = mp.mpf(0)
    P = mp.mpf(1)
    for j in range(1, r + 1):
        P *= mp.mpf(r - j + 1) / r
        s += P
        if P < mp.mpf(10) ** (-45):
            break
    return s


def D_r_mp(r):
    s = s_r_mp(r)
    return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))


def mu0(X, r):
    return (mp.sqrt((4 + X) ** 2 + 12 * (r - 1)) - (4 + X)) / 3


def Gt(r, k, D=None):
    """producer's Gtilde(r,k) (Cor 10.3)"""
    D = D_r_mp(r) if D is None else D
    X = mp.mpf(r) ** 2 / k
    Xh = mp.mpf(r) * (r + 1) / (k - 1)
    return k * (mp.mpf(1) / (2 * r) - mp.mpf(1) / (3 * r * r)) - mp.mpf(5) / 2 + mu0(Xh, r) / 2 + 2 * (1 - mp.mpf(1) / k) * mu0(X, r) - k / (k - 1) * D


def Gt1(r, k, D=None):
    """producer's Gtilde_1(r,k) (Cor 13.2)"""
    D = D_r_mp(r) if D is None else D
    X1 = mp.mpf(r) * (r + 2) / (2 * k)
    Xh = mp.mpf(r) * (r + 1) / (k - 1)
    return k * (mp.mpf(1) / (2 * r) - mp.mpf(1) / (3 * r * r)) - mp.mpf(5) / 2 + mu0(Xh, r) / 2 + 2 * (1 - mp.mpf(1) / k) * mu0(X1, r) - k / (k - 1) * D


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "all"

    if what in ("all", "1"):
        print("(1) Lemma 10.2 and (2) moment identity, exact rationals")
        worst = None
        for r in list(range(1, 26)) + [40, 60]:
            for h in [Fr(1, 50), Fr(1, 5), Fr(1, 2), Fr(3, 4), Fr(9, 10), Fr(99, 100), Fr(1)]:
                p = hom_law(r, h)
                mu, m2 = moments(p)
                lhs = tau(r + 1, h) / tau(r, h)
                rhs = Fr(r + 1, r) ** r * (1 - (1 - h) / (2 * h * (r + 1)) * mu)
                assert lhs <= rhs, ("Lemma 10.2 FAILS", r, h)
                X = r * (1 / h - 1)
                assert m2 + (3 + X) * mu == 2 * (r - 1), ("identity fails", r, h)
                assert (m2 - mu) <= Fr(3, 2) * mu * mu, ("EJ(J-1)<=1.5mu^2 fails", r, h)
                if r >= 2:
                    gap = float(rhs / lhs - 1)
                    if worst is None or gap < worst[0]:
                        worst = (gap, r, h)
        print("   all pass; smallest relative gap rhs/lhs-1 (r>=2):", worst)

    if what in ("all", "3"):
        print("(3) Cor 10.3 / 13.2 lower bounds vs truth (exact rationals from Prop 5.8 formulas)")
        from pf import first_layer_exact
        print("   (n,k)   r   u=r^1.5/k   k*log(B+C-/(B-C+))   bound10.3(mu,mu_h exact)   bound13.2(mu_1,mu_h exact)   Gt    Gt1")
        for (k, r) in [(8, 3), (12, 4), (20, 6), (30, 8), (30, 12), (45, 12), (45, 20), (60, 14), (60, 24), (80, 20), (80, 30)]:
            n = k + r
            f = first_layer_exact(n, k)
            true = k * mp.log(mp.mpf(f["Bp"].numerator) * f["Cm"].numerator * f["Bm"].denominator * f["Cp"].denominator
                              / (mp.mpf(f["Bp"].denominator) * f["Cm"].denominator * f["Bm"].numerator * f["Cp"].numerator))
            D = D_r_exact(r)
            rho = Fr(k, k + r)
            h = Fr(k - 1, k + r)
            h1 = Fr(k) / (k + 1 + Fr(r, 2))
            mu = moments(hom_law(r, rho))[0]
            muh = moments(hom_law(r, h))[0]
            mu1 = moments(hom_law(r, h1))[0]
            base = Fr(k) * (Fr(1, 2 * r) - Fr(1, 3 * r * r)) - Fr(5, 2) + Fr(1, k) - Fr(k, k - 1) * D + Fr(k, 2 * (k - 1)) * muh
            b103 = base + 2 * (1 - Fr(1, k)) * mu
            b132 = base + 2 * (1 - Fr(1, k)) * mu1
            fm = lambda q: mp.mpf(q.numerator) / q.denominator
            b103, b132, mu, muh, mu1 = fm(b103), fm(b132), fm(mu), fm(muh), fm(mu1)
            assert true >= b132 >= b103, ("bound violated", n, k)
            # mu >= mu0 checks
            assert mu >= mu0(mp.mpf(r) * r / k, r) - mp.mpf(10) ** -30 and mu1 >= mu0(mp.mpf(r) * (r + 2) / (2 * k), r) - mp.mpf(10) ** -30 and muh >= mu0(mp.mpf(r) * (r + 1) / (k - 1), r) - mp.mpf(10) ** -30
            print(f"   ({n},{k}) {r:3d} {r ** 1.5 / k:6.3f}   {float(true):9.4f}   {float(b103):9.4f}   {float(b132):9.4f}   {float(Gt(r, k)):8.4f} {float(Gt1(r, k)):8.4f}")

    if what in ("all", "4"):
        print("(4) Theorems 10.1 and 13.3: Gtilde at the strip end, and the linear minorants")
        mn10 = None
        mn13 = None
        for r in range(42, 20001):
            x = mp.sqrt(r)
            D = D_r_mp(r)
            if r >= 42:
                v = Gt(r, mp.mpf(2) / 3 * x ** 3, D)
                lin = mp.mpf("0.322189") * x - mp.mpf("1.913297")
                assert v >= lin > 0, ("Thm 10.1 chain", r, v, lin)
                if mn10 is None or v < mn10[0]:
                    mn10 = (v, r)
            if r >= 55:
                v1 = Gt1(r, mp.mpf(5) / 11 * x ** 3, D)
                lin1 = mp.mpf("0.309746") * x - mp.mpf("2.034856")
                assert v1 >= lin1 > 0, ("Thm 13.3 chain", r, v1, lin1)
                if mn13 is None or v1 < mn13[0]:
                    mn13 = (v1, r)
        print("   r in [42,20000]: min Gtilde(r,2/3 r^1.5)  =", mp.nstr(mn10[0], 8), "at r =", mn10[1])
        print("   r in [55,20000]: min Gtilde_1(r,5/11 r^1.5) =", mp.nstr(mn13[0], 8), "at r =", mn13[1])
        # where would the strips end if one did not round to linear minorants?  first r with Gt1(r, c r^1.5) > 0 for wider strips
        for c_num, c_den in [(11, 5), (5, 2), (3, 1), (16, 5)]:
            u = mp.mpf(c_num) / c_den
            first = None
            last_neg = None
            for r in range(2, 4000):
                x = mp.sqrt(r)
                kk = x ** 3 / u
                if kk <= r + 2:
                    continue
                if Gt1(r, kk) <= 0:
                    last_neg = r
            print(f"   strip u<={float(u):.2f}: last r<4000 with Gtilde_1(r, r^1.5/u) <= 0 is r = {last_neg}")

    if what in ("all", "5"):
        print("(5) inequality (10.1) and Ramanujan's theta")
        worst = None
        for r in list(range(1, 3001)) + [5000, 10000, 20000]:
            s = s_r_mp(r)
            bound = mp.sqrt(mp.pi * r / 2) * mp.e ** (mp.mpf(1) / (12 * r)) - mp.mpf(1) / 3
            assert s <= bound, ("(10.1) fails", r)
            # theta(r) from s_r = r! e^r/(2 r^r) - theta
            theta = mp.factorial(r) * mp.e ** r / (2 * mp.mpf(r) ** r) - s
            assert mp.mpf(1) / 3 < theta < mp.mpf(1) / 2, ("theta out of range", r, theta)
            gap = bound - s
            if worst is None or gap < worst[0]:
                worst = (gap, r)
        print("   (10.1) holds for r<=3000 and samples; smallest gap", mp.nstr(worst[0], 6), "at r =", worst[1],
              "; theta(1), theta(42), theta(3000) =", mp.nstr(mp.factorial(1) * mp.e / 2 - s_r_mp(1), 8),
              mp.nstr(mp.factorial(42) * mp.e ** 42 / (2 * mp.mpf(42) ** 42) - s_r_mp(42), 8),
              mp.nstr(mp.factorial(3000) * mp.e ** 3000 / (2 * mp.mpf(3000) ** 3000) - s_r_mp(3000), 8))
