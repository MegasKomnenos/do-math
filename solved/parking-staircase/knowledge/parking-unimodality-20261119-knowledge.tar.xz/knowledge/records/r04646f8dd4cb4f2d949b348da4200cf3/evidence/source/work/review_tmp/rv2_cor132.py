# Independent checks for Corollary 13.2 (and Lemma 10.2 as a by-product). Exact rationals.
from fractions import Fraction as F
from math import factorial, isqrt
import time
t0 = time.time()

def a(j):
    return F(j ** (j - 1), factorial(j))

A_CACHE = {}
def aa(j):
    if j not in A_CACHE:
        A_CACHE[j] = a(j)
    return A_CACHE[j]

def Lambda_poly(m, lam):
    """Return dict q -> total mass of compositions of m with q parts, cut factors lam[s], s=1..m-1.
    DP over the position of the last cut: G[j][c] = mass of prefix [0,j] ending with a cut at j, having c cuts."""
    G = [dict() for _ in range(m + 1)]
    G[0] = {0: F(1)}
    for j in range(1, m):
        d = {}
        for i in range(0, j):
            for c, v in G[i].items():
                d[c + 1] = d.get(c + 1, F(0)) + v * aa(j - i) * lam[j]
        G[j] = d
    out = {}
    for i in range(0, m):
        for c, v in G[i].items():
            out[c + 1] = out.get(c + 1, F(0)) + v * aa(m - i)
    return out   # keyed by Q = cuts+1

def T(m, q):
    return F(q, m) * F(m ** (m - q), factorial(m - q))

def homog_law(r, h):
    w = [T(r, q) * h ** (q - 1) for q in range(1, r + 1)]
    Z = sum(w)
    return [x / Z for x in w]     # index q-1  -> P(Q=q), i.e. index j -> P(J=j)

def sqrt_lower(x, digits=30):
    # rational lower bound of sqrt(x) for Fraction x >= 0
    sc = 10 ** digits
    n = (x.numerator * sc * sc) // x.denominator
    return F(isqrt(n), sc)

def mu0_lower(X, r):
    return (sqrt_lower((4 + X) ** 2 + 12 * (r - 1)) - (4 + X)) / 3

fails = {"lr": 0, "ineq1": 0, "jensen": 0, "mu1>=mu0": 0, "muh>=mu0": 0, "identity": 0, "EJ(J-1)": 0, "lem10.2": 0,
         "dp_vs_T": 0}
n = 0
sites = []
for k in range(3, 41):
    for r in range(2, min(k - 1, 26) + 1):
        if (k + r) % 3 == 0 or r <= 6 or k in (30, 40):
            sites.append((k, r))
for (k, r) in sites:
    N = k + r + 1
    lam = {s: F(k, N - s) for s in range(1, r)}
    mass = Lambda_poly(r, lam)                      # Q -> mass under threshold profile with y=k
    Z = sum(mass.values())
    # DP sanity: homogeneous factor 1 must reproduce T_{r,q}
    if n == 0:
        one = Lambda_poly(r, {s: F(1) for s in range(1, r)})
        for q in range(1, r + 1):
            if one[q] != T(r, q):
                fails["dp_vs_T"] += 1
    # LHS: Lambda_r(k+2)/Lambda_r(k) = E_lambda (1+2/k)^(Q-1)
    lhs = sum(v * F(k + 2, k) ** (q - 1) for q, v in mass.items()) / Z
    h1 = F(k) / (k + 1 + F(r, 2))
    P1 = homog_law(r, h1)
    # likelihood ratio monotone (Lemma 13.1 with m=r,y=k,N=k+r+1)
    ratios = [(mass[q] / Z) / P1[q - 1] for q in range(1, r + 1)]
    if any(ratios[i + 1] < ratios[i] for i in range(r - 1)):
        fails["lr"] += 1
    mid = sum(P1[q - 1] * F(k + 2, k) ** (q - 1) for q in range(1, r + 1))
    if lhs < mid:
        fails["ineq1"] += 1
    mu1 = sum(P1[j] * j for j in range(r))
    # Jensen: mid >= (1+2/k)^mu1  (compare in floats with tolerance; exact values are rationals / irrational power)
    import math
    if float(mid) < (1 + 2 / k) ** float(mu1) * (1 - 1e-13):
        fails["jensen"] += 1
    X1 = F(r * (r + 2), 2 * k)
    assert r * (1 / h1 - 1) == X1
    if mu1 < mu0_lower(X1, r):
        fails["mu1>=mu0"] += 1
    h = F(k - 1, k + r)
    Ph = homog_law(r, h)
    muh = sum(Ph[j] * j for j in range(r))
    Xh = F(r * (r + 1), k - 1)
    assert r * (1 / h - 1) == Xh
    if muh < mu0_lower(Xh, r):
        fails["muh>=mu0"] += 1
    # identity E J^2 + (3 + r(1/h-1)) mu = 2(r-1) and E J(J-1) <= 3/2 mu^2, for assorted homogeneous factors
    for hh in [h1, h, F(k, k + r), F(1, 1000), F(1, 2), F(1), F(3), F(1000)]:
        P = homog_law(r, hh)
        mu = sum(P[j] * j for j in range(r))
        EJ2 = sum(P[j] * j * j for j in range(r))
        if EJ2 + (3 + r * (1 / hh - 1)) * mu != 2 * (r - 1):
            fails["identity"] += 1
        if EJ2 - mu > F(3, 2) * mu * mu:
            fails["EJ(J-1)"] += 1
    # Lemma 10.2: tau_{r+1}(h)/tau_r(h) <= (1+1/r)^r (1 - (1-h)/(2h(r+1)) mu_h), 0<h<=1
    for hh in [h, F(k, k + r), F(1, 1000), F(1, 2), F(1)]:
        tau_r = sum(T(r, q) * hh ** (q - 1) for q in range(1, r + 1))
        tau_r1 = sum(T(r + 1, q) * hh ** (q - 1) for q in range(1, r + 2))
        P = homog_law(r, hh)
        mu = sum(P[j] * j for j in range(r))
        if tau_r1 / tau_r > F(r + 1, r) ** r * (1 - (1 - hh) / (2 * hh * (r + 1)) * mu):
            fails["lem10.2"] += 1
    n += 1
print("sites tested:", n, " failures:", fails)

# a few larger sites (the ones quoted in the report: (k,r)=(265,57),(265,70),(60,20)) for the first inequality
for (k, r) in [(60, 20), (265, 57), (265, 70)]:
    N = k + r + 1
    lam = {s: F(k, N - s) for s in range(1, r)}
    mass = Lambda_poly(r, lam)
    Z = sum(mass.values())
    lhs = sum(v * F(k + 2, k) ** (q - 1) for q, v in mass.items()) / Z
    h1 = F(k) / (k + 1 + F(r, 2))
    P1 = homog_law(r, h1)
    mid = sum(P1[q - 1] * F(k + 2, k) ** (q - 1) for q in range(1, r + 1))
    mu1 = sum(P1[j] * j for j in range(r))
    mulam = sum(v * (q - 1) for q, v in mass.items()) / Z
    hmin = F(k, k + r)
    Pm = homog_law(r, hmin)
    mumin = sum(Pm[j] * j for j in range(r))
    P0 = homog_law(r, F(1))
    mufree = sum(P0[j] * j for j in range(r))
    ratios = [(mass[q] / Z) / P1[q - 1] for q in range(1, r + 1)]
    mono = all(ratios[i + 1] >= ratios[i] for i in range(r - 1))
    import math
    print((k, r), "LR monotone:", mono, " E_lam>=E_h1:", lhs >= mid, " log lhs=%.6f  mu1*log(1+2/k)=%.6f" % (
        math.log(float(lhs)), float(mu1) * math.log(1 + 2 / k)),
        " mean cuts: tilted %.4f  midpoint %.4f  minfactor %.4f  free %.4f  mu0(X1)=%.4f" % (
            float(mulam), float(mu1), float(mumin), float(mufree), float(mu0_lower(F(r * (r + 2), 2 * k), r))))
print("time %.1fs" % (time.time() - t0))
