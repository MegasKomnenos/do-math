# t19: test of a conjecture that arose while trying to widen the strip (section 10).
# Chain law of the bottom chain: vertices at excesses 1 = e_1 < e_2 < ... < e_Q <= r,
# gaps weighted by a_g = g^(g-1)/g!, top gap r+1-e_Q, factor k/(k+e_i) at each vertex.
# psi(q) = E[ prod k/(k+e_i) | Q = q ]  (under the factor-free composition measure).
# Conjecture tested: psi(q+1)/psi(q) lies in [k/(k+c1 r), k/(k+c2 r)] with c1 < 1, c2 > 0
# (likelihood-ratio sandwich by homogeneous laws with intermediate factors).
# Output: c(q) := k (psi(q)/psi(q+1) - 1)/r for all q, with the birthday probability of q.
import sys
from fractions import Fraction as Fr
from math import factorial

def run(r, k):
    a = [Fr(0)] + [Fr(g ** (g - 1), factorial(g)) for g in range(1, r + 2)]
    # U[q][e]: weight of chains with q vertices, the q-th at excess e (with factors), V: without factors
    U = {1: {1: Fr(k, k + 1)}}
    V = {1: {1: Fr(1)}}
    for q in range(2, r + 1):
        Uq, Vq = {}, {}
        for e2 in range(q, r + 1):
            su = Fr(0); sv = Fr(0)
            for e, w in U[q - 1].items():
                if e < e2:
                    su += w * a[e2 - e]
            for e, w in V[q - 1].items():
                if e < e2:
                    sv += w * a[e2 - e]
            Uq[e2] = su * Fr(k, k + e2); Vq[e2] = sv
        U[q] = Uq; V[q] = Vq
    c = {}; T = {}
    for q in range(1, r + 1):
        c[q] = sum(w * a[r + 1 - e] for e, w in U[q].items())
        T[q] = sum(w * a[r + 1 - e] for e, w in V[q].items())
        # check T against Lagrange: (q/r) r^(r-q)/(r-q)!
        assert T[q] == Fr(q, r) * Fr(r ** (r - q), factorial(r - q)), (q, T[q])
    tot = sum(T.values())
    psi = {q: c[q] / T[q] for q in c}
    print("r=%d k=%d  u=%.3f  r/k=%.3f" % (r, k, r ** 1.5 / k, r / k))
    print("  q  birthday P(Q=q)   psi(q+1)/psi(q)   c(q)=k(psi(q)/psi(q+1)-1)/r   [k/(k+r/2)=%.5f]" % (k / (k + r / 2)))
    cs = []
    for q in range(1, r):
        ratio = psi[q + 1] / psi[q]
        cq = float(k * (1 / ratio - 1) / r)
        p = float(T[q] / tot)
        cs.append((q, cq, p))
        if q <= 30 or q % 5 == 0 or q == r - 1:
            print("  %3d  %.3e   %.6f   %.4f" % (q, p, float(ratio), cq))
    sig = [(q, cq) for q, cq, p in cs if p > 1e-6]
    print("  range of c(q) over q with P>1e-6: min %.4f (q=%d)  max %.4f (q=%d);  over all q: min %.4f max %.4f" % (
        min(sig, key=lambda t: t[1])[1], min(sig, key=lambda t: t[1])[0],
        max(sig, key=lambda t: t[1])[1], max(sig, key=lambda t: t[1])[0],
        min(cq for q, cq, p in cs), max(cq for q, cq, p in cs)))
    # means under the three laws: true tilted, homogeneous with r/2, factor-free
    def mean(wts):
        s = sum(wts.values()); return float(sum(q * w for q, w in wts.items()) / s)
    def d32(wts):
        n3 = sum(q * (q - 1) * (q - 2) * w for q, w in wts.items()); n2 = sum(q * (q - 1) * w for q, w in wts.items())
        return float(n3 / n2)
    true = {q: c[q] for q in c}
    for name, cc in (("c=1", 1.0), ("c=3/4", 0.75), ("c=1/2", 0.5), ("c=1/4", 0.25), ("c=0", 0.0)):
        h = Fr(k) / (Fr(k) + Fr(cc).limit_denominator(1000) * r)
        hom = {q: T[q] * h ** q for q in T}
        print("  homogeneous %-6s: E[Q]=%.4f  E[Q(Q-1)(Q-2)]/E[Q(Q-1)]=%.4f" % (name, mean(hom), d32(hom)))
    print("  true tilted       : E[Q]=%.4f  E[Q(Q-1)(Q-2)]/E[Q(Q-1)]=%.4f" % (mean(true), d32(true)))

if __name__ == "__main__":
    args = [int(x) for x in sys.argv[1:]]
    for i in range(0, len(args), 2):
        run(args[i], args[i + 1])
