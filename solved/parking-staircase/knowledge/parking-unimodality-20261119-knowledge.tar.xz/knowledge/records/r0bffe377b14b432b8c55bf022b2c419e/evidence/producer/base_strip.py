# Independent exact recomputation of the base used in Corollary 3.3:
#   (L1°) on the strip 2k+1 <= n <= 3k-1 for 12 <= k <= 100  (all n <= 299, i.e. inside the C5 range n <= 300),
# with exact integers via the last-car recursion  A_{m+1,s-1} = sum_j C(m,j) min(j+1,s) A_{j,s-1} A_{m-j,s-1}.
# The same fact is the computational observation of the published claim rb9ca4897.../p-size-convexity-link;
# this script only re-checks it (it does not extend the range).
from math import comb
from fractions import Fraction
import sys, time

def column(s, nmax):          # a[n] = A_{n,s-1} for 0<=n<=nmax  (threshold s)
    a = [1]
    for m in range(0, nmax):
        if m+1 <= s:
            a.append((m+2)**m); continue            # A_{m+1,s-1} = p_{m+1} when m+1 <= s
        tot = 0
        row = 1                                     # C(m,j) built incrementally
        for j in range(0, m+1):
            tot += row*min(j+1, s)*a[j]*a[m-j]
            row = row*(m-j)//(j+1)
        a.append(tot)
    return a

def p(n): return 1 if n == 0 else (n+1)**(n-1)

t0 = time.time()
kmin, kmax = 12, 100
cells = 0; bad = []
minrel = None
for k in range(kmin, kmax+1):
    nmax = 3*k
    a = column(k, nmax)
    # sanity: unconstrained values
    assert a[k] == p(k) and a[k+1] == p(k+1)-p(k)
    for n in range(2*k+1, 3*k):
        val = a[n-1]*p(n)*p(n+1)-2*a[n]*p(n-1)*p(n+1)+a[n+1]*p(n-1)*p(n)
        cells += 1
        if val < 0: bad.append((n, k))
        rel = float(Fraction(val*k*k, a[n]*p(n-1)*p(n+1)))
        if minrel is None or rel < minrel[0]: minrel = (rel, n, k)
print("k in [%d,%d], strip 2k+1<=n<=3k-1 (max n = %d): cells=%d, violations=%d, min k^2*(second difference)/phi_n = %.3f at (n,k)=(%d,%d); time %.0fs" % (
    kmin, kmax, 3*kmax-1, cells, len(bad), minrel[0], minrel[1], minrel[2], time.time()-t0))
