# Peer: end-to-end check of the chain of section 6.2 (columns c >= 25):
#   Theorem S (ga) at theta = x_{3c}
#   ->  upper bound NB on the peak N_chi :
#         25 <= c <= 31 : growth lemma (Lemma 4.4), L = 2, R = 5      =>  N_chi <= 1.6c + 1
#         32 <= c <= 55 : growth lemma, L = 4, R = 8                   =>  N_chi <= 1.6c + 1
#         c >= 56       : delayed mass bound (Lemma 4.3)               =>  N_chi < 1.6694c + 0.123
#   ->  pivot bound from the peak (Lemma 4.5):  (m+1) C_m >= (2 - theta G(min(m - N_chi, c-1))) D_{m-1}
#   ->  lifting convexity to the local tilt x_{n+1} (Lemma 2.8)
#   ->  Theorem 3.3 on the window 2c+1 <= n <= 2c+J,  J = ceil(0.58 c^(2/3)) - 1.
# Every inequality the hand proof states is evaluated with the true quantities and with the bounds the proof uses.
# Independent code (tilted last-car recursion), mpmath 40 digits.  Checks statements of a hand proof on examples.
from mpmath import mp, mpf, exp, log, sqrt, pi, ceil
from math import factorial
mp.dps = 40
def xm(m): return (mpf(m)/(m+1))**(m-1)
def Bor(n): return exp(-n)*mpf(n)**(n-1)/factorial(n)
def Jhand(c):
    t = 1
    while (100*t)**3 < 58**3*c*c: t += 1            # t = ceil(0.58 c^(2/3))
    return t-1
fails = []
def chk(cond, tag):
    if not cond: fails.append(tag)
def fk(c, t): return (c+t)*exp(t/(2*mpf(c)))/(sqrt(2*pi)*t**mpf('1.5'))
def ell(c):                # lower bound of j = m - N_chi used in the proof
    if c >= 56: return mpf('0.3306')*c - mpf('0.58')*mpf(c)**(mpf(2)/3) + mpf('0.877')
    return mpf('0.4')*c - mpf('0.58')*mpf(c)**(mpf(2)/3)
# Borel constants quoted in the text
chk(mp.fsum(Bor(n) for n in range(1, 4)) <= mpf('0.57790') and mp.fsum(n*Bor(n) for n in range(1, 4)) <= mpf('0.86260'), 'B3')
chk(mpf('0.048841') <= Bor(4) <= mpf('0.048842'), 'Bor4')
chk(mp.fsum(Bor(n) for n in range(1, 6)) <= mpf('0.66184') and mp.fsum(n*Bor(n) for n in range(1, 6)) <= mpf('1.23343'), 'B5')
chk(mpf('0.02677') <= Bor(6) <= mpf('0.026771'), 'Bor6'); chk(Bor(9) <= mpf('0.01464'), 'Bor9')
chk(fk(25, ell(25)+1) < mpf('0.9412') and fk(56, ell(56)+1) < mpf('0.80'), 'f-values')

def run(c):
    th = xm(3*c); J = Jhand(c); Nmax = 2*c+J+3
    cm = mpf(c)
    mi = lambda i: min(i+1, c)
    u = [mpf(1)]
    for N in range(0, Nmax):
        u.append(th*mp.fsum(mi(i)*u[i]*u[N-i] for i in range(0, N+1))/(N+1))
    w = [mpf(1)]
    for j in range(1, Nmax+1): w.append(w[-1]*th/xm(j))
    D = [u[N]-u[N+1] for N in range(0, Nmax)]
    C = [None]+[D[N-1]-D[N] for N in range(1, Nmax)]
    G = lambda i: (c+i+1)*w[i]
    bb = lambda l: th*(G(l)-G(l+1))
    chk(1 <= J <= c-1 and 2*c+J+1 <= 3*c, ('J-range', c))
    for i in range(0, c):
        chk(th*G(i) <= fk(c, mpf(i+1)), ('1.2-theta', c, i))
        if i >= 1: chk(G(i) <= G(i-1), ('G-mono', c, i))
    chk(C[c] <= 0, ('Cc', c))
    Nchi = min(N for N in range(c+1, Nmax-1) if C[N] > 0)
    chk(all(C[N] <= 0 for N in range(c, Nchi)) and all(C[N] >= 0 for N in range(Nchi, Nmax)), ('S-ga', c))
    eta = D[c]/w[c]
    chk(abs(eta-(1-th/xm(c+1)+th/(c+1))) < mpf(10)**(-30), ('eta-formula', c))
    eta_lb = (1-mpf('2.84')/c+mpf('0.3678')*c/(c+1))/c
    chk(eta >= eta_lb, ('eta-lb', c)); chk(th*c+th-2 > 0, ('xc+x-2>0', c))
    # window length: Psi(0.58, c) <= 1.265 and sigma_c
    lm = mpf('0.58')
    Psi = (1+lm*cm**(-mpf(1)/3))*exp(mpf('0.75')*lm*cm**(-mpf(1)/3))/(sqrt(2*pi)*lm**mpf('1.5'))
    chk(Psi <= mpf('1.257'), ('Psi', c))
    xc = xm(c)
    sig = 1 - c*xc**(c+1)*mpf(c+1)**(c-1)/factorial(c)
    chk(sig >= mpf('0.6490'), ('sigma', c))
    if c <= 55:
        L, R = (2, 5) if c <= 31 else (4, 8)
        gL = th*G(L+1); gR = th*G(R)
        S = mp.fsum((l+1)*bb(l) for l in range(0, L+1))
        chk(abs(S-(mp.fsum(th*G(l) for l in range(0, L+1))-(L+1)*gL)) < mpf(10)**(-30), ('S-ident', c))
        chk(abs(mp.fsum(bb(l) for l in range(0, L+1))-(th*(c+1)-gL)) < mpf(10)**(-30), ('b-sum', c))
        if c <= 31:
            chk(gL <= (c+4)*exp(mpf(2)/cm)*mpf('0.048842') <= mpf('1.8235'), ('gL<=2', c))
            Sbar = exp(mpf('1.5')/cm)*(mpf('0.57790')*c+mpf('0.86260')) - mpf('0.146523')*c - mpf('0.586092')
            gRbar = (c+6)*exp(mpf(3)/cm)*mpf('0.026771')
            chk(2-gRbar >= mpf('0.9088') and Sbar <= mpf('0.48031')*c, ('block-25-31', c))
            Ablk, Hblk = mpf('1.892'), mpf('1.24'); low = mpf('1.13')
        else:
            chk(gL <= (c+6)*exp(mpf(3)/cm)*mpf('0.026771') <= 2, ('gL<=2', c))
            Sbar = exp(mpf('2.5')/cm)*(mpf('0.66184')*c+mpf('1.23343')) - mpf('0.13385')*c - mpf('0.8031')
            gRbar = (c+9)*exp(mpf('4.5')/cm)*mpf('0.01464')
            if c <= 37:
                chk(2-gRbar >= mpf('1.2394') and Sbar <= mpf('0.59836')*c, ('block-32-37', c))
                Ablk, Hblk = mpf('2.0713'), mpf('1.2679'); low = mpf('0.47')
            else:
                chk(2-gRbar >= mpf('0.9831') and Sbar <= mpf('0.58653')*c, ('block-38-55', c))
                Ablk, Hblk = mpf('1.676'), mpf('1.2836'); low = mpf('0.34')
        chk(S <= Sbar, ('Sbar', c)); chk(gR <= gRbar < 2, ('gRbar', c))
        a = (2-gR)/S; alb = (2-gRbar)/Sbar
        chk(a >= alb >= Ablk/c, ('a-lb', c)); chk(eta_lb >= Hblk/c, ('eta-blk', c))
        K = mpf(3*c)/5 - R + mpf(1)/5                    # = 0.6c - R + 0.2, exactly
        chk(K >= 0, ('K>=0', c))
        chk(R+K+1+a*K*(K+3)/2 >= 1/eta, ('mass-true', c))
        hand = R+K+1+(Ablk/(2*c))*K*(K+3) - cm/Hblk
        chk(R+K+1+alb*K*(K+3)/2 - 1/eta_lb >= hand >= low, ('mass-hand', c))
        Kstar = int(ceil(K - mpf(10)**(-30)))
        chk(Kstar >= K - mpf(10)**(-25) and Kstar - K <= mpf('0.8') + mpf(10)**(-25), ('Kstar', c))
        NB = c + R + Kstar
        chk(NB <= mpf('1.6')*c + 1 + mpf(10)**(-25), ('NB<=1.6c+1', c))
        chk(Nchi <= NB, ('growth-bound', c))
        j0 = c+R-1
        for j in (c+R, c+R+3, c+R+9):
            lhs2 = mp.fsum(bb(l)*(1+a*(j-1-l-j0)) for l in range(0, L+1))
            chk(abs(lhs2-((1+a*(j-j0))*(th*(c+1)-gL)-a*S)) < mpf(10)**(-28), ('step-ident', c, j))
        b2 = None
    else:
        chk(abs(u[c+1]-(w[c+1]-th*w[c]/(c+1))) < mpf(10)**(-30), ('u_{c+1}', c))
        chk(abs(u[c+2]-(w[c+2]-2*th*(th*w[c]+w[c+1])/(c+2))) < mpf(10)**(-30), ('u_{c+2}', c))
        Dc1 = (w[c+1]-w[c+2]) - th*w[c]/(c+1) + 2*th*(th*w[c]+w[c+1])/(c+2)
        chk(abs(Dc1-D[c+1]) < mpf(10)**(-30), ('D_{c+1}', c))
        b2 = c+1+(w[c]-D[c])/D[c+1]
        hb = mpf('1.6694')*c+mpf('0.123')
        chk(Nchi < b2 <= hb, ('delayed-bound', c))
        NB = int(ceil(hb))-1                                   # largest integer < 1.6694c + 0.123
    fc = fk(c, ell(c)+1)
    chk(fc <= (mpf('0.9412') if c <= 55 else mpf('0.80')), ('f', c))
    chk(0 < ell(c)+1 <= c, ('ell', c))
    minhand = None; maxreq = mpf(0); minslack = None; minfinal = None; mintrue = None
    for n in range(2*c+1, 2*c+J+1):
        xl = xm(n+1); rho = xl/th; r = 1/rho
        chk(rho >= 1, ('rho>=1', c, n))
        req = 2*n*(rho-1); maxreq = max(maxreq, req)
        chk(req <= 1-mpf('1.74')/c, ('6.1ra', c, n))
        up = [u[j]*rho**j for j in range(0, n+2)]
        wp = [w[j]*rho**j for j in range(0, n+2)]
        chk(all((c+l+1)*wp[l] >= (c+l+2)*wp[l+1] for l in range(0, c-1)), ('3.4ga', c, n))
        xG = xl*(c+J+1)*wp[J]
        delta = 1 - (xl/xc)*(1 - sig/n)
        chk(up[n-1]-up[n] >= delta*up[n-1], ("1.2''-local", c, n))
        lhs = (2-xG)*delta; rhs = (n+1)*(1-xl/xm(n))
        chk(xG <= Psi, ('3.4da', c, n)); chk(1-xl/xc >= mpf('0.7151')/c, ('3.4na-1', c, n))
        chk(rhs < mpf('0.75')/c, ('3.4na-2', c, n)); chk(lhs >= rhs, ('iii', c, n))
        s = (lhs-rhs)*c; minslack = s if minslack is None else min(minslack, s)
        for m in range(n-J, n):
            jh = min(m-NB, c-1)
            chk(jh >= 1, ('lag-hand', c, n, m))
            chk(m-NB > ell(c), ('lag-real', c, n, m))
            chk(th*G(jh) <= fc, ('6.2-kernel', c, n, m))
            chk(2-th*G(jh) >= req, ('6.2-final-hand', c, n, m))
            minhand = (2-th*G(jh)-req) if minhand is None else min(minhand, 2-th*G(jh)-req)
            jt = min(m-Nchi, c-1)
            q = (m+1)*C[m]/D[m-1]
            chk(q >= 2-th*G(jt) >= 2-th*G(jh), ('pivot', c, n, m))
            mintrue = (2-th*G(jt)-req) if mintrue is None else min(mintrue, 2-th*G(jt)-req)
            chk(0 <= D[m] <= D[m-1], ('D-mono', c, m))
            Cp = up[m-1]-2*up[m]+up[m+1]
            ident = r**(-(m+1))*(r*r*C[m]-2*r*(1-r)*D[m]+(1-r)**2*u[m+1])
            chk(abs(Cp-ident) <= mpf(10)**(-28)*abs(up[m]), ('2.8-ident', c, n, m))
            chk(r*C[m] >= 2*(1-r)*D[m], ('2.8-cond', c, n, m))
            chk(Cp >= 0, ('lifted', c, n, m))
        Cn = up[n-1]-2*up[n]+up[n+1]
        final = Cn-(1-xl/xm(n))*up[n-1]
        chk(final >= (lhs-rhs)/(n+1)*up[n-1], ('3.3-quant', c, n)); chk(final >= 0, ('L1', c, n))
        fq = final/wp[n]*c*(n+1)/(u[n-1]/w[n-1]); minfinal = fq if minfinal is None else min(minfinal, fq)
    for N in range(Nchi+1, Nmax-1):
        chk((N+1)*C[N] >= (2-th*G(min(N-Nchi, c-1)))*D[N-1], ('4.5-pivot', c, N))
    return (c, J, Nchi, NB, None if b2 is None else round(float(b2), 1), round(float(fc), 4), round(float(minhand), 3), round(float(mintrue), 3),
            round(float(maxreq), 4), round(float(minslack), 4), round(float(minfinal), 2))

print("c, J, N_chi, integer bound on N_chi used, bound of Lemma 4.3 (c>=56), kernel bound f(c), min margin with the proof's bounds, min margin with the true N_chi, max 2n(rho_n-1), min c*slack of (iii), min c(n+1)C_{n,c}/phi_{n-1} on the window")
cs = list(range(25, 131)) + [140, 150, 160, 180, 200, 250, 320]
for c in cs:
    res = run(c)
    if c in (25, 26, 28, 30, 31, 32, 33, 37, 38, 40, 45, 50, 55, 56, 57, 58, 60, 70, 80, 101, 130, 200, 320): print(res)
print("columns checked:", len(cs), "(25..130 all, then 140, 150, 160, 180, 200, 250, 320)")
print("failures:", fails[:20], len(fails))
print("f(25) = %.4f, f(55) = %.4f, f(56) = %.4f" % (float(fk(25, ell(25)+1)), float(fk(55, ell(55)+1)), float(fk(56, ell(56)+1))))

# the growth lemma on real dips: columns whose dip is longer than R.  L = least with theta G(L+1) <= 2, R = L+1, L+3
print("growth lemma on real dips: c, N_chi, (L, R), number of sizes j checked, min of D_j / (D_c (1 + a (j - j0))), R+K+1+aK(K+3)/2 vs 1/eta")
for c in (150, 200, 320, 500):
    th = xm(3*c); Nmax = c + 60
    mi = lambda i: min(i+1, c)
    u = [mpf(1)]
    for N in range(0, Nmax):
        u.append(th*mp.fsum(mi(i)*u[i]*u[N-i] for i in range(0, N+1))/(N+1))
    w = [mpf(1)]
    for j in range(1, Nmax+1): w.append(w[-1]*th/xm(j))
    D = [u[N]-u[N+1] for N in range(0, Nmax)]
    C = [None]+[D[N-1]-D[N] for N in range(1, Nmax)]
    G = lambda i: (c+i+1)*w[i]
    bb = lambda l: th*(G(l)-G(l+1))
    Nchi = min(N for N in range(c+1, Nmax-1) if C[N] > 0)
    L = 0
    while th*G(L+1) > 2: L += 1
    for R in (L+1, L+3):
        S = mp.fsum((l+1)*bb(l) for l in range(0, L+1))
        a = (2-th*G(R))/S
        j0 = c+R-1
        M = Nchi-1
        js = list(range(c+R, M))
        ratios = [D[j]/(D[c]*(1+a*(j-j0))) for j in js]
        chk(all(x >= 1 for x in ratios), ('growth-real', c, R))
        K = M-c-R
        chk(R+K+1+a*K*(K+3)/2 < w[c]/D[c], ('mass-real', c, R))
        print(c, Nchi, (L, R), len(js), "%.3f" % float(min(ratios)), "%.2f < %.2f" % (float(R+K+1+a*K*(K+3)/2), float(w[c]/D[c])))
print("failures:", fails[:20], len(fails))
