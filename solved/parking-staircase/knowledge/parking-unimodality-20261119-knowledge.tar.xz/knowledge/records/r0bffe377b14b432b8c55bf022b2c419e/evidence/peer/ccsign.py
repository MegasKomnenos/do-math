# check: at tilt theta = x_{3c}, C_c = w_{c-1} - 2 w_c + w_{c+1} - theta*w_c/(c+1) <= 0 ?  (exact rationals)
from fractions import Fraction as F
from math import factorial
def xm(m): return F(m, m+1)**(m-1)
def w(j, x): return x**j * F((j+1)**(j-1) if j>=1 else 1, factorial(j))
bad = []
first_ok = None
for c in range(2, 131):
    th = xm(3*c)
    Cc = w(c-1, th) - 2*w(c, th) + w(c+1, th) - th*w(c, th)/(c+1)
    if Cc > 0: bad.append(c)
print("c in 2..130 with C_c > 0 at tilt x_{3c}:", bad)
