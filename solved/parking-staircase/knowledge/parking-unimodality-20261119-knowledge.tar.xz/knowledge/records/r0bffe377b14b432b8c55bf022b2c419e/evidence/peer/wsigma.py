# Peer: checks for Corollary 2.1a and section 3.3.
#   Corollary 2.1a: for 0 < x <= x_c and N >= 2c-1:   (N+1) D_N >= (1 - x c w_c) u_N;
#   at the critical tilt x_c this reads   (N+1)(u_N - u_{N+1}) >= sigma_c u_N,   sigma_c := 1 - c x_c^{c+1} p_c / c!      (1.2'')
#   (the same inequality is the N >= 2c-1 case of the closed-form consequence stated in the published r3e1c5b9d.../p-survival-decay)
# (a) exact rationals: (1.2'') for c <= 16, 2c-1 <= N <= 4c; the intermediate inequality of the proof,
#        (N+1) D_N >= (1 - x c) u_N + x c sum_{j=0}^{c-1} d_j u_{N-1-j} >= (1 - x c w_c) u_N,
#     at the tilts x_c, x_{2c+2}, x_{3c};  sigma_c >= 1 - S(c);  sigma_c > 0 (sigma_2 = 1/9; closed form for c >= 3)
# (b) sigma_c >= 1 - 1.78794 e^{1/c} c/(c+1)^{3/2};  >= 0.5024 (c >= 12), >= 0.6490 (c >= 25);  beta_c = 0.3678 sigma_c / x_c >= 0.4456, 0.6117
# (c) the criterion (W_{c,J}) at tilt x_{2c+2}:  (2 - xG(J)) [ (1 - x/x_c)(2c+1)(2c+3)/(2c+2) + beta_c ] >= 3/2   (exact rationals),
#     J_c := least J (certified in exact rationals; the scan over J is in 40-digit arithmetic); monotone in J;  closed forms:  x_{2c+2} G(J) <= 1.2 (c>=12) resp. 1.265 (c>=25)  ==>  (W);
#     J_c <= ceil(0.66 c^{2/3}) - 1 (c >= 12),  <= ceil(0.58 c^{2/3}) - 1 (c >= 25);  Psi(0.66,12) < 1.191, Psi(0.58,25) < 1.257
# (d) (W_{c,J}) ==> condition (iii) of Theorem 3.3 at every n >= 2c+1 (n up to 2c+400 and 5c, 10c, 50c; 12 <= c <= 100), with
#     delta_c(n) = 1 - (x_{n+1}/x_c)(1 - sigma_c/n)
from fractions import Fraction as F
from math import factorial, comb
from mpmath import mp, mpf, exp, sqrt, pi
mp.dps = 40
def xmF(m): return F(m, m+1)**(m-1)
def xm(m): return (mpf(m)/(m+1))**(m-1)
def sigmaF(c): return 1 - c*xmF(c)**(c+1)*F((c+1)**(c-1), factorial(c))
def SF(c):
    x = xmF(c)
    return sum(F(n**(n-1), factorial(n))*x**n for n in range(2, c+2))
fails = []
def chk(cond, tag):
    if not cond: fails.append(tag)
# (a)
def cum(nmax, c):
    a = [1]
    for m in range(0, nmax):
        a.append(sum(comb(m, j)*min(j+1, c)*a[j]*a[m-j] for j in range(0, m+1)))
    return a
cnt = 0
for c in (2, 3, 5, 8, 12, 16):
    x = xmF(c); a = cum(4*c+2, c); sg = sigmaF(c)
    u = [F(a[N], factorial(N))*x**N for N in range(0, 4*c+2)]
    for N in range(2*c-1, 4*c+1):
        chk((N+1)*(u[N]-u[N+1]) >= sg*u[N], ("1.2''", c, N)); cnt += 1
print("(a) (1.2'') checked exactly at", cnt, "pairs (c, N); smallest value of (N+1) D_N / u_N - sigma_c seen is nonnegative:", not fails)
cnt2 = 0
for c in (2, 3, 5, 8, 12, 16):
    a = cum(4*c+2, c)
    for x in (xmF(c), xmF(2*c+2), xmF(3*c)):
        u = [F(a[N], factorial(N))*x**N for N in range(0, 4*c+2)]
        w = [F((j+1)**(j-1), factorial(j))*x**j if j >= 1 else F(1) for j in range(0, c+2)]
        d = [w[j]-w[j+1] for j in range(0, c+1)]
        chk(all(u[j] == w[j] for j in range(0, c+1)), ('u=w', c))
        chk(all(d[j] >= 0 for j in range(0, c)), ('d>=0', c))
        for N in range(2*c-1, 4*c+1):
            lhs = (N+1)*(u[N]-u[N+1])
            mid = (1-x*c)*u[N] + x*c*sum(d[j]*u[N-1-j] for j in range(0, c))
            chk(lhs >= mid >= (1-x*c*w[c])*u[N], ('2.1a-mid', c, N)); cnt2 += 1
print("    intermediate inequality of Corollary 2.1a checked exactly at", cnt2, "triples (c, tilt, N)")
chk(sigmaF(2) == F(1, 9), 'sigma_2')
for c in range(2, 101):
    chk(sigmaF(c) >= 1 - SF(c), ('sigma>=1-S', c))
for c in range(3, 301):
    cl = mpf('1.78794')*exp(mpf(1)/c)*c/mpf(c+1)**mpf('1.5')
    sg = sigmaF(c)
    chk(cl < mpf('0.936') and 1 - mpf(sg.numerator)/mpf(sg.denominator) <= cl, ('sigma>0 closed form', c))
# (b)
for c in range(12, 301):
    sg = sigmaF(c); sgm = mpf(sg.numerator)/mpf(sg.denominator)
    lb = 1 - mpf('1.78794')*exp(mpf(1)/c)*c/mpf(c+1)**mpf('1.5')
    chk(sgm >= lb, ('sigma-lb', c))
    chk(lb >= (mpf('0.5024') if c < 25 else mpf('0.6490')), ('sigma-const', c))
    beta = mpf('0.3678')*sgm/xm(c)
    chk(beta >= (mpf('0.4456') if c < 25 else mpf('0.6117')), ('beta-const', c))
chk(mpf('0.3678')*mpf('0.5024')/xm(12) >= mpf('0.4456') and mpf('0.3678')*mpf('0.6490')/xm(25) >= mpf('0.6117'), 'beta-arith')
chk(2 - mpf('1.5')/(mpf('1.4302')+mpf('0.4456')) >= mpf('1.2') and 2 - mpf('1.5')/(mpf('1.4302')+mpf('0.6117')) >= mpf('1.265'), 'g-star')
def Psi(lm, c):
    t = mpf(c)**(-mpf(1)/3)
    return (1+lm*t)*exp(mpf('0.75')*lm*t)/(sqrt(2*pi)*lm**mpf('1.5'))
print("Psi(0.66,12) = %.5f, Psi(0.58,25) = %.5f" % (float(Psi(mpf('0.66'), 12)), float(Psi(mpf('0.58'), 25))))
chk(Psi(mpf('0.66'), 12) < mpf('1.191') and Psi(mpf('0.58'), 25) < mpf('1.257'), 'Psi-values')
# (c), (d)
def xGF(c, J, x): return (c+J+1)*x**(J+1)*F((J+1)**(J-1), factorial(J))
def W(c, J):
    x = xmF(2*c+2); xc = xmF(c)
    beta = F(3678, 10000)*sigmaF(c)/xc
    lhs = (2 - xGF(c, J, x))*((1 - x/xc)*F((2*c+1)*(2*c+3), 2*c+2) + beta)
    return lhs >= F(3, 2)
def ceil_lam(c, p):          # ceil(p/100 * c^(2/3))
    t = 1
    while (100*t)**3 < p**3*c*c: t += 1
    return t
def Wmp(c, J):
    x = xm(2*c+2); xc = xm(c)
    sg = sigmaF(c); sgm = mpf(sg.numerator)/mpf(sg.denominator)
    xG = (c+J+1)*x**(J+1)*mpf((J+1)**(J-1))/factorial(J)
    return (2 - xG)*((1 - x/xc)*mpf((2*c+1)*(2*c+3))/(2*c+2) + mpf('0.3678')*sgm/xc) - mpf('1.5'), xG
CMAX = 100
table = {}
for c in range(12, CMAX+1):
    Jc = None
    for J in range(1, min(c, 30)):
        v, xG = Wmp(c, J)
        if v >= 0 and Jc is None: Jc = J
        if Jc is not None: chk(v >= 0, ('W-mono', c, J))
        thr = mpf('1.2') if c < 25 else mpf('1.265')
        if xG <= thr: chk(v >= 0, ('closed=>W', c, J))
    # J_c certified in exact rationals
    chk(W(c, Jc) and (Jc == 1 or not W(c, Jc-1)), ('Jc-exact', c))
    table[c] = Jc
    chk(Jc <= ceil_lam(c, 66)-1, ('Jc<=0.66', c))
    if c >= 25: chk(Jc <= ceil_lam(c, 58)-1, ('Jc<=0.58', c))
    # (d) (W) ==> (iii) for all n >= 2c+1
    sg = sigmaF(c); sgm = mpf(sg.numerator)/mpf(sg.denominator)
    Js = sorted(set([Jc, ceil_lam(c, 66)-1] + ([ceil_lam(c, 58)-1] if c >= 25 else [])))
    for n in list(range(2*c+1, 2*c+401)) + [5*c, 10*c, 50*c]:
        xl = xm(n+1)
        delta = 1 - (xl/xm(c))*(1 - sgm/n)
        chk(1-xl/xm(c) >= mpf('0.7151')/c and (n+1)*(1-xl/xm(n)) < mpf('0.75')/c, ('3.4na', c, n))
        for J in Js:
            xG = (c+J+1)*xl**(J+1)*mpf((J+1)**(J-1))/factorial(J)
            chk((2-xG)*delta >= (n+1)*(1-xl/xm(n)), ('iii', c, J, n))
        Jt = -(-c//3)
        xG3 = (c+Jt+1)*xl**(Jt+1)*mpf((Jt+1)**(Jt-1))/factorial(Jt)
        chk(xG3 < mpf('0.81') and (2-xG3)*(1-xl/xm(c)) - (n+1)*(1-xl/xm(n)) >= mpf('0.1')/c, ('c/3', c, n))
runs = []
c0 = 12
for c in range(13, CMAX+1):
    if table[c] != table[c0]:
        runs.append((c0, c-1, table[c0])); c0 = c
runs.append((c0, CMAX, table[c0]))
print("(c) J_c (least J with (W_{c,J})), as ranges (c_from, c_to, J_c):", runs)
print("    cells of the shortest windows 2c+1 <= n <= 2c+J_c: 12<=c<=24:", sum(table[c] for c in range(12, 25)), "; 12<=c<=55:", sum(table[c] for c in range(12, 56)))
print("    sigma_c for c = 12, 25, 55, 100: ", ["%.4f" % float(mpf(sigmaF(c).numerator)/mpf(sigmaF(c).denominator)) for c in (12, 25, 55, 100)])
print("failures:", fails[:20], len(fails))
