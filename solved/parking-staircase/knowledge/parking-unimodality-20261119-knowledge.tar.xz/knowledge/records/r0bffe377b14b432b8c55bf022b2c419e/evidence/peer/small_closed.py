# Peer (information; not used in any proof): what the closed-form estimates of section 6 would give for the peak in the columns 12 <= c <= 24 (section 10.1, item (5)).
#   theta = x_{3c}.  Closed-form ingredients (as in Lemma 6.1 (na1)):
#     theta G(t-1) = (c+t)(e theta)^t Bor(t),   (c+t) Bor(t) <= theta G(t-1) <= (c+t) e^{t/(2c)} Bor(t),
#     S <= Sbar(L)  := sum_{l=0}^{L} (c+l+1) e^{(l+1)/(2c)} Bor(l+1) - (L+1)(c+L+2) Bor(L+2),
#     theta G(R) <= gbar(R) := (c+R+1) e^{(R+1)/(2c)} Bor(R+1),      eta >= etabar(c) := (1/c)[1 - 2.84/c + 0.3678 c/(c+1)],
#   Lemma 4.4:  N_chi <= c+R+K  as soon as  R+K+1 + a K(K+3)/2 >= 1/eta,   a := (2 - theta G(R))/S.
#   closed  = min over (L,R) of the bound with a >= (2-gbar)/Sbar and eta >= etabar          (Borel numbers exact, no rounding)
#   exact   = min over (L,R) of the bound with the exact a and eta
#   need    = largest integer NB accepted by the comparison of Proposition 6.2/6.3 on the window J = ceil(0.66 c^{2/3}) - 1:
#             2 - theta G(min(m-NB, c-1)) >= 2 (rho_n - 1)(m+1)   for 2c+1 <= n <= 2c+J, n-J <= m <= n-1     (kernel and rho exact)
#   needH   = the same with the right side replaced by the hand bound 1 - 1.74/c of Lemma 6.1 (ra)
from mpmath import mp, mpf, exp, factorial
mp.dps = 40
def xm(m): return (mpf(m)/(m+1))**(m-1)
def Bor(t): return exp(-mpf(t))*mpf(t)**(t-1)/factorial(t)
def ceil_lam(c, p):
    t = 1
    while (100*t)**3 < p**3*c*c: t += 1
    return t
print("c, J, N_chi, exact, closed, need, needH, closed<=need, closed<=needH, etabar valid")
for c in range(12, 25):
    th = xm(3*c); Nmax = 2*c+8
    mi = lambda i: min(i+1, c)
    u = [mpf(1)]
    for N in range(0, Nmax):
        u.append(th*mp.fsum(mi(i)*u[i]*u[N-i] for i in range(0, N+1))/(N+1))
    w = [mpf(1)]
    for j in range(1, Nmax+1): w.append(w[-1]*th/xm(j))
    D = [u[N]-u[N+1] for N in range(0, Nmax)]
    C = [None]+[D[N-1]-D[N] for N in range(1, Nmax)]
    G = lambda i: (c+i+1)*w[i]
    bb = lambda l: th*(G(l)-G(l+1))
    Nchi = min(N for N in range(c+1, Nmax-1) if C[N] > 0)
    eta = D[c]/w[c]
    etabar = (1 - mpf('2.84')/c + mpf('0.3678')*c/(c+1))/c
    J = ceil_lam(c, 66) - 1
    def accept(hand):
        for NB in range(2*c, c, -1):
            ok = True
            for n in range(2*c+1, 2*c+J+1):
                rho = xm(n+1)/th
                for m in range(n-J, n):
                    if m-NB < 1: ok = False; break
                    rhs = (1 - mpf('1.74')/c) if hand else 2*(rho-1)*(m+1)
                    if 2 - th*G(min(m-NB, c-1)) < rhs: ok = False; break
                if not ok: break
            if ok: return NB
    best_exact = None; best_closed = None
    for L in range(0, 12):
        if th*G(L+1) > 2: continue
        S = mp.fsum((l+1)*bb(l) for l in range(0, L+1))
        Sbar = mp.fsum((c+l+1)*exp(mpf(l+1)/(2*c))*Bor(l+1) for l in range(0, L+1)) - (L+1)*(c+L+2)*Bor(L+2)
        assert S <= Sbar
        for R in range(L+1, c-1):
            gbar = (c+R+1)*exp(mpf(R+1)/(2*c))*Bor(R+1)
            assert th*G(R) <= gbar
            if th*G(R) < 2:
                a = (2-th*G(R))/S; K = 0
                while R+K+1+a*K*(K+3)/2 < 1/eta: K += 1
                if best_exact is None or c+R+K < best_exact[0]: best_exact = (c+R+K, L, R)
            if gbar < 2:
                a = (2-gbar)/Sbar; K = 0
                while R+K+1+a*K*(K+3)/2 < 1/etabar: K += 1
                if best_closed is None or c+R+K < best_closed[0]: best_closed = (c+R+K, L, R)
    need = accept(False); needH = accept(True)
    print(c, J, Nchi, best_exact, best_closed, need, needH, best_closed[0] <= need, best_closed[0] <= needH, eta >= etabar)
# (Y1) in the columns 13 <= c <= 24, small-rho case of section 5 ((r+1)/c < 0.16):  with a_t = (t+1.2) w_{c-2-t}, b_t = a_t - a_{t-1}, T = c-2-r, t0 = floor(c/2),
#   true   = sum_{t=1}^{T} b_t d_{r+t}
#   split  = b_{t0} (w_{r+1} - w_{r+t0+1}) + d_{r+t0+1} (a_T - a_{t0})          (the split of section 5 before its closed-form simplification)
#   crude  = (b_{t0} + c d_{t0+1}) w_r                                           (the simplified form; section 5 bounds it by 12.22 w_{c-1} w_r for c >= 25)
#   allow  = 2 c^2 d_r d_{c-1} - a_0 d_r                                         ((Y1) at r follows from  true <= allow)
print("(Y1), small-rho case: c, r, true/allow, split/allow, crude/allow")
worst = (0, 0, 0)
for c in range(13, 25):
    th = xm(3*c)
    w = [mpf(1)]
    for j in range(1, c+3): w.append(w[-1]*th/xm(j))
    d = lambda j: w[j]-w[j+1]
    a_ = lambda t: (t+mpf('1.2'))*w[c-2-t]
    b_ = lambda t: a_(t)-a_(t-1)
    for r in range(1, c-1):
        if mpf(r+1)/c >= mpf('0.16'): continue
        T = c-2-r; t0 = c//2
        true = mp.fsum(b_(t)*d(r+t) for t in range(1, T+1))
        split = b_(t0)*(w[r+1]-w[r+t0+1]) + d(r+t0+1)*(a_(T)-a_(t0))
        crude = (b_(t0) + c*d(t0+1))*w[r]
        allow = 2*c*c*d(r)*d(c-1) - a_(0)*d(r)
        worst = (max(worst[0], true/allow), max(worst[1], split/allow), max(worst[2], crude/allow))
        print(c, r, "%.3f %.3f %.3f" % (float(true/allow), float(split/allow), float(crude/allow)))
print("largest ratios (true, split, crude):", ["%.3f" % float(v) for v in worst])
# The other two cases of section 5 in the columns 12 <= c <= 24, evaluated exactly:
#   T in {1,2}:                 2 b_2 d_r / allow          (for T = 1:  b_1 d_{r+1} <= b_2 d_r as well)
#   T >= 3, (r+1)/c >= 0.16:    cheb / allow,   cheb = ((a_T - a_0)/T) (w_{r+1} - w_{c-1})      (Chebyshev's sum inequality)
wT = 0; wC = (0, None)
for c in range(12, 25):
    th = xm(3*c)
    w = [mpf(1)]
    for j in range(1, c+3): w.append(w[-1]*th/xm(j))
    d = lambda j: w[j]-w[j+1]
    a_ = lambda t: (t+mpf('1.2'))*w[c-2-t]
    b_ = lambda t: a_(t)-a_(t-1)
    for r in range(1, c-1):
        T = c-2-r
        if T == 0: continue
        allow = 2*c*c*d(r)*d(c-1) - a_(0)*d(r)
        true = mp.fsum(b_(t)*d(r+t) for t in range(1, T+1))
        assert true <= allow
        if T <= 2:
            wT = max(wT, 2*b_(2)*d(r)/allow)
        elif mpf(r+1)/c >= mpf('0.16'):
            v = ((a_(T)-a_(0))/T)*(w[r+1]-w[c-1])/allow
            if v > wC[0]: wC = (v, (c, r))
print("columns 12..24: largest 2 b_2 d_r / allow over T in {1,2}: %.3f;  largest cheb/allow over T>=3, (r+1)/c>=0.16: %.3f at (c,r)=%s" % (float(wT), float(wC[0]), wC[1]))
