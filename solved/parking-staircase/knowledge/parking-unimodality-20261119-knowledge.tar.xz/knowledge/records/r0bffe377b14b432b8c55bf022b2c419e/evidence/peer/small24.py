# Peer: end-to-end check of Proposition 6.3 (columns 12 <= c <= 24):
#   base cells C_N(theta) >= 0, N0 <= N <= N0+J'-1 (N0 = c+2 for c <= 17, c+3 for 18 <= c <= 24; J' = 2 for c <= 21, 3 for 22..24)   [exact integers: thetabase.py]
#   ->  propagation at the fixed tilt theta (Lemma 4.5): C_N >= 0 for all N >= N0 and
#        (N+1) C_N >= (2 - theta G(min(N-N0, c-1))) D_{N-1}  for N >= N0+J'
#   ->  lifting to the local tilt x_{n+1} (Lemma 2.8)  ->  Theorem 3.3 on the window 2c+1 <= n <= 2c+J, J = ceil(0.66 c^(2/3)) - 1.
# Independent code (tilted last-car recursion), mpmath 40 digits.  Checks statements of a hand proof on examples.
from mpmath import mp, mpf, exp, sqrt, pi
from math import factorial
mp.dps = 40
def xm(m): return (mpf(m)/(m+1))**(m-1)
def ym(m): return (mpf(m)/(m+1))**m
def Bor(n): return exp(-n)*mpf(n)**(n-1)/factorial(n)
def Jhand(c):
    t = 1
    while (100*t)**3 < 66**3*c*c: t += 1      # t = ceil(0.66 c^(2/3))
    return t-1
def Jp(c): return 2 if c <= 21 else 3
def N0f(c): return c + 2 if c <= 17 else c + 3
fails = []
def chk(cond, tag):
    if not cond: fails.append(tag)
def ells(c): return mpf(c) - 2 - mpf('0.66')*mpf(c)**(mpf(2)/3)        # m - N0 > ells(c)
def fs(c):
    l = ells(c) + 1
    return (c+l)*exp(l/(2*mpf(c)))/(sqrt(2*pi)*l**mpf('1.5'))
chk(Bor(3) <= mpf('0.074681') and Bor(4) <= mpf('0.048842') and Bor(5) <= mpf('0.035094'), 'Borel')
chk(24*exp(mpf(3)/42)*mpf('0.074681') <= mpf('1.9251'), 'J2'); chk(28*exp(mpf(2)/24)*mpf('0.048842') <= mpf('1.4865'), 'J3')
chk(fs(12) < mpf('0.516'), 'fs12')

def run(c):
    th = xm(3*c); J = Jhand(c); Nmax = 2*c+J+3
    cm = mpf(c)
    N0 = N0f(c); J1 = Jp(c)
    mi = lambda i: min(i+1, c)
    u = [mpf(1)]
    for N in range(0, Nmax):
        u.append(th*mp.fsum(mi(i)*u[i]*u[N-i] for i in range(0, N+1))/(N+1))
    w = [mpf(1)]
    for j in range(1, Nmax+1): w.append(w[-1]*th/xm(j))
    D = [u[N]-u[N+1] for N in range(0, Nmax)]
    C = [None]+[D[N-1]-D[N] for N in range(1, Nmax)]
    G = lambda i: (c+i+1)*w[i]
    h = lambda i: (i+1)*w[i]
    d = lambda j: w[j]-w[j+1]
    bb = lambda l: th*(G(l)-G(l+1))
    chk(th <= ym(c-1), ('theta<=y', c)); chk(1 <= J <= c-1 and 2*c+J+1 <= 3*c, ('J-range', c))
    chk(all(bb(l) >= 0 for l in range(0, c-1)), ('b>=0', c))
    # base cells (floating check; the exact integer check is thetabase.py)
    chk(all(C[N] >= 0 for N in range(N0, N0+J1)), ('base', c))
    # theta G(J') < 2 by the closed form
    gJ = th*G(J1)
    cf = (c+J1+1)*exp(mpf(J1+1)/(2*cm))*Bor(J1+1)
    chk(gJ <= cf < 2, ('gJ<2', c))
    # (2.4') and E_N >= 0 in the first layer
    for N in range(c+1, 2*c):
        E = th*mp.fsum((h(i)-h(i+1))*d(N-2-i) for i in range(N-c, c-1))
        chk(E >= 0, ('E>=0', c, N))
        rhs = mp.fsum(bb(l)*D[N-2-l] for l in range(0, N-c)) + E - (th*c+th-2)*D[N-1]
        chk(abs((N+1)*C[N]-rhs) <= mpf(10)**(-28)*u[N], ("2.4'", c, N))
    # propagation at theta (Lemma 4.5)
    minq = None
    for N in range(N0, Nmax-1):
        chk(C[N] >= 0, ('prop-sign', c, N))
        if N >= N0+J1:
            j = min(N-N0, c-1)
            chk((N+1)*C[N] >= (2-th*G(j))*D[N-1], ('prop-pivot', c, N))
    # window
    l = ells(c); fc = fs(c)
    chk(J1 < l < c-1, ('ells', c)); chk(fc <= mpf('0.516'), ('fs', c))
    k34 = (1+mpf('0.66')*cm**(-mpf(1)/3))*exp(mpf('0.75')*mpf('0.66')*cm**(-mpf(1)/3))/(sqrt(2*pi)*mpf('0.66')**mpf('1.5'))
    chk(k34 <= mpf('1.191'), ('Psi', c))
    xc = xm(c)
    sig = 1 - c*xc**(c+1)*mpf(c+1)**(c-1)/factorial(c)
    chk(sig >= mpf('0.5024'), ('sigma', c))
    minhand = None; maxreq = mpf(0); minfinal = None
    for n in range(2*c+1, 2*c+J+1):
        xl = xm(n+1); rho = xl/th; r = 1/rho
        chk(rho >= 1, ('rho>=1', c, n))
        req = 2*n*(rho-1); maxreq = max(maxreq, req)
        chk(req <= 1-mpf('1.74')/c, ('6.1ra', c, n))
        up = [u[j]*rho**j for j in range(0, n+2)]
        wp = [w[j]*rho**j for j in range(0, n+2)]
        chk(all((c+i+1)*wp[i] >= (c+i+2)*wp[i+1] for i in range(0, c-1)), ('3.4ga', c, n))
        xG = xl*(c+J+1)*wp[J]
        delta = 1 - (xl/xc)*(1 - sig/n)
        chk(up[n-1]-up[n] >= delta*up[n-1], ("1.2''-local", c, n))
        lhs = (2-xG)*delta; rhs = (n+1)*(1-xl/xm(n))
        chk(xG <= k34, ('3.4da', c, n)); chk(lhs >= rhs, ('iii', c, n))
        for m in range(n-J, n):
            chk(m >= N0+J1, ('m>=N0+J1', c, n, m))
            j = min(m-N0, c-1)
            chk(m-N0 > l, ('lag', c, n, m))
            chk(th*G(j) <= fc, ('kernel', c, n, m))
            chk(2-th*G(j) >= req, ('final-hand', c, n, m))
            minhand = (2-th*G(j)-req) if minhand is None else min(minhand, 2-th*G(j)-req)
            chk(0 <= D[m] <= D[m-1], ('D-mono', c, m))
            Cp = up[m-1]-2*up[m]+up[m+1]
            ident = r**(-(m+1))*(r*r*C[m]-2*r*(1-r)*D[m]+(1-r)**2*u[m+1])
            chk(abs(Cp-ident) <= mpf(10)**(-28)*abs(up[m]), ('2.8-ident', c, n, m))
            chk(r*C[m] >= 2*(1-r)*D[m], ('2.8-cond', c, n, m))
            chk(Cp >= 0, ('lifted', c, n, m))
        Cn = up[n-1]-2*up[n]+up[n+1]
        final = Cn-(1-xl/xm(n))*up[n-1]
        chk(final >= 0, ('L1', c, n))
        fq = final/wp[n]*c*(n+1)/(u[n-1]/w[n-1]); minfinal = fq if minfinal is None else min(minfinal, fq)
    return (c, N0, J1, J, round(float(cf), 4), round(float(l), 2), round(float(fc), 4), round(float(minhand), 3), round(float(maxreq), 4), round(float(minfinal), 2))

print("c, N0, J', J, closed-form bound of theta G(J'), ell_s(c) (lower bound of m - N0), f_s(c), min margin (2 - theta G(j) - 2n(rho_n-1)), max 2n(rho_n-1), min c(n+1)C_{n,c}/phi_{n-1} on the window")
for c in range(12, 25):
    print(run(c))
print("columns checked: 13 (12..24)")
print("failures:", fails[:20], len(fails))
