# Peer: exact-rational check of the identities (2.1),(2.2),(2.4),(C2),(star) at several tilts.
from fractions import Fraction as Fr
from math import comb, factorial
from base import cum_by_recursion

def setup(c, x, Nmax):
    a = cum_by_recursion(Nmax+2, c)
    u = [Fr(a[N], factorial(N))*x**N for N in range(Nmax+3)]
    w = [Fr((N+1)**(N-1) if N>0 else 1, factorial(N))*x**N for N in range(Nmax+3)]
    D = [u[N]-u[N+1] for N in range(Nmax+2)]
    C = [None]+[D[N-1]-D[N] for N in range(1, Nmax+2)]
    return u, w, D, C

def check(c, x, Nmax):
    u, w, D, C = setup(c, x, Nmax)
    m = lambda i: min(i+1, c)
    for N in range(0, c+1):
        assert u[N] == w[N]
    d = [w[j]-w[j+1] for j in range(Nmax+1)]
    h = lambda j: (j+1)*w[j]
    G = lambda j: (c+j+1)*w[j]
    g = lambda i: m(i)*u[i]
    dstar = d[c-1]
    def Om(i):
        if i <= c-1: return x*G(i)
        return x*c*(u[i]+w[c-1])
    assert x*G(c-1) == x*c*(u[c-1]+w[c-1])
    mm = lambda i: Om(i)-2
    cnt = 0
    for N in range(0, Nmax):
        # (2.1)
        lhs = (N+1)*D[N]
        rhs = (1-x*m(N))*u[N] + x*sum(m(i)*u[i]*D[N-1-i] for i in range(0, N))
        assert lhs == rhs, ("2.1", c, x, N)
    for N in range(c+1, Nmax):
        # (2.2)
        rhs = x*c*(1-x)*D[N-2] + x*sum((g(i)-g(i+1))*D[N-2-i] for i in range(0, N-2)) - (x*c+x-2)*D[N-1]
        assert (N+1)*C[N] == rhs, ("2.2", c, x, N)
    for N in range(2*c-1, Nmax):
        Q = sum(D[i]*D[N-2-i] for i in range(c-1, N-1-c+1))
        beta = [x*(G(l)-G(l+1)) for l in range(0, c-1)]
        rhs24 = sum(beta[l]*D[N-2-l] for l in range(0, c-1)) + x*c*Q - (x*c+x-2)*D[N-1]
        assert (N+1)*C[N] == rhs24, ("2.4", c, x, N)
        T = [x*(G(j)-G(c-1)) for j in range(0, c-1)]
        rhsC2 = sum(T[j]*C[N-1-j] for j in range(0, c-1)) + 2*(1-x*c*w[c-1])*D[N-1] + x*c*Q
        assert (N+1)*C[N] == rhsC2, ("C2", c, x, N)
    def src(N):
        if N <= 2*c-1:
            E = x*sum((h(i)-h(i+1))*d[N-2-i] for i in range(N-c, c-1))
            s1 = (2-x*G(N-c))*dstar + E
        if N >= 2*c-1:
            s2 = dstar*(2-x*c*w[c-1]-x*c*u[N-c])
        if N == 2*c-1:
            assert s1 == s2
        return s1 if N <= 2*c-1 else s2
    for N in range(c+1, Nmax):
        rhs = sum(mm(N-1-k)*C[k] for k in range(c, N)) + src(N)
        assert (N+1)*C[N] == rhs, ("star", c, x, N)
        cnt += 1
    return cnt

tot = 0
for c in (2, 3, 4, 5, 7, 10, 13):
    xc = Fr(c, c+1)**(c-1)
    x3c = Fr(3*c, 3*c+1)**(3*c-1)
    yc1 = Fr(c-1, c)**(c-1)
    for x in (xc, x3c, yc1, Fr(1,3), Fr(3,10), Fr(1,2), Fr(9,5)):
        tot += check(c, x, 4*c+7)
print("all identities exact; (star) checked at", tot, "(c,x,N) triples")
