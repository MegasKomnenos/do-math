# Peer: end-to-end test of Theorem 3.3 (one step at the local tilt) on exact data.
# For c and n >= 2c-1, tilt x = x_{n+1} (exact rational), check
#  (a) Lemma 3.2: if C_m >= 0 for n-J <= m <= n-1 then (n+1) C_n >= (2 - xG(J)) D_{n-1}
#  (b) (2.6):  w_n * (phi_{n-1} - 2 phi_n + phi_{n+1}) = C_n - (1 - x_{n+1}/x_n) u_{n-1}
#  (c) (1.2'): D_N >= [1 - (x/x_c)(1 - sigma_c/(N+1))] u_N for 2c-1 <= N <= n,
#              sigma_c = 1 - c x_c^{c+1} p_c / c!   (Corollary 2.1a, tilted)
#  (d) Theorem 3.3 (n >= 2c): if the window is convex and (iii) holds, i.e.
#        (2 - xG(J)) * delta_c(n) >= (n+1)(1 - x_{n+1}/x_n),   delta_c(n) = 1 - (x_{n+1}/x_c)(1 - sigma_c/n),
#      then  w_n * (phi_{n-1} - 2 phi_n + phi_{n+1}) >= [ (2-xG(J)) delta_c(n) - (n+1)(1-x_{n+1}/x_n) ] u_{n-1} / (n+1) >= 0
#  (e) Lemma 2.7: (L1) at m  =>  C_m >= 0 at tilt x_{n+1} for m < n
from fractions import Fraction as Fr
from math import factorial
from base import cum_by_recursion

def xm(m): return Fr(m, m+1)**(m-1)
def sigma(c): return 1 - c*xm(c)**(c+1)*Fr((c+1)**(c-1), factorial(c))

def run(c, nmax):
    a = cum_by_recursion(nmax+3, c)      # a[N] = A_{N,c-1}
    p = lambda N: 1 if N == 0 else (N+1)**(N-1)
    phi = [Fr(a[N], p(N)) for N in range(nmax+3)]
    d2phi = lambda n: phi[n-1]-2*phi[n]+phi[n+1]
    sg = sigma(c); xc = xm(c)
    stats = {"F1":0, "transfer":0, "P":0, "L27":0, "K2":0, "Jmin":{}}
    for n in range(2*c-1, nmax):
        x = xm(n+1)
        u = [Fr(a[N], factorial(N))*x**N for N in range(n+3)]
        w = [Fr(p(N), factorial(N))*x**N for N in range(n+3)]
        D = [u[N]-u[N+1] for N in range(n+2)]
        C = [None]+[D[N-1]-D[N] for N in range(1, n+2)]
        lhs = w[n]*d2phi(n)
        rhs = C[n] - (1-xm(n+1)/xm(n))*u[n-1]
        assert lhs == rhs, ("transfer", c, n)
        stats["transfer"] += 1
        G = lambda j: (c+j+1)*w[j]
        assert all(G(l) >= G(l+1) for l in range(0, c-1)), ("G monotone fails", c, n)
        assert all(Dv >= 0 for Dv in D), ("D>=0 fails", c, n)
        for N in range(2*c-1, n+1):
            assert D[N] >= (1-(x/xc)*(1-sg/(N+1)))*u[N], ("K2", c, n, N)
            stats["K2"] += 1
        delta = 1-(x/xc)*(1-sg/n)
        gap = (n+1)*(1-xm(n+1)/xm(n))
        Jmin = None
        for J in range(1, c):
            if n-J < c: break
            window_ok = all(C[m] >= 0 for m in range(n-J, n))
            for m in range(n-J, n):
                if d2phi(m) >= 0:
                    assert C[m] >= 0, ("L2.7", c, n, m)
                    stats["L27"] += 1
            if window_ok:
                assert (n+1)*C[n] >= (2-x*G(J))*D[n-1], ("F1", c, n, J)
                stats["F1"] += 1
                if n >= 2*c:
                    slack = (2-x*G(J))*delta - gap
                    if slack >= 0:
                        assert lhs >= slack*u[n-1]/(n+1) >= 0, ("P", c, n, J)
                        stats["P"] += 1
                        if Jmin is None: Jmin = J
        stats["Jmin"][n] = Jmin
    return stats

tot = {"F1":0, "P":0, "K2":0}
for c in (3, 5, 8, 12, 13, 16, 20, 25):
    nmax = min(6*c, 110)
    s = run(c, nmax)
    jm = s["Jmin"]
    for k in tot: tot[k] += s[k]
    print("c=%d n in [%d,%d): (2.6) %d, Lemma 3.2 checks %d, Theorem 3.3 confirmations %d, Lemma 2.7 checks %d, (1.2') checks %d; least J with (iii) and a convex window at n=2c,2c+1,3c: %s %s %s"
          % (c, 2*c-1, nmax, s["transfer"], s["F1"], s["P"], s["L27"], s["K2"], jm.get(2*c), jm.get(2*c+1), jm.get(3*c)))
print("totals: Lemma 3.2 %d, Theorem 3.3 %d, (1.2') %d; no assertion failed" % (tot["F1"], tot["P"], tot["K2"]))
