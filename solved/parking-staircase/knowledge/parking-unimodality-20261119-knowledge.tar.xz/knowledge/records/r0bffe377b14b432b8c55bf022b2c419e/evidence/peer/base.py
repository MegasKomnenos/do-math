# Peer's independent base code (written from scratch).
# Exact cumulative counts A[n][l] = #{parking functions of length n with max displacement <= l}
# (1) brute force by simulating the parking process (small n), (2) last-car recursion.
from itertools import product
from math import comb
from fractions import Fraction as Fr

def brute_rows(n):
    """b[l] = number of parking functions of length n with max displacement exactly l (brute force)."""
    b = [0]*n
    for pref in product(range(1, n+1), repeat=n):
        occ = [False]*(n+2)
        ok = True; M = 0
        for a in pref:
            s = a
            while s <= n and occ[s]:
                s += 1
            if s > n:
                ok = False; break
            occ[s] = True
            M = max(M, s-a)
        if ok:
            b[M] += 1
    return b

def cum_by_recursion(nmax, c):
    """a[N] = A_{N,c-1} for N=0..nmax (threshold c>=1: all displacements < c), via last-car recursion
       A_{m+1,c-1} = sum_j C(m,j) min(j+1,c) A_{j,c-1} A_{m-j,c-1}."""
    a = [1]
    for m in range(0, nmax):
        s = 0
        for j in range(0, m+1):
            s += comb(m, j)*min(j+1, c)*a[j]*a[m-j]
        a.append(s)
    return a

if __name__ == "__main__":
    # root table check
    root = {1:[1],2:[2,1],3:[6,7,3],4:[24,51,34,16],5:[120,421,377,253,125],
            6:[720,3963,4594,3688,2546,1296],7:[5040,42253,62145,57398,46142,32359,16807]}
    for n in range(1, 8):
        b = brute_rows(n)
        assert b == root[n], (n, b)
        # recursion: A_{n,l} with threshold c=l+1
        for l in range(0, n):
            A = cum_by_recursion(n, l+1)[n]
            assert A == sum(b[:l+1]), (n, l)
    print("brute force rows n<=7 match root table; recursion matches cumulative sums")
