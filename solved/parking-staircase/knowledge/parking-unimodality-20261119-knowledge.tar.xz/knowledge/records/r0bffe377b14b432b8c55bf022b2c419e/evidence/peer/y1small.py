# Peer (information; not used in any proof): (Y1)_c(theta) for small c: max over r of LHS/RHS; sign of C_c; theta <= y_{c-1}
from mpmath import mp, mpf
mp.dps = 30
def xm(m): return (mpf(m)/(m+1))**(m-1)
def ym(m): return (mpf(m)/(m+1))**m
for c in list(range(5, 31)) + [35, 40, 45, 50, 55, 56]:
    th = xm(3*c)
    w = [mpf(1)]
    for j in range(1, c+3): w.append(w[-1]*th/xm(j))
    h = lambda i: (i+1)*w[i]
    d = lambda j: w[j]-w[j+1]
    Cw = lambda j: w[j-1]-2*w[j]+w[j+1]
    worst = None
    for r in range(1, c-1):
        lhs = mp.fsum((h(i)-h(i+1))*Cw(r+c-1-i) for i in range(r, c-1))
        rhs = c*d(r)*d(c-1)
        q = lhs/rhs
        if worst is None or q > worst[0]: worst = (q, r)
    Cc = w[c-1]-2*w[c]+w[c+1]-th*w[c]/(c+1)
    print(c, "Y1 ratio max = %.4f at r=%d" % (float(worst[0]), worst[1]), "C_c<=0:", Cc <= 0, "theta<=y_{c-1}:", th <= ym(c-1))
