# Peer: independent numerical check (mpmath, 50 digits) of the producer's chain for c>=101 at tilt theta=x_{3c}:
# Numbering note: the labels below follow the producer's report. In the record's exposition they are
#   Lemma 6.1 (na),(ra) -> Lemma 8.2 (ga),(na);  Lemma 6.1 (da) -> Lemma 6.1 (da);  Prop 6.2 -> Proposition 8.3;  (6.1) -> (8.1).
#  Theorem S hypotheses and conclusions, Lemma 6.1, the bounds used in Prop 6.2, and the final brace of (6.1)
#  evaluated with the PROVEN lower bounds only (N_chi replaced by its bound 1.7486c).
import sys
from mpmath import mp, mpf, sqrt, pi, exp, log, floor, ceil
mp.dps = 50
def xm(m): return (mpf(m)/(m+1))**(m-1)
def ym(m): return (mpf(m)/(m+1))**m

def run(c, verbose=True):
    th = xm(3*c)
    assert th <= ym(c-1)
    Nmax = 3*c+2
    mi = lambda i: min(i+1, c)
    u = [mpf(1)]
    for N in range(0, Nmax):
        s = mp.fsum(mi(i)*u[i]*u[N-i] for i in range(0, N+1))
        u.append(th*s/(N+1))
    w = [mpf(1)]
    for j in range(1, Nmax+1):
        w.append(w[-1]*th/xm(j))        # w_j/w_{j-1} = theta/x_j
    for j in range(0, c+1):
        assert abs(u[j]-w[j]) < mpf(10)**(-40)
    D = [u[N]-u[N+1] for N in range(0, Nmax)]
    C = [None]+[D[N-1]-D[N] for N in range(1, Nmax)]
    d = [w[j]-w[j+1] for j in range(0, Nmax)]
    h = lambda j: (j+1)*w[j]
    G = lambda j: (c+j+1)*w[j]
    Cw = lambda j: d[j-1]-d[j]
    dstar = d[c-1]
    def Om(i):
        return th*G(i) if i <= c-1 else th*c*(u[i]+w[c-1])
    # hypotheses
    assert C[c] <= 0, "C_c<=0 fails"
    y1max = 0
    for r in range(1, c-1):
        lhs = mp.fsum((h(i)-h(i+1))*Cw(r+c-1-i) for i in range(r, c-1))
        rhs = c*d[r]*d[c-1]
        assert lhs <= rhs, ("Y1", c, r)
        y1max = max(y1max, lhs/rhs)
    # kernel monotone
    assert all(Om(i) >= Om(i+1) for i in range(0, Nmax-3))
    # sign pattern
    Nchi = min(N for N in range(c+1, Nmax-1) if C[N] > 0)
    assert all(C[N] <= 0 for N in range(c, Nchi))
    assert all(C[N] >= 0 for N in range(Nchi, Nmax-1)), "sign pattern fails"
    eta = D[c]/w[c]
    assert abs(eta - (1-th/xm(c+1)+th/(c+1))) < mpf(10)**(-40)
    assert Nchi < c + 1/eta
    assert eta >= mpf('1.336')/c and c+1/eta < mpf('1.7486')*c
    # pivot (da) and one-more (ra) with J=floor(c/10)
    minq = None
    for N in range(Nchi+1, 3*c+1):
        L = N-1-Nchi
        q = (N+1)*C[N]/D[N-1]
        assert q >= 2-Om(L) - mpf(10)**(-30), ("da", c, N)
        # improved pivot via (2.4) (peer's F1), for N>=2c-1 and L+1<=c-1
        if N >= 2*c-1 and L+1 <= c-1:
            assert q >= 2-th*G(L+1) - mpf(10)**(-30), ("F1", c, N)
        J = c//10
        if 1 <= J <= L and Om(L-J) <= 2:
            lb = 2-Om(L)+(2-Om(L-J))/N*mp.fsum(Om(j)-Om(L) for j in range(0, J))
            assert q >= lb - mpf(10)**(-30), ("ra", c, N)
        if 2*c+1 <= N <= 3*c-1:
            minq = q if minq is None else min(minq, q)
    # Lemma 6.1 (da),(ra)
    def kappa(al): return (1+al)*exp(al/2)/(sqrt(2*pi)*al**mpf('1.5'))
    for al in (mpf(1)/4, mpf('0.15')):
        i0 = int(ceil(al*c))-1
        assert Om(i0) <= kappa(al)/sqrt(c), ("6.1da", c, al)
    for J in range(1, c+1):
        assert mp.fsum(Om(j) for j in range(0, J)) >= c*(1-mpf('0.8')/sqrt(J)), ("6.1ra", c, J)
    # Prop 6.2 brace with the proven bounds: N_chi -> bound, q -> proven lower bound
    eps = 1-th/xm(c)
    assert eps >= (1-mpf('1.28')/c)/c
    NchiB = int(ceil(mpf('1.7486')*c))-1       # N_chi <= this (integer)
    minbrace = None; minbrace_win = None
    Jw = -(-c//3)
    for n in range(2*c+1, 3*c):
        L = n-1-NchiB
        q = 2-Om(L)
        if n <= mpf('2.5')*c:
            J = c//10
            assert 1 <= J <= L and Om(L-J) <= 2
            q = q + (2-Om(L-J))/n*mp.fsum(Om(j)-Om(L) for j in range(0, J))
            assert q >= mpf('1.8738'), ("q case1", c, n, q)
        else:
            assert q >= mpf('1.5501'), ("q case2", c, n, q)
        rho_n = xm(n+1)/th; tau = xm(n)/th
        R = 2-rho_n-1/tau
        inner = q/(n+1)-2*(rho_n-1)
        assert inner >= 0
        brace = eps*inner - R
        assert brace > 0, ("brace", c, n)
        b2 = brace*c*c
        minbrace = b2 if minbrace is None else min(minbrace, b2)
        if n <= 2*c+Jw:
            minbrace_win = b2 if minbrace_win is None else min(minbrace_win, b2)
    if verbose:
        print("c=%d: Y1 ratio max %.4f; N_chi=%d (N_chi-c=%d, %.2f c^(2/3)); c+1/eta=%.2f; min true q on strip %.3f; c^2*brace (proven bounds): strip min %.4f, window min %.4f"
              % (c, float(y1max), Nchi, Nchi-c, (Nchi-c)/c**(2/3.), float(c+1/eta), float(minq), float(minbrace), float(minbrace_win)))
    return float(minbrace)

cs = [int(a) for a in sys.argv[1:]] if len(sys.argv) > 1 else [101, 102, 103, 113, 137, 160, 200]
for c in cs:
    run(c)
    sys.stdout.flush()
