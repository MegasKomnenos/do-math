# Peer: base computation of Proposition 6.3 (columns 12 <= c <= 24), exact integer arithmetic; rows n <= 30 only.
#   For each column c:  N0 = c + 2 (12<=c<=17), c + 3 (18<=c<=24);  J' = 2 (12<=c<=21), 3 (22<=c<=24).
#   Cells:  N0 <= N <= N0+J'-1 :  C_N(theta) >= 0,  theta = x_{3c} = (3c/(3c+1))^{3c-1},  i.e. with P=(3c)^{3c-1}, Q=(3c+1)^{3c-1}
#       N (N+1) A_{N-1,c-1} Q^2 - 2 (N+1) A_{N,c-1} P Q + A_{N+1,c-1} P^2  >=  0 .
#   A_{N,c-1} by the last-car recursion (exact integers).
# Also reported (information): the exact N_chi(c) = least N >= c+1 with C_N(theta) > 0, and the sign of C_N for c <= N <= N0+J'+5.
from math import comb
def cum_by_recursion(nmax, c):   # a[N] = A_{N,c-1}
    a = [1]
    for m in range(0, nmax):
        s = 0
        for j in range(0, m + 1):
            s += comb(m, j) * min(j + 1, c) * a[j] * a[m - j]
        a.append(s)
    return a
def Jp(c): return 2 if c <= 21 else 3
def N0f(c): return c + 2 if c <= 17 else c + 3
def cell(a, c, N):
    P = (3*c)**(3*c-1); Q = (3*c+1)**(3*c-1)
    return N*(N+1)*a[N-1]*Q*Q - 2*(N+1)*a[N]*P*Q + a[N+1]*P*P
tot = 0; viol = 0; maxrow = 0
print("c, N0, J', cells (N: sign), exact N_chi, signs of C_N for c <= N <= N0+J'+5")
for c in range(12, 25):
    N0 = N0f(c); J = Jp(c)
    top = N0 + J + 6
    a = cum_by_recursion(top + 1, c)
    assert a[c] == (c+1)**(c-1) and a[c+1] == (c+2)**c - (c+1)**(c-1)
    cells = []
    for N in range(N0, N0 + J):
        v = cell(a, c, N); tot += 1; maxrow = max(maxrow, N + 1)
        if v < 0: viol += 1
        cells.append((N, '+' if v > 0 else ('0' if v == 0 else '-')))
    signs = ''.join('+' if cell(a, c, N) > 0 else ('0' if cell(a, c, N) == 0 else '-') for N in range(c, top))
    Nchi = min(N for N in range(c+1, top) if cell(a, c, N) > 0)
    print(c, N0, J, cells, Nchi, signs)
print("cells:", tot, " violations:", viol, " largest row used:", maxrow)
assert maxrow <= 30
