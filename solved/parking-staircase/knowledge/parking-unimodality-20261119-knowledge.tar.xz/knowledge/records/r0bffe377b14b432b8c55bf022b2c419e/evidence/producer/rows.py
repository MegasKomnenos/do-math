# Exact rows b_{n,l} via last-car recursion:
# A_{n+1,k} = sum_m C(n,m) * min(m+1,k+1) * A_{m,k} * A_{n-m,k}
import sys, pickle, os
from math import comb
def cum_table(nmax):
    # A[k][n] for 0<=k<=nmax-1, 0<=n<=nmax ; for k>=n-1, A = (n+1)^(n-1)
    A = {}
    for k in range(0, nmax):
        a = [1]
        for n in range(0, nmax):
            if n+1 <= k+1:
                a.append((n+2)**n)
                continue
            s = 0
            for m in range(0, n+1):
                s += comb(n, m) * min(m+1, k+1) * a[m] * a[n-m]
            a.append(s)
        A[k] = a
    return A
if __name__ == "__main__":
    nmax = int(sys.argv[1])
    A = cum_table(nmax)
    with open(f"A_{nmax}.pkl","wb") as f:
        pickle.dump(A, f)
    # sanity
    def b(n,l):
        return A[l][n] - (A[l-1][n] if l>=1 else 0)
    for n in range(1,8):
        print(n, [b(n,l) for l in range(n)])
