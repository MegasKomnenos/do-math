# Remark for section 9: an alternative to the "one more step" bound.  With the explicit second decrement
#   D_{c+1} = d_{c+1} + 2 theta (theta w_c + w_{c+1})/(c+2) - theta w_c/(c+1)
# the mass argument gives N_chi < c + 1 + (w_c - D_c)/D_{c+1}; is the pivot bound alone then enough on the strip?
import mpmath as mp, sys
mp.mp.dps = 40
def xq(j): return (mp.mpf(j)/(j+1))**(j-1)
for c in [int(t) for t in sys.argv[1:]]:
    th = xq(3*c); m = lambda i: min(i+1, c)
    u = [mp.mpf(1)]
    for N in range(0, c+3):
        u.append(th*mp.fsum(m(i)*u[i]*u[N-i] for i in range(0, N+1))/(N+1))
    w = [mp.mpf(1), th]
    for j in range(2, c+4):
        w.append(w[-1]*th*(mp.mpf(j+1)/j)**(j-1))
    Dc = u[c]-u[c+1]; Dc1 = u[c+1]-u[c+2]
    formula = (w[c+1]-w[c+2])+2*th*(th*w[c]+w[c+1])/(c+2)-th*w[c]/(c+1)
    Nb = c+1+(w[c]-Dc)/Dc1
    G = [(c+j+1)*w[j] for j in range(0, c)]
    eps = 1-th/xq(c)
    Nchi = int(mp.ceil(Nb))-1
    worst = None
    for n in range(2*c+1, 3*c):
        L = n-1-Nchi
        q = 2-th*G[min(L, c-1)]
        tau = xq(n)/th; kap = xq(n+1)/xq(n); rho = xq(n+1)/th
        mg = (eps*(q/(n+1)-2*(rho-1))-((1-kap)*tau-(tau-1)**2/tau))*c*c
        if worst is None or mg < worst[0]: worst = (mg, n, q)
    print("c=%4d: D_{c+1} formula error %.1e ; c*D_c/w_c=%.4f c*D_{c+1}/w_c=%.4f ; N_chi < %.1f (%.4fc) ; pivot-only strip margin c^2*min=%.4f at n=%d (q=%.3f)" % (
        c, float(abs(formula-Dc1)/Dc1), float(c*Dc/w[c]), float(c*Dc1/w[c]), float(Nb), float(Nb/c), float(worst[0]), worst[1], float(worst[2])))
