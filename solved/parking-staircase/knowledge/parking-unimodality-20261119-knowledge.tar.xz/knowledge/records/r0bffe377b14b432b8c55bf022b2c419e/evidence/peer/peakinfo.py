# Peer (information only; not used in any proof): what the comparison of section 6,
#     2 - theta G(min(m - NB, c-1))  >=  2 (rho_n - 1)(m+1)        (window 2c+1 <= n <= 2c+J, n-J <= m <= n-1),
# accepts as an upper bound NB of the peak N_chi, against what the available arguments give.  Tilt theta = x_{3c}; mpmath 40 digits.
#   J     = least window length for which condition (iii) of Theorem 3.3 (with delta_c(n) = 1 - (x_{n+1}/x_c)(1 - sigma_c/n)) holds at every n of the window (kernel exact)
#   acc   = largest integer NB for which the comparison holds on the whole window
#   mass  = integer bound from Theorem S (na):  N_chi < c + 1/eta
#   L4.3  = integer bound from Lemma 4.3
#   gmass = best bound of the mass argument with exact D:  min over a >= c of  a + ceil(u_a/D_a) - 1
#   lin   = Lemma 4.4 with exact a, eta, minimised over (L, R)        (integer K)
#   rec   = the dip inequalities iterated exactly:  L_c = D_c,  L_j = max(L_{j-1}, [sum_{l=0}^{j-c} b_l L_{j-1-l} + E_{j+1}]/(xc+x-2)),
#           and the largest M with  sum_{j=c}^{M} L_j < w_c   (L_M := L_{M-1})
from mpmath import mp, mpf, ceil
from fractions import Fraction as F
from math import factorial
mp.dps = 40
def xm(m): return (mpf(m)/(m+1))**(m-1)
def xmF(m): return F(m, m+1)**(m-1)
def sigmaF(c): return 1 - c*xmF(c)**(c+1)*F((c+1)**(c-1), factorial(c))
def iii_slack(c, J, n, sg):
    x = xm(n+1)
    xG = (c+J+1)*x**(J+1)*mpf((J+1)**(J-1))/factorial(J)
    return (2-xG)*(1-(x/xm(c))*(1-sg/n)) - (n+1)*(1-x/xm(n))
def least_J(c):
    sF = sigmaF(c); sg = mpf(sF.numerator)/mpf(sF.denominator)
    for J in range(1, c):
        if all(iii_slack(c, J, n, sg) >= 0 for n in range(2*c+1, 2*c+J+1)): return J
def run(c):
    th = xm(3*c); Nmax = 2*c+3
    mi = lambda i: min(i+1, c)
    u = [mpf(1)]
    for N in range(0, Nmax):
        u.append(th*mp.fsum(mi(i)*u[i]*u[N-i] for i in range(0, N+1))/(N+1))
    w = [mpf(1)]
    for j in range(1, Nmax+1): w.append(w[-1]*th/xm(j))
    D = [u[N]-u[N+1] for N in range(0, Nmax)]
    C = [None]+[D[N-1]-D[N] for N in range(1, Nmax)]
    G = lambda i: (c+i+1)*w[i]
    h = lambda i: (i+1)*w[i]
    d = lambda j: w[j]-w[j+1]
    bb = lambda l: th*(G(l)-G(l+1))
    Nchi = min(N for N in range(c+1, Nmax-1) if C[N] > 0)
    J = least_J(c)
    def margin(NB):
        worst = None
        for n in range(2*c+1, 2*c+J+1):
            rho = xm(n+1)/th
            for m in range(n-J, n):
                if m-NB < 1: return None
                marg = (2-th*G(min(m-NB, c-1))) - 2*(rho-1)*(m+1)
                worst = marg if worst is None else min(worst, marg)
        return worst
    acc = None
    for NB in range(2*c, c, -1):
        mg = margin(NB)
        if mg is not None and mg >= 0: acc = NB; break
    eta = D[c]/w[c]
    mass = int(ceil(c+1/eta))-1
    l43 = int(ceil(c+1+(w[c]-D[c])/D[c+1]))-1
    gmass = min(a+int(ceil(u[a]/D[a]))-1 for a in range(c, 2*c))
    lin = None
    for L in range(0, 14):
        if th*G(L+1) > 2: continue
        S1 = mp.fsum((l+1)*bb(l) for l in range(0, L+1))
        for R in range(L+1, c-1):
            a = (2-th*G(R))/S1
            K = 0
            while R+K+1+a*K*(K+3)/2 < 1/eta: K += 1
            if lin is None or c+R+K < lin: lin = c+R+K
    xc2 = th*c+th-2
    def E(N): return th*mp.fsum((h(i)-h(i+1))*d(N-2-i) for i in range(N-c, c-1))
    Lo = {c-1: d(c-1), c: D[c]}
    rec = None
    for M in range(c+1, 2*c):
        j = M-1
        if j > c:
            val = (mp.fsum(bb(l)*Lo[j-1-l] for l in range(0, j-c+1)) + E(j+1))/xc2
            Lo[j] = max(Lo[j-1], val)
        if mp.fsum(Lo[t] for t in range(c, M)) + Lo[M-1] < w[c]: rec = M+1
        else: break
    return (c, J, Nchi, round(float(margin(Nchi)), 2), acc, mass, l43, gmass, lin, rec)
print("c, J, N_chi, margin with the true N_chi, acc, mass, L4.3, gmass, lin, rec")
ok = {k: [] for k in ("mass", "L4.3", "gmass", "lin", "rec")}
for c in range(12, 61):
    r = run(c)
    if c in (12, 13, 14, 16, 20, 24, 25, 28, 30, 36, 40, 50, 56, 60): print(r)
    for k, v in zip(("mass", "L4.3", "gmass", "lin", "rec"), r[5:]):
        if v <= r[4]: ok[k].append(c)
for k in ok: print("columns 12..60 where the bound '%s' is accepted:" % k, ok[k])
