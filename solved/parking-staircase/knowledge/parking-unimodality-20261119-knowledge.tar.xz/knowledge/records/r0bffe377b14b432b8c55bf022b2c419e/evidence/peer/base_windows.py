# Peer: exact-integer recomputation of the base cells.
# For 12<=k<=100: (L1) inequality  A_{n-1,k-1}/p_{n-1} - 2 A_{n,k-1}/p_n + A_{n+1,k-1}/p_{n+1} >= 0
#  (a) on the window  2k+1 <= n <= 2k+ceil(k/3)   (what the peer's main line needs)
#  (b) on the producer's strip 2k+1 <= n <= 3k-1   (what the producer's Theorem I needs)
# A_{N,k-1} from the last-car recursion (exact integers).  Sign test done with integers:
#  A_{n-1} p_n p_{n+1} - 2 A_n p_{n-1} p_{n+1} + A_{n+1} p_{n-1} p_n >= 0.
from math import comb
import sys, time
def col(c, nmax):
    a = [1]
    for m in range(0, nmax):
        s = 0
        for j in range(0, m+1):
            s += comb(m, j)*min(j+1, c)*a[j]*a[m-j]
        a.append(s)
    return a
def p(n): return 1 if n == 0 else (n+1)**(n-1)
t0 = time.time()
tot_w = tot_s = 0; viol_w = viol_s = 0; maxn_w = maxn_s = 0
minrel = None
for k in range(12, 101):
    Jk = -(-k//3)
    nmax = 3*k
    a = col(k, nmax)
    for n in range(2*k+1, 3*k):
        val = a[n-1]*p(n)*p(n+1) - 2*a[n]*p(n-1)*p(n+1) + a[n+1]*p(n-1)*p(n)
        ok = val >= 0
        tot_s += 1; viol_s += (not ok); maxn_s = max(maxn_s, n)
        if n <= 2*k+Jk:
            tot_w += 1; viol_w += (not ok); maxn_w = max(maxn_w, n)
        # relative size k^2 * second difference / phi_n  (float, information only)
        rel = k*k*val*p(n)/(a[n]*p(n-1)*p(n)*p(n+1)) if False else None
    if k % 10 == 0:
        print("k=%d done (%.0fs)" % (k, time.time()-t0)); sys.stdout.flush()
print("window cells 12<=k<=100, 2k+1<=n<=2k+ceil(k/3): %d cells, violations %d, largest n %d (rows up to %d)" % (tot_w, viol_w, maxn_w, maxn_w+1))
print("strip  cells 12<=k<=100, 2k+1<=n<=3k-1:          %d cells, violations %d, largest n %d (rows up to %d)" % (tot_s, viol_s, maxn_s, maxn_s+1))
