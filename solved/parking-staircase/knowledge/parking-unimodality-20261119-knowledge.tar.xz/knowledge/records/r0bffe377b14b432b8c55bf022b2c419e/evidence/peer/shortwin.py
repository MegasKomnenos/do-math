# Peer: shortest admissible window per column, by the exact rational criterion (W_{c,J}) of Lemma 3.4 (ra),
# and exact integer verification of the inequality (L1) on the base cells  12 <= c <= 55,  2c+1 <= n <= 2c+J_c
# (these are the only computed cells the proof of Theorem 7.1 uses), and, for comparison only, on 56 <= c <= 100.
#
# (W_{c,J}):  (2 - x*G(J)) * [ (1 - x/x_c) * N(N+2)/(N+1) + beta_c ]  >=  3/2,     N = 2c+J+1,  x = x_{N+1},
#   x_m = (m/(m+1))^(m-1),   x*G(J) = (c+J+1) x^(J+1) (J+1)^(J-1) / J!,
#   beta_c = (3678/10000) (1 - S(c)) / x_c,   S(c) = sum_{n=2}^{c+1} n^(n-1) x_c^n / n!   (the constant of Theorem K).
# J_c := least J in [1, c-1] with (W_{c,J}).
from fractions import Fraction as F
from math import comb, factorial

def xm(m):
    return F(m, m + 1) ** (m - 1)

_S = {}
def S(c):
    if c not in _S:
        x = xm(c)
        _S[c] = sum(F(n ** (n - 1), factorial(n)) * x ** n for n in range(2, c + 2))
    return _S[c]

def W(c, J):
    N = 2 * c + J + 1
    x = xm(N + 1)
    xc = xm(c)
    xG = (c + J + 1) * x ** (J + 1) * F((J + 1) ** (J - 1), factorial(J))
    beta = F(3678, 10000) * (1 - S(c)) / xc
    lhs = (2 - xG) * ((1 - x / xc) * F(N * (N + 2), N + 1) + beta)
    return lhs >= F(3, 2), lhs

def least_J(c):
    for J in range(1, c):
        if W(c, J)[0]:
            return J

def ceil_lam(c, num, den):
    # least integer t with t >= (num/den) c^(2/3), i.e. den^3 t^3 >= num^3 c^2
    t = 0
    while den ** 3 * t ** 3 < num ** 3 * c * c:
        t += 1
    return t

def cum_by_recursion(nmax, c):
    a = [1]
    for m in range(0, nmax):
        s = 0
        for j in range(0, m + 1):
            s += comb(m, j) * min(j + 1, c) * a[j] * a[m - j]
        a.append(s)
    return a

def p(n):
    return (n + 1) ** (n - 1) if n >= 1 else 1

CMAX_TABLE = 141
CBASE = 55
Jc = {}
for c in range(12, CMAX_TABLE + 1):
    assert 0 < S(c) < 1
    J = least_J(c)
    Jc[c] = J
    J85 = ceil_lam(c, 17, 20) - 1          # ceil(0.85 c^(2/3)) - 1   (Lemma 3.4 (da), all c >= 12)
    Jt = -(-c // 3)                          # ceil(c/3)
    assert J <= J85 <= c - 1 and W(c, J85)[0] and W(c, Jt)[0], c
    if c >= 45:
        J70 = ceil_lam(c, 7, 10) - 1       # ceil(0.7 c^(2/3)) - 1    (Lemma 3.4 (da), c >= 45)
        assert J <= J70 and W(c, J70)[0], c
    if J > 1:
        assert not W(c, J - 1)[0]
    for JJ in range(J, c):                   # monotonicity in J
        assert W(c, JJ)[0]

print("least J with (W_{c,J}), columns 12..%d (exact rationals):" % CMAX_TABLE)
start = 12
for c in range(12, CMAX_TABLE + 2):
    if c == CMAX_TABLE + 1 or Jc[c] != Jc[start]:
        print("  J_c = %2d  for %3d <= c <= %3d" % (Jc[start], start, c - 1))
        start = c
worst = min((W(c, Jc[c])[1] / F(3, 2), c) for c in range(12, CBASE + 1))
print("min over 12<=c<=%d of LHS/RHS of (W) at J_c: %.4f at c=%d" % (CBASE, float(worst[0]), worst[1]))
print("S(12)=%.4f, S(55)=%.4f, S(141)=%.4f" % (float(S(12)), float(S(55)), float(S(141))))
print("largest c with 2c+J_c <= 299 (range of the published observation):",
      max(c for c in range(12, CMAX_TABLE + 1) if 2 * c + Jc[c] <= 299))

def verify(c_lo, c_hi):
    viol = 0; cells = 0; maxn = 0
    for c in range(c_lo, c_hi + 1):
        J = Jc[c]
        a = cum_by_recursion(2 * c + J + 1, c)
        for n in range(2 * c + 1, 2 * c + J + 1):
            v = a[n - 1] * p(n) * p(n + 1) - 2 * a[n] * p(n - 1) * p(n + 1) + a[n + 1] * p(n - 1) * p(n)
            cells += 1
            maxn = max(maxn, n)
            if v < 0:
                viol += 1
    return cells, viol, maxn

cells, viol, maxn = verify(12, CBASE)
print("BASE  12<=c<=%d, 2c+1<=n<=2c+J_c: %d cells, violations %d, largest n %d (rows up to %d)" % (CBASE, cells, viol, maxn, maxn + 1))
cells2, viol2, maxn2 = verify(CBASE + 1, 100)
print("(comparison) %d<=c<=100, 2c+1<=n<=2c+J_c: %d cells, violations %d, largest n %d" % (CBASE + 1, cells2, viol2, maxn2))
tot_closed = sum((ceil_lam(c, 7, 10) - 1) if c >= 45 else (ceil_lam(c, 17, 20) - 1) for c in range(12, CBASE + 1))
print("(comparison) cells 12<=c<=%d with the closed-form windows of Lemma 3.4 (da): %d" % (CBASE, tot_closed))
print("(comparison) cells 12<=c<=100 with ceil(c/3): %d; cells of the strip 2c+1<=n<=3c-1: %d"
      % (sum(-(-c // 3) for c in range(12, 101)), sum(c - 1 for c in range(12, 101))))
