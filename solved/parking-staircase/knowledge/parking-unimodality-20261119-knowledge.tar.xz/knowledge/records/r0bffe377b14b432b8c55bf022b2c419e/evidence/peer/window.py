# Peer (information): conditions (i) and (iii) of Theorem 3.3 at the local tilt x = x_{n+1},
#   (i)   G nonincreasing on [0, c-1]
#   (iii) (2 - x G(J)) * delta_c(n) >= (n+1)(1 - x_{n+1}/x_n),   delta_c(n) = 1 - (x/x_c)(1 - sigma_c/n),   sigma_c = 1 - c x_c^{c+1} p_c/c!,
# and, for each c, the least J in [1,c-1] for which (iii) holds at every n with 2c+1 <= n < 12c.  mpmath 40 digits.
from mpmath import mp, mpf, exp, log, loggamma
mp.dps = 40
def xm(m): return (mpf(m)/(m+1))**(m-1)
def sigma(c):
    return 1 - c*exp((c+1)*log(xm(c)) + (c-1)*log(mpf(c+1)) - loggamma(c+1))
def minJ(c, n, sg):
    x = xm(n+1)
    delta = 1-(x/xm(c))*(1-sg/n)
    need = (n+1)*(1-xm(n+1)/xm(n))/delta   # need 2 - xG(J) >= need
    w = mpf(1); Gprev = mpf(c+1); mono = True
    best = None
    for J in range(1, c):
        w *= x*(mpf(J+1)/J)**(J-1)
        Gj = (c+J+1)*w
        if Gj > Gprev: mono = False
        Gprev = Gj
        if best is None and 2 - x*Gj >= need:
            best = J
    return best, float(need), mono
for c in [2,3,4,5,6,7,8,9,10,11,12,13,14,16,20,25,30,40,50,60,80,100,101,150,200,300,500,1000]:
    sg = sigma(c)
    worst = 0; worstn = None; allmono = True; at = None
    for n in range(2*c+1, 12*c):
        J, need, mono = minJ(c, n, sg)
        allmono = allmono and mono
        if J is None: J = 10**9
        if n == 2*c+1: at = (J, round(need, 4))
        if J > worst: worst, worstn = J, n
    print("c=%4d  sigma_c=%.4f  at n=2c+1: (least J, needed 2-xG) = %s   max over 2c+1<=n<12c: J=%s at n=%s   J/c^(2/3)=%.3f   (i) on the whole range: %s"
          % (c, float(sg), at, worst, worstn, worst/c**(2/3.), allmono))
