# Peer: check of every numerical statement in the proof of Proposition 5.2 ((Y1) at tilt theta = x_{3c}, c >= 25)
# and of Lemma 6.1 (ga), (na).  mpmath, 50 digits.
# It re-computes the numbers of a hand proof on examples; it is not part of the proof.
from mpmath import mp, mpf, exp, log
mp.dps = 50
def xm(m): return (mpf(m)/(m+1))**(m-1)
def ym(m): return (mpf(m)/(m+1))**m
fails = []
def chk(cond, tag):
    if not cond: fails.append(tag)
K = dict(w2='1.0436', a0='1.2524', tgt='3.8124', rho0='0.16', zlo='1.2916', zhi='0.375', efac='0.8125', e1='1.0494', e2='0.4063',
         two='1.8475', m1='1.9387', m2='0.7507', sA='1.8069', sB='1.542', z4='0.04833', w4='1.1561', b2='1.2791', small='2.5582',
         wj0='2.692', ej0='2.7646', t0e='1.4045', bt0='6.473', wt0='2.2963', et0='2.5', dt0='5.741', tot='12.22',
         zr='7.6108', er='6.705', fin='12.61', e_s2='0.4064', e_s3='0.3211', e_s4='0.2618')
K = {k: mpf(v) for k, v in K.items()}
# consistency of the constants among themselves (the arithmetic the text performs)
chk(mpf('1.2')*K['w2'] <= K['a0'], 'a0-const'); chk(mpf('2.56')+K['a0'] <= K['tgt'], 'tgt-const')
chk(mpf('1.5')*(1-mpf(5)/36) >= K['zlo'], 'zlo-const'); chk(1-K['zhi']/2 >= K['efac'], 'efac-const')
chk(K['efac']*K['zlo'] >= K['e1'] and K['efac']*mpf('0.5') <= K['e2'], 'e-const')
chk(2-K['tgt']/25 >= K['two'], 'two-const'); chk(K['two']*K['e1'] >= K['m1'] and K['two']*K['e2'] <= K['m2'], 'm-const')
chi = lambda rho: rho**mpf('-0.5')*exp(-(1-rho)/2)
chk(mpf('1.1')*chi(K['rho0']) <= K['sA'] < K['m1'], 'sub-A'); chk(mpf('1.4')*chi(mpf('0.5')) <= K['sB'] < K['m1'], 'sub-B')
chk(exp(3*K['z4']) <= K['w4'] and K['w4']*(1+mpf('2.2')*K['z4']) <= K['b2'] and 2*K['b2'] <= K['small'], 'small-T-const')
chk(K['wj0']*(1+K['t0e']) <= K['bt0'], 'bt0-const'); chk(K['wt0']*K['et0'] <= K['dt0'], 'dt0-const'); chk(K['bt0']+K['dt0'] <= K['tot'], 'tot-const')
chk((mpf('9.375')*(1-mpf(5)/(9*mpf('4.12')))-mpf('0.5')) >= K['zr'], 'zr-const')
chk(K['zr']*(1-K['zr']/(2*32)) >= K['er'], 'er-const'); chk(K['er']*(2-K['tgt']/32) >= K['fin'] > K['tot'], 'fin-const')
chk(mpf('0.75')-mpf(5)/24-mpf('0.02') >= mpf('0.5216') and 1-exp(-mpf('0.5216')) >= K['e_s2'], 'e_s2')
chk(mpf('0.5')-mpf(5)/54-mpf('0.02') >= mpf('0.3874') and 1-exp(-mpf('0.3874')) >= K['e_s3'], 'e_s3')
chk(mpf('0.375')-mpf('0.05209')-mpf(1)/52 >= mpf('0.3036') and 1-exp(-mpf('0.3036')) >= K['e_s4'], 'e_s4')
chk(K['e_s2']*(50-K['tgt']) >= mpf('18.77') > K['tot'] and K['e_s3']*(50-K['tgt']) >= mpf('14.83') > K['tot'] and K['e_s4']*(52-K['tgt']) >= mpf('12.61') > K['tot'], 'small-s-const')

def run(c):
    th = xm(3*c)
    w = [mpf(1)]
    for j in range(1, c+4): w.append(w[-1]*th/xm(j))
    d = [w[j]-w[j+1] for j in range(0, c+3)]
    h = [(j+1)*w[j] for j in range(0, c+3)]
    Cw = [None]+[d[j-1]-d[j] for j in range(1, c+2)]
    z = [log(xm(j+1)/th) for j in range(0, c+3)]
    e = [1-th/xm(j+1) for j in range(0, c+3)]
    cm = mpf(c)
    chk(th <= ym(c-1) < xm(c), ('1.1ga', c)); chk(th > exp(-1) and 1+log(th) <= 1/(2*cm), ('1.1ga2', c))
    chk(e[c-1] >= (1-mpf('1.28')/c)/c, ('5.1da-eps', c))
    chk(w[c-2] <= K['w2']*w[c-1], ('5.1da-w', c))
    for j in range(0, c+1):
        lo = mpf(3)/(2*(j+1)) - mpf(5)/(6*(j+1)**2) - 1/(2*cm)
        hi = mpf(3)/(2*(j+1)) - 1/(2*cm) + mpf(5)/(54*cm**2)
        chk(lo <= z[j] <= hi, ('5.3', c, j)); chk(z[j]-z[j]**2/2 <= e[j] <= z[j], ('5.3e', c, j))
    for i in range(0, c-1):
        chk(0 <= h[i]-h[i+1] <= w[i]*(cm-mpf('0.8')-i)/(2*cm), ('5.1ga', c, i))
    for a in range(1, c-1):
        for b in range(a+1, c):
            chk(w[a]/w[b] <= (mpf(b)/a)**mpf('1.5')*exp(-(b-a)/(2*cm)*(1-mpf(5)/(27*cm))), ('5.1na', c, a, b))
    worst = mpf(0)
    t0 = c//2; j0 = c-2-t0
    chk(w[j0] <= K['wj0']*w[c-1], ('wj0', c))
    chk(e[j0] <= K['ej0']/c, ('ej0', c))
    chk((t0+mpf('0.2'))*e[j0] <= K['t0e'], ('t0e', c))
    bt0 = w[j0]+(t0+mpf('0.2'))*d[j0]
    chk(bt0 <= K['bt0']*w[c-1], ('bt0', c))
    chk(w[t0+1] <= K['wt0']*w[c-1], ('wt0', c))
    chk(e[t0+1] <= K['et0']/c, ('et0', c))
    chk(d[t0+1] <= K['dt0']/c*w[c-1], ('dt0', c))
    chk(2-K['tgt']/c >= K['two'], ('two', c))
    chk(2*cm*cm*d[c-1] >= (2*cm-mpf('2.56'))*w[c-1], ('2c2d', c))
    chk(z[c-4] <= K['z4'] and w[c-4] <= K['w4']*w[c-1], ('w4', c))
    for r in range(1, c-1):
        T = c-2-r
        lhs = mp.fsum((h[i]-h[i+1])*Cw[r+c-1-i] for i in range(r, c-1))
        rhs = c*d[r]*d[c-1]
        chk(lhs <= rhs, ('Y1', c, r)); worst = max(worst, lhs/rhs)
        a = [(t+mpf('1.2'))*w[c-2-t] for t in range(0, T+1)]
        S1 = mp.fsum(a[t]*Cw[r+1+t] for t in range(0, T+1))/(2*cm)
        chk(lhs <= S1, ('S1', c, r))
        b = [None]+[a[t]-a[t-1] for t in range(1, T+1)]
        for t in range(2, T+1): chk(b[t] >= b[t-1] >= 0, ('b-mono', c, r, t))
        Sb = mp.fsum(b[t]*d[r+t] for t in range(1, T+1))
        chk(2*cm*S1 <= a[0]*d[r]+Sb, ('Abel', c, r))
        chk(a[0]*d[r] <= K['a0']*w[c-1]*d[r], ('a0', c, r))
        chk(Sb <= (2*cm-K['tgt'])*w[c-1]*w[r]*e[r], ('5.4', c, r))
        if T == 0: continue
        rho = mpf(r+1)/c
        if T <= 2:
            b2 = w[c-4]+mpf('2.2')*d[c-4]
            chk(Sb <= 2*b2*d[r] <= K['small']*w[c-1]*d[r] <= (2*cm-K['tgt'])*w[c-1]*d[r], ('small-T', c, r))
        elif rho >= K['rho0']:
            cheb = (a[T]-a[0])/T*(w[r+1]-w[c-1])
            chk(Sb <= cheb <= (1+mpf('1.2')/T)*w[r]*(w[r+1]-w[c-1]), ('cheb', c, r))
            ch = chi(rho)
            chk(w[r+1]/w[c-1] <= rho**mpf('-1.5')*exp(-(1-rho)/2), ('wratio', c, r))
            chk(z[r] >= (K['zlo']/rho-mpf('0.5'))/c, ('zr-lo', c, r))
            chk(z[r] <= K['zhi'], ('zr-hi', c, r))
            chk(e[r] >= (K['e1']/rho-K['e2'])/c, ('er-lo', c, r))
            chk((1+mpf('1.2')/T)*(ch-rho) <= K['m1']-K['m2']*rho, ('main-a', c, r))
            if rho <= mpf('0.5'):
                chk(T >= 12, ('T>=12', c, r)); chk((1+mpf('1.2')/T)*ch <= K['sA'], ('sub-A', c, r))
            else: chk((1+mpf('1.2')/T)*ch <= K['sB'], ('sub-B', c, r))
        else:
            chk(T > t0 >= 1, ('T>t0', c, r))
            chk(Sb <= bt0*w[r]+c*w[r]*d[t0+1] <= K['tot']*w[c-1]*w[r], ('split', c, r))
            if c >= 32:
                chk(z[r] >= K['zr']/c, ('zr-b', c, r)); chk(e[r] >= K['er']/c, ('er-b', c, r))
                chk((2*cm-K['tgt'])*K['er']/c >= K['fin'], ('final-b', c))
            else:
                s = r+1
                chk(s in (2, 3, 4), ('small-s-range', c, r))
                eb = {2: K['e_s2'], 3: K['e_s3'], 4: K['e_s4']}[s]
                if s == 4: chk(c >= 26, ('s4-c', c))
                chk(e[r] >= eb, ('small-s-e', c, r)); chk(eb*(2*cm-K['tgt']) >= K['tot'], ('small-s-final', c, r))
    Cc = w[c-1]-2*w[c]+w[c+1]-th/(c+1)*w[c]
    chk(Cc <= 0, ('Cc', c))
    chk(exp(z[c-1])-1 <= 1/cm+mpf('0.13')/cm**2, ('6.1ga-1', c))
    chk(1-exp(-z[c]) >= 1/cm-mpf('2.84')/cm**2, ('6.1ga-2', c))
    chk(1/cm-mpf('2.34')/cm**2 <= z[c] <= 1/cm, ('zc', c))
    chk(mpf('2.97')/cm**2 - mpf('0.3678')/(c+1) < 0, ('6.1ga-3', c))
    eta = 1-th/xm(c+1)+th/(c+1)
    chk(eta >= (1-mpf('2.84')/c+mpf('0.3678')*c/(c+1))/c, ('eta', c))
    Dc1 = w[c+1]*(1-th/xm(c+2)) - th*w[c]/(c+1) + 2*th*(th*w[c]+w[c+1])/(c+2)
    q = Dc1/w[c]
    bound = c+1+(1-eta)/q
    if c >= 56:
        chk(z[c+1] >= 1/cm-mpf('3.84')/cm**2, ('zc1', c))
        chk(exp(-z[c])*(1-exp(-z[c+1])) >= 1/cm-mpf('5.34')/cm**2, ('D-t1', c))
        chk(th/(c+1) <= mpf('0.36788')/c, ('D-t2', c))
        chk(2*th*(th+exp(-z[c]))/(c+2) >= mpf('1.0064')/c-mpf('2.75')/cm**2, ('D-t3', c))
        chk(q >= mpf('1.63852')/c-mpf('8.09')/cm**2 >= mpf('1.494')/c, ('Dc1', c))
        chk(eta >= mpf('1.3106')/c, ('eta56', c))
        chk(bound <= mpf('1.6694')*c+mpf('0.123'), ('Nchi-bound', c))
    return float(worst), float(eta*c), float(q*c), float(bound/c)

print("c, max ratio of the two sides of (Y1), c*eta, c*D_{c+1}/w_c, (c+1+(w_c-D_c)/D_{c+1})/c")
cs = list(range(25, 141)) + [150, 160, 180, 200, 250, 300, 400, 500, 700, 1000]
for c in cs:
    res = run(c)
    if c in (25, 26, 28, 30, 31, 32, 35, 40, 45, 50, 55, 56, 57, 58, 60, 70, 80, 101, 120, 150, 200, 300, 500, 1000):
        print(c, ["%.4f" % v for v in res])
print("columns checked:", len(cs), "(25..140 all, then 150, 160, 180, 200, 250, 300, 400, 500, 700, 1000)")
print("failures:", fails[:20], len(fails))
