# Peer: check of Lemma 1.2 (kernel bound) and of the items of Lemma 3.4, on examples (mpmath 40 digits).
# Re-computes the numbers of a hand proof; not part of the proof.
#   sigma_c = 1 - c x_c^{c+1} p_c / c!,  beta_c = 0.3678 sigma_c / x_c,  delta_c(n) = 1 - (x_{n+1}/x_c)(1 - sigma_c/n)
#   (W_{c,J}) at tilt x = x_{2c+2}:  (2 - xG(J)) [ (1 - x/x_c)(2c+1)(2c+3)/(2c+2) + beta_c ] >= 3/2
from mpmath import mp, mpf, exp, log, sqrt, pi, loggamma
mp.dps = 40
def xm(m): return (mpf(m)/(m+1))**(m-1)
def ceil_lam(c, num, den):
    t = 0
    while den**3 * t**3 < num**3 * c * c: t += 1
    return t
def sigma(c):
    # 1 - c x_c^{c+1} (c+1)^{c-1} / c!
    return 1 - c*exp((c+1)*log(xm(c)) + (c-1)*log(mpf(c+1)) - loggamma(c+1))
fails = []
def chk(cond, tag):
    if not cond: fails.append(tag)
def Psi(lam, c):
    a = lam*mpf(c)**(-mpf(1)/3)
    return (1+a)*exp(mpf('0.75')*a)/(sqrt(2*pi)*mpf(lam)**mpf('1.5'))
chk(Psi(mpf('0.66'), 12) < mpf('1.19'), 'Psi(0.66,12)')
chk(Psi(mpf('0.58'), 25) < mpf('1.256'), 'Psi(0.58,25)')
print("Psi(0.66,12) = %.6f, Psi(0.58,25) = %.6f" % (float(Psi(mpf('0.66'), 12)), float(Psi(mpf('0.58'), 25))))
chk(xm(12) < mpf('0.4146') and xm(25) < mpf('0.3902'), 'x12,x25')
maxG3 = {}
for c in list(range(12, 161)) + [200, 300, 500, 1000, 2000]:
    cm = mpf(c)
    ns = list(range(2*c+1, 2*c+41)) + [3*c, 4*c, 6*c, 10*c, 30*c, 100*c]
    J66 = ceil_lam(c, 33, 50) - 1
    J58 = ceil_lam(c, 29, 50) - 1
    J3 = -(-c // 3)
    chk(1 <= J58 <= J66 <= c-1, ('J-range', c))
    sg = sigma(c)
    lb = 1 - mpf('1.78794')*exp(1/cm)*c/mpf(c+1)**mpf('1.5')
    chk(sg >= lb and lb >= (mpf('0.5024') if c < 25 else mpf('0.6490')), ('sigma-lb', c))
    beta = mpf('0.3678')*sg/xm(c)
    chk(beta >= (mpf('0.4456') if c < 25 else mpf('0.6117')), ('beta', c))
    for n in ns:
        x = xm(n+1)
        s = mpf(3)/(4*c+4)
        chk(1+log(x) <= mpf(3)/(2*(n+1)) <= s <= 1/cm, ('s', c, n))
        w = [mpf(1)]
        for j in range(1, c+1): w.append(w[-1]*x/xm(j))
        G = [(c+j+1)*w[j] for j in range(0, c)]
        # Lemma 1.2
        for t in range(1, c+1):
            chk(x*G[t-1] <= (c+t)*exp(s*t)/(sqrt(2*pi)*mpf(t)**mpf('1.5')), ('1.2', c, n, t))
        # (ga)
        chk(all(G[l] >= G[l+1] for l in range(0, c-1)), ('3.4ga', c, n))
        # (na)
        a1 = 1-x/xm(c); a2 = (n+1)*(1-x/xm(n))
        delta = 1-(x/xm(c))*(1-sg/n)
        chk(delta >= a1 >= mpf('0.7151')/c, ('3.4na-1', c, n)); chk(a2 <= mpf(3)*(n+1)/(2*mpf(n)*(n+2)) < mpf('0.75')/c, ('3.4na-2', c, n))
        # (da)
        chk(x*G[J66] <= Psi(mpf('0.66'), c) <= mpf('1.19'), ('3.4da-0.66', c, n))
        if c >= 25: chk(x*G[J58] <= Psi(mpf('0.58'), c) <= mpf('1.256'), ('3.4da-0.58', c, n))
        chk(x*G[J3] <= mpf('0.81'), ('3.4da-c/3', c, n))
        maxG3[c] = max(maxG3.get(c, 0), x*G[J3])
        # (ra) at n = 2c+1: (W_{c,J}) for the closed-form lengths, and the closed-form thresholds
        if n == 2*c+1:
            br = a1*mpf((2*c+1)*(2*c+3))/(2*c+2)
            chk(br >= mpf('1.4302'), ('bracket', c))
            for J in ([J66, J3] + ([J58] if c >= 25 else [])):
                chk((2-x*G[J])*(br+beta) >= mpf('1.5'), ('W', c, J))
        # consequence: (iii) with these J at every n, and the slack 0.1/c for J = ceil(c/3)
        for J in ([J66, J3] + ([J58] if c >= 25 else [])):
            chk((2-x*G[J])*delta >= a2, ('iii', c, n, J))
        chk((2-x*G[J3])*a1 - a2 >= mpf('0.1')/c, ('slack-0.1', c, n))
print("columns: 12..160 all, then 200, 300, 500, 1000, 2000; n = 2c+1..2c+40, 3c, 4c, 6c, 10c, 30c, 100c")
print("max of x*G(ceil(c/3)) at c=12: %.4f" % float(maxG3[12]))
print("failures:", fails[:20], len(fails))
