# Numerical cross-check of the explicit inequalities used in the hand proofs of sections 4-6 (tilt theta = x_{3c}).
# These are closed-form (Cayley/Borel) quantities; nothing here is a table of A_{n,k}.  Evidence only; the proofs are by hand.
import mpmath as mp, sys
mp.mp.dps = 40
def xq(j): return (mp.mpf(j)/(j+1))**(j-1)
def yq(j): return (mp.mpf(j)/(j+1))**j
def kappa(al): return (1+al)*mp.e**(al/2)/(mp.sqrt(2*mp.pi)*al**mp.mpf(1.5))

def run(c, full=True):
    th = xq(3*c)
    w = [mp.mpf(1), th]
    for j in range(2, c+3):
        w.append(w[-1]*th*(mp.mpf(j+1)/j)**(j-1))
    d = [w[j]-w[j+1] for j in range(0, c+2)]
    Cw = [None]+[d[j-1]-d[j] for j in range(1, c+1)]
    h = [(i+1)*w[i] for i in range(0, c+1)]
    G = [(c+i+1)*w[i] for i in range(0, c)]
    ok = True
    def chk(name, cond):
        nonlocal ok
        if not cond:
            ok = False; print("   FAIL c=%d: %s" % (c, name))
    lt = mp.log(th)
    chk("N1", -1+mp.mpf(1)/(2*c)-mp.mpf(5)/(54*c*c) <= lt <= -1+mp.mpf(1)/(2*c)-mp.mpf(1)/(18*c*c))
    chk("N2 theta<=y_{c-1}", th <= yq(c-1))
    eps = 1-th/xq(c)
    chk("N3 eps", eps >= (1-mp.mpf('1.28')/c)/c)
    Cc = w[c-1]-2*w[c]+w[c+1]-th*w[c]/(c+1)
    chk("N4 C_c<=0", Cc <= 0 and Cc/w[c] <= mp.mpf('2.94')/c**2-mp.mpf('0.3679')/(c+1))
    eta = 1-th/xq(c+1)+th/(c+1)
    chk("N5 eta", eta >= mp.mpf('1.336')/c)
    # N6: Omega(i) <= kappa(alpha)/sqrt(c) whenever i+1 >= alpha c
    for al in (mp.mpf('0.25'), mp.mpf('0.15'), mp.mpf('0.1')):
        i0 = int(mp.ceil(al*c))-1
        chk("N6 alpha=%s" % al, th*G[i0] <= kappa(al)/mp.sqrt(c))
    # N7: theta*sum_{j<J} w_j >= 1 - 0.8/sqrt(J)
    S = mp.mpf(0)
    for J in range(1, c+1):
        S += th*w[J-1]
        if not (S >= 1-mp.mpf('0.8')/mp.sqrt(J)): chk("N7 J=%d" % J, False); break
    # monotonicity facts
    chk("h noninc", all(h[i] >= h[i+1] for i in range(0, c-1)))
    chk("G noninc", all(G[i] >= G[i+1] for i in range(0, c-1)))
    chk("w convex", all(Cw[j] >= 0 for j in range(1, c)))
    # (Y1): sum_{i=r}^{c-2} [h(i)-h(i+1)] Cw_{r+c-1-i} <= c d_r d_{c-1}
    worst = 0
    if full:
        for r in range(1, c-1):
            lhs = mp.fsum((h[i]-h[i+1])*Cw[r+c-1-i] for i in range(r, c-1))
            rhs = c*d[r]*d[c-1]
            worst = max(worst, lhs/rhs)
            # intermediate bounds of the proof
            T = c-2-r
            b1 = (h[r]-h[r+1])  # dummy
            # step A: 2c*lhs <= a_0 d_r + sum_{t=1}^T b_t d_{r+t},  a_t=(t+1.2)w_{c-2-t}, b_t=a_t-a_{t-1}
            a = [(t+mp.mpf('1.2'))*w[c-2-t] for t in range(0, T+1)]
            stepA = a[0]*d[r]+mp.fsum((a[t]-a[t-1])*d[r+t] for t in range(1, T+1))
            if not (2*c*lhs <= stepA*(1+mp.mpf(10)**(-25))): chk("Y1 stepA r=%d" % r, False)
            rho = mp.mpf(r+1)/c
            if rho >= mp.mpf('0.15'):
                bound = mp.mpf('1.2')*w[c-2]*d[r]+((1+mp.mpf('1.2')/T)*w[r]*(w[r+1]-w[c-1]) if T >= 1 else 0)
            else:
                t0 = c//2
                bt0 = w[c-2-t0]+(t0+mp.mpf('0.2'))*d[c-2-t0]
                bound = mp.mpf('1.2')*w[c-2]*d[r]+bt0*w[r+1]+(c-mp.mpf('0.8')-r)*w[r]*d[r+t0+1]
                if not (bt0 <= mp.mpf('5.29')*w[c-1]): chk("Y1 bt0", False)
                if not (d[t0+1] <= mp.mpf('5.55')*w[c-1]/c): chk("Y1 d_{t0+1}", False)
            if not (stepA <= bound*(1+mp.mpf(10)**(-25))): chk("Y1 regime bound r=%d" % r, False)
            if not (bound <= (2*c-mp.mpf('2.56'))*w[c-1]*d[r]): chk("Y1 final r=%d" % r, False)
        chk("Y1", worst <= 1)
    chk("w_{c-2}<=1.011 w_{c-1}", w[c-2] <= mp.mpf('1.011')*w[c-1])
    print("c=%5d: all explicit checks %s ; max (Y1) lhs/rhs = %.4f ; eta*c=%.4f eps*c=%.4f Omega(0.25c)*sqrt(c)=%.3f (kappa=%.3f)" % (
        c, "OK" if ok else "FAILED", float(worst), float(eta*c), float(eps*c), float(th*G[int(mp.ceil(c/4))-1]*mp.sqrt(c)), float(kappa(mp.mpf('0.25')))))

for c in [int(t) for t in sys.argv[1:]]:
    run(c)
