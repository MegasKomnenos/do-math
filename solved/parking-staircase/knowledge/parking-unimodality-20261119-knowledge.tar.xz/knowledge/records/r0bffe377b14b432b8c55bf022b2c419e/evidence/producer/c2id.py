# Exact check (rationals) of the second-difference identity for the critically tilted
# single-threshold mass u_N = x^N A_{N,c-1}/N!,  x = (c/(c+1))^(c-1).
# Purpose: verify a specific step (identity (C2)) of the argument under construction.
from fractions import Fraction as F
import sys

def run(c, Nmax):
    x = F(c, c+1)**(c-1)
    m = lambda i: min(i+1, c)
    u = [F(1)]
    for N in range(0, Nmax):
        s = sum(m(i)*u[i]*u[N-i] for i in range(0, N+1))
        u.append(x*s/(N+1))
    # Cayley tilted masses w_j = x^j (j+1)^(j-1)/j!
    w = [F(1)]
    for j in range(1, Nmax+1):
        w.append(w[-1]*x*F(j+1, j)**(j-1) if j > 1 else x)   # w_j/w_{j-1} = x*((j+1)/j)^(j-1)
    for j in range(0, c+1):
        assert u[j] == w[j], j
    D = [u[N]-u[N+1] for N in range(0, Nmax)]
    C = [None] + [D[N-1]-D[N] for N in range(1, Nmax)]
    G = lambda j: (c+j+1)*w[j]
    # (K1): (N+1) D_N = (1 - x m_N) u_N + x sum_{i<N} m_i u_i D_{N-1-i}
    for N in range(0, Nmax-1):
        lhs = (N+1)*D[N]
        rhs = (1-x*m(N))*u[N] + x*sum(m(i)*u[i]*D[N-1-i] for i in range(0, N))
        assert lhs == rhs, ("K1", N)
    # (C2): for N >= 2c:  (N+1) C_N = x sum_{j=0}^{c-2} [G(j)-G(c-1)] C_{N-1-j} + 2(1 - x c w_{c-1}) D_{N-1} + x c Q_N
    okfrom = None
    for N in range(c+1, Nmax-1):
        Q = sum(D[i]*D[N-2-i] for i in range(c, N-2-c+1)) if N-2-c >= c else 0
        rhs = x*sum((G(j)-G(c-1))*C[N-1-j] for j in range(0, c-1)) + 2*(1-x*c*w[c-1])*D[N-1] + x*c*Q
        ok = ((N+1)*C[N] == rhs)
        if ok and okfrom is None: okfrom = N
        if (not ok) and okfrom is not None:
            print("  (C2) fails again at", N); okfrom = None
    print("c=%d: (K1) exact for N<%d; (C2) exact for all N >= %s (checked up to %d)" % (c, Nmax-1, okfrom, Nmax-2))
    return u, w, D, C

for c in (3, 5, 8, 12):
    run(c, 6*c+5)
