# Peer: check of the quantitative corollary of Theorem P on exact data:
#   for k>=12, n >= 2k+1+ceil(k/3):   C_{n,k} := phi_{n-1}-2phi_n+phi_{n+1} >= 0.1 * phi_{n-1} / (k (n+1)).
# Also record the true size of k*(n+1)*C/phi_{n-1} and k^2*C/phi_n (information).
from fractions import Fraction as Fr
from base import cum_by_recursion
def p(n): return 1 if n == 0 else (n+1)**(n-1)
for k in (12, 13, 16, 20, 25, 30, 40):
    nmax = 6*k+2
    a = cum_by_recursion(nmax+2, k)
    phi = [Fr(a[N], p(N)) for N in range(nmax+2)]
    J = -(-k//3)
    worst = None; worst_all = None
    for n in range(2*k+1, nmax):
        Cn = phi[n-1]-2*phi[n]+phi[n+1]
        ratio = Cn*k*(n+1)/phi[n-1]
        if n >= 2*k+1+J:
            assert ratio >= Fr(1, 10), (k, n)
            worst = ratio if worst is None else min(worst, ratio)
        worst_all = ratio if worst_all is None else min(worst_all, ratio)
    print("k=%d: min of k(n+1)C/phi_{n-1} over 2k+1+J<=n<%d is %.3f ; over all n>=2k+1 it is %.3f" % (k, nmax, float(worst), float(worst_all)))
