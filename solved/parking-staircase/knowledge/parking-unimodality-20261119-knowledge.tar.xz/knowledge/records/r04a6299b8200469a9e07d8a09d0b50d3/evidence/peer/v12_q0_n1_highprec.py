# v12 (peer): 30-digit confirmation of the two integers q_0(k) and n_1(k) used in the (KK_k) test at k=2400.
#   True profile Psi_s = Pr(M_s<=k-2) by the one-level last-car recursion (tilted by e^{-s});
#   step_n ~ -J_n + sum_j (2 Psi_{j-1}/j)(gg_{k+1}(n;j)-gg_k(n;j));  Mem_n ~ sum_{j=k}^{n-1} kappa_{n-j} step_j.
import mpmath as mp, sys, time
mp.mp.dps = 30
def run(k, top):
    t0 = time.time()
    l = k - 2
    al = [mp.mpf(1)]
    em1 = mp.exp(-1)
    for n in range(1, top + 1):
        al.append(em1 * mp.fsum(min(j + 1, l + 1) * al[j] * al[n - 1 - j] for j in range(n)) / n)
    cs = lambda s: mp.exp(-s + (s - 1) * mp.log(s + 1) - mp.loggamma(s + 1))
    Psi = {s: al[s] / cs(s) for s in range(k - 1, top + 1)}
    Bor = [mp.mpf(0)] + [mp.exp(-g + (g - 1) * mp.log(g) - mp.loggamma(g + 1)) for g in range(1, top + 3)]
    kap = [mp.mpf(0), mp.exp(-1)] + [mp.exp(-m + (m - 1) * mp.log(m - 1) - mp.loggamma(m + 1)) for m in range(2, top + 3)]
    def response(c, w):
        X = {}
        for N in range(k, top + 1):
            X[N] = w(N) * N * Bor[N] + c * mp.fsum(Bor[N - s] * X[s] / s for s in range(k, N))
        return {n: mp.fsum(Bor[n + 1 - s] * X[s] / s for s in range(k, n + 1)) for n in range(k, top + 1)}
    w1 = lambda j: Psi[j - 1] / j
    Rk = response(k, w1); Rk1 = response(k + 1, w1)
    J = response(k + 1, lambda j: mp.mpf(1) / k if j == k else mp.mpf(0))
    step = {n: 2 * (Rk1[n] - Rk[n]) - J[n] for n in range(k, top + 1)}
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    Mem = {n: mp.fsum(kap[n - j] * step[j] for j in range(k, n)) for n in range(k + 1, top + 1)}
    n1 = next(n for n in range(k + 1, top + 1) if Mem[n] >= 0)
    print("k=%d: q_0=%d (step/J at q_0-1, q_0: %s, %s); n_1=%d (Mem/|Mem_{n_1-1}| at n_1-1, n_1: -1, %s)   [%.0fs]" % (
        k, q0, mp.nstr(step[q0 - 1] / J[q0 - 1], 6), mp.nstr(step[q0] / J[q0], 6), n1, mp.nstr(Mem[n1] / abs(Mem[n1 - 1]), 6), time.time() - t0), flush=True)
run(349, 400)
run(2400, 2545)
