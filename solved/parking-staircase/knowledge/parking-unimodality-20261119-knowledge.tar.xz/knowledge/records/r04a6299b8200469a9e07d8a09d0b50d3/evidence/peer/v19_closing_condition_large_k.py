# v19 (peer): checks for Lemma 8.3 (closing condition (ii) for k >= 50000) and the elementary bounds used in Corollary 8.2.  Not proof steps.
#   eps_m = (m-1)^(m-1)/m!,  g(m) = eps_{m+1}/eps_m,  gamma_k = (1+1/k)^(k-2),  x_k = (k/(k+1))^(k-1),  z_r = min(1/gamma_k, 1/g(r-1)).
#   (ii):  n kappa_r <= q kappa_{r_q},  kappa_m = z^m eps_m,  n = k+r, q = k+r_q;   in logs:  log n + r log z + log eps_r - log q - r_q log z - log eps_{r_q} <= 0.
# Only the kernel numbers enter (no parking-function table); the crossing deficit r_q is a parameter, and Lemma 8.3 uses r_q <= k^(2/3)+1.
import sys
from math import lgamma, log, exp, e
def leps(m): return ((m - 1) * log(m - 1) if m > 1 else 0.0) - lgamma(m + 1)
def lg(m): return leps(m + 1) - leps(m)

def elementary(mmax=2000):
    bad = 0
    for j in range(1, mmax):
        v = (1 + 1.0 / j) ** j
        if not (e * (1 - 1.0 / (2 * j + 1)) < v < e * (1 - 1.0 / (2 * j + 2))): bad += 1
    for m in range(1, mmax):
        if not exp(lg(m)) < e * (1 - 3.0 / (2 * (m + 1))): bad += 1
    for k in range(3, mmax):
        if not (1 + 1.0 / k) ** (k - 2) > e * (1 - 5.0 / (2 * k)): bad += 1
        if not (1 + 1.0 / k) ** (k - 1) > e * (1 - 3.0 / (2 * k)): bad += 1
    inc = sum(1 for m in range(1, mmax) if lg(m + 1) < lg(m))
    print("elementary bounds for j, m, k < %d: violations %d ; g nondecreasing: violations %d" % (mmax, bad, inc))

def column(k, rq):
    lgam = (k - 2) * log(1 + 1.0 / k)
    worst = (-1e9, None)
    for r in range(rq + 1, k):
        lz = -max(lgam, lg(r - 1))
        c = log(k + r) + r * lz + leps(r) - (log(k + rq) + rq * lz + leps(rq))
        if c > worst[0]: worst = (c, r)
    return worst

if __name__ == "__main__":
    elementary()
    for k in (50000, 100000, 1000000):
        K23 = k ** (2.0 / 3.0)
        psi = 1.5 * log((0.6 * k) / (K23 + 2)) - 2.1 - 4.0 / k
        expo = -1.5 * log((0.6 * k) / (K23 + 2)) + 0.6 * k * (5.0 / (2 * k) + 25.0 / (4.0 * k * k))
        print("k=%d: the two numbers of the proof: psi(3k/5) >= %.3f (needs >= 0) ; exponent in the case r > 3k/5 <= %.3f (needs <= -log 2 = -0.693)" % (k, psi, expo))
        for rq in (int(K23) + 1, int(0.6 * K23), 2):
            w = column(k, rq)
            print("     r_q = %6d: largest value of log(n kappa_r) - log(q kappa_{r_q}) over r_q < r <= k-1: %.5f at r = %d" % (rq, w[0], w[1]))
