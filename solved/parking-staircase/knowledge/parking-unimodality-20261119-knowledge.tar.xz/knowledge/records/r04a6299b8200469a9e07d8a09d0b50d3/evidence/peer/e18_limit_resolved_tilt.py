# e18 (peer): the resolved-form partial sum at the row-adapted tilt, in the limit.
# Finite k: tilt x_n = (1+1/r)^(-r) ~ e^{-1} e^{1/(2r)}  (r = n-k), the largest tilt for which the resolved kernel is nonincreasing on [0,r].
# Relative to tilt 1/e the term of row s gets the factor e^{theta (s-k)/r}, theta = 1/2, which is O(1) in the window.  Limit:
#   M_theta(z) := 1 - int_0^z e^{theta u/z} (2 f(u) + u f'(u)) du ,    M_0 = psi - z f.
# Prints M_0 and M_{1/2}, their zeros, minima, and the explorer's finite values (report 5.1; t03) for comparison.
import numpy as np
from limf import *
f = lambda z: talbot(fhat, z)
fp = lambda z: -talbot(etahat, z)
grid = np.concatenate([np.linspace(1e-3, 0.2, 40), np.linspace(0.2, 6.0, 291)[1:]])
h = np.array([2 * f(u) + u * fp(u) for u in grid])
def Mth(z, th):
    m = grid <= z + 1e-12
    u = grid[m]; v = np.exp(th * u / z) * h[m]
    # trapezoid on the grid plus the small piece [0, grid[0]] where 2f+uf' ~ c sqrt(u)
    return 1.0 - (np.trapezoid(v, u) + (2.0 / 3.0) * grid[0] * v[0])
zs = [1.0, 1.2, 1.35, 1.5, 1.62, 2.0, 2.15, 2.5, 2.69, 2.72, 3.0, 3.23, 3.77, 4.0, 4.25, 5.0, 6.0]
print("    z     M_0(z)   M_1/2(z)")
for z in zs:
    zz = grid[np.argmin(abs(grid - z))]
    print("  %5.2f  %8.4f  %8.4f" % (zz, Mth(zz, 0.0), Mth(zz, 0.5)))
for th in (0.0, 0.5):
    vals = np.array([Mth(z, th) for z in grid[60:]])
    zz = grid[60:]
    i0 = np.argmax(vals <= 0)
    print("theta=%.1f: first zero near z = %.2f ; minimum %.4f at z = %.2f" % (th, zz[i0], vals.min(), zz[np.argmin(vals)]))
print("explorer's finite values M~_n(x_n)/iota (t03): k=80: r=25,30,40,50,60,70,79 (z=1.35,1.62,2.15,2.69,3.23,3.77,4.25): 0.0630,-0.0142,-0.0813,-0.0901,-0.0786,-0.0625,-0.0487")
print("                                             k=40: r=20,25,30,39 (z=1.71,2.14,2.56,3.33): 0.0178,-0.0345,-0.0507,-0.0448")
# --- added: the zeros of M_0 and M_{1/2} by bisection (the grid above only brackets them).
# Substitution u = t^2 removes the square-root behaviour at 0; g(t) = (2 f(t^2) + t^2 f'(t^2)) 2t is tabulated once and interpolated.
tg = np.linspace(0.0, np.sqrt(1.9), 561)
c0 = f(1e-3) / np.sqrt(1e-3)                      # f(u) ~ c0 sqrt(u) at 0, so 2f + u f' ~ (5/2) c0 sqrt(u); the inversion is not used below u = 1e-3
gg = np.array([5 * c0 * t * t if t * t < 1e-3 else (2 * f(t * t) + t * t * fp(t * t)) * 2 * t for t in tg])
gx, gw = np.polynomial.legendre.leggauss(40)
def Mfine(z, th):
    tot = 0.0
    edges = np.linspace(0.0, np.sqrt(z), 9)
    for a, b in zip(edges[:-1], edges[1:]):
        t = 0.5 * (b - a) * gx + 0.5 * (b + a)
        tot += 0.5 * (b - a) * np.dot(gw, np.exp(th * t * t / z) * np.interp(t, tg, gg))
    return 1.0 - tot
print("check of the quadrature: M_0 at z_h = 1.5839 (zero from e17): %.2e ; M_0(1.0), M_1/2(1.0) = %.4f, %.4f (grid values 0.2336, 0.0026)" % (Mfine(1.5839, 0.0), Mfine(1.0, 0.0), Mfine(1.0, 0.5)))
for th, lo, hi in ((0.0, 1.4, 1.8), (0.5, 0.9, 1.2)):
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if Mfine(mid, th) > 0: lo = mid
        else: hi = mid
    print("theta=%.1f: zero of M_theta by bisection: z = %.4f" % (th, 0.5 * (lo + hi)))
