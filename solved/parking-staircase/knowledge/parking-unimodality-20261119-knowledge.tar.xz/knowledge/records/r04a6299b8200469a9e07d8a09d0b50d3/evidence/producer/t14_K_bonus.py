# Test 14 (tied to the argument).  Does the tilted form of property K (r26911cae Lemma 0: for all lambda>=0,
#   e^lambda*W(k+1) + e^-lambda*W(k-1) >= 2*e^(lambda/k)*W(k) ) applied to the diagonal triple
#   (d_{N-1}, b_N, a_{N+1}) = (u_{N-1}(k-1), u_N(k), u_{N+1}(k+1))  at the critical tilt
# give "debt <= one cell" (D1') at the deficit-adapted tilt z = x_k*e^lambda ?
# If the triple has property K, then at tilt z:  DC(N) >= 2(e^(lambda/k)-1) b_N,  and with the identity
#   U_J - h_J = sum_{N=k}^{J-1} DC(N) + e-_k - e-_J      (e-_N = b_N - d_{N-1})
# (D1') at row n=J+1 follows from
#   (**)   2(e^(lambda/k)-1) * sum_{N=k}^{J-1} b_N + e-_k  >=  e-_J .
# Tested here with exact tables (floats for the transcendental factor):
#  (1) property K of the diagonal triple itself, in the form (2.1), at lambda = log(z/x_k)   [i.e. DC(N) >= 2(e^(lambda/k)-1) b_N at tilt z]
#  (2) on which far rows (**) holds, and the ratio  LHS/RHS.
from pf import T
from fractions import Fraction as Fr
from math import factorial, log, exp
t = T(160)
def g(m):
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
print("k q0 Ri | K-form violations (cells) | far rows where (**) fails | min LHS/RHS (row) | LHS/RHS at r=Ri+1, 0.7k, 0.8k, 0.9k, k-1")
for k in [20, 30, 40, 50, 60, 79]:
    xk = Fr(k, k+1)**(k-1); xdag = Fr(k, k+1)**(k-2)
    Ri = max(r for r in range(1, k) if all(xdag*g(m) <= 1 for m in range(1, r)))
    q0 = next(n for n in range(k+1, 2*k+1) if t.d(n,k) > 0)
    kv = 0; fails = []; mn = (9e9, None); sel = {}
    for n in range(k+Ri+1, 2*k):
        r = n-k; J = n-1
        z = 1/g(r-1)
        lam = log(float(z/xk))
        bonus = 2*(exp(lam/k)-1)
        a = {i: z**i*Fr(t.A(i,k), factorial(i)) for i in range(k, n+1)}
        b = {i: z**i*Fr(t.A(i,k-1), factorial(i)) for i in range(k-1, n+1)}
        d = {i: z**i*Fr(t.A(i,k-2), factorial(i)) for i in range(k-1, n+1)}
        for N in range(k, J):
            DC = a[N+1]-2*b[N]+d[N-1]
            if float(DC) < bonus*float(b[N])*(1-1e-12): kv += 1
        em = lambda N: b[N]-d[N-1]
        lhs = bonus*float(sum(b[N] for N in range(k, J))) + float(em(k))
        rhs = float(em(J))
        ratio = lhs/rhs
        if ratio < 1: fails.append(n)
        if ratio < mn[0]: mn = (ratio, n)
        for tag, rr in (("Ri+1", Ri+1), ("0.7k", int(0.7*k)), ("0.8k", int(0.8*k)), ("0.9k", int(0.9*k)), ("k-1", k-1)):
            if r == rr: sel[tag] = round(ratio, 3)
    print(k, q0, Ri, "|", kv, "|", (fails if len(fails) <= 6 else "%d rows %d..%d" % (len(fails), fails[0], fails[-1])), "| %.3f (n=%s) |" % mn, sel)
