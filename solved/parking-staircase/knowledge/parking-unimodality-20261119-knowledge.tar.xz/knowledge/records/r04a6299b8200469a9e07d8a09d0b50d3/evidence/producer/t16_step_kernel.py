# Test 16 (tied to the argument).  The step eta_n = V_n - U_n as a linear functional of the survival masses d_s = w_s*Psi_s (s=k-1..n-1)
# of level k-2 (first layer), via the forward recursions of t15:
#      eta_n = sum_{s=k-1}^{n-1} c_n(s) d_s .
# Questions: (1) sign pattern of s -> c_n(s) for each row n;  (2) is the kernel "ordered in n" in the sense
#      c_{n+1}(s)/c_n(s)  >=  c_{n+1}(k-1)/c_n(k-1)   for all k <= s <= n-1   (and c_{n+1}(n) >= 0) ?
# If (2) holds at row n then eta_{n+1} >= rho_n * eta_n with rho_n = c_{n+1}(k-1)/c_n(k-1) > 0 for EVERY nonnegative
# sequence (d_s), i.e. sign persistence would follow from the kernel alone.  Tilt: 1 (no tilt; the statement is tilt-free
# up to the factor z, since c_n(s) scales as z^(n-s)).
from fractions import Fraction as Fr
from math import factorial, comb
def cay(i): return Fr((i+1)**(i-1), factorial(i)) if i > 0 else Fr(1)
def coeffs(k, nmax):
    # returns c[n][s] for n=k..nmax, s=k-1..n-1 (exact rationals), tilt z=1
    w = [cay(i) for i in range(0, nmax+1)]
    c = {n: {} for n in range(k, nmax+1)}
    for s in range(k-1, nmax):
        U = {k-1: Fr(0)}; V = {k: Fr(0)}
        dd = lambda i: Fr(1) if i == s else Fr(0)
        for j in range(k, nmax+1):
            U[j] = sum(w[j-tt]*Fr(1, tt)*(k*U[tt-1] + dd(tt-1)) for tt in range(k, j+1))
        for j in range(k+1, nmax+1):
            V[j] = sum(w[j-tt]*Fr(1, tt)*((k+1)*V[tt-1] + U[tt-1] + dd(tt-1)) for tt in range(k+1, j+1))
        for n in range(max(k, s+1), nmax+1):
            c[n][s] = V.get(n, Fr(0)) - U[n]
    return c
for k in [6, 10, 16, 24]:
    nmax = 2*k-1
    c = coeffs(k, nmax)
    print("==== k=%d (rows n=k..2k-1)" % k)
    for n in range(k, nmax+1):
        signs = ''.join('+' if c[n][s] > 0 else ('-' if c[n][s] < 0 else '0') for s in range(k-1, n))
        line = " n=%d signs(s=k-1..n-1): %s" % (n, signs)
        if n < nmax:
            rho = c[n+1][k-1]/c[n][k-1]
            # ordering test
            bad = [s for s in range(k, n) if c[n][s] != 0 and (c[n+1][s] - rho*c[n][s])*(1 if c[n][s] > 0 else 1) < 0]
            # proper statement: c_{n+1}(s) >= rho*c_n(s) for all s (then eta_{n+1} >= rho eta_n when d>=0)
            bad2 = [s for s in range(k, n) if c[n+1][s] < rho*c[n][s]]
            line += " | rho_n=%.4f ; s with c_{n+1}(s) < rho*c_n(s): %s ; c_{n+1}(n)>=0: %s" % (float(rho), bad2 if len(bad2) <= 8 else "%d of %d" % (len(bad2), n-k), c[n+1][n] >= 0)
        print(line)
