# v14 (peer): exact check of (2.1') -- the three negative parts of the three published splittings of the step.
#   |B| = G_{k+1}(n,k)/k  (kernel form; impulse response),  L = G_k(n,k)/k  (loss),  B_- = G_{k-1}(n,k)/k  (blocks),
# where G_c(n,k) sums, over forests on [n] with a marked vertex of subtree size k, the product of c/t_w over its proper ancestors.
# Checks, for k=3..14 and k <= n <= 2k-1:
#   (a) B_- = K_{n,k}(k-1) - A_{n,k-2}, via  d_{n,k} = C_- - B_-  with C_- = d + B_- >= 0 and  2|A| := d + |B| >= C_-;
#   (b) B_- <= L <= |B| <= (1+1/k)^(n-k) L   and   (1-(n-k)/k) L <= B_-.
from fractions import Fraction as Fr
from ptab import Tab
from green import H_table, G_from_H
t = Tab(28)
ok = True; cnt = 0
worst = Fr(0)
for k in range(3, 15):
    Hm = H_table(k - 1, k, 2 * k - 1); H0 = H_table(k, k, 2 * k - 1); Hp = H_table(k + 1, k, 2 * k - 1)
    for n in range(k, min(2 * k - 1, 28) + 1):
        Bm = G_from_H(Hm, k, n) / k; L = G_from_H(H0, k, n) / k; Bk = G_from_H(Hp, k, n) / k
        d = t.d(n, k)
        Cm = d + Bm
        a_ok = (Cm >= 0) and (d + Bk >= Cm)
        b_ok = (Bm <= L <= Bk <= Fr(k + 1, k) ** (n - k) * L) and (Fr(2 * k - n, k) * L <= Bm)
        ok &= a_ok and b_ok; cnt += 1
        worst = max(worst, Bk / Bm - 1)
print("cells checked: %d ; all inequalities hold: %s ; max of |B|/B_- - 1 = %.4f" % (cnt, ok, float(worst)))
# independent check of B_- against the published definition on small cases by forest enumeration is in v02 ((2.1) itself).
for k in (20, 40, 80):
    Hm = H_table(k - 1, k, 2 * k - 1); Hp = H_table(k + 1, k, 2 * k - 1)
    r = round(k ** (2 / 3)); n = k + r
    print("k=%d, n=k+%d (window): |B|/B_- = %.4f ; at n=2k-1: %.4f ; bound (1+1/k)^r/(1-r/k) at window row: %.4f" % (
        k, r, float(G_from_H(Hp, k, n) / G_from_H(Hm, k, n)), float(G_from_H(Hp, k, 2 * k - 1) / G_from_H(Hm, k, 2 * k - 1)),
        (1 + 1 / k) ** r / (1 - r / k)))
