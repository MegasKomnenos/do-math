# Test 6 (tied to the argument).  Soft chain at the row-adapted tilt x_n = min(x_dag, 1/g(n-k-1)):
#  (a) kernel x^m eps_m nonincreasing on 1<=m<=n-k  (by the choice of x_n),
#  (b) Dg (published c10) gives V_j >= (x/x_dag) U_{j-1}, hence  h_{n-1} <= B'_n := U_{n-1} + (1-x/x_dag) * sum_{j=k}^{n-2} U_j,
#  (c) step (*) of the proof of Theorem P:  eta_n<=0  ==>  kappa_{t+1} h_{n-1} > (2x/n) U_{n-1},  t=n-q0.
# So d_{n,k}>0 follows from (SC_x):  kappa_{t+1} * B'_n <= (2x/n) U_{n-1}.
# For n-k <= R_i(k) this is condition (iii) of Theorem P (no column data); beyond, it is a statement on column k-1 only.
# Question: on which rows after the crossing does [(ii) or (iii) at x_dag, r<=R_i]  or  [(SC_x)] hold?  margins?
from pf import T
from fractions import Fraction as Fr
from math import factorial
t = T(160)
def g(m):
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
def eps(m): return Fr((m-1)**(m-1), factorial(m)) if m>1 else Fr(1)
def run(k):
    xdag = Fr(k, k+1)**(k-2)
    Ri = max(r for r in range(1, k) if all(xdag*g(m) <= 1 for m in range(1, r)))
    q0 = next(n for n in range(k+1, 2*k+1) if t.d(n,k) > 0)
    rows = []
    for n in range(q0+1, 2*k):
        r = n-k; tt = n-q0
        x = min(xdag, 1/g(r-1)) if r >= 2 else xdag
        kap = lambda m: x**m*eps(m)
        U = {j: x**j*Fr(t.b(j,k-1), factorial(j)) for j in range(k, n)}
        V = {j: x**j*Fr(t.b(j,k), factorial(j)) for j in range(k, n)}
        h = sum(U[j]-V[j] for j in range(k, n))
        Bp = U[n-1] + (1-x/xdag)*sum(U[j] for j in range(k, n-1))
        allowed = (2*x/n)/kap(tt+1)
        ii = (n*kap(r))/(q0*kap(q0-k))
        sc = allowed*U[n-1]/Bp       # >=1 : soft chain closes
        rows.append((n, r, r <= Ri, float(h/U[n-1]), float(Bp/U[n-1]), float(allowed), float(sc), float(ii)))
    return q0, Ri, rows
print("k q0 Ri | uncovered rows (neither [(ii) with r<=Ri] nor SC_x) | min SC margin over rows r>Ri | at row")
for k in [20, 24, 30, 36, 40, 50, 60, 70, 79]:
    q0, Ri, rows = run(k)
    unc = [(n, r, round(sc,3), round(ii,3)) for (n, r, inRi, hU, BU, al, sc, ii) in rows if not (sc >= 1 or (inRi and ii <= 1))]
    far = [(sc, n, r, hU, BU, al) for (n, r, inRi, hU, BU, al, sc, ii) in rows if not inRi]
    m = min(far) if far else None
    print(k, q0, Ri, "|", unc, "|", (round(m[0],3), "n=%d r=%d h/U=%.3f B'/U=%.3f allowed=%.3f" % (m[1], m[2], m[3], m[4], m[5])) if m else None)
    for (n, r, inRi, hU, BU, al, sc, ii) in rows:
        if r in (Ri+1, int(0.7*k), int(0.8*k), int(0.9*k), k-1):
            print("     n=%d r=%d  h/U=%.3f  B'/U=%.3f  allowed=%.3f  SC margin=%.3f" % (n, r, hU, BU, al, sc))
