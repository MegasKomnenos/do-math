# v09 (peer): exact verification of the "cut profile" statement at k=120 and k=148.
# True profile Psi_s = A_{s,k-2}/p_s for s <= S, and 0 for s > S.  The column built from it agrees with the true column
# on rows n <= S+1 (row n only uses Psi_s with s <= n-2).  Exact integers/rationals throughout:
#   A_{n,l} at the single level l=k-2 by the last-car recursion; the column by the Green-function form (green.py logic).
from fractions import Fraction as Fr
from math import comb
import sys, time
def level_table(l, nmax):
    A = [1]
    for n in range(1, nmax + 1):
        if l >= n - 1:
            A.append((n + 1) ** (n - 1)); continue
        A.append(sum(comb(n - 1, j) * min(j + 1, l + 1) * A[j] * A[n - 1 - j] for j in range(n)))
    return A
def pw(a, e):
    return a ** e if e >= 0 else 1
def H_table_int(c, j, Nmax):
    H = {j: j ** (j - 1)}
    for N in range(j + 1, Nmax + 1):
        H[N] = c * sum(comb(N - 1, s) * pw(N - s, N - s - 2) * H[s] for s in range(j, N))
    return H
def G_int(H, j, n):
    return sum(comb(n, s) * pw(n + 1 - s, n - s - 1) * H[s] for s in range(j, n + 1))
def steps(k, Scut, top):
    A = level_table(k - 2, Scut)
    p = lambda s: 1 if s == 0 else (s + 1) ** (s - 1)
    step = {n: Fr(0) for n in range(k, top + 1)}
    for j in range(k, Scut + 2):
        Hk = H_table_int(k, j, top); Hk1 = H_table_int(k + 1, j, top)
        psi = Fr(A[j - 1], p(j - 1))
        for n in range(j, top + 1):
            gk = G_int(Hk, j, n); gk1 = G_int(Hk1, j, n)
            step[n] += 2 * psi * Fr(gk1 - gk, j)
            if j == k:
                step[n] -= Fr(gk1, k)
    return step
for (k, q0, cuts) in [(120, 143, (141, 142)), (148, 174, (172, 173, 174))]:
    top = 2 * k - 1
    for S in cuts:
        t0 = time.time()
        st = steps(k, S, top)
        neg_before = all(st[n] <= 0 for n in range(k, q0))
        firstpos = st[q0] > 0
        bad = [n for n in range(q0, top + 1) if st[n] < 0]
        print("k=%d, true profile cut at S=%d (q0=%d): steps<=0 on rows %d..%d: %s; step at q0 >0: %s; negative rows after q0: %s   [%.0fs]" % (
            k, S, q0, k, q0 - 1, neg_before, firstpos, ("none" if not bad else "%d..%d (%d rows)" % (bad[0], bad[-1], len(bad))), time.time() - t0), flush=True)
