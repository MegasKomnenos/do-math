# Test 26 (tied to the argument).  Does "kernel form + nonincreasing survival profile + sign pattern WITH THE CROSSING AT
# A GIVEN EARLY ROW q" force eta_{n+1} >= 0 up to the end of the first layer?   (float LP of test 21, fact set 'Pat' only.)
# For each k we take q in {q_imm, ..., q0+2} (q_imm = crossing row of the immortal model, q0 = true crossing row) and the
# target rows n+1 near the end of the first layer.  A negative optimum is re-evaluated from the returned profile:
# the profile is rebuilt as a mixture of death times, every pattern constraint and the objective are recomputed directly.
import sys
import numpy as np
from t21_softcone_lp_float import columns, solve

if __name__ == '__main__':
    k = int(sys.argv[1])
    q0 = int(sys.argv[2])
    rows = [int(a) for a in sys.argv[3:]]
    U, E, om, gam_t, top = columns(k)
    # immortal model = death time 'top' (never dies inside the layer)
    q_imm = next(n for n in range(k + 1, top + 1) if E[top][n] > 0)
    print("k=%d: q_imm=%d, true q0=%d, last row of the layer 2k-1=%d" % (k, q_imm, q0, top))
    for n in rows:
        out = []
        for q in range(q_imm, q0 + 3):
            st, mu, val, worst = solve(k, q, n, U, E, om, gam_t, ('Pat',))
            if st == 'infeasible':
                out.append((q, 'empty'))
                continue
            # independent re-evaluation of the returned profile
            Ss = list(range(k - 1, n + 2))
            eta = {j: float(sum(mu[a] * E[S][j] for a, S in enumerate(Ss))) for j in range(k, n + 2)}
            pat_ok = all(eta[j] <= 1e-9 * abs(E[k - 1][j]) for j in range(k, q)) and all(eta[j] >= -1e-9 * abs(E[k - 1][j]) for j in range(q, n + 1))
            out.append((q, '%.3e' % (eta[n + 1] / abs(E[k - 1][n + 1])), 'pattern ok' if pat_ok else 'PATTERN VIOLATED', 'support %s' % [(S, round(float(m), 3)) for S, m in zip(Ss, mu) if m > 1e-6]))
        print(" target row n+1=%d (deficit %d):" % (n + 1, n + 1 - k))
        for o in out:
            print("    q=%s: min eta_{n+1}/|impulse| = %s" % (o[0], ' ; '.join(str(v) for v in o[1:])))
