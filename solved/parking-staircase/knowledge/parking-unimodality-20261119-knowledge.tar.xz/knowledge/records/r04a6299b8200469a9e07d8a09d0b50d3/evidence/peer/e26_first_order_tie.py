# e26 (peer): the first-order term of "cell minus debt" at the critical tilt (test of a formal computation; not a proof step).
#
# Exact identity (first layer, any tilt z).  omega_N = z^N p_N/N!,  m_N(l) = Pr(M_N = l),  F_N(l) = Pr(M_N <= l),
# stay_N(l) = F_{N+1}(l) - F_N(l-1)  (numerator of the published transition ratio).  With U_j = omega_j m_j(k-1), V_j = omega_j m_j(k),
#   S_J := U_J - h_J = sum_{N=k+1}^{J} V_N - sum_{N=k}^{J-1} U_N = T1 + T2 + T3,
#   T1 = sum_{N=k}^{J-1} (omega_{N+1} - omega_N) m_N(k-1)                           (gain from the tilt; >= 0 at tilts >= critical)
#   T2 = - omega_{J+1} stay_J(k)                                                   (boundary term)
#   T3 = sum_{N=k}^{J-1} [ omega_{N+2} stay_{N+1}(k) - omega_{N+1} stay_N(k-1) ]     (the two stays have the same deficit N-k+2)
# (from m_{N+1}(k) - m_N(k-1) = stay_N(k) - stay_N(k-1), stay_k(k) = 0, and one Abel summation).
#
# Formal window limit at the critical tilt z = x_k, X = (J-k)/k^{2/3}, f = limit density, m1(X) = int_0^X y f(y) dy:
#   k^{4/3} T1/omega_k -> (3/2) m1(X),     k T2/omega_k -> -(2/3) X f(X),     k^{4/3} T3/omega_k -> -(2/9) m1(X) - (4/9) X^2 f(X).
# Consequence for rows in the bulk (X -> infinity):  k^{4/3} S_J/omega_k -> (23/18) E[Y],  E[Y] = int_0^inf psi = c^{2/3} Gamma(1/3) = 2.5758.
#
# Usage:  python e26_first_order_tie.py window k1 k2 ...     (rows at fixed window coordinate X)
#         python e26_first_order_tie.py bulk k1 k2 ...       (rows at deficit 0.6k, 0.8k and the junction row 2k-2)
#         python e26_first_order_tie.py check k              (direct evaluation of T3 against S - T1 - T2)
#         python e26_first_order_tie.py zero k1 k2 ...       (first row from which debt <= cell at the critical tilt, and the first-order prediction)
#         python e26_first_order_tie.py termwise k1 k2 ...   (is T1 + T3 nonnegative term by term?  double precision suffices up to k about 1600)
# Outputs: e26_first_order_tie_check.out.txt, _window.out.txt, _bulk.out.txt, _zero.out.txt, _termwise.out.txt.
import numpy as np, sys, time
from math import log, exp, gamma
from kern import column, true_profile, bor

def data(k, top):
    B = bor(top + 3)
    Psi = true_profile(k, top)
    cell, step, Jimp = column(k, Psi, top, B)
    N = np.arange(0, top + 1)
    lz = 1.0 + (k - 1) * log(k / (k + 1.0))                 # log(e x_k)
    om = np.zeros(top + 2)                                   # omega_N / omega_k
    for n in range(k - 1, top + 2):
        om[n] = exp((n - k) * lz) * B[n + 1] / B[k + 1]
    m1 = np.zeros(top + 1); m0 = np.zeros(top + 1)
    m1[k:] = cell[k:top + 1] / B[k + 1:top + 2]              # m_N(k-1)
    m0[k:] = (cell[k:top + 1] + step[k:top + 1]) / B[k + 1:top + 2]   # m_N(k)
    Fk2 = Psi                                                # F_N(k-2)
    Fk1 = Psi + m1                                           # F_N(k-1)   (valid for N >= k)
    Fk = Fk1 + m0                                            # F_N(k)
    stay_k = np.zeros(top + 1); stay_k1 = np.zeros(top + 1)
    stay_k[k:top] = Fk[k + 1:top + 1] - Fk1[k:top]           # stay_N(k),   k <= N <= top-1
    stay_k1[k:top] = Fk1[k + 1:top + 1] - Fk2[k:top]         # stay_N(k-1)
    Ucell = om[:top + 1] * m1                                # U_N / omega_k
    eta = np.zeros(top + 1)
    eta[k:] = om[k:top + 1] * step[k:top + 1] / B[k + 1:top + 2]   # (V_N - U_N)/omega_k
    return dict(om=om, m1=m1, m0=m0, stay_k=stay_k, stay_k1=stay_k1, U=Ucell, eta=eta)

def terms(d, k, J, direct=False):
    om, m1 = d["om"], d["m1"]
    S = d["U"][J] + np.sum(d["eta"][k:J + 1])
    T1 = np.sum((om[k + 1:J + 1] - om[k:J]) * m1[k:J])
    T2 = -om[J + 1] * d["stay_k"][J]
    T3 = S - T1 - T2
    if direct:
        T3d = np.sum(om[k + 2:J + 2] * d["stay_k"][k + 1:J + 1] - om[k + 1:J + 1] * d["stay_k1"][k:J])
        return S, T1, T2, T3, T3d
    return S, T1, T2, T3

if __name__ == "__main__":
    mode = sys.argv[1]
    ks = [int(a) for a in sys.argv[2:]]
    if mode == "check":
        for k in ks:
            d = data(k, 2 * k - 1)
            for J in (k + 3, k + int(k ** (2 / 3)), k + k // 2, 2 * k - 2):
                S, T1, T2, T3, T3d = terms(d, k, J, True)
                print("k=%d J=%d: S=%.6e  T1=%.6e  T2=%.6e  T3=S-T1-T2=%.6e  T3 direct=%.6e  (difference %.1e)" % (k, J, S, T1, T2, T3, T3d, abs(T3 - T3d)))
    elif mode == "window":
        from limf import talbot, Shat, fhat
        Xs = (1.0, 1.5, 2.0, 3.0, 4.0, 6.0)
        f = lambda z: talbot(fhat, z)
        psi = lambda z: talbot(Shat, z)
        ipsi = lambda z: talbot(lambda l: Shat(l) / l, z)
        print("limit functions:   X      (3/2) m1(X)   -(2/3) X f(X)   -(2/9) m1 - (4/9) X^2 f     [m1(X) = int_0^X y f]")
        lim = {}
        for X in Xs:
            m1X = ipsi(X) - X * psi(X)
            lim[X] = (1.5 * m1X, -(2 / 3) * X * f(X), -(2 / 9) * m1X - (4 / 9) * X * X * f(X))
            print("                 %5.2f   %10.4f   %12.4f   %14.4f" % (X, lim[X][0], lim[X][1], lim[X][2]))
        for k in ks:
            t0 = time.time()
            sc = k ** (2 / 3)
            top = min(2 * k - 1, k + int(6.0 * sc) + 3)
            d = data(k, top)
            print("k=%d   [%.0fs]" % (k, time.time() - t0))
            print("     X     k^(4/3) T1/om_k  (limit)     k T2/om_k   (limit)     k^(4/3) T3/om_k  (limit)     k^(4/3) S/om_k")
            for X in Xs:
                J = k + int(round(X * sc))
                if J > top - 1: continue
                S, T1, T2, T3 = terms(d, k, J)
                Xe = (J - k) / sc
                print("  %5.2f   %10.4f   (%7.4f)   %10.4f  (%7.4f)   %10.4f   (%7.4f)   %10.4f" % (
                    Xe, k ** (4 / 3) * T1, lim[X][0], k * T2, lim[X][1], k ** (4 / 3) * T3, lim[X][2], k ** (4 / 3) * S), flush=True)
    elif mode == "bulk":
        EY = (2 * 2 ** 0.5 / 3) ** (2 / 3) * gamma(1 / 3)
        print("E[Y] = %.4f,  (3/2) E[Y] = %.4f,  -(2/9) E[Y] = %.4f,  (23/18) E[Y] = %.4f" % (EY, 1.5 * EY, -2 * EY / 9, 23 * EY / 18))
        print("     k     row         k^(4/3) T1/om_k   k^(4/3) T2/om_k   k^(4/3) T3/om_k   T3/T1     k^(4/3) S/om_k    h/U at the critical tilt")
        for k in ks:
            t0 = time.time()
            d = data(k, 2 * k - 1)
            for name, J in (("0.6k", k + (3 * k) // 5), ("0.8k", k + (4 * k) // 5), ("2k-2", 2 * k - 2)):
                S, T1, T2, T3 = terms(d, k, J)
                c = k ** (4 / 3)
                print("  %6d  %-6s   %12.4f   %14.4f   %14.4f   %8.4f   %12.4f   %10.4f" % (k, name, c * T1, c * T2, c * T3, T3 / T1, c * S, 1 - S / d["U"][J]), flush=True)
            print("          [%.0fs]" % (time.time() - t0), flush=True)
    elif mode == "zero":
        # first row J0 from which S_J >= 0 (debt <= cell at the critical tilt) up to the row 2k-2, and the first-order prediction
        from limf import talbot, Shat, fhat
        f = lambda z: talbot(fhat, z)
        psi = lambda z: talbot(Shat, z)
        ipsi = lambda z: talbot(lambda l: Shat(l) / l, z)
        def pred(k):
            g = lambda X: -(2 / 3) * X * f(X) * k ** (1 / 3) + (23 / 18) * (ipsi(X) - X * psi(X)) - (4 / 9) * X * X * f(X)
            lo, hi = 0.7, 60.0
            for _ in range(50):
                mid = 0.5 * (lo + hi)
                if g(mid) < 0: lo = mid
                else: hi = mid
            return 0.5 * (lo + hi)
        print("     k   first row J0 with S_J >= 0 on J0..2k-2   deficit/k   (J0-k+1)/J0^(2/3)   (J0-k)/k^(2/3)   first-order prediction of (J0-k)/k^(2/3)")
        for k in ks:
            d = data(k, 2 * k - 1)
            J0 = None
            for J in range(2 * k - 2, k, -1):
                S = d["U"][J] + np.sum(d["eta"][k:J + 1])
                if S < 0: break
                J0 = J
            if J0 is None:
                print("  %6d   none" % k); continue
            print("  %6d   %8d   %24.3f   %14.2f   %14.2f   %18.2f" % (k, J0, (J0 - k) / k, (J0 - k + 1) / J0 ** (2 / 3), (J0 - k) / k ** (2 / 3), pred(k)), flush=True)
    elif mode == "termwise":
        # Is T1 + T3 nonnegative term by term?   t_N = (om_{N+1}-om_N) m_N(k-1) + om_{N+2} stay_{N+1}(k) - om_{N+1} stay_N(k-1),  k <= N <= 2k-3.
        # Formal limit of t_N / [(om_{N+1}-om_N) m_N(k-1)]:  (1/6 + (2/3) Theta)/(3/2), between 1/9 and 1.
        print("     k    rows with t_N < 0 (N-k listed)           min over N>=k+2 of t_N/[(om_{N+1}-om_N) m_N(k-1)]  (at N-k)")
        for k in ks:
            d = data(k, 2 * k - 1)
            om, m1 = d["om"], d["m1"]
            Ns = np.arange(k, 2 * k - 2)
            g = (om[Ns + 1] - om[Ns]) * m1[Ns]
            t = g + om[Ns + 2] * d["stay_k"][Ns + 1] - om[Ns + 1] * d["stay_k1"][Ns]
            bad = [int(n - k) for n, v in zip(Ns, t) if v < 0]
            r = t[2:] / g[2:]
            i = int(np.argmin(r))
            print("  %6d   %-40s   %8.4f  (%d)" % (k, (str(bad[:12]) + ("..." if len(bad) > 12 else "")) if bad else "none", r[i], i + 2), flush=True)
