# v17 (peer): the tree-form tilted base as a weighted average of the forest-column "cell minus debt" (critical tilt x = x_k).
#   B_k(X) = sum_{s=k}^{X} xi_s,   xi_s = x^s [(k+1) b_{s-1,k} - (k-1) b_{s-1,k-1}]/s!  (s >= k+1),   xi_k = -iota = -k^{k-2} x^k/k!     (published tilted base)
#   S_N = U_N - h_N  (cell minus debt of the forest column),   U_N = x^N b_{N,k-1}/N!
# Identity (definitions and one Abel summation), for X >= k+2:
#   B_k(X)/x = (k+1) [ S_{X-1}/X + sum_{N=k}^{X-2} S_N/((N+1)(N+2)) ]
#              + sum_{N=k}^{X-2} U_N (2N+3-k)/((N+1)(N+2)) - (k-1) U_{X-1}/X - iota/x .
# The weights (k+1)/((N+1)(N+2)) (N <= X-2) and (k+1)/X add up to 1.
# Exact rational arithmetic from the table module ptab (b_{n,l} for n <= 2k).
from fractions import Fraction as F
from math import factorial
import sys
import ptab

def check(k):
    X0 = 2 * k
    T = ptab.Tab(X0)                         # T.a(n, l) = number of parking functions of length n with max displacement <= l
    b = lambda n, l: T.a(n, l) - T.a(n, l - 1)
    x = F(k, k + 1) ** (k - 1)
    U = {N: x ** N * b(N, k - 1) / factorial(N) for N in range(k, X0)}
    V = {N: x ** N * b(N, k) / factorial(N) for N in range(k, X0)}
    S = {}
    acc = F(0)
    for N in range(k, X0):
        if N > k: acc += V[N] - U[N - 1]
        S[N] = acc                           # S_N = sum_{M=k+1}^{N} V_M - sum_{M=k}^{N-1} U_M
    iota = F(k) ** (k - 2) * x ** k / factorial(k)
    worst = F(0)
    for X in range(k + 2, X0 + 1):
        B = -iota + sum(x ** s * ((k + 1) * b(s - 1, k) - (k - 1) * b(s - 1, k - 1)) / factorial(s) for s in range(k + 1, X + 1))
        rhs = (k + 1) * (S[X - 1] / X + sum(S[N] / ((N + 1) * (N + 2)) for N in range(k, X - 1))) \
              + sum(U[N] * (2 * N + 3 - k) / ((N + 1) * (N + 2)) for N in range(k, X - 1)) - (k - 1) * U[X - 1] / X - iota / x
        worst = max(worst, abs(B / x - rhs))
    wsum = F(k + 1, X0) + sum(F(k + 1, (N + 1) * (N + 2)) for N in range(k, X0 - 1))
    print("k=%d: largest |B_k(X)/x - right side| over k+2 <= X <= 2k: %s ; sum of the weights at X=2k: %s" % (k, worst, wsum))

if __name__ == "__main__":
    for a in sys.argv[1:]:
        check(int(a))
