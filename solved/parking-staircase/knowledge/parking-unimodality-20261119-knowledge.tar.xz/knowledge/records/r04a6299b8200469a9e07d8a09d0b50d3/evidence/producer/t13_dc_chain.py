# Test 13 (tied to the argument).  Chain "first-layer diagonal convexity  ==>  debt <= one cell at the deficit-adapted tilt".
# Notation at tilt z (as in rf0331155 1.1, with z in place of x_k):  a_i = z^i A_{i,k}/i!,  b_i = z^i A_{i,k-1}/i!,  d_i = z^i A_{i,k-2}/i!,
#   U_i = b_i - d_i,  V_i = a_i - b_i,  e+_N = a_{N+1} - b_N,  e-_N = b_N - d_{N-1},  DC(N) = e+_N - e-_N.
# Step 1 (identity, any z>0, J>=k):   C(J) := sum_{j=k+1}^{J} (V_j - U_{j-1}) = U_J - h_J = sum_{N=k}^{J-1} DC(N) + e-_k - e-_J.
# Step 2: if DC(N)>=0 at the critical tilt x_k then DC(N)>=0 at every z>=x_k (DC/z^(N-1) is nondecreasing in z there).
# Step 3: hence (D1') at row n=J+1 follows from  e-_J <= e-_k = z^(k-1) c_(k-1) (z r_k - 1),  and
#         (D2') follows from  e-_{n-1} <= e-_{q-1}   [C(n-1)-C(q-1) = sum_{N=q-1}^{n-2} DC(N) + e-_{q-1} - e-_{n-1}].
# Questions tested (exact rationals): identity of step 1; DC(N)>=0 at the adapted tilt for k<=N<=n-2; on which rows beyond R_i
# the two smallness conditions hold, and with what room.
from pf import T
from fractions import Fraction as Fr
from math import factorial
t = T(160)
def g(m):
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
print("k q0 Ri | identity violations | DC<0 cells | rows r>Ri failing e-_{n-1}<=e-_k | failing e-_{n-1}<=e-_{q-1} | max e-_{n-1}/e-_k (row) | max e-_{n-1}/e-_{q-1} (row)")
for k in [12, 16, 20, 24, 30, 36, 40, 50, 60, 70, 79]:
    xdag = Fr(k, k+1)**(k-2)
    Ri = max(r for r in range(1, k) if all(xdag*g(m) <= 1 for m in range(1, r)))
    q0 = next(n for n in range(k+1, 2*k+1) if t.d(n,k) > 0)
    idv = 0; dcneg = 0; f1 = []; f2 = []; m1 = (0, None); m2 = (0, None)
    for n in range(k+Ri+1, 2*k):
        r = n-k; J = n-1
        z = 1/g(r-1)
        a = lambda i: z**i*Fr(t.A(i,k), factorial(i))
        b = lambda i: z**i*Fr(t.A(i,k-1), factorial(i))
        d = lambda i: z**i*Fr(t.A(i,k-2), factorial(i))
        av = {i: a(i) for i in range(k-1, n+1)}; bv = {i: b(i) for i in range(k-1, n+1)}; dv = {i: d(i) for i in range(k-2, n+1)}
        U = lambda i: bv[i]-dv[i]
        V = lambda i: av[i]-bv[i]
        em = lambda N: bv[N]-dv[N-1]
        DC = lambda N: av[N+1]-2*bv[N]+dv[N-1]
        C = sum(V(j)-U(j-1) for j in range(k+1, J+1))
        dcs = [DC(N) for N in range(k, J)]
        if C != sum(dcs) + em(k) - em(J): idv += 1
        dcneg += sum(1 for x in dcs if x < 0)
        r1 = em(J)/em(k); r2 = em(J)/em(q0-1)
        if r1 > 1: f1.append(n)
        if r2 > 1: f2.append(n)
        if float(r1) > m1[0]: m1 = (float(r1), n)
        if float(r2) > m2[0]: m2 = (float(r2), n)
    print(k, q0, Ri, "|", idv, "|", dcneg, "|", f1, "|", f2, "| %.3f (n=%s) | %.3f (n=%s)" % (m1[0], m1[1], m2[0], m2[1]))
