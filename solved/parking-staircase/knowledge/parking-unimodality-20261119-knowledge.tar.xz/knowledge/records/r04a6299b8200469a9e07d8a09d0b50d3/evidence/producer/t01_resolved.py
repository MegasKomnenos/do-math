# Test 1: exact resolved-form identity in summation-by-parts form (first layer k+1<=n<=2k-1).
#  D_n := d_{n,k}/n!,  rho'_i := (i+1)^i/i!
#  resolved form:  D_n = -iota*rho'_{n-k} + sum_{t=k+1}^{n} rho'_{n-t} * mu_t,
#     iota = k^{k-2}/k!,  mu_t = [2 b_{t-1,k-1} - (t-1-k) d_{t-1,k}]/t!
#  Mt_t := iota - sum_{s=k+1}^{t} mu_s  (untilted partial sums; tilt e^{-t} cancels in the identity if we
#     use tilted weights; here we check the tilted version with rational tilt x instead of 1/e)
#  Claim: with rt_i := x^i rho'_i,  Mtil_t := x^k iota - sum_{s=k+1}^t x^s mu_s,
#     x^n D_n = sum_{t=k}^{n-1} (rt_{n-1-t} - rt_{n-t}) (Mtil_t - Mtil_n) - rt_{n-k} Mtil_n .
#  Also: Mtil_n = second difference in level of W_j(n) := sum_{s=j+1}^{n} x^s (s-j) A_{s-1,j-1}/s!.
from pf import T
from fractions import Fraction as Fr
from math import factorial
import sys
t = T(160)
def check(k, x):
    bad = 0
    iota = Fr(k**(k-2), factorial(k))
    rp = lambda i: Fr((i+1)**i, factorial(i))
    mu = {}
    for s in range(k+1, 2*k):
        mu[s] = Fr(2*t.b(s-1,k-1) - (s-1-k)*t.d(s-1,k), factorial(s))
    Mtil = {k: x**k*iota}
    for s in range(k+1, 2*k):
        Mtil[s] = Mtil[s-1] - x**s*mu[s]
    def W(j, n):
        return sum(x**s*(s-j)*Fr(t.A(s-1,j-1), factorial(s)) for s in range(j+1, n+1))
    for n in range(k+1, 2*k):
        D = Fr(t.d(n,k), factorial(n))
        # resolved form itself
        rhs0 = -iota*rp(n-k) + sum(rp(n-s)*mu[s] for s in range(k+1, n+1))
        if rhs0 != D: bad += 1
        lhs = x**n*D
        rt = lambda i: x**i*rp(i)
        rhs = sum((rt(n-1-s)-rt(n-s))*(Mtil[s]-Mtil[n]) for s in range(k, n)) - rt(n-k)*Mtil[n]
        if lhs != rhs: bad += 1
        # second-difference representation
        m2 = W(k+1,n) - 2*W(k,n) + W(k-1,n)
        if m2 != Mtil[n]: bad += 1
    return bad
for k in [3,4,5,8,13,20,31]:
    print(k, check(k, Fr(1,3)), check(k, Fr(3,8)))
