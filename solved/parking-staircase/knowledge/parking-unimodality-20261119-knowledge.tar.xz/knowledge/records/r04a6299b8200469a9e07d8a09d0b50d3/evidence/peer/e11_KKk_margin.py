# e11 (peer): size of the violation of (KK)(n_1,n) below N_0 at larger columns, and where (KK_k) first fails.
import numpy as np, sys, time
from math import lgamma, log, exp, ceil
from kern import true_profile
from e09_twopoint_large_k import kernel_matrices
def analyse(k, xmax=4.2, detail=False):
    sc = k ** (2 / 3)
    top = min(2 * k, k + int(xmax * sc))
    W = top - k + 1
    Psi = true_profile(k, top)
    E, J = kernel_matrices(k, top)
    step = -J + E @ Psi[k - 1:top]
    q0 = k + next(i for i in range(1, W) if step[i] > 0)
    eps = np.zeros(W + 1)
    for m in range(1, W + 1):
        eps[m] = exp(-m + ((m - 1) * log(m - 1) if m > 1 else 0.0) - lgamma(m + 1))
    Eps = np.zeros((W, W))
    for i in range(1, W):
        Eps[i, :i] = eps[i - np.arange(0, i)]
    Cm = Eps @ E; I = Eps @ J; Mem = Eps @ step
    n1 = k + next(i for i in range(1, W) if Mem[i] >= 0)
    N0 = q0 + ceil(2.2 * sc) + 1
    i1 = n1 - k; ncol = n1 - k - 1
    worst = (1e9, None, None)
    first_bad = None
    for n in range(n1 + 1, N0):
        i = n - k
        ratio = (Cm[i, :ncol] * I[i1]) / (Cm[i1, :ncol] * I[i]) - 1.0
        j = int(np.argmin(ratio))
        if ratio[j] < worst[0]:
            worst = (ratio[j], n, k - 1 + j)
        if ratio[j] < 0 and first_bad is None:
            first_bad = (n, k - 1 + j, ratio[j])
    return q0, n1, N0, worst, first_bad
if __name__ == '__main__':
    for k in [int(a) for a in sys.argv[1:]]:
        t0 = time.time()
        q0, n1, N0, worst, fb = analyse(k)
        print("k=%d q0=%d n_1=%d N_0=%d : min over n_1<n<N_0 and s of [c_n(s) I_{n1} / (c_{n1}(s) I_n) - 1] = %.3e at n=%d, s=%d (s-q0=%d) ; %s  [%.0fs]" % (
            k, q0, n1, N0, worst[0], worst[1], worst[2], worst[2] - q0,
            "(KK_k) holds" if fb is None else "(KK_k) FAILS first at n=%d (s=%d, value %.2e)" % fb, time.time() - t0), flush=True)
