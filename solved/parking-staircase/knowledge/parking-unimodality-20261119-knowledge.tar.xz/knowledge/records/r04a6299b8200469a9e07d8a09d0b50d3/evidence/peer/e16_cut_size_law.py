# e16 (peer): test of the derived law for the smallest cut size  S_min(k)  (section 5.3 / 6.4).
# Exact statement: the column cut at S is >= 0 at row n  iff  Lost_n(S) := sum_{s>S} (e_n(s)/J_n) Psi_s  <=  rho_n := step_n/J_n.
# Derivation tested here:
#   (a) for a row n far beyond the source (n - s >> s - k) the weight e_n(s)/J_n is close to  k^{-2/3} w_inf(y),  y=(s-k)/k^{2/3},
#       w_inf(y) = (2/Phi_tot) int mu exp(-Phi(mu) - mu y) dmu   -- also when n is the last row of the first layer (bulk);
#   (b) hence Lost_n(S) ~ T0 * y_S^{-5/2},  T0 = 4 a0/(5 Phi_tot) = 0.680  (a0 = sqrt(2/pi)),  y_S = (S-k)/k^{2/3};
#   (c) the binding row is the last row 2k-1, so  S_min - k ~ k^{2/3} (T0/rho_{2k-1})^{2/5}.
import numpy as np, sys, time
from math import gamma, sqrt, pi
from kern import column, true_profile, bor
C = 2 * sqrt(2) / 3
PHI_TOT = (2 / 3) * C ** (-2 / 3) * gamma(2 / 3)
T0 = 4 * sqrt(2 / pi) / (5 * PHI_TOT)
gx, gw = np.polynomial.legendre.leggauss(40)
def w_inf(y):
    tot = 0.0; a = 0.0; w = 0.25
    for _ in range(60):
        mu = 0.5 * w * gx + (a + 0.5 * w)
        tot += 0.5 * w * np.dot(gw, mu * np.exp(-C * mu ** 1.5 - mu * y)); a += w; w *= 1.5
        if a > 400: break
    return 2 * tot / PHI_TOT
def run(k, smin, weights=True):
    t0 = time.time()
    top = 2 * k - 1; sc = k ** (2 / 3)
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    rho_end = step[top] / J[top]
    out = ["k=%d q0=%d: rho at row 2k-1 = %.4f = %.3f k^(-1/3)" % (k, q0, rho_end, rho_end * k ** (1 / 3))]
    pred = sc * (T0 / rho_end) ** 0.4
    out.append("   law: S_min-k ~ k^(2/3) (T0/rho)^(2/5) = %.0f   (T0=%.4f) ; observed S_min-k = %d ; ratio = %.3f" % (pred, T0, smin - k, (smin - k) / pred))
    for S in (smin - 1, smin):
        P = Psi.copy(); P[S + 1:] = 0.0
        c2, s2, J2 = column(k, P, top, B)
        lost = (step - s2) / J
        bad = [n for n in range(q0, top + 1) if s2[n] < 0]
        yS = (S - k) / sc
        out.append("   cut S=k+%d (y=%.3f): Lost at row 2k-1 = %.4f (T0 y^(-5/2) = %.4f) ; negative rows: %s" % (
            S - k, yS, lost[top], T0 * yS ** -2.5, "none" if not bad else "%d..%d (x=%.2f..%.2f)" % (bad[0], bad[-1], (bad[0] - k) / sc, (bad[-1] - k) / sc)))
    if weights:
        ys = (0.5, 1.0, 2.0, 3.0, 5.0)
        rows = [("2k-1", top), ("k+0.5k", k + k // 2), ("x=6", k + int(6 * sc))]
        for name, n in rows:
            if n > top: continue
            vals = []
            for y in ys:
                s0 = k + int(round(y * sc))
                if s0 > n - 2: vals.append("  -  "); continue
                P = np.zeros(top + 2); P[s0] = 1.0
                c3, s3, J3 = column(k, P, top, B)
                vals.append("%.3f" % ((s3[n] + J[n]) / J[n] * sc / w_inf((s0 - k) / sc)))
            out.append("   row %s: [k^(2/3) e_n(s)/J_n] / w_inf(y) at y=%s: %s" % (name, ys, ", ".join(vals)))
    out.append("   [%.0fs]" % (time.time() - t0))
    print("\n".join(out), flush=True)
if __name__ == '__main__':
    for a in sys.argv[1:]:
        k, smin, wflag = a.split(':')
        run(int(k), int(smin), wflag == 'w')
