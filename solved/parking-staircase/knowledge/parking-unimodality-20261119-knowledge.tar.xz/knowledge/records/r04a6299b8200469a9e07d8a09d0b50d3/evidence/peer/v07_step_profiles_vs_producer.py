# v07 (peer): the producer's nested recursion (S1),(S2) for step profiles agrees exactly with the peer's Green-function form.
# (producer's routine: column() of t29_exact_witness_k100.py, copied verbatim below; peer's: green.column_from_profile)
from fractions import Fraction as Fr
from math import comb
from green import column_from_profile
def p(s):
    return 1 if s == 0 else (s + 1) ** (s - 1)
def column_producer(k, Psi, top):
    Ut = {k - 1: Fr(0)}
    Et = {}
    for n in range(k, top + 1):
        acc = Fr(0)
        for s in range(k - 1, n):
            g = n - s
            acc += comb(n, s) * g ** (g - 1) * (k * Ut[s] + p(s) * Psi(s)) / (s + 1)
        Ut[n] = acc
        acc = Fr(0)
        for s in range(k, n):
            g = n - s
            acc += comb(n, s) * g ** (g - 1) * ((k + 1) * Et[s] + 2 * Ut[s]) / (s + 1)
        g = n - k + 1
        Et[n] = acc - Fr(comb(n, k - 1) * g ** (g - 1) * p(k - 1), k)
    return Ut, Et
ok = True; cnt = 0
for k in (12, 16, 24):
    top = 2 * k - 1
    for S in (k - 1, k, k + 3, k + 7, top - 2, top):
        Psi = lambda s, S=S: Fr(1) if s <= S else Fr(0)
        Ut, Et = column_producer(k, Psi, top)
        b, d = column_from_profile(k, Psi, top)
        same = all(Ut[n] == b[n] and Et[n] == d[n] for n in range(k, top + 1))
        ok &= same; cnt += top - k + 1
    print("k=%d: step profiles agree: %s" % (k, ok))
print("all %d (row, profile) pairs agree exactly: %s" % (cnt, ok))
