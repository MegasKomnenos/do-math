# Test 24 (tied to the argument).  Two-point kernel comparison AGAINST A REFERENCE ROW q, for the step, in two forms:
#   (KK)(q,n)   coefficientwise:  e_n(s) J_q >= e_q(s) J_n  for all s <= q-2        [r9faef2b6 Theorem 16; any Psi >= 0]
#   (cKK)(q,n)  cumulative:       exists lam >= 0 with  Pi_n(S) >= lam * Pi_q(S)  for all death times S
#               where Pi_n(S) = -J_n + sum_{s<=min(S,n-2)} e_n(s)  is the step at row n of the model whose level-(k-2)
#               survival profile is the indicator of {s <= S}.   By Farkas this is EQUIVALENT to:
#               "eta_q >= 0  ==>  eta_n >= 0   for every nonincreasing profile Psi with values in [0,1], Psi_{k-1}=1".
# For each reference row q we report the last row n_end such that the condition holds for every n in (q, n_end].
# Double precision at the critical tilt x_k (the conditions are tilt-invariant).  The published ranges for (KK)(q_0,.)
# (r9faef2b6, observation 4, last paragraph) serve as a cross-check of this code: 112 (k=60), 178 (k=100), 207 (k=120), 244 (k=148).
import sys
import numpy as np
from math import lgamma, log, exp


def kernels_vec(k):
    x = (k / (k + 1)) ** (k - 1)
    N = 2 * k
    lx = log(x)
    om = np.array([exp(s * lx + (s - 1) * log(s + 1) - lgamma(s + 1)) for s in range(0, N + 1)])
    tau = np.array([0.0] + [exp(g * lx + (g - 1) * log(g) - lgamma(g + 1)) for g in range(1, N + 1)])
    inv = 1.0 / (np.arange(N + 1) + 1.0)
    u = np.zeros((N + 1, N + 1))
    e = np.zeros((N + 1, N + 1))
    J = np.zeros(N + 1)
    for n in range(k, 2 * k):
        s = np.arange(k - 1, n)
        base = np.zeros(N + 1)
        base[s] = tau[n - s] * om[s] * inv[s]
        if n > k:
            sp = np.arange(k, n)
            w = tau[n - sp] * inv[sp]
            u[n] = base + k * (w @ u[sp])
            e[n] = w @ ((k + 1) * e[sp] + 2 * u[sp])
            J[n] = tau[n - k + 1] * om[k - 1] / k + (k + 1) * (w @ J[sp])
        else:
            u[n] = base
            J[n] = tau[n - k + 1] * om[k - 1] / k
    return e, J


def Pi(e, J, k, n):
    # array over S = k-1 .. 2k-1 of Pi_n(S)
    c = np.cumsum(e[n][k - 1:])
    return -J[n] + c[: (2 * k - 1) - (k - 1) + 1]


def ckk(Pq, Pn, k, n):
    # S ranges over k-1..n-2 (later death times are equivalent at rows <= n)
    m = (n - 2) - (k - 1) + 1
    a = Pq[:m]
    b = Pn[:m]
    L = 0.0
    H = np.inf
    neg = a < 0
    pos = a > 0
    if neg.any():
        L = max(0.0, float((b[neg] / a[neg]).max()))
    if pos.any():
        H = float((b[pos] / a[pos]).min())
    zero = ~(neg | pos)
    if zero.any() and (b[zero] < 0).any():
        return False, L, H
    return (L <= H * (1 + 1e-10) if H > 0 else (L <= H)), L, H


def kk(e, J, k, q, n):
    s = np.arange(k - 1, q - 1)
    return bool(np.all(e[n][s] * J[q] >= e[q][s] * J[n] * (1 - 1e-12)))


if __name__ == '__main__':
    ks = [int(a) for a in sys.argv[1:]]
    for k in ks:
        e, J = kernels_vec(k)
        P = {n: Pi(e, J, k, n) for n in range(k, 2 * k)}
        # crossing row of the immortal model (Psi == 1): first n with Pi_n(n-2) > 0
        q_imm = next(n for n in range(k + 1, 2 * k) if P[n][n - 2 - (k - 1)] > 0)
        print("k=%d: immortal-model crossing row q_imm=%d ; first layer ends at 2k-1=%d" % (k, q_imm, 2 * k - 1))
        for q in range(q_imm, min(q_imm + 9, 2 * k - 2)):
            end_kk = q
            for n in range(q + 1, 2 * k):
                if kk(e, J, k, q, n):
                    end_kk = n
                else:
                    break
            end_c = q
            margin = np.inf
            where = None
            for n in range(q + 1, 2 * k):
                ok, L, H = ckk(P[q], P[n], k, n)
                if ok:
                    end_c = n
                    if L > 0 and H / L < margin:
                        margin = H / L
                        where = n
                else:
                    break
            print("   reference row q=%d: (KK)(q,n) holds for q<n<=%d ; (cKK)(q,n) holds for q<n<=%d ; min H/L over those rows = %.4f at n=%s" % (
                q, end_kk, end_c, margin, where))
