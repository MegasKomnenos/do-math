# Peer's own exact table of A_{n,k} = #{PF of length n with max displacement <= k} (last-car recursion),
# written independently of the producer's pf.py.  Validated against brute force for n<=7 in v01.
from math import comb
from functools import lru_cache

class Tab:
    def __init__(self, nmax):
        self.nmax = nmax
        self.A = {}
        for n in range(0, nmax + 1):
            for k in range(0, max(n, 1)):
                self.A[(n, k)] = self._calc(n, k)
    def a(self, n, k):
        if n == 0:
            return 1
        if k < 0:
            return 0
        if k >= n - 1:
            return (n + 1) ** (n - 1)
        return self.A[(n, k)]
    def _calc(self, n, k):
        if n == 0:
            return 1
        if k >= n - 1:
            return (n + 1) ** (n - 1)
        # last car parks at spot j+1 (j cars to its left, n-1-j to its right); its displacement is in 0..min(j,k)
        s = 0
        for j in range(n):
            s += comb(n - 1, j) * min(j + 1, k + 1) * self.a(j, k) * self.a(n - 1 - j, k)
        return s
    def b(self, n, k):
        if k < 0 or k > n - 1:
            return 0
        return self.a(n, k) - self.a(n, k - 1)
    def d(self, n, k):
        return self.b(n, k) - self.b(n, k - 1)

def p(s):
    return 1 if s == 0 else (s + 1) ** (s - 1)

def brute_row(n):
    # direct simulation of the parking process over all preference sequences
    from itertools import product
    cnt = [0] * n
    for alpha in product(range(1, n + 1), repeat=n):
        occ = [False] * (n + 2)
        M = 0
        ok = True
        for a in alpha:
            pos = a
            while pos <= n and occ[pos]:
                pos += 1
            if pos > n:
                ok = False
                break
            occ[pos] = True
            M = max(M, pos - a)
        if ok:
            cnt[M] += 1
    return cnt
