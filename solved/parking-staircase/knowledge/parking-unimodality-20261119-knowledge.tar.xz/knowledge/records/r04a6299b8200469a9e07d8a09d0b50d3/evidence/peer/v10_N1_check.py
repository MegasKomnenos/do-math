# v10 (peer): independent exact check of the producer's observation N1 at k=24 and k=40.
# Deficit-adapted tilt z_r = min(1/gamma_k, 1/g(r-1)), r=n-k>=2;  eps_m=(m-1)^(m-1)/m!, g(m)=eps_{m+1}/eps_m, gamma_k=(1+1/k)^(k-2).
# At tilt z: U_j = z^j b_{j,k-1}/j!, V_j = z^j b_{j,k}/j!, debt h_J = sum_{j=k}^{J} (U_j - V_j), kap_m = z^m eps_m.
# (D1'): h_{n-1} <= U_{n-1}.   (D2'): sum_{j=q}^{n-1} (V_j - U_{j-1}) >= 0.   (ii): n kap_r <= q kap_{r_q}  (r_q=q-k).
from fractions import Fraction as Fr
from math import factorial
from ptab import Tab
import sys
t = Tab(80)
def eps(m):
    return Fr((m - 1) ** (m - 1) if m > 1 else 1, factorial(m))
def g(m):
    return eps(m + 1) / eps(m)
for k in (24, 40):
    gam = Fr(k + 1, k) ** (k - 2)
    q = next(n for n in range(k + 1, 2 * k) if t.d(n, k) > 0)
    bad1 = []; bad2 = []; bad3 = []; mx = (Fr(0), None)
    for n in range(q + 1, 2 * k):
        r = n - k
        z = min(1 / gam, 1 / g(r - 1))
        U = lambda j: z ** j * Fr(t.b(j, k - 1), factorial(j))
        V = lambda j: z ** j * Fr(t.b(j, k), factorial(j))
        h = sum(U(j) - V(j) for j in range(k, n))
        ratio = h / U(n - 1)
        if ratio > mx[0]: mx = (ratio, n)
        if h > U(n - 1): bad1.append(n)
        if sum(V(j) - U(j - 1) for j in range(q, n)) < 0: bad2.append(n)
        kap = lambda m: z ** m * eps(m)
        if n * kap(r) > q * kap(q - k): bad3.append(n)
    hj = None
    print("k=%d q0=%d: rows where (D1') fails: %s; (D2') fails: %s; (ii) fails: %s; max h/U = %.3f at row %d" % (
        k, q, bad1 or "none", bad2 or "none", ("%d..%d" % (bad3[0], bad3[-1]) if bad3 else "none"), float(mx[0]), mx[1]))
