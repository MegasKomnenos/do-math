# Test 27 (tied to the argument).  Which facts carry the forced positivity in the far rows of larger columns?
# Float dual of the LP of test 21 for the fact set Pat+Dg (kernel form, nonincreasing profile, sign pattern with crossing q,
# diagonal lower bound at every row).  Dual:  maximize t  s.t.  t + sum_i y_i G_i(S) <= c(S) for every death time S, y >= 0.
# The returned y is then CHECKED directly:  t_check = min_S [ c(S) - sum_i y_i G_i(S) ]  (this check does not use the solver),
# so that  eta_{n+1}/|impulse| >= t_check + sum_i y_i * (fact_i) >= t_check  for every profile of the cone.
import sys
import numpy as np
from t21_softcone_lp_float import columns, build, simplex_float


def labels(k, q, n, use):
    lab = []
    if 'Pat' in use:
        lab += [("-eta", j) for j in range(k, q)] + [("+eta", j) for j in range(q, n + 1)]
    if 'Dg' in use:
        lab += [("Dg", j) for j in range(k + 1, n + 2)]
    return lab


def dual(k, q, n, U, E, om, gam_t, use):
    Ss, G, obj = build(k, q, n, U, E, om, gam_t, use)
    scale = abs(E[k - 1][n + 1])
    c = obj / scale
    m, nS = G.shape
    # variables: y (m), t+ , t- , slack_S (nS)
    A = np.hstack([G.T, np.ones((nS, 1)), -np.ones((nS, 1)), np.eye(nS)])
    b = c.copy()
    neg = b < 0
    A[neg] *= -1
    b[neg] *= -1
    cost = np.concatenate([np.zeros(m), [-1.0, 1.0], np.zeros(nS)])
    st, x, val = simplex_float(A, b, cost)
    if x is None:
        return None
    y = np.clip(x[:m], 0, None)
    t_check = float((c - G.T @ y).min())
    return y, t_check, labels(k, q, n, use)


if __name__ == '__main__':
    k = int(sys.argv[1])
    U, E, om, gam_t, top = columns(k)
    for spec in sys.argv[2:]:
        n1, q = [int(v) for v in spec.split(':')]     # target row n+1 and crossing row q
        n = n1 - 1
        for use in [('Pat',), ('Pat', 'Dg')]:
            out = dual(k, q, n, U, E, om, gam_t, use)
            if out is None:
                print("k=%d target %d q=%d facts=%s: dual solver returned nothing" % (k, n1, q, '+'.join(use)))
                continue
            y, t_check, lab = out
            tot = y.sum()
            supp = [(lab[i][0], lab[i][1], y[i] / tot) for i in range(len(y)) if y[i] > 1e-9 * tot]
            byk = {}
            for kind, j, w in supp:
                byk.setdefault(kind, []).append((j, w))
            print("k=%d target row %d (deficit %d) crossing q=%d facts=%s: certified lower bound eta/|impulse| >= %.4e" % (k, n1, n1 - k, q, '+'.join(use), t_check))
            for kind in byk:
                rows = byk[kind]
                wsum = sum(w for j, w in rows)
                top5 = sorted(rows, key=lambda r: -r[1])[:6]
                print("     %s: %d rows carry weight (share of total %.3f); rows %d..%d ; heaviest: %s" % (
                    kind, len(rows), wsum, min(j for j, w in rows), max(j for j, w in rows), [(j, round(w, 4)) for j, w in top5]))
