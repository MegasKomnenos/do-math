# Test 11 (tied to the argument).  Scan of the pure Cayley-number inequality (DF+) over all columns k in a range.
# No parking-function table is used.  For each k:  q_bar(k) = assumed upper bound for the crossing row,
#    q_bar = k + ceil(k^(2/3)) + 1                (k <= 264;  for 77<=k<=264 this is the C5 fact quoted in r6c69820c/rf0331155)
#    q_bar = k + floor((11k/5)^(2/3)) + 1         (k >= 265;  strip theorem r04646f8d c-crossing-strip)
# Rows n = k+r, q_bar < n <= 2k-1.  A row is covered if
#    W:  r <= R_s(k)+1                                  (published window, Cor. P1), or
#    I:  r <= R_i(k) and  n*x_dag^t*eps_{t+1} <= 2      (condition (iii) of Theorem P at the diagonal tilt), or
#    D:  r >  R_i(k) and (DF+) holds with x = 1/g(r-1), t = n - q_bar, best Lambda <= LamMax.
# Output: for each k the uncovered rows (if any) and the worst (DF+) margin.
import numpy as np, sys
from math import lgamma, log, floor, ceil, exp
NM = 3000
Ls = np.arange(0, NM, dtype=np.float64)
lgc = (Ls-1)*np.log(Ls+1) - np.array([lgamma(i+1) for i in range(NM)])
def lg_eps(m): return ((m-1)*log(m-1) if m > 1 else 0.0) - lgamma(m+1)
def lg_g(m):
    if m == 1: return log(0.5)
    return log(m/(m+1)) + (m-1)*log(m/(m-1))
def lg_r(m): return (m-1)*log(1+1/m)
def Tbar(k, n, lx, LamMax):
    rho = n-k-1
    x = exp(lx)
    w = np.exp(Ls[:rho+1]*lx + lgc[:rho+1]); W = np.cumsum(w)
    Rat = W[:-1]/w[1:]
    pm = np.maximum.accumulate(Rat)                 # prefix max
    sm = np.maximum.accumulate(Rat[::-1])[::-1]     # suffix max
    zeta = max(0.0, exp(lx + lg_r(rho)) - 1)
    y = x*(k-1)/(n-1)
    best = float(sm[0]); bl = 0
    v = np.zeros(min(LamMax, rho)+1)
    for Lam in range(1, min(LamMax, rho)+1):
        i = Lam-1
        v[i] = 1.0 if i == 0 else 1 + y*float(np.dot(w[:i], v[i-1::-1][:i]))
        pis = y/(1+zeta)*float(np.dot(w[:Lam], v[Lam-1::-1][:Lam]))
        Th_o = float(sm[Lam-1]); Th_r = float(pm[Lam-2]) if Lam >= 2 else 0.0
        if Th_r > Th_o: continue
        val = (Th_o + pis*Th_r)/(1+pis)
        if val < best: best = val; bl = Lam
    return best, bl
def column(k, LamMax=40):
    lxdag = (k-2)*log(k/(k+1)); lgam = -lxdag
    Ri = 1
    for r in range(2, k):
        if lxdag + lg_g(r-1) <= 0: Ri = r
        else: break
    Rs = 0
    for R in range(1, k-1):
        if log(k+R+1) + lxdag + lg_g(R) <= log(k+R): Rs = R
        else: break
    q = k + int(ceil(k**(2/3))) + 1 if k <= 264 else k + int(floor((11*k/5)**(2/3))) + 1
    unc = []; worst = (9e9, None)
    for n in range(q+1, 2*k):
        r = n-k; t = n-q
        if r <= Rs+1: continue
        if r <= Ri:
            if n*exp(t*lxdag + lg_eps(t+1)) <= 2: continue
            unc.append((r, 'I')); continue
        lx = -lg_g(r-1)
        tb, Lam = Tbar(k, n, lx, LamMax)
        m = 2/(n*exp(t*lx + lg_eps(t+1))*(1 + (1-exp(lx+lgam))*tb))
        if m < worst[0]: worst = (m, r)
        if m < 1: unc.append((r, 'D'))
    return q, Rs, Ri, unc, worst
lo, hi = int(sys.argv[1]), int(sys.argv[2])
first_all_ok = None; last_bad = None
for k in range(lo, hi+1):
    q, Rs, Ri, unc, worst = column(k)
    if unc: last_bad = k
    if unc or k % 25 == 0 or k in (lo, hi):
        print("k=%d qbar=%d Rs=%d Ri=%d uncovered=%s worst(DF+) margin=%.3f at r=%s" % (
            k, q, Rs, Ri, (unc if len(unc) <= 8 else "%d rows %s..%s" % (len(unc), unc[0], unc[-1])), worst[0], worst[1]))
print("scan %d..%d: last column with an uncovered row: %s" % (lo, hi, last_bad))
