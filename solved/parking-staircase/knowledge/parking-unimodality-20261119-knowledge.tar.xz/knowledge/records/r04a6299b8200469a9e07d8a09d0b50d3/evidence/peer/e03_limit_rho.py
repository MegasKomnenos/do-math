# e03 (peer): limit curve rho_inf(x) = (-f'(x))/J(x) by numerical Laplace inversion; checks of the limit object
# against published numbers of the limit density (r9faef2b6 4.7: f(0.6)=0.436, f(1)=0.391, f(2)=0.200, f(5)=0.028,
# -f'/f = 0.476, 0.759, 0.511 at x=1,2,5; mode x0=0.5996; E[Y]=c_*=2.5758).
import numpy as np
from limf import *
print("Z = %.6f   15/(2Z) = %.4f" % (Z, 15 / (2 * Z)))
print("E[Y] = Shat(0+) = %.5f" % Shat(1e-9).real)
# mode
lo, hi = 0.4, 0.8
for _ in range(40):
    mid = 0.5 * (lo + hi)
    if talbot(etahat, mid) < 0:
        lo = mid
    else:
        hi = mid
print("zero of -f': x0 = %.5f" % (0.5 * (lo + hi)))
print("   x      f(x)     -f'(x)      J(x)     rho=-f'/J   -f'/f    15/(2Zx)   (M=20 | M=16 check of rho)")
for x in [0.3, 0.6, 0.8, 1, 1.5, 2, 2.65, 3, 4, 5, 6, 8, 10, 12, 15, 20, 30, 50]:
    fx = talbot(fhat, x); e = talbot(etahat, x); J = talbot(Jhat, x)
    e2 = talbot(etahat, x, 16); J2 = talbot(Jhat, x, 16)
    print("%6.2f  %9.6f  %10.3e  %10.3e  %9.5f  %7.4f   %8.4f   (%.5f)" % (x, fx, e, J, e / J, e / fx, 15 / (2 * Z * x), e2 / J2))
