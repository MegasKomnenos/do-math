# e01 (peer; tied to the claim "in the kernel form the step/impulse ratio is asymptotically a function rho(x) of the
# window coordinate x=(n-k)/k^{2/3}, rho(x) ~ 15/(2 Z x) for large x").  True columns, first layer, float.
import numpy as np, sys, time
from kern import column, true_profile, bor
ks = [int(a) for a in sys.argv[1:]] or [100, 400, 1600, 6400]
xs = [0.3, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 12.0, 15.0]
Z = 0.938893
print("columns:", ks)
res = {}
for k in ks:
    t0 = time.time()
    top = 2 * k - 1
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top)
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    sc = k ** (2.0 / 3.0)
    row = {}
    for x in xs:
        n = k + int(round(x * sc))
        if n <= top:
            row[x] = step[n] / J[n]
    res[k] = row
    nm = max(range(q0, top + 1), key=lambda n: step[n] / J[n])
    print("k=%d q0=%d (x=%.3f)  max of step/J = %.4f at row %d (x=%.2f);  at row 2k-1 (x=%.2f): %.4f ; at n=1.5k (x=%.2f): %.4f   [%.1fs]" % (
        k, q0, (q0 - k) / sc, step[nm] / J[nm], nm, (nm - k) / sc, (top - k) / sc, step[top] / J[top],
        (int(1.5 * k) - k) / sc, step[int(1.5 * k)] / J[int(1.5 * k)], time.time() - t0))
print("\nstep/J at window coordinate x (blank: outside the first layer); last line: 15/(2 Z x)")
print("   x    " + "".join("%9s" % ("k=%d" % k) for k in ks) + "   15/(2Zx)")
for x in xs:
    print("%6.2f  " % x + "".join(("%9.4f" % res[k][x]) if x in res[k] else "         " for k in ks) + "   %7.3f" % (15 / (2 * Z * x)))
