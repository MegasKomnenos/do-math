# v15 (peer): exact (rational) check of the closing condition (ii) of the two-point argument at the deficit-adapted tilt,
#   (ii)  n kappa_r <= q kappa_{r_q},  kappa_m = z^m eps_m,  z = z_r = min{1/gamma_k, 1/g(r-1)},  r = n-k, r_q = q-k, q = q0(k),
# and of (iii) kappa_{t+1} <= 2 z / n (t = n-q), for all rows q0 < n <= 2k-1, columns 28 <= k <= 45.
# The crossing rows q0(k) come from the exact table (ptab).  Purpose: the explorer's sample (k = 36, 40, 45, ...) suggested that (ii)
# holds on all rows for k >= 36; the double-precision check e25 found a failing row at k = 38.
from fractions import Fraction as Fr
from math import factorial
from ptab import Tab
t = Tab(92)
def eps(m):
    return Fr((m - 1) ** (m - 1) if m > 1 else 1, factorial(m))
def g(m):
    return eps(m + 1) / eps(m)
for k in range(28, 46):
    q0 = next(n for n in range(k + 1, 2 * k) if t.d(n, k) > 0)
    gam = Fr(k + 1, k) ** (k - 2)
    bad_ii = []; bad_both = []
    for n in range(q0 + 1, 2 * k):
        r = n - k; rq = q0 - k; tt = n - q0
        z = min(1 / gam, 1 / g(r - 1)) if r >= 2 else 1 / gam
        ii = n * z ** (r - rq) * eps(r) <= q0 * eps(rq)
        iii = z ** (tt + 1) * eps(tt + 1) <= 2 * z / n
        if not ii: bad_ii.append(n)
        if not ii and not iii: bad_both.append(n)
    print("k=%d q0=%d: (ii) fails on rows %s ; neither (ii) nor (iii) on rows %s" % (k, q0, bad_ii if bad_ii else "none", bad_both if bad_both else "none"))
