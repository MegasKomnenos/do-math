# Test 21 (tied to the argument).  Float version of test 20 (same model, same facts, same LP), to reach larger k.
# Everything is computed at the critical tilt x_k so that all coefficients are O(1); the LP is solved by a dense
# two-phase simplex in double precision (Bland's rule, tolerance 1e-11).  Results at k<=24 are cross-checked against
# the exact rational LP of test 20.  A reported NEGATIVE optimum is then re-evaluated from the profile itself
# (all constraints and the objective recomputed from the returned measure), so the verdict does not rest on the solver.
import sys
import numpy as np
from math import lgamma, log, exp


def simplex_float(A, b, c, tol=1e-11, maxit=20000):
    m, n = A.shape
    T = np.hstack([A, np.eye(m), b.reshape(-1, 1)]).astype(float)
    basis = list(range(n, n + m))

    def pivot(r, col):
        T[r] /= T[r, col]
        for i in range(m):
            if i != r and abs(T[i, col]) > 0:
                T[i] -= T[i, col] * T[r]
        basis[r] = col

    def run(cost, ncols):
        for _ in range(maxit):
            y = cost[basis]
            rc = cost[:ncols] - y @ T[:, :ncols]
            rc[[j for j in basis if j < ncols]] = 0.0
            cand = np.where(rc < -tol)[0]
            if len(cand) == 0:
                return 'optimal'
            enter = int(cand[0])
            col = T[:, enter]
            rows = np.where(col > tol)[0]
            if len(rows) == 0:
                return 'unbounded'
            ratios = T[rows, -1] / col[rows]
            rmin = ratios.min()
            ties = rows[np.where(ratios <= rmin + 1e-13)[0]]
            row = int(min(ties, key=lambda i: basis[i]))
            pivot(row, enter)
        return 'maxit'

    cost1 = np.concatenate([np.zeros(n), np.ones(m)])
    run(cost1, n + m)
    art = sum(T[i, -1] for i in range(m) if basis[i] >= n)
    if art > 1e-8:
        return 'infeasible', None, None
    for i in range(m):
        if basis[i] >= n:
            for j in range(n):
                if abs(T[i, j]) > 1e-9 and j not in basis:
                    pivot(i, j)
                    break
    cost2 = np.concatenate([c, np.full(m, 1e6)])
    st = run(cost2, n)
    x = np.zeros(n)
    for i in range(m):
        if basis[i] < n:
            x[basis[i]] = T[i, -1]
    return st, x, float(c @ x)


def columns(k):
    top = 2 * k - 1
    x = (k / (k + 1)) ** (k - 1)
    lx = log(x)
    tau = np.array([0.0] + [exp(g * lx + (g - 1) * log(g) - lgamma(g + 1)) for g in range(1, top + 2)])
    om = np.array([exp(s * lx + (s - 1) * log(s + 1) - lgamma(s + 1)) for s in range(0, top + 1)])
    inv = 1.0 / (np.arange(0, top + 1) + 1.0)
    U = np.zeros((top + 2, top + 1))     # U[S][n]
    E = np.zeros((top + 2, top + 1))
    for S in range(k - 1, top + 1):
        Uv = np.zeros(top + 1)
        Ev = np.zeros(top + 1)
        src = np.where(np.arange(0, top + 1) <= S, om, 0.0)
        for n in range(k, top + 1):
            s = np.arange(k - 1, n)
            Uv[n] = np.dot(tau[n - s], (k * Uv[s] + src[s]) * inv[s])
            s2 = np.arange(k, n)
            Ev[n] = np.dot(tau[n - s2], ((k + 1) * Ev[s2] + 2 * Uv[s2]) * inv[s2]) - tau[n - k + 1] * om[k - 1] / k
        U[S] = Uv
        E[S] = Ev
    gam_t = x * ((k + 1) / k) ** (k - 2)      # tilted Dg constant: V_j >= x*gamma_k*U_{j-1}
    return U, E, om, gam_t, top


def build(k, q, n, U, E, om, gam_t, use):
    Ss = list(range(k - 1, n + 2))
    rows = []
    psi = lambda S, j: 1.0 if j <= S else 0.0
    F1 = lambda S, j: psi(S, j) + (U[S][j] / om[j] if j >= k else 0.0)
    F2 = lambda S, j: F1(S, j) + ((U[S][j] + E[S][j]) / om[j] if j >= k else 0.0)
    if 'Pat' in use:
        for j in range(k, q):
            rows.append([-E[S][j] for S in Ss])
        for j in range(q, n + 1):
            rows.append([E[S][j] for S in Ss])
    if 'Dg' in use:
        for j in range(k + 1, n + 2):
            rows.append([(U[S][j] + E[S][j]) - gam_t * (U[S][j - 1] if j - 1 >= k else 0.0) for S in Ss])
    if 'R' in use:
        for j in range(k - 1, n + 1):
            rows.append([F1(S, j) - F1(S, j + 1) for S in Ss])
            rows.append([F2(S, j) - F2(S, j + 1) for S in Ss])
        for j in range(k, n + 2):
            rows.append([1 - F2(S, j) for S in Ss])
    if 'D' in use:
        for j in range(k - 1, n + 1):
            rows.append([F1(S, j + 1) - psi(S, j) for S in Ss])
            rows.append([F2(S, j + 1) - F1(S, j) for S in Ss])
    G = np.array(rows, dtype=float)
    # scale each constraint row to unit max-norm (does not change the cone)
    sc = np.abs(G).max(axis=1)
    sc[sc == 0] = 1.0
    G = G / sc[:, None]
    obj = np.array([E[S][n + 1] for S in Ss])
    return Ss, G, obj


def solve(k, q, n, U, E, om, gam_t, use):
    Ss, G, obj = build(k, q, n, U, E, om, gam_t, use)
    nv = len(Ss)
    m = G.shape[0]
    A = np.vstack([np.concatenate([np.ones(nv), np.zeros(m)]), np.hstack([G, -np.eye(m)])])
    b = np.concatenate([[1.0], np.zeros(m)])
    scale = abs(E[k - 1][n + 1])
    c = np.concatenate([obj / scale, np.zeros(m)])
    st, xx, val = simplex_float(A, b, c)
    if xx is None:
        return st, None, None, None
    mu = np.clip(xx[:nv], 0, None)
    mu = mu / mu.sum()
    val2 = float(obj @ mu) / scale
    worst = float((G @ mu).min())
    return st, mu, val2, worst


if __name__ == '__main__':
    k = int(sys.argv[1])
    U, E, om, gam_t, top = columns(k)
    args = sys.argv[2:]
    light = 'light' in args          # 'light': only the two small fact sets (the float solver is unreliable with (R),(D))
    rows_n = [int(a) for a in args if a != 'light']
    sets = [('Pat',), ('Pat', 'Dg')] if light else [('Pat',), ('Pat', 'Dg'), ('Pat', 'Dg', 'R', 'D')]
    for n in rows_n:
        for use in sets:
            line = []
            for q in range(k + 2, n + 1):
                st, mu, val, worst = solve(k, q, n, U, E, om, gam_t, use)
                if st == 'infeasible':
                    continue
                line.append((q, val, worst, st))
            if not line:
                print("k=%d n=%d facts=%s: no feasible crossing row q" % (k, n, '+'.join(use)))
                continue
            qs = [l[0] for l in line]
            best = min(line, key=lambda l: l[1])
            neg = [l[0] for l in line if l[1] < -1e-9 and l[2] > -1e-9]
            print("k=%d n=%d (deficit %d) facts=%s: feasible q in [%d,%d]; min over q of (min eta_{n+1})/|impulse| = %.3e at q=%d (worst constraint slack %.1e, status %s); q with NEGATIVE optimum: %s" % (
                k, n, n - k, '+'.join(use), min(qs), max(qs), best[1], best[0], best[2], best[3],
                (neg if len(neg) <= 12 else "%d values %d..%d" % (len(neg), neg[0], neg[-1]))))
