# e10 (peer): the published conditional hypothesis (KK_k) of r9faef2b6 (Corollary 19), for larger columns.
#   c_n(s) = sum_{j=s+2}^{n-1} kappa_{n-j} e_j(s),  I_n = sum_{j=k}^{n-1} kappa_{n-j} J_j,  Mem_n ~ sum_j kappa_{n-j} step_j
#   n_1(k) = min{n>=k+1 : Mem_n >= 0},  N_0 = q0 + ceil(2.2 k^{2/3}) + 1
#   (KK)(n',n): for all k-1 <= s <= n'-3:  c_n(s) I_{n'} >= c_{n'}(s) I_n.     (KK_k): (KK)(n_1,n) for all n_1 < n < N_0.
# Ratios are tilt-free, so the Borel normalization (tilt 1/e) of kern.py is used: kappa_m -> e^{-m}(m-1)^{m-1}/m!.
# Published values to reproduce (r9faef2b6, observation 4): k=148: n_1=179, end 250, N_0-1=236; k=349: n_1=396, end 523, N_0-1=501.
import numpy as np, sys, time
from math import lgamma, log, exp, ceil
from kern import true_profile
from e09_twopoint_large_k import kernel_matrices
def run(k, xmax):
    t0 = time.time()
    sc = k ** (2 / 3)
    top = min(2 * k, k + int(xmax * sc))
    W = top - k + 1
    Psi = true_profile(k, top)
    E, J = kernel_matrices(k, top)                 # E[n-k, j-k] = e_n(j-1), J[n-k]
    step = -J + E @ Psi[k - 1:top]
    q0 = k + next(i for i in range(1, W) if step[i] > 0)
    eps = np.zeros(W + 1)
    for m in range(1, W + 1):
        eps[m] = exp(-m + ((m - 1) * log(m - 1) if m > 1 else 0.0) - lgamma(m + 1))
    Eps = np.zeros((W, W))                          # Eps[n-k, j-k] = eps_{n-j} for j<n
    for i in range(1, W):
        Eps[i, :i] = eps[i - np.arange(0, i)]
    Cm = Eps @ E                                    # Cm[n-k, j-k] = c_n(j-1)   (e_j(s)=0 unless j>=s+2 automatically)
    I = Eps @ J
    Mem = Eps @ step
    n1 = k + next(i for i in range(1, W) if Mem[i] >= 0)
    N0 = q0 + ceil(2.2 * sc) + 1
    i1 = n1 - k
    def KK(n):
        i = n - k
        ncol = n1 - 3 - (k - 1) + 1                 # s = k-1 .. n1-3  -> columns 0..n1-k-2
        return bool(np.all(Cm[i, :ncol] * I[i1] >= Cm[i1, :ncol] * I[i] * (1 - 1e-11)))
    n = n1 + 1
    while n <= top and KK(n): n += 1
    end = n - 1
    ok = end >= N0 - 1
    print("k=%d q0=%d n_1=%d N_0-1=%d (x=%.2f): (KK)(n_1,.) holds through row %d (x=%.2f)%s  => (KK_k) %s   [%.0fs]" % (
        k, q0, n1, N0 - 1, (N0 - 1 - k) / sc, end, (end - k) / sc, " (scan end)" if end == top else "",
        "HOLDS" if ok else "FAILS (first failing row %d)" % (end + 1), time.time() - t0), flush=True)
if __name__ == '__main__':
    for a in sys.argv[1:]:
        k, xmax = a.split(':')
        run(int(k), float(xmax))
