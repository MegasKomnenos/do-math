# e04 (peer): constants of the formal scaling limit of the kernel form (window coordinate x).
#  (a) immortal profile Psi=1: crossing x_imm (zero of Pi(x;inf)), and Pi(x;inf)/J(x) at large x (-> 1)
#  (b) step profiles: far-field ratio R_inf(sigma) = 2(1-m(sigma)), m(sigma) = int exp(-Phi(mu)-mu sigma) dmu / Z; sigma_c: m=1/2
#  (c) true profile: far-field weight w(y) = (2/Z) int mu exp(-Phi(mu)-mu y) dmu; check int S w = 1; mass of w*S below y
#  (d) true profile cut at y_D: re-entry point x_re(y_D)
import numpy as np, sys
from limf import *
gx, gw = np.polynomial.legendre.leggauss(60)

def quad(f, a, b, parts=8):
    edges = np.linspace(a, b, parts + 1)
    tot = 0.0
    for i in range(parts):
        u = 0.5 * (edges[i + 1] - edges[i]) * gx + 0.5 * (edges[i + 1] + edges[i])
        tot += 0.5 * (edges[i + 1] - edges[i]) * np.dot(gw, f(u))
    return tot

def quad_inf(f):
    # int_0^inf by panels
    tot = 0.0; a = 0.0; w = 0.25
    for _ in range(60):
        tot += quad(f, a, a + w, 1); a += w; w *= 1.5
        if a > 400: break
    return tot

# (a)
imm_hat = eta_profile_hat(lambda mu: 1.0 / mu)
lo, hi = 0.3, 0.6
for _ in range(40):
    mid = 0.5 * (lo + hi)
    if talbot(imm_hat, mid) < 0: lo = mid
    else: hi = mid
x_imm = 0.5 * (lo + hi)
print("(a) immortal profile: crossing x_imm = %.5f (true crossing x0 = 0.59963)" % x_imm)
print("    Pi_imm(x)/J(x) at x = 1, 2, 5, 10, 30, 100:", ["%.4f" % (talbot(imm_hat, x) / talbot(Jhat, x)) for x in (1, 2, 5, 10, 30, 100)])
# (b)
m = lambda sig: quad_inf(lambda mu: np.exp(-C * mu ** 1.5 - mu * sig)) / Z
lo, hi = 0.1, 5.0
for _ in range(50):
    mid = 0.5 * (lo + hi)
    if m(mid) > 0.5: lo = mid
    else: hi = mid
sig_c = 0.5 * (lo + hi)
print("(b) step profiles: R_inf(sigma) = 2(1-m(sigma)) at sigma = 0.3, 0.6, 1, 2, 4:", ["%.4f" % (2 * (1 - m(s))) for s in (0.3, 0.6, 1, 2, 4)], "; sigma_c = %.5f" % sig_c)
for sig in (0.6, 1.0, 2.0):
    ph = eta_profile_hat(lambda mu, sig=sig: (1 - np.exp(-mu * sig)) / mu)
    print("    check sigma=%.1f: Pi(x;sigma)/J(x)+1 at x = 10, 30, 100:" % sig, ["%.4f" % (talbot(ph, x) / talbot(Jhat, x) + 1) for x in (10, 30, 100)])
# (c)
ygrid_edges = np.concatenate([np.linspace(0, 2, 41), np.linspace(2, 12, 41)[1:], np.linspace(12, 200, 61)[1:]])
Sfun = lambda y: talbot(Shat, y)
def w_of(y):
    return (2 / Z) * quad_inf(lambda mu: mu * np.exp(-C * mu ** 1.5 - mu * y))
tot = 0.0; cum = []
gx8, gw8 = np.polynomial.legendre.leggauss(8)
for i in range(len(ygrid_edges) - 1):
    a, b = ygrid_edges[i], ygrid_edges[i + 1]
    u = 0.5 * (b - a) * gx8 + 0.5 * (b + a)
    vals = np.array([Sfun(yy) * w_of(yy) for yy in u])
    tot += 0.5 * (b - a) * np.dot(gw8, vals)
    cum.append((b, tot))
# tail beyond 200: S ~ sqrt(2/pi) y^{-3/2}, w ~ (2/Z) y^{-2}
tail = np.sqrt(2 / np.pi) * (2 / Z) * (200.0 ** -2.5) / 2.5
print("(c) int_0^200 S w = %.5f, + tail estimate %.2e  => int S w = %.5f (claim: exactly 1)" % (tot, tail, tot + tail))
for yb in (0.6, 1.0, 1.5, 2.0, 3.0, 5.0, 10.0, 30.0):
    val = min(cum, key=lambda t: abs(t[0] - yb))
    print("    int_0^%.1f S w = %.4f" % (val[0], val[1]))
