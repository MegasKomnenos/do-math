# v05 (peer): the float kernel code reproduces exact cells/steps (k=12..15, rows to 2k-1) to relative 1e-10.
import numpy as np
from math import lgamma, exp, log
from ptab import Tab
from kern import column, true_profile
t = Tab(30)
worst = 0.0
for k in (8, 12, 15):
    top = 2 * k - 1
    Psi = true_profile(k, top)
    # check profile
    for s in range(k - 1, top):
        ex = t.a(s, k - 2) / ((s + 1) ** (s - 1) if s > 0 else 1)
        worst = max(worst, abs(Psi[s] - ex))
    cell, step, J = column(k, Psi, top)
    for n in range(k, top + 1):
        norm = exp(-(n + 1) - lgamma(n + 1))
        eb = t.b(n, k - 1) * norm; ed = t.d(n, k) * norm
        worst = max(worst, abs(cell[n] - eb) / eb, abs(step[n] - ed) / abs(eb))
print("max deviation (profile abs, cell rel, step rel to cell):", worst)
