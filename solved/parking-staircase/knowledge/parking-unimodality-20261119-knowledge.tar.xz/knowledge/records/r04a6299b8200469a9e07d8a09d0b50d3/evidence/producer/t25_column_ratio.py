# Test 25 (tied to the argument).  Candidate sign-only structure covering window and bulk at once:
#   (TP)  b_{n+1,k} * b_{n,k-1}  >=  b_{n,k} * b_{n+1,k-1}      (the column ratio b_{n,k}/b_{n,k-1} is nondecreasing in n)
# If (TP) held for all n >= k+1, "d_{n,k} >= 0 ==> d_{n+1,k} >= 0" would follow at once in every regime.
# Exact integers from the table (n <= 160).  For each k we list the rows n in [k+1, nmax-1] where (TP) FAILS.
import sys
from pf import T

tab = T(160)
nmax = 160


def fails(k):
    out = []
    for n in range(k + 1, nmax):
        lhs = tab.b(n + 1, k) * tab.b(n, k - 1)
        rhs = tab.b(n, k) * tab.b(n + 1, k - 1)
        if lhs < rhs:
            out.append(n)
    return out


if __name__ == '__main__':
    ks = [int(a) for a in sys.argv[1:]] or [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 30, 36, 40, 50, 60, 70, 79]
    for k in ks:
        f = fails(k)
        q0 = next((n for n in range(k + 1, nmax + 1) if tab.d(n, k) > 0), None)
        # also the size of the increments of the ratio near the crossing and at the end of the table
        def ratio(n):
            return tab.b(n, k) / tab.b(n, k - 1)
        r = [ratio(n) for n in range(k + 1, nmax + 1)]
        inc = [r[i + 1] / r[i] - 1 for i in range(len(r) - 1)]
        mi = min(range(len(inc)), key=lambda i: inc[i])
        print("k=%d q0=%s: rows k+1..%d where (TP) fails: %s ; smallest relative increment of the ratio = %.3e at n=%d (deficit %d)" % (
            k, q0, nmax - 1, (f if len(f) <= 12 else "%d rows %d..%d" % (len(f), f[0], f[-1])), inc[mi], k + 1 + mi, 1 + mi))
