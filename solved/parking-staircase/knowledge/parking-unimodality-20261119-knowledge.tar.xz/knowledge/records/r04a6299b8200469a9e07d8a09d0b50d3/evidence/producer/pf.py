# Exact tables for parking functions by maximum displacement.
# A[n][k] = #{alpha in PF_n : M(alpha) <= k}; b[n][k] = A[n][k]-A[n][k-1].
# Last-car recursion: A_{n,k} = sum_{j=0}^{n-1} C(n-1,j) * min(j+1,k+1) * A_{j,k} * A_{n-1-j,k}.
import sys, pickle, os
from math import comb
from fractions import Fraction

def build(nmax, cache=None):
    if cache and os.path.exists(cache):
        with open(cache,'rb') as f:
            A = pickle.load(f)
        if len(A) > nmax:
            return A
    # A[n] is a list over k = 0..n-1 (for k >= n-1, A = (n+1)^(n-1))
    A = [None]*(nmax+1)
    A[0] = [1]
    def get(n,k):
        if n == 0: return 1
        if k >= n-1: return (n+1)**(n-1)
        return A[n][k]
    for n in range(1, nmax+1):
        row = []
        binom = [comb(n-1,j) for j in range(n)]
        for k in range(0, n):
            if k >= n-1:
                row.append((n+1)**(n-1)); continue
            s = 0
            for j in range(n):
                s += binom[j]*min(j+1,k+1)*get(j,k)*get(n-1-j,k)
            row.append(s)
        A[n] = row
    if cache:
        with open(cache,'wb') as f:
            pickle.dump(A,f)
    return A

class T:
    def __init__(self, nmax, cache='A_cache.pkl'):
        self.nmax = nmax
        self.Atab = build(nmax, cache)
    def A(self,n,k):
        if n == 0: return 1
        if k < 0: return 0
        if k >= n-1: return (n+1)**(n-1)
        return self.Atab[n][k]
    def b(self,n,k):
        if k < 0 or k > n-1: return 0
        return self.A(n,k)-self.A(n,k-1)
    def d(self,n,k):
        return self.b(n,k)-self.b(n,k-1)
    def p(self,n):
        # exact integer also for n=0 (1**-1 would evaluate to the float 1.0)
        return 1 if n == 0 else (n+1)**(n-1)

if __name__ == '__main__':
    nmax = int(sys.argv[1]) if len(sys.argv)>1 else 30
    t = T(nmax)
    for n in range(1,8):
        print(n, [t.b(n,k) for k in range(n)])
