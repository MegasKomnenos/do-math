# Test 19 (tied to the argument).  One candidate "single quantity" for both regimes in the published kernel form
# (r9faef2b6 Theorem 15):  eta_n = -J_n + (survival response),  J_n = response of the first step d_{k,k} (Cayley-only):
#       J_n = tau_{n-k+1} omega_{k-1}/k + (k+1) sum_{s=k}^{n-1} tau_{n-s} J_s/(s+1)        (no tilt: tau_g=g^(g-1)/g!, omega_s=c_s).
# Conclusion of the kernel two-point theorem for consecutive rows:   d_{n+1,k}/(n+1)! / J_{n+1}  >=  d_{n,k}/n! / J_n .
# Question: does this monotonicity hold for the TRUE columns on the whole first layer (both regimes), and how does the
# ratio  rho_n := eta_n/J_n  (= -1 at n=k, 0 at the crossing) behave in the bulk?
from pf import T
from fractions import Fraction as Fr
from math import factorial
t = T(160)
for k in [8, 12, 20, 30, 40, 50, 60, 79]:
    N = 2*k-1
    tau = [Fr(0)] + [Fr(g**(g-1), factorial(g)) for g in range(1, N+2)]
    om = lambda s: Fr((s+1)**(s-1), factorial(s)) if s > 0 else Fr(1)
    J = {}
    for n in range(k, N+1):
        J[n] = tau[n-k+1]*om(k-1)/k + (k+1)*sum(tau[n-s]*J[s]/(s+1) for s in range(k, n))
    rho = {n: Fr(t.d(n, k), factorial(n))/J[n] for n in range(k, N+1)}
    assert rho[k] == -1
    viol = [n for n in range(k, N) if rho[n+1] < rho[n]]
    q0 = next(n for n in range(k+1, 2*k+1) if t.d(n,k) > 0)
    sel = [N, k + (3*(N-k))//4, k + (N-k)//2, q0+1, q0, q0-1]
    print("k=%d q0=%d: rows n in [k,2k-2] with rho_{n+1} < rho_n: %s ; rho at n=q0-1,q0,q0+1, mid, 3/4, 2k-1: %s" % (
        k, q0, viol if len(viol) <= 10 else "%d rows %d..%d" % (len(viol), viol[0], viol[-1]),
        [round(float(rho[n]), 3) for n in sorted(set(sel)) if n in rho]))
