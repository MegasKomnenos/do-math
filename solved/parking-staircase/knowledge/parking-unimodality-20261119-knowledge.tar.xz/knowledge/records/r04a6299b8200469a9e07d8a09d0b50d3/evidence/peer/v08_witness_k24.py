# v08 (peer): independent exact witnesses for the producer's counterexample N4 (a) at k=24.
# For a crossing row q and a target row n+1, find a mixture of two step profiles (death times S1<S2, weights w, 1-w)
# whose column (peer's Green-function form) satisfies eta_j<=0 (24<=j<q), eta_j>=0 (q<=j<=n), eta_{n+1}<0.
from fractions import Fraction as Fr
from green import column_from_profile
k = 24; top = 47
cols = {}
def col(S):
    if S not in cols:
        cols[S] = column_from_profile(k, (lambda s, S=S: Fr(1) if s <= S else Fr(0)), top)[1]
    return cols[S]
def interval(q, n, S1, S2):
    """exact interval of weights w on S1 for which the sign pattern up to row n holds; then eta_{n+1} at both ends"""
    a, b = col(S1), col(S2)
    lo, hi = Fr(0), Fr(1)
    for j in range(k, n + 1):
        # eta_j(w) = w a_j + (1-w) b_j  = b_j + w (a_j - b_j);  a_j <= b_j since S1<S2
        dj = a[j] - b[j]
        if j < q:      # need <= 0
            if dj == 0:
                if b[j] > 0: return None
            else:
                lo = max(lo, -b[j] / dj)      # dj<0: w >= b_j/(-dj)
        else:          # need >= 0
            if dj == 0:
                if b[j] < 0: return None
            else:
                hi = min(hi, -b[j] / dj)      # w <= b_j/(-dj)
    if lo > hi: return None
    e = lambda w: w * a[n + 1] + (1 - w) * b[n + 1]
    return lo, hi, e(lo), e(hi)
imp = {j: -col(k - 1)[j] for j in range(k, top + 1)}       # the producer's normalizer: -Pi_j(k-1) = J_j - e_j(k-1)
for (q, n, S1, S2) in [(41, 43, 23, 36), (42, 43, 23, 38), (40, 46, 23, 37), (40, 46, 23, 38), (44, 46, 23, 42), (39, 46, 23, 35), (40, 43, 23, 35)]:
    r = interval(q, n, S1, S2)
    if r is None:
        print("q=%d target row %d, death times (%d,%d): no admissible weight" % (q, n + 1, S1, S2)); continue
    lo, hi, elo, ehi = r
    best = min(elo, ehi)
    print("q=%d target row %d, death times (%d,%d): admissible weights on S=%d: [%.4f, %.4f]; min eta_%d / (J-e(k-1)) = %.4e  -> %s" % (
        q, n + 1, S1, S2, S1, float(lo), float(hi), n + 1, float(best / imp[n + 1]), "NEGATIVE (exact)" if best < 0 else "nonnegative"))
