# Peer: fast double-precision evaluation of the formal scaling limit of the first-layer kernel form.
#   Phi(l) = (2 sqrt2/3) l^{3/2}.  For a function g:  T[g](l) = int_0^inf exp(-(Phi(l+t)-Phi(l))) g(l+t) dt.
#   Shat = T[sqrt(2/mu)],  Jhat = T[1],  eta-hat = -l + l^2 Shat  (transform of -f'),  fhat = 1 - l Shat.
#   Column built from a profile Psi (Laplace transform Psihat):  eta-hat[Psi](l) = T[ 2(mu-l) Psihat(mu) - 1 ](l).
# Inversion: fixed Talbot (Abate-Valko), M nodes; inner integral: composite Gauss-Legendre on doubling panels.
import numpy as np
C = 2 * np.sqrt(2) / 3
_gl_x, _gl_w = np.polynomial.legendre.leggauss(24)

def Phi(l):
    return C * l ** 1.5

def Tint(l, g):
    """T[g](l) for complex scalar l; g(mu, l) vectorized in mu."""
    Pl = Phi(l)
    h = min(0.05, 0.2 / max(abs(np.sqrt(2 * l)), 1e-9))
    a = 0.0
    tot = 0.0 + 0.0j
    width = h
    for _ in range(80):
        b = a + width
        t = 0.5 * (b - a) * _gl_x + 0.5 * (b + a)
        mu = l + t
        val = np.exp(-(Phi(mu) - Pl)) * g(mu, l)
        tot += 0.5 * (b - a) * np.dot(_gl_w, val)
        if (Phi(l + b) - Pl).real > 46:
            break
        a = b
        width *= 1.6
    return tot

def talbot(F, x, M=20):
    r = 2.0 * M / (5.0 * x)
    acc = 0.5 * F(complex(r)).real * np.exp(r * x)
    for kk in range(1, M):
        th = kk * np.pi / M
        cot = np.cos(th) / np.sin(th)
        s = r * th * (cot + 1j)
        sig = th + (th * cot - 1) * cot
        acc += (np.exp(x * s) * F(s) * (1 + 1j * sig)).real
    return acc * r / M

Shat = lambda l: Tint(l, lambda mu, l0: np.sqrt(2 / mu))
Jhat = lambda l: Tint(l, lambda mu, l0: 1.0 + 0 * mu)
etahat = lambda l: -l + l * l * Shat(l)
fhat = lambda l: 1 - l * Shat(l)

def eta_profile_hat(Psihat):
    return lambda l: Tint(l, lambda mu, l0: 2 * (mu - l0) * Psihat(mu) - 1.0)

from math import gamma
Z = (2.0 / 3.0) * (3.0 / (2 * np.sqrt(2))) ** (2.0 / 3.0) * gamma(2.0 / 3.0)
