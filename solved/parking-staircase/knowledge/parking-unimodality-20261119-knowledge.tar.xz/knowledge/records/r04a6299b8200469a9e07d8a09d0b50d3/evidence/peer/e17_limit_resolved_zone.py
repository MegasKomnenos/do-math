# e17 (peer): limit form of the explorer's "resolved form" sign criterion (report 5.1, 5.5).
#   M(z) := psi(z) - z f(z)   (limit of the partial sums M~_n of the resolved form; M(0)=1)
#   Laplace transforms:  M^ = sqrt(2 l) f^ ,   (f')^ = l f^ = (1/2) sqrt(2 l) M^        (from psi^' = sqrt(2l) psi^ - sqrt(2/l))
#   => f'(z) = (1/sqrt 2) [ M(z)/sqrt(pi z) + (1/(2 sqrt pi)) int_0^z (M(z)-M(t)) (z-t)^(-3/2) dt ]   (Marchaud form)
#   Sign criterion: M(z) <= 0 and M(z) <= M(t) for all t<z  ==>  f'(z) < 0.
#   M' = -(2 f + z f'), so M decreases exactly while z^2 f increases.
# Computes z_h (M=0, i.e. z f = psi), z_2 (2f + z f' = 0, i.e. the maximum of z^2 f), and checks the Marchaud formula.
import numpy as np
from limf import *
psi = lambda z: talbot(Shat, z)
f = lambda z: talbot(fhat, z)
fp = lambda z: -talbot(etahat, z)          # etahat is the transform of -f'
M = lambda z: psi(z) - z * f(z)
print("check of M^ = sqrt(2l) f^ at l = 0.5, 2:", [abs(np.sqrt(2 * l) * fhat(l) - (-l) * (np.sqrt(2 * l) * Shat(l) - np.sqrt(2 / l))) for l in (0.5, 2.0)])
def bis(g, lo, hi, n=40):
    glo = g(lo)
    for _ in range(n):
        mid = 0.5 * (lo + hi)
        if (g(mid) > 0) == (glo > 0): lo = mid
        else: hi = mid
    return 0.5 * (lo + hi)
zh = bis(M, 1.0, 3.0)
z2 = bis(lambda z: 2 * f(z) + z * fp(z), 2.0, 3.5)
print("z_h (z f = psi)            = %.4f   [M(z_h) = %.1e]" % (zh, M(zh)))
print("z_2 (2 f + z f' = 0)       = %.4f   [-z f'/f at z_2 = %.4f]" % (z2, -z2 * fp(z2) / f(z2)))
print("   z:      M(z)      z f/psi   -z f'/f")
for z in (0.3, 0.6, 1.0, 1.5, 2.0, 2.5, z2, 3.0, 4.0, 6.0, 10.0, 20.0):
    print("  %6.3f  %9.5f  %7.4f  %7.4f" % (z, M(z), z * f(z) / psi(z), -z * fp(z) / f(z)))
# Marchaud check at z = 1 and 2.5 (substitution t = z - s^2 removes the endpoint singularity)
gx, gw = np.polynomial.legendre.leggauss(40)
for z in (1.0, 2.5):
    Mz = M(z)
    smax = np.sqrt(z)
    tot = 0.0
    edges = np.linspace(0, smax, 9)
    for i in range(8):
        a, b = edges[i], edges[i + 1]
        s = 0.5 * (b - a) * gx + 0.5 * (b + a)
        vals = np.array([(Mz - M(z - si * si)) / (si * si) * 2 for si in s])     # (M(z)-M(t)) (z-t)^(-3/2) dt = 2 (M(z)-M(z-s^2))/s^2 ds
        tot += 0.5 * (b - a) * np.dot(gw, vals)
    rhs = (Mz / np.sqrt(np.pi * z) + tot / (2 * np.sqrt(np.pi))) / np.sqrt(2)
    print("Marchaud check at z=%.1f: f'(z) = %.6f ; formula = %.6f" % (z, fp(z), rhs))
