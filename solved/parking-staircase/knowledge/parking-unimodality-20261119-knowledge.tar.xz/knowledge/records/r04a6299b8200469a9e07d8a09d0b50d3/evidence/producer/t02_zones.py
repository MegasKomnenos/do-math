# Test 2 (tied to the argument): along column k in the first layer k+1<=n<=2k-1, where do the
# sign-only criteria apply?
#  (W) window theorem P (published r6af349eb, Cor. P1): rows n <= k+R_s(k)+1
#  (R) resolved running-minimum criterion: Mtil_n <= 0 and Mtil_n = min_{t<=n} Mtil_t (tilt 1/e)
#  (B) both critical brackets nonnegative: DB = b_{n,k} - r_k n b_{n-1,k-1} >= 0, CB = r_k n b_{n-1,k-1} - b_{n,k-1} >= 0
from pf import T
from fractions import Fraction as Fr
from math import factorial, exp, log
import mpmath as mp
mp.mp.dps = 40
t = T(160)
def g(m):  # eps_{m+1}/eps_m, eps_m=(m-1)^(m-1)/m!
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
def Rs(k):
    xd = Fr(k, k+1)**(k-2)
    R = 0
    for r in range(1, k-1):
        if (k+r+1)*xd*g(r) <= k+r: R = r
        else: break
    return R
def col(k):
    q0 = None
    for n in range(k+1, 2*k+1):
        if t.d(n,k) > 0: q0 = n; break
    rk = Fr(k+1,k)**(k-1)
    DBs=[]; CBs=[]
    for n in range(k+1, 2*k):
        DB = t.b(n,k) - rk*n*t.b(n-1,k-1)
        CB = rk*n*t.b(n-1,k-1) - t.b(n,k-1)
        DBs.append((n, DB>=0)); CBs.append((n, CB>=0))
    # Mtil at tilt 1/e (mpmath)
    x = mp.e**(-1)
    iota = mp.mpf(k**(k-2))/mp.factorial(k)
    M = {k: x**k*iota}
    for s in range(k+1, 2*k):
        mu = mp.mpf(2*t.b(s-1,k-1) - (s-1-k)*t.d(s-1,k))/mp.factorial(s)
        M[s] = M[s-1] - x**s*mu
    runmin = {}
    cur = M[k]
    for s in range(k+1, 2*k):
        runmin[s] = (M[s] <= cur)
        cur = min(cur, M[s])
    nM = next((n for n in range(k+1,2*k) if M[n] <= 0), None)
    nminend = max((n for n in range(k+1,2*k) if runmin[n]), default=None)
    def sign_changes(L):
        s = [v for (_,v) in L]
        return sum(1 for i in range(1,len(s)) if s[i]!=s[i-1])
    nDB = next((n for (n,v) in DBs if v), None)
    nCB = next((n for (n,v) in CBs if v), None)
    return dict(k=k, q0=q0, r0=q0-k if q0 else None, Rs=Rs(k), win_end=k+Rs(k)+1,
                nM=nM, nminend=nminend, nDB=nDB, nCB=nCB,
                scDB=sign_changes(DBs), scCB=sign_changes(CBs), end=2*k-1)
print("k q0 r0 | window_end(k+Rs+1) | resolved zone [nM, nminend] | nDB(sc) nCB(sc) | 2k-1")
for k in [12,16,20,24,30,36,40,50,60,70,80]:
    c = col(k)
    print(c['k'], c['q0'], c['r0'], '|', c['win_end'], '|', c['nM'], c['nminend'], '|',
          c['nDB'], '(%d)'%c['scDB'], c['nCB'], '(%d)'%c['scCB'], '|', c['end'])
