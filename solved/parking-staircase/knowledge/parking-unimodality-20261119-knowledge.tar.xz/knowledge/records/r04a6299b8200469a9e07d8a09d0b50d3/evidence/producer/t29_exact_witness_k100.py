# Test 29 (tied to the argument).  EXACT witness for the negative statement of test 26 at k=100:
#   there is a nonincreasing profile Psi (values in [0,1], Psi_{k-1}=1) whose column, built by the first-layer kernel
#   equations (S1),(S2) of r9faef2b6, has the sign pattern of a single crossing AT THE TRUE CROSSING ROW q=121
#   (eta_j < 0 for 100 <= j <= 120, eta_j > 0 for 121 <= j <= 198)  and  eta_199 < 0.
# Exact rational arithmetic; no table of parking functions is used (only Cayley numbers), except in the sanity check
# at k=24 where the same recursion with the true profile is compared with the exact table.
# Integer-scaled recursion (Ut_n = n! U_n, Et_n = n! eta_n, p_s = (s+1)^(s-1)):
#   Ut_n = sum_{s=k-1}^{n-1} C(n,s) (n-s)^(n-s-1) (k Ut_s + p_s Psi_s)/(s+1),            Ut_{k-1}=0,
#   Et_n = sum_{s=k}^{n-1}   C(n,s) (n-s)^(n-s-1) ((k+1) Et_s + 2 Ut_s)/(s+1)  -  C(n,k-1) (n-k+1)^(n-k) p_{k-1}/k.
import sys
from fractions import Fraction as Fr
from math import comb


def p(s):
    return 1 if s == 0 else (s + 1) ** (s - 1)


def column(k, Psi, top):
    Ut = {k - 1: Fr(0)}
    Et = {}
    for n in range(k, top + 1):
        acc = Fr(0)
        for s in range(k - 1, n):
            g = n - s
            acc += comb(n, s) * g ** (g - 1) * (k * Ut[s] + p(s) * Psi(s)) / (s + 1)
        Ut[n] = acc
        acc = Fr(0)
        for s in range(k, n):
            g = n - s
            acc += comb(n, s) * g ** (g - 1) * ((k + 1) * Et[s] + 2 * Ut[s]) / (s + 1)
        g = n - k + 1
        Et[n] = acc - Fr(comb(n, k - 1) * g ** (g - 1) * p(k - 1), k)
    return Ut, Et


def sanity():
    from pf import T
    tab = T(160)
    k = 24
    Psi = lambda s: Fr(tab.A(s, k - 2), tab.p(s))
    Ut, Et = column(k, Psi, 2 * k - 1)
    ok = all(Ut[n] == tab.b(n, k - 1) and Et[n] == tab.d(n, k) for n in range(k, 2 * k))
    print("sanity (k=24, true profile): recursion reproduces b_{n,k-1} and d_{n,k} exactly on k<=n<=2k-1: %s" % ok)


if __name__ == '__main__':
    sanity()
    k, q, top = 100, 121, 199
    # step profiles (death times) suggested by the float LP of test 26
    deaths = [99, 117, 195]
    cols = {}
    for S in deaths:
        cols[S] = column(k, (lambda s, S=S: Fr(1) if s <= S else Fr(0)), top)[1]
        print("exact column for death time %d done" % S)
    # weights: two-parameter family w = (w99, w117, w195); exact search on a small rational grid around the float optimum
    best = None
    for a in range(40, 91):                 # w99 = a/1000
        for c in range(0, 6):               # w195 = c/2000
            w = {99: Fr(a, 1000), 195: Fr(c, 2000)}
            w[117] = 1 - w[99] - w[195]
            eta = {j: sum(w[S] * cols[S][j] for S in deaths) for j in range(k, top + 1)}
            neg_ok = all(eta[j] < 0 for j in range(k, q))
            pos_ok = all(eta[j] > 0 for j in range(q, top))
            if neg_ok and pos_ok and eta[top] < 0:
                imp = -cols[99][top]        # death time k-1: no source, eta = -(impulse response)
                val = eta[top] / cols[99][top] * (-1)
                rel = float(eta[top] / imp)
                if best is None or rel < best[0]:
                    best = (rel, dict(w), eta)
    if best is None:
        print("no strict witness on the grid")
        sys.exit(0)
    rel, w, eta = best
    print("EXACT strict witness at k=100, crossing row q=121:")
    print("   profile: Psi_99 = 1;  Psi_s = %s for 100<=s<=117;  Psi_s = %s for 118<=s<=195;  Psi_s = 0 for s>=196" % (w[117] + w[195], w[195]))
    print("   eta_j < 0 for 100<=j<=120: %s ; eta_j > 0 for 121<=j<=198: %s ; eta_199 < 0: %s" % (
        all(eta[j] < 0 for j in range(k, q)), all(eta[j] > 0 for j in range(q, top)), eta[top] < 0))
    imp = {j: -cols[99][j] for j in range(k, top + 1)}
    print("   eta_j / impulse_j at j=120,121,122,150,180,197,198,199: %s" % [round(float(eta[j] / imp[j]), 6) for j in (120, 121, 122, 150, 180, 197, 198, 199)])
