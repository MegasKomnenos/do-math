# e22 (peer): which rows fail when the true profile is cut one size below S_min(k)?  (small and middle columns)
import numpy as np, sys
from kern import column, true_profile, bor
for a in sys.argv[1:]:
    k, smin = [int(v) for v in a.split(":")]
    top = 2 * k - 1
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    P = Psi.copy(); P[smin:] = 0.0          # cut at S = smin-1
    c2, s2, J2 = column(k, P, top, B)
    bad = [n for n in range(q0, top + 1) if s2[n] < 0]
    print("k=%d q0=%d, cut at S_min-1=%d: negative rows %s ; true step/J at q0: %.4f, at 2k-1: %.4f" % (
        k, q0, smin - 1, ("%d..%d" % (bad[0], bad[-1])) if bad else "none", step[q0] / J[q0], step[top] / J[top]))
