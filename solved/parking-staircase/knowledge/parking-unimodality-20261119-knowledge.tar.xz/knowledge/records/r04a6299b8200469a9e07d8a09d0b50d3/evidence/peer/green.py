# Peer: Green functions of the heavy chain, exact integers / rationals.
#   H_c(N,j): sum over rooted labelled trees on N vertices with a marked vertex v of subtree size j,
#             of prod over proper ancestors w of v (root included) of c/t_w.      H_c(j,j) = j^(j-1).
#             H_c(N,j) = c * sum_{s=j}^{N-1} C(N-1,s) (N-s)^(N-s-2) H_c(s,j)   (N>j)
#   G_c(n,j): same sum over rooted forests on [n] (virtual root carries no weight):
#             G_c(n,j) = sum_{s=j}^{n} C(n,s) (n+1-s)^(n-s-1) H_c(s,j)
# First-layer formulas (k <= n <= 2k-1), Psi_s = Pr(M_s <= k-2):
#   b_{n,k-1} = sum_{j=k}^{n} (Psi_{j-1}/j) G_k(n,j)
#   d_{n,k}   = sum_{j=k}^{n} (2 Psi_{j-1}/j) (G_{k+1}(n,j) - G_k(n,j))  -  (1/k) G_{k+1}(n,k)
from fractions import Fraction as Fr
from math import comb

def pw(a, e):
    # a^e for integers, with a^(-1) only used at a=1
    if e >= 0:
        return a ** e
    assert a == 1
    return 1

def H_table(c, j, Nmax):
    H = {j: Fr(j ** (j - 1))}
    for N in range(j + 1, Nmax + 1):
        H[N] = c * sum(comb(N - 1, s) * pw(N - s, N - s - 2) * H[s] for s in range(j, N))
    return H

def G_from_H(H, j, n):
    return sum(comb(n, s) * pw(n + 1 - s, n - s - 1) * H[s] for s in range(j, n + 1))

def column_from_profile(k, Psi, top):
    """Returns dicts b[n] (level k-1 cell) and d[n] (step) for k<=n<=top built from the profile Psi(s), s>=k-1."""
    b = {n: Fr(0) for n in range(k, top + 1)}
    d = {n: Fr(0) for n in range(k, top + 1)}
    for j in range(k, top + 1):
        Hk = H_table(k, j, top)
        Hk1 = H_table(k + 1, j, top)
        ps = Psi(j - 1)
        for n in range(j, top + 1):
            gk = G_from_H(Hk, j, n)
            gk1 = G_from_H(Hk1, j, n)
            b[n] += ps * gk / j
            d[n] += 2 * ps * (gk1 - gk) / j
            if j == k:
                d[n] -= gk1 / k
    return b, d
