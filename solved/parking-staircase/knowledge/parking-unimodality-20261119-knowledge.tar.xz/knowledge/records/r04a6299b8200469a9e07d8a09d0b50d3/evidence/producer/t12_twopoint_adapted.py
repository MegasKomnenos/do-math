# Test 12 (tied to the argument).  The two-point argument of Theorem P (r6af349eb c12) run verbatim at the
# deficit-adapted tilt z_r = min(1/gamma_k, 1/g(r-1)) (the tilt of r69068ac5 Theorem F) needs, at row n=k+r:
#   (D1')  h_{n-1} <= U_{n-1},      (D2')  sum_{j=q}^{n-1} (V_j - U_{j-1}) >= 0,      (ii)  n*kappa_r <= q*kappa_{r_q}.
# For r <= R_i(k) these are the published hypotheses (Dg gives (D1),(D2)).  Question: beyond R_i, do the three hold
# simultaneously on every row after the crossing (one closing condition for window and bulk alike)?
# Exact rationals; columns with tables n<=160.
from pf import T
from fractions import Fraction as Fr
from math import factorial
t = T(160)
def g(m):
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
def eps(m): return Fr((m-1)**(m-1), factorial(m)) if m>1 else Fr(1)
print("k q0 Ri | rows after crossing where (D1') fails | (D2') fails | (ii) fails | max h/U (row) | min (D2')/U (row) | max (ii) ratio beyond Ri (row)")
for k in [20, 24, 28, 30, 33, 36, 40, 45, 50, 60, 70, 79]:
    xdag = Fr(k, k+1)**(k-2)
    Ri = max(r for r in range(1, k) if all(xdag*g(m) <= 1 for m in range(1, r)))
    q0 = next(n for n in range(k+1, 2*k+1) if t.d(n,k) > 0)
    f1 = []; f2 = []; f3 = []; mx = (0, None); mn = (10**9, None); mii = (0, None)
    for n in range(q0+1, 2*k):
        r = n-k
        x = min(xdag, 1/g(r-1)) if r >= 2 else xdag
        U = {j: x**j*Fr(t.b(j,k-1), factorial(j)) for j in range(k, n)}
        V = {j: x**j*Fr(t.b(j,k), factorial(j)) for j in range(k, n)}
        h = sum(U[j]-V[j] for j in range(k, n))
        D2 = sum(V[j]-U[j-1] for j in range(q0, n))
        ii = (n*x**r*eps(r))/(q0*x**(q0-k)*eps(q0-k))
        if h > U[n-1]: f1.append(n)
        if D2 < 0: f2.append(n)
        if ii > 1: f3.append(n)
        hu = float(h/U[n-1]); d2 = float(D2/U[n-1])
        if hu > mx[0]: mx = (hu, n)
        if d2 < mn[0]: mn = (d2, n)
        if r > Ri and float(ii) > mii[0]: mii = (float(ii), n)
    print(k, q0, Ri, "|", f1, "|", f2, "|", f3, "| %.3f (n=%s) | %.3f (n=%s) | %.3f (n=%s)" % (mx[0], mx[1], mn[0], mn[1], mii[0], mii[1]))
