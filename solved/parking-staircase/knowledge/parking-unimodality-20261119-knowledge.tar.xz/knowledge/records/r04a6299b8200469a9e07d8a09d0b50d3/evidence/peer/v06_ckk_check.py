# v06 (peer): independent recomputation of the ends of (KK)(q0,.) and (cKK)(q0,.) with the peer's kernel code.
# Pi_n(S) = step of the column built from the step profile dying at S; e_n(s) = Pi_n(s) - Pi_n(s-1) (s>=k), e_n(k-1) = Pi_n(k-1)+J_n.
import numpy as np, sys
from kern import column, true_profile, bor
def run(k):
    top = 2 * k - 1
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    Pi = np.zeros((top + 1, top + 1))      # Pi[S][n]
    for S in range(k - 1, top):
        P = np.zeros(top + 1); P[k - 1:S + 1] = 1.0
        c2, s2, J2 = column(k, P, top, B)
        Pi[S, :] = s2[:top + 1]
    qimm = next(n for n in range(k + 1, top + 1) if Pi[n - 2, n] > 0)
    def cKK(q, n):
        a = np.array([Pi[min(S, q - 2), q] for S in range(k - 1, n - 1)])
        b = np.array([Pi[min(S, n - 2), n] for S in range(k - 1, n - 1)])
        if np.any((a >= 0) & (b < 0)): return False
        H = np.min(b[a > 0] / a[a > 0]) if np.any(a > 0) else np.inf
        L = np.max(b[a < 0] / a[a < 0]) if np.any(a < 0) else -np.inf
        return max(L, 0) <= H * (1 + 1e-12)
    def KK(q, n):
        for s in range(k - 1, q - 1):
            eq = Pi[s, q] - (Pi[s - 1, q] if s >= k else -J[q])
            en = Pi[s, n] - (Pi[s - 1, n] if s >= k else -J[n])
            if en * J[q] < eq * J[n] * (1 - 1e-12): return False
        return True
    def last(test):
        n = q0 + 1
        while n <= top and test(q0, n): n += 1
        return n - 1
    sc = k ** (2 / 3)
    eK, eC = last(KK), last(cKK)
    print("k=%d q_imm=%d q0=%d 2k-1=%d : (KK)(q0,.) holds through row %d (deficit %.2f k^(2/3)); (cKK)(q0,.) through row %d (deficit %.2f k^(2/3))" % (
        k, qimm, q0, top, eK, (eK - k) / sc, eC, (eC - k) / sc), flush=True)
for k in [int(a) for a in sys.argv[1:]]:
    run(k)
