# v11 (peer): 40-digit confirmation of one violated instance of (KK)(n_1,n) below N_0 (hypothesis (KK_k) of r9faef2b6).
#   c_n(s) I_{n1} >= c_{n1}(s) I_n   is tested at the cell found by e11 (double precision).
# Borel normalization (tilt 1/e; the comparison is tilt-free):
#   hh_c(N;j): hh(j;j)=j Bor(j), hh(N;j)=sum_{t=j}^{N-1} Bor(N-t)(c/t) hh(t;j);   gg_c(n;j)=sum_{t=j}^{n} Bor(n+1-t) hh(t;j)/t
#   e_n(s) ~ (2/(s+1)) (gg_{k+1}(n;s+1)-gg_k(n;s+1)),  J_n ~ gg_{k+1}(n;k)/k,  kappa_m ~ e^{-m}(m-1)^{m-1}/m!
#   c_n(s) = sum_{j=s+2}^{n-1} kappa_{n-j} e_j(s),   I_n = sum_{j=k}^{n-1} kappa_{n-j} J_j
import mpmath as mp, sys, time
mp.mp.dps = 40
def run(k, n1, n, s):
    t0 = time.time()
    top = n
    Bor = [mp.mpf(0)] + [mp.exp(-g + (g - 1) * mp.log(g) - mp.loggamma(g + 1)) for g in range(1, top + 2)]
    kap = [mp.mpf(0), mp.exp(-1)] + [mp.exp(-m + (m - 1) * mp.log(m - 1) - mp.loggamma(m + 1)) for m in range(2, top + 2)]
    def gg(c, j):
        hh = {j: j * Bor[j]}
        for N in range(j + 1, top + 1):
            hh[N] = c * mp.fsum(Bor[N - t] * hh[t] / t for t in range(j, N))
        return {nn: mp.fsum(Bor[nn + 1 - t] * hh[t] / t for t in range(j, nn + 1)) for nn in range(j, top + 1)}
    g1 = gg(k + 1, s + 1); g0 = gg(k, s + 1)
    e = {j: 2 * (g1[j] - g0[j]) / (s + 1) for j in range(s + 1, top + 1)}
    gJ = gg(k + 1, k)
    J = {j: gJ[j] / k for j in range(k, top + 1)}
    c = lambda nn: mp.fsum(kap[nn - j] * e[j] for j in range(s + 2, nn))
    I = lambda nn: mp.fsum(kap[nn - j] * J[j] for j in range(k, nn))
    val = c(n) * I(n1) / (c(n1) * I(n)) - 1
    print("k=%d, n_1=%d, n=%d, s=%d:  c_n(s) I_{n1}/(c_{n1}(s) I_n) - 1 = %s   [%.0fs]" % (k, n1, n, s, mp.nstr(val, 12), time.time() - t0), flush=True)
run(349, 396, 397, 348)        # published margin 0.0083
run(2400, 2538, 2924, 2511)    # e11: -2.896e-3
