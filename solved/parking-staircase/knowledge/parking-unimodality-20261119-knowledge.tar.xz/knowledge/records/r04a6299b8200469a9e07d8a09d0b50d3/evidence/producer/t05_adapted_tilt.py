# Test 5 (tied to the argument): Theorem P (published, r6af349eb) uses the diagonal tilt x_dag=1/gamma_k, where
# Dg gives (D1) h_{n-1}<=U_{n-1} and (D2) sum_{j=q}^{n-1}(V_j-U_{j-1})>=0, but the kernel x^m eps_m is nonincreasing
# only for lags m<=R_i(k)~0.6k.  For a row n beyond that, take the row-adapted tilt x_n = min(x_dag, 1/g(n-k-1))
# (largest tilt for which x^m eps_m is nonincreasing on 1<=m<=n-k).  The proof of Theorem P then needs, at tilt x_n:
#   (D1') h_{n-1} <= U_{n-1}        (debt at most one cell)
#   (D2') sum_{j=q}^{n-1} (V_j - U_{j-1}) >= 0
#   and (ii) n*kappa_r <= q*kappa_{r_q}   or  (iii) kappa_{t+1} <= 2x/n.
# Question: do (D1'),(D2') hold at the row-adapted tilt on the whole first layer?  How large is the slack?
from pf import T
from fractions import Fraction as Fr
from math import factorial
t = T(160)
def g(m):
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
def eps(m): return Fr((m-1)**(m-1), factorial(m)) if m>1 else Fr(1)
def run(k):
    xdag = Fr(k, k+1)**(k-2)
    q0 = next(n for n in range(k+1, 2*k+1) if t.d(n,k) > 0)
    out = []
    for n in range(q0+1, 2*k):
        r = n-k
        x = min(xdag, 1/g(r-1)) if r >= 2 else xdag
        U = lambda j: x**j*Fr(t.b(j,k-1), factorial(j))
        V = lambda j: x**j*Fr(t.b(j,k), factorial(j))
        Us = {j: U(j) for j in range(k, n)}
        Vs = {j: V(j) for j in range(k, n)}
        h = sum(Us[j]-Vs[j] for j in range(k, n))
        D1 = h/Us[n-1]                       # want <= 1
        D2 = sum(Vs[j]-Us[j-1] for j in range(q0, n))   # want >= 0
        kap = lambda m: x**m*eps(m)
        tt = n-q0
        c_ii = (n*kap(r)) / (q0*kap(q0-k))   # want <= 1
        c_iii = kap(tt+1)/(2*x/n)            # want <= 1
        # required mean excess lambda: x = xdag/(1+lam/k)
        lam = float(k*(xdag/x - 1))
        out.append((n, r, lam, float(D1), D2 >= 0, float(D2/Us[n-1]), float(c_ii), float(c_iii)))
    return q0, out
print("k q0 | n r | lam(needed mean excess) | h/U (want<=1) | D2>=0, D2/U | (ii) ratio | (iii) ratio | ok")
for k in [20, 30, 40, 50, 60, 79]:
    q0, out = run(k)
    fail = [o for o in out if not (o[3] <= 1 and o[4] and (o[6] <= 1 or o[7] <= 1))]
    print("k=%d q0=%d rows tested %d..%d ; rows failing: %s" % (k, q0, out[0][0], out[-1][0], [(o[0], round(o[3],3), o[4], round(o[6],2), round(o[7],2)) for o in fail][:12]))
    for o in out:
        if o[1] in (int(0.5*k), int(0.6*k), int(0.7*k), int(0.8*k), int(0.9*k), k-1):
            print("    n=%d r=%d lam=%.3f  h/U=%.4f  D2ok=%s D2/U=%.3f  (ii)=%.3f (iii)=%.3f" % o)
