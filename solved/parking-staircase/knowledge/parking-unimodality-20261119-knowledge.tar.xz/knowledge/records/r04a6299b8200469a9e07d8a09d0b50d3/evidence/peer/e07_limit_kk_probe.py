# e07 (peer): probe of the limit two-point comparison: R(x;y) = 2K(x,y)/J(x) as a function of x for fixed source point y.
import numpy as np
from limf import *
def K2(x, y):
    return talbot(lambda l: Tint(l, lambda mu, l0: 2 * (mu - l0) * np.exp(-(mu - l0) * y)), x - y)
J = lambda x: talbot(Jhat, x)
print("2K(x,y) at small lags (y=0.5): lag -> value:", ["%.3f:%.4f" % (lag, K2(0.5 + lag, 0.5)) for lag in (0.001, 0.01, 0.05, 0.1, 0.3, 1.0)])
for y in (0.0, 0.3, 0.55):
    xs = [y + d for d in (0.02, 0.05, 0.1, 0.2, 0.4, 0.8, 1.5, 2.5, 4.0, 6.0, 9.0)]
    print("y=%.2f: R(x;y) at x-y = 0.02,0.05,0.1,0.2,0.4,0.8,1.5,2.5,4,6,9:" % y, ["%.3f" % (K2(x, y) / J(x)) for x in xs])
print("J(x) at x=0.05,0.1,0.3,0.6,1,2:", ["%.4f" % J(x) for x in (0.05, 0.1, 0.3, 0.6, 1, 2)])
