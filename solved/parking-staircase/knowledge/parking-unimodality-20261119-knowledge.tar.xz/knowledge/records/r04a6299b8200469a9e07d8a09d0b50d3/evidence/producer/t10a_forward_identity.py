# Test 10a (tied to the argument): exact check of the single-tree (forward) identity used in Lemma R:
#   for k <= n' <= 2k-1:   b_{n',k-1} = sum_{t=k}^{n'} C(n',t) * [ (k-1) b_{t-1,k-1} + A_{t-1,k-1} ] * p_{n'-t},   p_0 = 1.
# (The first run of t10 reported violations because pf.T.p(0) evaluates 1**(-1) as the float 1.0; here p is exact.)
from math import comb
from pf import T
tab = T(160)
def p(i): return 1 if i == 0 else (i+1)**(i-1)
bad = 0; cnt = 0
for k in [3, 4, 6, 9, 14, 22, 35, 50, 79]:
    for n1 in range(k, 2*k):
        rhs = sum(comb(n1, t)*((k-1)*tab.b(t-1, k-1) + tab.A(t-1, k-1))*p(n1-t) for t in range(k, n1+1))
        cnt += 1
        if rhs != tab.b(n1, k-1): bad += 1
    # one row beyond the single-tree range, to see that the range is sharp (expected: inequality there)
    n1 = 2*k
    rhs = sum(comb(n1, t)*((k-1)*tab.b(t-1, k-1) + tab.A(t-1, k-1))*p(n1-t) for t in range(k, n1+1))
    print("k=%d: n'=2k: rhs - b = %s" % (k, "0" if rhs == tab.b(n1, k-1) else ("positive" if rhs > tab.b(n1, k-1) else "negative")))
print("forward identity on k<=n'<=2k-1: %d cases, %d violations" % (cnt, bad))
