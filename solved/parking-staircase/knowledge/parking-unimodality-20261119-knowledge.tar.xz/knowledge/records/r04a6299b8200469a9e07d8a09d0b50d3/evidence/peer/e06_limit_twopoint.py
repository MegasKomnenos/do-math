# e06 (peer): reach constants of the kernel-only two-point conditions in the formal scaling limit.
#   Pi(x;sig) = Pi_imm(x) - L^{-1}[Qst_sig](x-sig)   (sig<x),   Qst_sig(l) = int_0^inf e^{-(Phi(l+t)-Phi(l))} 2 t e^{-t sig}/(l+t) dt
#   2K(x,y)   = L^{-1}[Q_y](x-y),                               Q_y(l)   = int_0^inf e^{-(Phi(l+t)-Phi(l))} 2 t e^{-t y} dt
#   (KK)(xq,x):  2K(x,y)/J(x) >= 2K(xq,y)/J(xq)  for all 0<=y<xq
#   (cKK)(xq,x): exists lam>=0 with Pi(x;sig) >= lam Pi(xq;sig) for all sig in [0,x]   (Pi(.;0) = -J)
import numpy as np, sys, time
from limf import *
out = open(sys.argv[1], 'w') if len(sys.argv) > 1 else sys.stdout
def P(*a):
    print(*a, file=out); out.flush()
x0 = 0.59963
imm_hat = eta_profile_hat(lambda mu: 1.0 / mu)
_c = {}
def J(x):
    if ('J', x) not in _c: _c[('J', x)] = talbot(Jhat, x)
    return _c[('J', x)]
def Pimm(x):
    if ('I', x) not in _c: _c[('I', x)] = talbot(imm_hat, x)
    return _c[('I', x)]
def Pi(x, sig):
    if sig <= 0: return -J(x)
    if sig >= x - 1e-6: return Pimm(x)
    key = ('P', x, sig)
    if key not in _c:
        _c[key] = Pimm(x) - talbot(lambda l: Tint(l, lambda mu, l0: 2 * (mu - l0) * np.exp(-(mu - l0) * sig) / mu), x - sig)
    return _c[key]
def K2(x, y):
    key = ('K', x, y)
    if key not in _c:
        _c[key] = talbot(lambda l: Tint(l, lambda mu, l0: 2 * (mu - l0) * np.exp(-(mu - l0) * y)), x - y)
    return _c[key]

t0 = time.time()
# sanity: Pi(x;sig) increasing in sig, and d/dsig Pi = 2K
x = 2.0
P("sanity x=2: Pi(2;sig) for sig=0,0.5,1,1.5,2(imm): %s" % ["%.5f" % Pi(x, s) for s in (0, 0.5, 1.0, 1.5, 2.0)])
P("   finite difference (Pi(2;1.01)-Pi(2;0.99))/0.02 = %.5f ; 2K(2,1) = %.5f   [%.1fs]" % ((Pi(x, 1.01) - Pi(x, 0.99)) / 0.02, K2(x, 1.0), time.time() - t0))

def cKK_ok(xq, x, nq=30):
    sig = np.concatenate([np.linspace(0, xq, nq + 1), np.linspace(xq, x, max(8, int(6 * (x - xq)) + 2))[1:]])
    a = np.array([Pi(xq, s) for s in sig]); b = np.array([Pi(x, s) for s in sig])
    if np.any((a >= 0) & (b < 0)): return False
    H = np.min(b[a > 0] / a[a > 0]) if np.any(a > 0) else np.inf
    L = np.max(b[a < 0] / a[a < 0]) if np.any(a < 0) else -np.inf
    return max(L, 0) <= H
def KK_ok(xq, x, ny=24):
    ys = np.linspace(0.0, xq, ny, endpoint=False)
    r = np.array([K2(x, y) / J(x) - K2(xq, y) / J(xq) for y in ys])
    return bool(np.all(r >= 0))
def end(test, xq, hi, step=0.5):
    x = xq + step; last = xq
    while x <= hi + 1e-9:
        if not test(xq, round(x, 6)):
            a, b = last, x
            for _ in range(5):
                mid = round(0.5 * (a + b), 6)
                if test(xq, mid): a = mid
                else: b = mid
            return 0.5 * (a + b)
        last = x; x += step
    return None
P("ends of the two-point conditions (reference point xq; None = holds up to 12)")
for xq in (x0, 0.70, 0.85, 0.975):
    e1 = end(KK_ok, xq, 12.0)
    P("   xq = %.3f : X_KK = %s   [%.0fs]" % (xq, e1 if e1 is None else "%.2f" % e1, time.time() - t0))
    e2 = end(cKK_ok, xq, 12.0)
    P("   xq = %.3f : X_cKK = %s   [%.0fs]" % (xq, e2 if e2 is None else "%.2f" % e2, time.time() - t0))
P("done")
