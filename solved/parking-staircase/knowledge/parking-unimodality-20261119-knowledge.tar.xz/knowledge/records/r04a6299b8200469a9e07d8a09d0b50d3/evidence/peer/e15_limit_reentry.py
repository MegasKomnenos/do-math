# e15 (peer): limit model -- re-entry point x_re(y_D) of the column of the true limit profile psi cut at y_D:
#   eta_cut(x) = -beta_0(x) + int_0^{y_D} e_inf(x,y) psi(y) dy ,  e_inf(x,y) = L^{-1}[ T[2(mu-l) exp(-(mu-l) y)] ](x-y).
# x_re = first zero after the crossing (bisection between brackets found by a coarse scan).  Double precision, fixed Talbot.
import numpy as np, sys, time
from limf import *
def K2(x, y):
    return talbot(lambda l: Tint(l, lambda mu, l0: 2 * (mu - l0) * np.exp(-(mu - l0) * y)), x - y)
gx, gw = np.polynomial.legendre.leggauss(12)
_psi = {}
def psi(y):
    if y not in _psi: _psi[y] = talbot(Shat, y)
    return _psi[y]
def ratio(x, yD, parts):
    edges = np.linspace(0, yD, parts + 1); tot = 0.0
    for i in range(parts):
        a, b = edges[i], edges[i + 1]
        u = 0.5 * (b - a) * gx + 0.5 * (b + a)
        tot += 0.5 * (b - a) * sum(w * K2(x, y) * psi(y) for y, w in zip(u, gw))
    J = talbot(Jhat, x)
    return (-J + tot) / J
for yD, lo, hi in [(0.55, 2.0, 3.5), (0.59963, 2.5, 4.5), (0.7, 3.5, 6.0), (0.8, 4.5, 8.0), (1.0, 6.5, 11.0), (1.2, 9.0, 15.0), (1.5, 14.0, 23.0)]:
    t0 = time.time()
    parts = 4 if yD < 0.9 else 6
    flo, fhi = ratio(lo, yD, parts), ratio(hi, yD, parts)
    assert flo > 0 > fhi, (yD, flo, fhi)
    for _ in range(11):
        mid = 0.5 * (lo + hi)
        if ratio(mid, yD, parts) > 0: lo = mid
        else: hi = mid
    print("y_D=%.4f: x_re = %.2f   (bracket values %.4f, %.4f)   [%.0fs]" % (yD, 0.5 * (lo + hi), flo, fhi, time.time() - t0), flush=True)
