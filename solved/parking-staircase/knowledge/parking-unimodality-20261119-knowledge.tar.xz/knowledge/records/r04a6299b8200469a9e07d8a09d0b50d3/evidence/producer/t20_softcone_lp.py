# Test 20 (tied to the argument).  Are the thresholds of the published far-row arguments intrinsic to the facts they use?
# Model: first-layer kernel equations (S1),(S2) of r9faef2b6 driven by a level-(k-2) survival profile Psi (Psi_{k-1}=1):
#     U_n   = sum_{s=k-1}^{n-1} tau_{n-s} (k U_s + omega_s Psi_s)/(s+1),            U_{k-1} = 0,
#     eta_n = sum_{s=k}^{n-1} tau_{n-s} ((k+1) eta_s + 2 U_s)/(s+1) - tau_{n-k+1} omega_{k-1}/k       (k <= n <= 2k-1),
# written without tilt: tau_g = g^(g-1)/g!, omega_s = c_s, U_n = b_{n,k-1}/n!, eta_n = d_{n,k}/n!.
# "Soft cone": profiles for which every soft fact used by the published arguments holds for the derived column:
#   (M)   Psi nonincreasing with values in [0,1]                            [stochastic monotonicity in the size]
#   (R)   Pr(M_j<=k-1), Pr(M_j<=k) nonincreasing in j and <= 1               [same, for the two derived levels]
#   (D)   Pr(M_{j+1}<=k-1) >= Pr(M_j<=k-2),  Pr(M_{j+1}<=k) >= Pr(M_j<=k-1)   [M_{j+1} <= M_j + 1 stochastically]
#   (Dg)  b_{j,k} >= gamma_k * j * b_{j-1,k-1}                               [diagonal lower bound, r6af349eb c10]
#   (Pat) eta_j <= 0 for k<=j<q,  eta_j >= 0 for q<=j<=n                      [sign pattern assumed by the persistence theorems]
# LP (exact rationals): minimize eta_{n+1} over the cone.  A negative optimum is an explicit profile satisfying all of the
# above whose step turns negative at row n+1; a nonnegative optimum means the listed facts alone force eta_{n+1} >= 0.
import sys
from fractions import Fraction as Fr
from math import factorial
from lp_exact import simplex
from pf import T

tab = T(160)


def cay(i):
    return Fr((i + 1) ** (i - 1), factorial(i)) if i > 0 else Fr(1)


def columns(k, top):
    tau = [Fr(0)] + [Fr(g ** (g - 1), factorial(g)) for g in range(1, top + 2)]
    om = [cay(s) for s in range(0, top + 1)]
    res = {}
    for S in range(k - 1, top + 1):          # S = top: the profile never dies inside the first layer
        U = {k - 1: Fr(0)}
        eta = {}
        for n in range(k, top + 1):
            U[n] = sum(tau[n - s] * (k * U[s] + (om[s] if s <= S else 0)) / (s + 1) for s in range(k - 1, n))
            eta[n] = sum(tau[n - s] * ((k + 1) * eta[s] + 2 * U[s]) / (s + 1) for s in range(k, n)) - tau[n - k + 1] * om[k - 1] / k
        res[S] = (U, eta)
    return res, om


def build(k, q, n, res, om, use):
    Ss = sorted(S for S in res if S <= n + 1)   # death times; S >= n+1 are equivalent for all rows and facts up to n+1
    gam = Fr(k + 1, k) ** (k - 2)
    rows = []

    def psi(S, j):
        return Fr(1) if j <= S else Fr(0)

    def F1(S, j):  # Pr(M_j <= k-1) for the step profile S
        U, eta = res[S]
        return psi(S, j) + (U[j] / om[j] if j >= k else Fr(0))

    def F2(S, j):  # Pr(M_j <= k)
        U, eta = res[S]
        return F1(S, j) + ((U[j] + eta[j]) / om[j] if j >= k else Fr(0))

    if 'Pat' in use:
        for j in range(k, q):
            rows.append([-res[S][1][j] for S in Ss])
        for j in range(q, n + 1):
            rows.append([res[S][1][j] for S in Ss])
    if 'Dg' in use:
        for j in range(k + 1, n + 2):
            rows.append([(res[S][0][j] + res[S][1][j]) - gam * (res[S][0][j - 1] if j - 1 >= k else Fr(0)) for S in Ss])
    if 'R' in use:
        for j in range(k - 1, n + 1):
            rows.append([F1(S, j) - F1(S, j + 1) for S in Ss])
            rows.append([F2(S, j) - F2(S, j + 1) for S in Ss])
        for j in range(k, n + 2):
            rows.append([1 - F2(S, j) for S in Ss])
    if 'D' in use:
        for j in range(k - 1, n + 1):
            rows.append([F1(S, j + 1) - psi(S, j) for S in Ss])
            rows.append([F2(S, j + 1) - F1(S, j) for S in Ss])
    obj = [res[S][1][n + 1] for S in Ss]
    return Ss, rows, obj


def solve(k, q, n, res, om, use):
    Ss, rows, obj = build(k, q, n, res, om, use)
    nv = len(Ss)
    m = len(rows)
    A = [[Fr(1)] * nv + [Fr(0)] * m]
    for i, r in enumerate(rows):
        A.append(list(r) + [Fr(-1) if j == i else Fr(0) for j in range(m)])
    b = [Fr(1)] + [Fr(0)] * m
    c = list(obj) + [Fr(0)] * m
    st, x, val = simplex(A, b, c)
    return st, (dict(zip(Ss, x[:nv])) if x else None), val, Ss


if __name__ == '__main__':
    k = int(sys.argv[1])
    top = 2 * k - 1
    res, om = columns(k, top)
    q0 = next(nn for nn in range(k + 1, 2 * k + 1) if tab.d(nn, k) > 0)
    Ss_all = sorted(res)
    Psi_true = {s: Fr(tab.A(s, k - 2), tab.p(s)) for s in range(k - 1, top + 1)}
    mu_true = {}
    for S in Ss_all:
        mu_true[S] = Psi_true[S] - Psi_true[S + 1] if S < Ss_all[-1] else Psi_true[S]
    etat = {j: sum(mu_true[S] * res[S][1][j] for S in Ss_all) for j in range(k, top + 1)}
    ok = all(etat[j] == Fr(tab.d(j, k), factorial(j)) for j in range(k, top + 1))
    print("k=%d q0=%d ; kernel form with the true profile reproduces the true steps: %s" % (k, q0, ok))
    use_all = ('Pat', 'Dg', 'R', 'D')
    args = sys.argv[2:]
    light = 'light' in args      # 'light': only the two small fact sets (the full set is slow in exact arithmetic)
    for n in [int(a) for a in args if a != 'light']:
        for use in ([('Pat',), ('Pat', 'Dg')] if light else [('Pat',), ('Pat', 'Dg'), use_all]):
            print(" n=%d (deficit %d) facts=%s:" % (n, n - k, '+'.join(use)))
            for q in range(q0 - 2, n + 1):
                if not (k + 1 <= q <= n):
                    continue
                st, mu, val, Ss = solve(k, q, n, res, om, use)
                if st == 'infeasible':
                    print("     q=%d: cone with this pattern is empty" % q)
                    continue
                rel = float(val / abs(res[k - 1][1][n + 1]))
                word = "NEGATIVE" if val < 0 else "nonnegative"
                supp = [(S, round(float(v), 4)) for S, v in sorted(mu.items()) if v != 0]
                print("     q=%d: min eta_{n+1} is %s (relative to the impulse response: %.3e); support of the optimal profile: %s" % (q, word, rel, supp))
