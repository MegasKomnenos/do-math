# Test 18 (tied to the argument).  Exact witnesses that, beyond the window, the first-layer kernel equations plus
# monotonicity of the survival profile do NOT force sign persistence of the step.
# Kernel form (r9faef2b6 Theorem 15, written without tilt: tau_g = g^(g-1)/g!, omega_s = c_s = (s+1)^(s-1)/s!):
#     U_n   = sum_{s=k-1}^{n-1} tau_{n-s} (k U_s + omega_s Psi_s)/(s+1),            U_{k-1} = 0,
#     eta_n = sum_{s=k}^{n-1} tau_{n-s} ((k+1) eta_s + 2 U_s)/(s+1) - tau_{n-k+1} omega_{k-1}/k        (k <= n <= 2k-1),
# with Psi_{k-1} = 1.  For the true column Psi_s = Pr(M_s <= k-2), which is nonincreasing in s.
# A "two-death profile" is  Psi_s = 1 (s<=S1),  p (S1 < s <= S2),  0 (s > S2)   with 0 < p < 1:  nonincreasing, values in [0,1].
# For each k: search rows n and (S1,S2,p) such that the column built from this profile has eta_n = 0 (p chosen so) and eta_{n+1} < 0,
# and print the sign sequence of the whole column eta_k..eta_{2k-1} of the witness.
from fractions import Fraction as Fr
from math import factorial
def column(k, Psi):
    N = 2*k-1
    tau = [Fr(0)] + [Fr(g**(g-1), factorial(g)) for g in range(1, N+2)]
    om = [Fr((s+1)**(s-1), factorial(s)) if s > 0 else Fr(1) for s in range(0, N+1)]
    U = {k-1: Fr(0)}; eta = {}
    for n in range(k, N+1):
        U[n] = sum(tau[n-s]*(k*U[s] + om[s]*Psi(s))/(s+1) for s in range(k-1, n))
        eta[n] = sum(tau[n-s]*((k+1)*eta[s] + 2*U[s])/(s+1) for s in range(k, n)) - tau[n-k+1]*om[k-1]/k
    return U, eta
def step_profile(S):      # level k-2 survives up to size S, then dies
    return lambda s: Fr(1) if s <= S else Fr(0)
for k in [16, 24, 36]:
    N = 2*k-1
    Pi = {}
    for S in range(k-1, N):
        _, eta = column(k, step_profile(S))
        Pi[S] = eta
    found = None
    for n in range(k+2, N):
        best = None
        for S1 in range(k-1, n):
            a1, b1 = Pi[S1][n], Pi[S1][n+1]
            if a1 >= 0: continue
            for S2 in range(S1+1, n):
                a2, b2 = Pi[S2][n], Pi[S2][n+1]
                if a2 <= 0: continue
                p = -a1/(a2-a1)                     # eta_n of the mixture = 0
                val = p*b2 + (1-p)*b1               # eta_{n+1} of the mixture
                if val < 0 and (best is None or val/abs(b1) < best[0]):
                    best = (val/abs(b1), S1, S2, p, val)
        if best is not None:
            found = (n, best); break
    if found is None:
        print("k=%d: no two-death witness on rows k+2..2k-2" % k); continue
    n, (rel, S1, S2, p, val) = found
    Psi = lambda s, S1=S1, S2=S2, p=p: Fr(1) if s <= S1 else (p if s <= S2 else Fr(0))
    U, eta = column(k, Psi)
    signs = ''.join('+' if eta[j] > 0 else ('-' if eta[j] < 0 else '0') for j in range(k, N+1))
    print("k=%d: first row with a witness: n=%d (deficit %d).  S1=%d, S2=%d, p=%.6f" % (k, n, n-k, S1, S2, float(p)))
    print("   eta_n = %s (exact), eta_{n+1} = %.3e < 0 ; cells U_j > 0 for all j: %s" % (eta[n], float(eta[n+1]), all(U[j] > 0 for j in range(k, N+1))))
    print("   sign sequence of eta_k..eta_{2k-1}: %s" % signs)
