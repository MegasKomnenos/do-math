# e12 (peer): the other published conditional hypothesis (KM_k) of r9faef2b6 (Corollary 19) at larger columns.
# Comparison column: Psi^flat from Lemma 17 (U') of r9faef2b6 (hazard upper bound with the lower Euler inequality):
#   L=k-2, K_n(g) = Bor(g) Bor(n+1-g)/(Bor(n+1) (n+1-g)),  theta_i = (i+1+L)/(2(i+1)),  nu_L = 0,
#   nu_n = sum_{g=1}^{n-L} K_n(g) [(L+1) nu_{n-g} + 1] * Psi^flat_{max(n-g,L+1)}/Psi^flat_n,   abar_n = theta_n nu_n,
#   Psi^flat_{L+1} = 1,  Psi^flat_{n+1} = (1-abar_n) Psi^flat_n.
# (KM_k): Mem^flat_n >= 0 for n_1(k) < n < N_0.   Published values to reproduce (observation 3): k=349: eta^flat>0 from 391,
#   Mem^flat>=0 from 396, Mem^flat/Mem = 0.951 at n_1+1, 0.963 at N_0-1; k=148: 174, 179, 0.953, 0.945.
import numpy as np, sys, time
from math import lgamma, log, exp, ceil
from kern import true_profile, bor
from e09_twopoint_large_k import kernel_matrices
def psi_flat(k, top, B):
    L = k - 2
    nu = np.zeros(top + 2)
    Pf = np.zeros(top + 2); Pf[:L + 2] = 1.0          # Psi^flat_s = 1 for s <= L+1 = k-1
    ok_to = top
    for n in range(L + 1, top + 1):
        g = np.arange(1, n - L + 1)
        K = B[g] * B[n + 1 - g] / (B[n + 1] * (n + 1 - g))
        src = (L + 1) * nu[n - g] + 1.0
        nu[n] = np.dot(K, src * Pf[np.maximum(n - g, L + 1)]) / Pf[n]
        ab = (n + 1 + L) / (2.0 * (n + 1)) * nu[n]
        if ab >= 1:
            ok_to = n - 1; break
        Pf[n + 1] = (1 - ab) * Pf[n]
    return Pf, ok_to
def run(k, xmax):
    t0 = time.time()
    sc = k ** (2 / 3)
    top = min(2 * k - 1, k + int(xmax * sc))
    W = top - k + 1
    B = bor(top + 3)
    Psi = true_profile(k, top)
    Pf, ok_to = psi_flat(k, top, B)
    E, J = kernel_matrices(k, top)
    step = -J + E @ Psi[k - 1:top]
    stepf = -J + E @ Pf[k - 1:top]
    q0 = k + next(i for i in range(1, W) if step[i] > 0)
    eps = np.zeros(W + 1)
    for m in range(1, W + 1):
        eps[m] = exp(-m + ((m - 1) * log(m - 1) if m > 1 else 0.0) - lgamma(m + 1))
    Eps = np.zeros((W, W))
    for i in range(1, W):
        Eps[i, :i] = eps[i - np.arange(0, i)]
    Mem = Eps @ step; Memf = Eps @ stepf
    n1 = k + next(i for i in range(1, W) if Mem[i] >= 0)
    N0 = min(q0 + ceil(2.2 * sc) + 1, top + 1)
    qf = k + next((i for i in range(1, W) if np.all(stepf[i:] > 0)), W)
    n1f = k + next((i for i in range(1, W) if np.all(Memf[i:] >= 0)), W)
    km = bool(np.all(Memf[n1 + 1 - k:N0 - k] >= 0))
    assert np.all(Pf[k - 1:top] <= Psi[k - 1:top] * (1 + 1e-9))
    print("k=%d q0=%d n_1=%d N_0-1=%d scan to %d (x=%.2f): eta^flat>0 from row %d to scan end; Mem^flat>=0 from row %d to scan end; "
          "Mem^flat/Mem at n_1+1: %.3f, at N_0-1: %.3f; eta^flat/eta at scan end: %.3f; Psi^flat/Psi at N_0-1: %.3f => (KM_k) %s  [%.0fs]" % (
        k, q0, n1, N0 - 1, top, (top - k) / sc, qf, n1f, Memf[n1 + 1 - k] / Mem[n1 + 1 - k], Memf[N0 - 1 - k] / Mem[N0 - 1 - k],
        stepf[-1] / step[-1], Pf[N0 - 1] / Psi[N0 - 1], "HOLDS" if km else "FAILS", time.time() - t0), flush=True)
if __name__ == '__main__':
    for a in sys.argv[1:]:
        k, xmax = a.split(':')
        run(int(k), float(xmax))
