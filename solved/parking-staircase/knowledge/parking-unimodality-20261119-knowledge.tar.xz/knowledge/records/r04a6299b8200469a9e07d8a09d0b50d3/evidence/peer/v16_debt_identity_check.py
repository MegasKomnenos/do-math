# v16 (peer): check of the published debt identity in the form used in section 8.4 (critical tilt):
#   S_J := U_J - h_J = sum_{M=k}^{J} DC(M) - [u_{J+1}(k+1) - u_J(k)],      DC(M) = u_{M+1}(k+1) - 2 u_M(k) + u_{M-1}(k-1),   u_N(c) = omega_N F_N(c-1),
# and of the regrouping   sum_{M=k}^{J} DC(M) = T1 + T3 + (omega_{J+1} - omega_J) F_J(k-1).
# Double precision; quantities from e26_first_order_tie.data (all divided by omega_k).
import numpy as np, sys
from kern import true_profile
import e26_first_order_tie as E
for k in [int(a) for a in sys.argv[1:]]:
    top = 2 * k - 1
    d = E.data(k, top)
    om, m1, m0 = d["om"], d["m1"], d["m0"]
    Psi = true_profile(k, top)
    Fk2 = Psi.copy(); Fk1 = Psi + m1; Fk = Fk1 + m0          # F_N(k-2), F_N(k-1), F_N(k) for N >= k
    u_km1 = lambda N: om[N] * (Fk2[N] if N >= k else 1.0)   # u_N(k-1)
    u_k = lambda N: om[N] * (Fk1[N] if N >= k else 1.0)     # u_N(k)
    u_kp1 = lambda N: om[N] * (Fk[N] if N >= k else 1.0)    # u_N(k+1)
    DC = {M: u_kp1(M + 1) - 2 * u_k(M) + u_km1(M - 1) for M in range(k, top)}
    worst = 0.0; neg = 0
    for J in range(k + 1, top - 1):
        S, T1, T2, T3 = E.terms(d, k, J)
        acc = sum(DC[M] for M in range(k, J + 1))
        e1 = abs(S - (acc - (u_kp1(J + 1) - u_k(J))))
        e2 = abs(acc - (T1 + T3 + (om[J + 1] - om[J]) * Fk1[J]))
        worst = max(worst, e1, e2)
    neg = sum(1 for M in range(k, top) if DC[M] < -1e-15)
    print("k=%d: largest deviation of the two identities over k+1 <= J <= 2k-3: %.1e ; rows k <= M <= 2k-2 with DC(M) < 0: %d" % (k, worst, neg))
