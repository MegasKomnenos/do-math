# v18 (peer): checks for Proposition 8.1 (cell minus debt at the critical tilt is positive on bulk rows for large k).  Not proof steps.
# Notation at the critical tilt x = x_k:  u_N(c) = x^N A_{N,c-1}/N!,  DC(N) = u_{N+1}(k+1) - 2 u_N(k) + u_{N-1}(k-1)   (forest / kernel-mass form),
#   n_c(t) = min(t,c) A_{t-1,c-1} x^t/t!,  DC^T(t) = n_{k+1}(t+1) - 2 n_k(t) + n_{k-1}(t-1)                                (tree form),
#   C(X) = sum_{t=k+1}^{X-1} DC^T(t),   E_M(c) = u_{M+1}(c+1) - u_M(c),   S_J = U_J - h_J.
# (A) exact (rational):  DC^T(N+1) = x [ (k/(N+1)) DC(N) + ((N-k+1)/(N+1)) ( u_{N+1}(k+1)/(N+2) - u_{N-1}(k-1)/N ) ],   k <= N <= 2k-2.
# (B) double precision:  S_J = sum_{N=k}^{J} DC(N) - E_J(k)  >=  C(J+2)/x - Q_J - E_J(k),
#       Q_J = sum_{N=k}^{J} ((N-k+1)/(k(N+2))) [E_N(k) + E_{N-1}(k-1)],
#     and the sizes of the pieces in units k^{-4/3} omega_k (main term) and k^{-3/2} omega_k (corrections).
# (C) the moment bounds used in the proof:  sum (M-k+1)^2 m_M(k) <= 280 k^{3/2},  sum (M-k+1) F_M(k-1) <= 37 k^{3/2},  and m_J(k) k^{3/2} on bulk rows.
# Usage:  python v18_conversion_and_bounds.py exact 4 6 9 12      |      python v18_conversion_and_bounds.py float 100 400 1600
import sys
from fractions import Fraction as F
from math import factorial

def exact(k):
    import ptab
    T = ptab.Tab(2 * k)
    x = F(k, k + 1) ** (k - 1)
    u = lambda N, c: x ** N * T.a(N, c - 1) / factorial(N)
    nt = lambda c, t: min(t, c) * T.a(t - 1, c - 1) * x ** t / factorial(t)
    worst = F(0); neg = 0
    for N in range(k, 2 * k - 1):
        DC = u(N + 1, k + 1) - 2 * u(N, k) + u(N - 1, k - 1)
        DCT = nt(k + 1, N + 2) - 2 * nt(k, N + 1) + nt(k - 1, N)
        rhs = x * (F(k, N + 1) * DC + F(N - k + 1, N + 1) * (u(N + 1, k + 1) / (N + 2) - u(N - 1, k - 1) / N))
        worst = max(worst, abs(DCT - rhs))
        if DCT < 0 or DC < 0: neg += 1
    print("k=%d: largest |DC^T(N+1) - right side of (A)| over k <= N <= 2k-2: %s ; rows with DC or DC^T negative: %d" % (k, worst, neg))

def flt(k):
    import numpy as np
    from kern import true_profile
    import e26_first_order_tie as E
    top = 2 * k - 1
    d = E.data(k, top)
    om, m1, m0 = d["om"], d["m1"], d["m0"]                 # omega_N/omega_k, m_N(k-1), m_N(k)
    Psi = true_profile(k, top)
    Fk2 = Psi.copy(); Fk1 = Psi + m1; Fk = Fk1 + m0          # F_N(k-2), F_N(k-1), F_N(k), valid for N >= k
    one = lambda arr, N: arr[N] if N >= k else 1.0
    u_km1 = lambda N: om[N] * one(Fk2, N)
    u_k = lambda N: om[N] * one(Fk1, N)
    u_kp1 = lambda N: om[N] * one(Fk, N)
    x = (k / (k + 1.0)) ** (k - 1)
    DC = {N: u_kp1(N + 1) - 2 * u_k(N) + u_km1(N - 1) for N in range(k, top)}
    # tree form through n_c(t) = (x c/t) u_{t-1}(c)  (t >= c); values divided by omega_k as well
    DCT = {N + 1: x * ((k + 1) * u_kp1(N + 1) / (N + 2) - 2 * k * u_k(N) / (N + 1) + (k - 1) * u_km1(N - 1) / N) for N in range(k, top)}
    E_k = {N: u_kp1(N + 1) - u_k(N) for N in range(k, top)}                 # E_N(k)
    E_km1 = {N: u_k(N + 1) - u_km1(N) for N in range(k - 1, top - 1)}        # E_N(k-1)
    print("k=%d   (units: main terms in k^(-4/3) omega_k, corrections in k^(-3/2) omega_k)" % k)
    print("     J      S_J      sum DC     C(J+2)/x     Q_J[k^-3/2]   E_J(k)[k^-3/2]   lower bound C/x-Q-E    m_J(k) k^(3/2)")
    for J in (k + (k + 1) // 2, k + (3 * k) // 4, 2 * k - 3):
        S = d["U"][J] + np.sum(d["eta"][k:J + 1])
        acc = sum(DC[N] for N in range(k, J + 1))
        C = sum(DCT[t] for t in range(k + 1, J + 2))
        Q = sum((N - k + 1) / (k * (N + 2.0)) * (E_k[N] + E_km1[N - 1]) for N in range(k, J + 1))
        a, b = k ** (4 / 3), k ** 1.5
        print("  %6d  %8.4f  %8.4f   %8.4f     %8.3f      %8.3f          %8.4f            %8.3f" % (
            J, a * S, a * acc, a * C / x, b * Q, b * E_k[J], a * (C / x - Q - E_k[J]), m0[J] * b))
        assert S >= C / x - Q - E_k[J] - 1e-12
    J = 2 * k - 2
    mom2 = sum((M - k + 1) ** 2 * m0[M] for M in range(k, J + 1)) / k ** 1.5
    mom1 = sum((M - k + 1) * Fk1[M] for M in range(k, J + 1)) / k ** 1.5
    print("  moments: sum (M-k+1)^2 m_M(k) / k^(3/2) = %.2f (bound 280) ; sum (M-k+1) F_M(k-1) / k^(3/2) = %.2f (bound 37) ; max omega_M/omega_k = %.3f (bound 5)" % (mom2, mom1, max(om[k:top + 1])))

if __name__ == "__main__":
    mode = sys.argv[1]
    for a in sys.argv[2:]:
        (exact if mode == "exact" else flt)(int(a))
