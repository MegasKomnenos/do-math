# e20 (peer): the smallest cut size S_min(k) without the lower search bound q0-2 used in e02 (small and middle columns),
# to compare with J_min(k) of e19.  S_min = least S such that the true profile cut at S gives a column that is >= 0 on all rows q0..2k-1.
import numpy as np, sys
from kern import column, true_profile, bor
for k in [int(a) for a in sys.argv[1:]]:
    top = 2 * k - 1
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    def ok(S):
        P = Psi.copy(); P[S + 1:] = 0.0
        c2, s2, J2 = column(k, P, top, B)
        return all(s2[n] >= 0 for n in range(q0, top + 1))
    lo, hi = k - 1, top
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if ok(mid): hi = mid
        else: lo = mid
    # monotonicity in S holds because the removed response is nonnegative
    print("k=%d q0=%d: S_min = %d = q0%+d = k+%d (%.3f k^(2/3))" % (k, q0, hi, hi - q0, hi - k, (hi - k) / k ** (2 / 3)), flush=True)
