# Test 23 (tied to the argument).  Dual certificates for the LP of test 20 (exact rationals).
# Primal:  v* = min  sum_S mu_S c(S)   s.t.  sum mu = 1,  sum_S mu_S G_i(S) >= 0 (all facts i),  mu >= 0,
#          c(S) = eta_{n+1} of the step profile S,  G_i(S) = value of fact i on the step profile S.
# A certificate is a vector y >= 0 with   c(S) - sum_i y_i G_i(S) >= v*   for every death time S; then for every
# profile in the cone  eta_{n+1} >= v* + sum_i y_i (fact i) >= v*.  Among all certificates we take one of minimal total
# weight (LP: min sum y) to see WHICH facts carry the argument.
import sys
from fractions import Fraction as Fr
from lp_exact import simplex
from t20_softcone_lp import columns, build, solve, tab


def labels(k, q, n, use):
    lab = []
    if 'Pat' in use:
        lab += ["-eta_%d" % j for j in range(k, q)] + ["+eta_%d" % j for j in range(q, n + 1)]
    if 'Dg' in use:
        lab += ["Dg_%d" % j for j in range(k + 1, n + 2)]
    return lab


def certificate(k, q, n, res, om, use):
    st, mu, vstar, Ss = solve(k, q, n, res, om, use)
    if st == 'infeasible':
        return None
    Ss, rows, obj = build(k, q, n, res, om, use)
    m = len(rows)
    nS = len(Ss)
    # constraints:  sum_i y_i G_i(S) + slack_S = c(S) - v*      (one per S),  y, slack >= 0 ;  minimize sum y
    # scale each fact row by its max abs value to keep the multipliers comparable (y is reported for the scaled facts)
    sc = [max(abs(v) for v in r) or Fr(1) for r in rows]
    A = []
    b = []
    for a, S in enumerate(Ss):
        rhs = obj[a] - vstar
        row = [rows[i][a] / sc[i] for i in range(m)] + [Fr(1) if j == a else Fr(0) for j in range(nS)]
        if rhs < 0:
            row = [-v for v in row]
            rhs = -rhs
        A.append(row)
        b.append(rhs)
    c = [Fr(1)] * m + [Fr(0)] * nS
    st2, x, val = simplex(A, b, c)
    if x is None:
        return (vstar, None)
    y = x[:m]
    lab = labels(k, q, n, use)
    supp = [(lab[i], float(y[i])) for i in range(m) if y[i] != 0]
    # verify the certificate exactly
    ok = all(obj[a] - sum(y[i] * rows[i][a] / sc[i] for i in range(m)) >= vstar for a in range(nS))
    return (vstar, supp, ok)


if __name__ == '__main__':
    k = int(sys.argv[1])
    top = 2 * k - 1
    res, om = columns(k, top)
    q0 = next(nn for nn in range(k + 1, 2 * k + 1) if tab.d(nn, k) > 0)
    for spec in sys.argv[2:]:
        n, q = [int(v) for v in spec.split(':')]
        for use in [('Pat',), ('Pat', 'Dg')]:
            out = certificate(k, q, n, res, om, use)
            if out is None:
                print("k=%d n=%d q=%d facts=%s: cone empty" % (k, n, q, '+'.join(use)))
                continue
            vstar, supp, ok = out
            rel = float(vstar / abs(res[k - 1][1][n + 1]))
            print("k=%d (q0=%d) n=%d q=%d facts=%s: v*/|impulse| = %.4e ; certificate verified exactly: %s" % (k, q0, n, q, '+'.join(use), rel, ok))
            print("     facts carrying weight (scaled multipliers): %s" % supp)
