# Test 15 (tied to the argument).  In the first layer every column quantity is a linear functional of the tilted
# survival masses of ONE level:  d_s := z^s A_{s,k-2}/s! = w_s * Psi_s,  Psi_s = Pr(M_s <= k-2)  (Psi_s = 1 for s<=k-1).
# Forward (single-tree) recursions, valid for j <= 2k-1 (U) and j <= 2k+1 (V):
#    U_j = sum_{t=k}^{j}   w_{j-t} (z/t) [ k U_{t-1} + d_{t-1} ]                       (U_{k-1}=0)
#    V_j = sum_{t=k+1}^{j} w_{j-t} (z/t) [ (k+1) V_{t-1} + U_{t-1} + d_{t-1} ]          (V_k=0)
# Hence  C(J) := sum_{j=k+1}^{J} V_j - sum_{j=k}^{J-1} U_j  =  sum_{s=k-1}^{J-1} c_J(s) * d_s   with Cayley-only coefficients c_J(s).
# (D1') at row n=J+1 is C(J) >= 0.  Since Psi is nonincreasing in s (stochastic monotonicity) with Psi_{k-1}=1,
# C(J) >= 0 would follow from  "all partial sums  Pi_J(S) := sum_{s=k-1}^{S} c_J(s) w_s  are >= 0"  (Abel summation).
# Tested: (1) the recursions and the linear representation against the exact tables;  (2) the sign pattern of c_J(s);
#         (3) the partial sums Pi_J(S)  at the deficit-adapted tilt.
from pf import T
from fractions import Fraction as Fr
from math import factorial
t = T(160)
def g(m):
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
def cay(i): return Fr((i+1)**(i-1), factorial(i)) if i > 0 else Fr(1)
def solve(k, J, z, d):
    # d: dict s->value for s=k-1..J-1 ; returns U (k..J), V (k+1..J)
    w = [z**i*cay(i) for i in range(0, J+1)]
    U = {k-1: Fr(0)}; V = {k: Fr(0)}
    for j in range(k, J+1):
        U[j] = sum(w[j-tt]*(z/tt)*(k*U[tt-1] + d.get(tt-1, 0)) for tt in range(k, j+1))
    for j in range(k+1, J+1):
        V[j] = sum(w[j-tt]*(z/tt)*((k+1)*V[tt-1] + U[tt-1] + d.get(tt-1, 0)) for tt in range(k+1, j+1))
    return U, V, w
def Cfun(k, J, U, V):
    return sum(V[j] for j in range(k+1, J+1)) - sum(U[j] for j in range(k, J))
for k in [8, 13, 20, 30]:
    xdag = Fr(k, k+1)**(k-2)
    Ri = max(r for r in range(1, k) if all(xdag*g(m) <= 1 for m in range(1, r)))
    print("==== k=%d  R_i=%d" % (k, Ri))
    for r in sorted(set([Ri+1, (Ri+k)//2, k-1])):
        n = k+r; J = n-1
        z = min(xdag, 1/g(r-1))
        dtrue = {s: z**s*Fr(t.A(s, k-2), factorial(s)) for s in range(k-1, J)}
        U, V, w = solve(k, J, z, dtrue)
        # (1) check against tables
        ok = all(U[j] == z**j*Fr(t.b(j,k-1), factorial(j)) for j in range(k, J+1)) and all(V[j] == z**j*Fr(t.b(j,k), factorial(j)) for j in range(k+1, J+1))
        Ctrue = Cfun(k, J, U, V)
        # coefficients
        coef = {}
        for s in range(k-1, J):
            Us, Vs, _ = solve(k, J, z, {s: Fr(1)})
            coef[s] = Cfun(k, J, Us, Vs)
        rep = sum(coef[s]*dtrue[s] for s in coef)
        signs = ''.join('+' if coef[s] > 0 else ('-' if coef[s] < 0 else '0') for s in sorted(coef))
        ps = []; acc = Fr(0)
        for s in sorted(coef):
            acc += coef[s]*w[s]; ps.append(acc)
        neg = [k-1+i for i, v in enumerate(ps) if v < 0]
        print(" r=%d J=%d: recursions match tables: %s ; linear rep exact: %s ; C(J)/U_J = %.4f" % (r, J, ok, rep == Ctrue, float(Ctrue/U[J])))
        print("    sign pattern of c_J(s), s=k-1..J-1: %s" % signs)
        print("    partial sums Pi_J(S)<0 at S in: %s ; min Pi/U_J = %.4f ; final Pi_J(J-1)/U_J = %.4f" % (
            (neg if len(neg) <= 10 else "%d values %d..%d" % (len(neg), neg[0], neg[-1])), float(min(ps)/U[J]), float(ps[-1]/U[J])))
