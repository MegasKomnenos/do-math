# v04 (peer): independent exact re-verification of the producer's counterexample N4 (b).
# Profile at k=100: Psi_99 = 1, Psi_s = 937/1000 (100<=s<=117), Psi_s = 0 (s>=118).
# The step is computed from the Green-function (forest) form of green.py, not from the nested recursion (S1),(S2).
from fractions import Fraction as Fr
from math import comb
import sys, time

def pw(a, e):
    if e >= 0:
        return a ** e
    assert a == 1
    return 1

def H_table_int(c, j, Nmax):
    H = {j: j ** (j - 1)}
    for N in range(j + 1, Nmax + 1):
        H[N] = c * sum(comb(N - 1, s) * pw(N - s, N - s - 2) * H[s] for s in range(j, N))
    return H

def G_int(H, j, n):
    return sum(comb(n, s) * pw(n + 1 - s, n - s - 1) * H[s] for s in range(j, n + 1))

k, top = 100, 199
prof = {99: Fr(1)}
for s in range(100, 118):
    prof[s] = Fr(937, 1000)
t0 = time.time()
step = {n: Fr(0) for n in range(k, top + 1)}
imp = {}
for j in range(k, 119):
    Hk = H_table_int(k, j, top)
    Hk1 = H_table_int(k + 1, j, top)
    for n in range(j, top + 1):
        gk = G_int(Hk, j, n); gk1 = G_int(Hk1, j, n)
        step[n] += 2 * prof[j - 1] * Fr(gk1 - gk, j)
        if j == k:
            imp[n] = Fr(gk1, k)
            step[n] -= imp[n]
neg1 = all(step[n] < 0 for n in range(100, 121))
pos = all(step[n] > 0 for n in range(121, 199))
neg2 = step[199] < 0
print("steps < 0 on rows 100..120: %s ; > 0 on rows 121..198: %s ; < 0 at row 199: %s" % (neg1, pos, neg2))
print("step/impulse at rows 120,121,122,150,180,197,198,199:",
      [round(float(step[n] / imp[n]), 6) for n in (120, 121, 122, 150, 180, 197, 198, 199)])
print("time %.1fs" % (time.time() - t0))
