# e08 (peer): is the long reach of the coefficientwise condition (KK)(q0,.) at k<=349 a lattice effect?
# R_n(s) = e_n(s)/J_n for single sources s = q0-g (g rows before the crossing row), as a function of the row n.
# In the continuum limit R decreases from the start for sources close to the reference row (e07); here: finite k.
import numpy as np, sys
from kern import column, true_profile, bor
def run(k, span):
    top = min(2 * k - 1, k + span)
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    sc = k ** (2 / 3)
    print("k=%d q0=%d (x=%.3f)" % (k, q0, (q0 - k) / sc))
    for g in (2, 3, 5, 10, 20, 40, 80):
        s = q0 - g
        if s < k - 1: continue
        P = np.zeros(top + 1); P[s] = 1.0
        c2, s2, J2 = column(k, P, top, B)
        e = s2 + J              # e_n(s) (the delta profile has no other source; step = -J + e)
        R = e / np.where(J > 0, J, 1)
        base = R[q0]
        # first row n>q0 with R_n < R_q0
        bad = [n for n in range(q0 + 1, top + 1) if R[n] < base * (1 - 1e-12)]
        mx = max(range(q0, top + 1), key=lambda n: R[n])
        print("   source s=q0-%d: R at rows q0, q0+1, q0+2, q0+5, q0+20: %s ; max at q0+%d ; first row with R<R_q0: %s" % (
            g, ["%.5f" % R[q0 + d] for d in (0, 1, 2, 5, 20)], mx - q0,
            "none in range" if not bad else "q0+%d (deficit %.2f k^(2/3))" % (bad[0] - q0, (bad[0] - k) / sc)), flush=True)
for a in sys.argv[1:]:
    k, span = a.split(':')
    run(int(k), int(span))
