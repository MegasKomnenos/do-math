# Test 8 (tied to the argument).  Same criterion as t07 (Proposition SC at the row-adapted tilt x_n = min(x_dag, 1/g(n-k-1)),
# and Theorem P (ii) at x_dag for r<=R_i), on a few larger columns inside the range of the paper's item C5 (rows n<=300),
# to compare with the published first-order criterion (AM°) of r6c69820c on the same columns.
# Exact integer columns by the last-car recursion (column-wise); ratios evaluated with 50-digit floats.
from math import comb, factorial
from mpmath import mp, mpf
mp.dps = 50
def colA(l, nmax):
    # A_{n,l} for n=0..nmax
    A = [1]
    for n in range(1, nmax+1):
        if l >= n-1:
            A.append((n+1)**(n-1)); continue
        s = 0
        for j in range(n):
            s += comb(n-1, j)*min(j+1, l+1)*A[j]*A[n-1-j]
        A.append(s)
    return A
def g(m):
    if m == 1: return mpf(1)/2
    return mpf(m)/(m+1)*(mpf(m)/(m-1))**(m-1)
def eps(m): return mpf((m-1)**(m-1))/factorial(m) if m > 1 else mpf(1)
def run(k):
    nmax = 2*k
    Ak, Ak1, Ak2 = colA(k, nmax), colA(k-1, nmax), colA(k-2, nmax)
    bk  = lambda n: Ak[n]-Ak1[n]       # b_{n,k}
    bk1 = lambda n: Ak1[n]-Ak2[n]      # b_{n,k-1}
    d = lambda n: bk(n)-bk1(n)
    q0 = next(n for n in range(k+1, 2*k+1) if d(n) > 0)
    single = all(d(n) <= 0 for n in range(k, q0)) and all(d(n) > 0 for n in range(q0, 2*k))
    xdag = (mpf(k)/(k+1))**(k-2); gam = 1/xdag
    Ri = max(r for r in range(1, k) if all(xdag*g(m) <= 1 for m in range(1, r)))
    u = {j: mpf(bk1(j))/factorial(j) for j in range(k, 2*k)}
    v = {j: mpf(bk(j))/factorial(j) for j in range(k, 2*k)}
    out = []
    for n in range(q0+1, 2*k):
        r = n-k; tt = n-q0
        x = min(xdag, 1/g(r-1)) if r >= 2 else xdag
        P_ok = (r <= Ri) and (n*xdag**r*eps(r) <= q0*xdag**(q0-k)*eps(q0-k))
        Tn = sum(x**(j-(n-1))*u[j] for j in range(k, n-1))/u[n-1]
        hU = sum(x**(j-(n-1))*(u[j]-v[j]) for j in range(k, n))/u[n-1]
        BU = 1 + (1-x*gam)*Tn
        allowed = 2/(n*x**tt*eps(tt+1))
        out.append((n, r, P_ok, float(hU), float(BU), float(allowed), float(allowed/BU)))
    return q0, Ri, single, out
for k in [79, 90, 100, 120, 148]:
    q0, Ri, single, out = run(k)
    unc = [(n, r, round(m,3)) for (n, r, P_ok, hU, BU, al, m) in out if not (P_ok or m >= 1)]
    notP = [(m, n, r, hU, BU, al) for (n, r, P_ok, hU, BU, al, m) in out if not P_ok]
    w = min(notP)
    far = [(m, n, r, hU, BU, al) for (n, r, P_ok, hU, BU, al, m) in out if r > Ri]
    wf = min(far)
    print("k=%d q0=%d Ri=%d single-crossing(first layer)=%s uncovered=%s" % (k, q0, Ri, single, unc))
    print("   worst margin among rows not covered by P: %.3f at n=%d r=%d (h/U=%.3f B'/U=%.3f allowed=%.3f)" % w)
    print("   worst margin among rows r>Ri:             %.3f at n=%d r=%d (h/U=%.3f B'/U=%.3f allowed=%.3f)" % wf)
    print("   max h/U over rows after crossing at adapted tilt: %.3f" % max(o[3] for o in out))
