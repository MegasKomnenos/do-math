# v13 (peer): ratio (J_n - e_n(k-1))/J_n, i.e. the factor between the producer's normalizer -Pi_n(k-1) and the impulse
# response J_n, at the rows where the producer's tables quote minima.  Cayley numbers only (double precision).
import numpy as np
from kern import column, bor
for k, rows in [(12, (21, 23)), (16, (28, 31)), (24, (37, 44, 47)), (36, (53, 71)), (50, (69, 99)), (79, (113, 157)), (100, (121, 150, 199)), (148, (295,))]:
    top = 2 * k - 1
    B = bor(top + 2)
    P = np.zeros(top + 2); P[k - 1] = 1.0          # step profile dying at S = k-1
    cell, step, J = column(k, P, top, B)
    print("k=%d: (J_n - e_n(k-1))/J_n at rows %s = %s" % (k, rows, ", ".join("%.4f" % (-step[n] / J[n]) for n in rows)))
