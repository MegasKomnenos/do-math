# v03 (peer): the Green-function form of the first-layer cell and step reproduces the exact table.
from fractions import Fraction as Fr
from ptab import Tab, p
from green import column_from_profile
t = Tab(30)
allok = True
cnt = 0
for k in range(2, 16):
    top = min(2 * k - 1, 30)
    Psi = lambda s, k=k: Fr(t.a(s, k - 2), p(s))
    b, d = column_from_profile(k, Psi, top)
    ok = all(b[n] == t.b(n, k - 1) and d[n] == t.d(n, k) for n in range(k, top + 1))
    cnt += top - k + 1
    allok &= ok
    print("k=%d rows %d..%d: %s" % (k, k, top, ok))
print("all %d cells: %s" % (cnt, allok))
# outside the first layer the formula must fail (range is sharp): n = 2k
for k in (3, 4, 5, 6):
    Psi = lambda s, k=k: Fr(t.a(s, k - 2), p(s))
    b, d = column_from_profile(k, Psi, 2 * k)
    print("k=%d, n=2k: cell equal %s, step equal %s" % (k, b[2 * k] == t.b(2 * k, k - 1), d[2 * k] == t.d(2 * k, k)))
