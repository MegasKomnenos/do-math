# e02 (peer; tied to the reading "facts about rows up to a cut have a finite reach in window units").
# True profile cut at size S (Psi_s kept for s<=S, set to 0 after).  reach(S) = last row n<=2k-1 such that the cut column
# is >= 0 on all rows q0..n  (the cut column agrees with the true one on rows n<=S+1).
# Also: S_min = least cut for which the cut column is >=0 on the whole first layer after the crossing.
import numpy as np, sys, time
from kern import column, true_profile, bor
ks = [int(a) for a in sys.argv[1:]] or [50, 100, 148, 400, 1600, 6400]
for k in ks:
    t0 = time.time()
    top = 2 * k - 1
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    sc = k ** (2.0 / 3.0)
    def reach(S):
        P = Psi.copy(); P[S + 1:] = 0.0
        c2, s2, J2 = column(k, P, top, B)
        bad = [n for n in range(q0, top + 1) if s2[n] < 0]
        return (bad[0] - 1) if bad else None
    out = []
    for S in (q0 - 2, q0, q0 + (q0 - k) // 2, q0 + (q0 - k), q0 + 2 * (q0 - k)):
        r = reach(S)
        out.append("S=%d (y=%.2f): %s" % (S, (S - k) / sc, "all rows" if r is None else "reach row %d (x=%.2f)" % (r, (r - k) / sc)))
    # bisection for S_min
    lo, hi = q0 - 2, top
    if reach(lo) is None:
        smin = lo
    else:
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if reach(mid) is None:
                hi = mid
            else:
                lo = mid
        smin = hi
    print("k=%d q0=%d x_end=%.2f | %s | S_min=%d: S_min-k=%d = %.2f k^(2/3) = %.3f k^(4/5) = %.3f k   [%.1fs]" % (
        k, q0, (top - k) / sc, " ; ".join(out), smin, smin - k, (smin - k) / sc, (smin - k) / k ** 0.8, (smin - k) / k, time.time() - t0))
