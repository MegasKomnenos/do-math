# e24 (peer): the explorer's observation N1 at larger columns.
# Two-point argument of Theorem P (r6af349eb) read at the deficit-adapted tilt z_r = min{1/gamma_k, 1/g(r-1)}, r = n-k,
# with reference row q = q0(k).  For every row q0 < n <= 2k-1 we test
#   (D1')  h_{n-1} <= U_{n-1}                         (debt at most one cell)
#   (D2')  sum_{j=q}^{n-1} (V_j - U_{j-1}) >= 0
#   (ii)   n kappa_r <= q kappa_{r_q}                 (closing condition of the two-point comparison),   kappa_m = z^m eps_m
#   (iii)  kappa_{t+1} <= 2 z / n,  t = n-q           (the other closing condition)
# U_j = z^j b_{j,k-1}/j!,  V_j = z^j b_{j,k}/j!,  h_J = -sum_{i=k}^{J} (V_i - U_i),  eps_m = (m-1)^{m-1}/m!,  g(m) = eps_{m+1}/eps_m.
# Columns from kern.py (double precision; true profile by the one-level recursion).  Explorer's exact values to reproduce:
#   k=36: max h/U = 0.884 (row 50), junction 0.875, (ii) never fails;  k=79: max 0.933 (row 99), junction 0.718;  k=24: (ii) fails on rows 37..45.
import numpy as np, sys, time
from math import lgamma, log, exp
from kern import column, true_profile, bor

def logeps(m):
    return ((m - 1) * log(m - 1) if m > 1 else 0.0) - lgamma(m + 1)

def run(k):
    t0 = time.time()
    top = 2 * k - 1
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)          # cell_n = e^{-(n+1)} b_{n,k-1}/n!,  step_n = e^{-(n+1)} d_{n,k}/n!
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    lgam = (k - 2) * log(1 + 1.0 / k)               # log gamma_k
    idx = np.arange(k, top + 1)
    bad = {"D1": [], "D2": [], "ii": [], "iii": [], "both": []}
    worst = (-1.0, None); junction = None; margin_ii = (-1e9, None)
    worst_far = (-9.0, None); first_far = None      # rows where the adapted tilt is below the diagonal tilt (r > R_i): (D1') not implied by Dg
    for n in range(q0 + 1, top + 1):
        r = n - k; rq = q0 - k; t = n - q0
        lg = logeps(r) - logeps(r - 1) if r >= 2 else -1e9      # log g(r-1)
        lz = -max(lgam, lg)                          # log z_r
        lez = lz + 1.0                               # log(e z)
        w = np.exp(lez * (idx - k))                  # (e z)^{j-k}, j = k..top
        U = w * cell[k:top + 1]
        V = w * (cell[k:top + 1] + step[k:top + 1])
        h = -np.cumsum(V - U)                        # h_j, j = k..top
        i = n - 1 - k
        ratio = h[i] / U[i]
        d1 = ratio <= 1.0
        d2 = np.sum(V[q0 - k:n - k] - U[q0 - 1 - k:n - 1 - k]) >= 0
        lk = lambda m: m * lz + logeps(m)
        c_ii = log(n) + lk(r) - (log(q0) + lk(rq))   # <= 0 means (ii) holds
        c_iii = lk(t + 1) - (log(2.0) + lz - log(n)) # <= 0 means (iii) holds
        if not d1: bad["D1"].append(n)
        if not d2: bad["D2"].append(n)
        if c_ii > 0: bad["ii"].append(n)
        if c_iii > 0: bad["iii"].append(n)
        if c_ii > 0 and c_iii > 0: bad["both"].append(n)
        if ratio > worst[0]: worst = (ratio, n)
        if lg > lgam:
            if first_far is None: first_far = n
            if ratio > worst_far[0]: worst_far = (ratio, n)
        if c_ii > margin_ii[0]: margin_ii = (c_ii, n)
        if n == top: junction = ratio
    rng = lambda L: "none" if not L else ("%d..%d (%d rows)" % (L[0], L[-1], len(L)))
    print("k=%d q0=%d: (D1') fails: %s ; (D2') fails: %s ; (ii) fails: %s ; (iii) fails: %s ; neither (ii) nor (iii): %s" % (
        k, q0, rng(bad["D1"]), rng(bad["D2"]), rng(bad["ii"]), rng(bad["iii"]), rng(bad["both"])))
    print("      max h/U = %.3f at row %d (x=%.2f) ; at the junction row 2k-1: %.3f ; largest log-violation of (ii): %.3f at row %d   [%.0fs]" % (
        worst[0], worst[1], (worst[1] - k) / k ** (2 / 3), junction, margin_ii[0], margin_ii[1], time.time() - t0), flush=True)
    if first_far is not None:
        print("      rows with r > R_i (adapted tilt below the diagonal tilt) start at row %d (r = %d = %.3f k); max h/U over them = %.3f at row %d" % (
            first_far, first_far - k, (first_far - k) / k, worst_far[0], worst_far[1]), flush=True)

if __name__ == "__main__":
    for a in sys.argv[1:]:
        run(int(a))
