# Test 4 (tied to the argument): the "soft chain" for rows beyond the window of Theorem P.
#  critical tilt x=x_k=(k/(k+1))^(k-1).  U_j = x^j b_{j,k-1}/j!, V_j = x^j b_{j,k}/j!, eta_j=V_j-U_j, h_j=-sum_{i<=j} eta_i.
#  (S1) Dg+Abel:  h_{n-1} <= U_{n-1} + (1/(k+1)) sum_{i=k}^{n-2} U_i            (bound B_n)
#  (S2) 0th-order max principle (Lemma A(b), kernel nonincreasing at x<=x*_k): eta_n >= (2x/n) U_{n-1} - kappa_w h_{n-1},
#       w = n - delta_n >= t+1 := n-q0+1  (use the weakest w=t+1)
#  Question: is kappa_{t+1} * B_n <= (2x/n) U_{n-1} on the rows n > k+R_s(k)+1 (beyond the window)?
#  Report: true ratio h/U, bound ratio B/U, allowed ratio (2x/n)/kappa_{t+1}; and the same with the sharp w=n-delta_n.
from pf import T
from fractions import Fraction as Fr
from math import factorial
t = T(160)
def g(m):
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
def Rs(k):
    xd = Fr(k, k+1)**(k-2)
    R = 0
    for r in range(1, k-1):
        if (k+r+1)*xd*g(r) <= k+r: R = r
        else: break
    return R
def eps(m): return Fr((m-1)**(m-1), factorial(m)) if m>1 else Fr(1)
def run(k, show):
    x = Fr(k, k+1)**(k-1)
    U = {j: x**j*Fr(t.b(j,k-1), factorial(j)) for j in range(k, 2*k)}
    V = {j: x**j*Fr(t.b(j,k), factorial(j)) for j in range(k, 2*k)}
    h = {}; s = Fr(0)
    for j in range(k, 2*k):
        s += U[j]-V[j]; h[j] = s
    q0 = next(n for n in range(k+1, 2*k+1) if t.d(n,k) > 0)
    kap = lambda m: x**m*eps(m)
    worst = None
    rows = []
    for n in range(k+Rs(k)+2, 2*k):
        tt = n - q0
        B = U[n-1] + Fr(1,k+1)*sum(U[i] for i in range(k, n-1))
        allowed_weak = (2*x/n)/kap(tt+1)
        dn = next(j for j in range(k, n) if h[j] >= h[n-1])
        allowed_sharp = (2*x/n)/kap(n-dn)
        rows.append((n, n-k, float(h[n-1]/U[n-1]), float(B/U[n-1]), float(allowed_weak), float(allowed_sharp)))
    return q0, rows
print("k q0 | n r | h/U  B/U  allowed(w=t+1)  allowed(w=n-delta)")
for k in [20, 30, 40, 50, 60, 70, 79]:
    q0, rows = run(k, True)
    # print first, worst-margin, and last rows
    if not rows: 
        print(k, q0, "no rows beyond window"); continue
    worst = min(rows, key=lambda r: r[4]/r[3])
    for tag, r in (("first", rows[0]), ("worst", worst), ("last", rows[-1])):
        print(k, q0, tag, "| %d %d | %.3f %.3f %.3f %.3f | margin(weak)=%.2f margin(sharp)=%.2f" % (r[0], r[1], r[2], r[3], r[4], r[5], r[4]/r[3], r[5]/r[3]))
