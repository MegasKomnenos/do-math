# e21 (peer): finite-k check of the limit of the resolved partial sums (explorer report 5.1; peer exposition 6.7).
#   mu_t = [2 b_{t-1,k-1} - (t-1-k) d_{t-1,k}]/t! ,  iota = k^{k-2}/k! ,   M~_n(x) = x^k iota - sum_{t=k+1}^{n} x^t mu_t .
# Printed: M~_n(x)/(x^k iota) at the tilts  1/e,  the critical tilt x_k=(k/(k+1))^{k-1},  the row-adapted tilt x_n=(1+1/r)^{-r} (r=n-k),
# at rows n = k + z k^{2/3}; limits: M_0(z)=psi - z f for fixed tilts e^{-1}(1+O(1/k)),  M_{1/2}(z) for the adapted tilt.
import numpy as np, sys
from math import exp, log
from kern import column, true_profile, bor
M0 = {1.0: 0.2336, 1.5: 0.0215, 2.0: -0.0659, 2.5: -0.0912, 3.0: -0.0910, 4.0: -0.0718, 5.0: -0.0532}
Mh = {1.0: 0.0026, 1.5: -0.2305, 2.0: -0.2942, 2.5: -0.2827, 3.0: -0.2472, 4.0: -0.1753, 5.0: -0.1248}
zs = (1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0)
print("limit  M_0(z):  ", "  ".join("%7.4f" % M0[z] for z in zs))
print("limit  M_1/2(z):", "  ".join("%7.4f" % Mh[z] for z in zs))
for k in [int(a) for a in sys.argv[1:]]:
    top = 2 * k - 1; sc = k ** (2 / 3)
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)
    iota = B[k] / k                                   # e^{-k} k^{k-2}/k!
    t = np.arange(k + 1, top + 1)
    emu = (2 * cell[t - 1] - (t - 1 - k) * step[t - 1]) / t      # e^{-t} mu_t
    lc_crit = 1.0 + (k - 1) * log(k / (k + 1.0))      # log(e x_k)
    def Mt(n, lc):
        m = t <= n
        return 1.0 - np.sum(np.exp(lc * (t[m] - k)) * emu[m]) / iota
    rows = [k + int(round(z * sc)) for z in zs if k + int(round(z * sc)) <= top]
    print("k=%d  (first row with mu_t<0: %s)" % (k, next((int(tt) for tt, v in zip(t, emu) if v < 0), None)))
    print("   tilt 1/e     :", "  ".join("%7.4f" % Mt(n, 0.0) for n in rows))
    print("   critical tilt:", "  ".join("%7.4f" % Mt(n, lc_crit) for n in rows))
    print("   adapted tilt :", "  ".join("%7.4f" % Mt(n, 1.0 - (n - k) * log(1 + 1.0 / (n - k))) for n in rows))
