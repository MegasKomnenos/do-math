# Test 32 (tied to the argument).  How far beyond the crossing must the diagonal lower bound be imposed to force
# positivity at the LAST row of the first layer?   Fact set: Pat (crossing at the true row q0, pattern through row 2k-2)
# plus (Dg)_j only for k+1 <= j <= Jmax.   Float LP of test 21 (same solver); the returned profile is re-evaluated:
# pattern and the imposed (Dg)_j are recomputed from the mixture, and the objective is recomputed directly.
import sys
import numpy as np
from t21_softcone_lp_float import columns, simplex_float


def solve_band(k, q, n, U, E, gam_t, Jmax):
    Ss = list(range(k - 1, n + 2))
    rows = []
    for j in range(k, q):
        rows.append([-E[S][j] for S in Ss])
    for j in range(q, n + 1):
        rows.append([E[S][j] for S in Ss])
    for j in range(k + 1, Jmax + 1):
        rows.append([(U[S][j] + E[S][j]) - gam_t * (U[S][j - 1] if j - 1 >= k else 0.0) for S in Ss])
    G = np.array(rows, dtype=float)
    sc = np.abs(G).max(axis=1)
    sc[sc == 0] = 1.0
    G = G / sc[:, None]
    obj = np.array([E[S][n + 1] for S in Ss])
    scale = abs(E[k - 1][n + 1])
    nv, m = len(Ss), G.shape[0]
    A = np.vstack([np.concatenate([np.ones(nv), np.zeros(m)]), np.hstack([G, -np.eye(m)])])
    b = np.concatenate([[1.0], np.zeros(m)])
    c = np.concatenate([obj / scale, np.zeros(m)])
    st, xx, val = simplex_float(A, b, c)
    if xx is None:
        return None
    mu = np.clip(xx[:nv], 0, None)
    mu = mu / mu.sum()
    return float(obj @ mu) / scale, float((G @ mu).min()), [(S, round(float(w), 3)) for S, w in zip(Ss, mu) if w > 1e-3]


if __name__ == '__main__':
    k, q0 = int(sys.argv[1]), int(sys.argv[2])
    U, E, om, gam_t, top = columns(k)
    n = top - 1
    cd = q0 - k
    print("k=%d q0=%d (crossing deficit %d), target row %d; facts: Pat with crossing q0 + (Dg)_j for j <= Jmax" % (k, q0, cd, top))
    for Jmax in [k, q0 - 2, q0, q0 + 1, q0 + 2, q0 + 3, q0 + 5, q0 + 8, q0 + cd // 2, q0 + cd, q0 + 2 * cd, top]:
        out = solve_band(k, q0, n, U, E, gam_t, Jmax)
        if out is None:
            print("   Jmax=%d (q0%+d): cone empty" % (Jmax, Jmax - q0))
            continue
        val, slack, supp = out
        tail = supp if len(supp) <= 6 else supp[:3] + ['...'] + supp[-3:]
        print("   Jmax=%d (q0%+d): min eta_{2k-1}/|impulse| = %+.4f (worst slack %.0e); death times of the optimal profile: %s" % (Jmax, Jmax - q0, val, slack, tail))
