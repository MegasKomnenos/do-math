# Test 9 (tied to the argument).  Data-free form of Proposition SC.
# In the first layer the cells of column k-1 are (tree cells)*(free forests):  U_j = sum_{t=k}^{j} a_t w_{j-t},  a_t>=0, w_i = x^i c_i.
# Hence  T_n := sum_{j=k}^{n-2} U_j / U_{n-1}  <=  Theta(x,r) := max_{1<=L<=r-1} W_{L-1}/w_L,   W_L = w_0+...+w_L,
# and Proposition SC is implied by the pure Cayley-number inequality
#   (DF)   n * x^t * eps_{t+1} * [ 1 + (1 - x*gamma_k) * Theta(x,r) ]  <=  2,     x = min(x_dag, 1/g(r-1)),  t = n - q.
# Question: for which rows r = n-k of the first layer does (DF) hold, given (an upper bound for) the crossing row q?
# No parking-function table is used; only k, r, q.  Double precision in log space (margins are not delicate).
import numpy as np
from math import lgamma, log, floor, ceil, exp
NM = 45000
Ls = np.arange(0, NM, dtype=np.float64)
lgc = (Ls-1)*np.log(Ls+1) - np.array([lgamma(i+1) for i in range(NM)])      # log c_L
def lg_eps(m): return ((m-1)*log(m-1) if m > 1 else 0.0) - lgamma(m+1)
def lg_g(m):
    if m == 1: return log(0.5)
    return log(m/(m+1)) + (m-1)*log(m/(m-1))
def margins(k, q, rows=None):
    lxdag = (k-2)*log(k/(k+1)); lgam = -lxdag
    Ri = 1
    for r in range(2, k):
        if lxdag + lg_g(r-1) <= 0: Ri = r
        else: break
    res = {}
    for n in (rows if rows is not None else range(q+1, 2*k)):
        r = n-k; t = n-q
        if r < 2 or t < 1: continue
        lx = min(lxdag, -lg_g(r-1))
        lw = Ls[:r]*lx + lgc[:r]
        w = np.exp(lw); W = np.cumsum(w)
        Theta = float(np.max(W[:-1]/w[1:]))
        lhs = n*exp(t*lx + lg_eps(t+1))*(1 + (1-exp(lx+lgam))*Theta)
        res[r] = 2/lhs
    return Ri, res
def report(k, q, label, step=1):
    rows = None if step == 1 else sorted(set(list(range(q+1, 2*k, step)) + list(range(2*k-60, 2*k))))
    Ri, res = margins(k, q, rows)
    rs = sorted(res)
    far = [r for r in rs if r > Ri]
    okfar = [r for r in far if res[r] >= 1]
    r_last = None
    for r in far:
        if res[r] >= 1: r_last = r
        else: break
    first_bad_after = next((r for r in far if res[r] < 1), None)
    print("k=%d q=%d (%s) Ri=%d (%.3fk): (DF) holds for all tested r in (Ri, %s]  i.e. up to r/k=%.4f, k-r=%s; first failing r=%s; margin at r=Ri+1: %s" % (
        k, q, label, Ri, Ri/k, r_last, (r_last or 0)/k, (k-r_last) if r_last else None, first_bad_after,
        ("%.3f" % res[Ri+1]) if (Ri+1) in res else "n/a"))
    for a in (0.7, 0.8, 0.9, 0.95):
        r = int(a*k)
        if r in res: print("      r=%d (%.2fk): margin %.3f" % (r, a, res[r]))
true_q = {30:42, 40:54, 50:65, 60:77, 79:98, 100:121, 120:143, 148:174}
for k in sorted(true_q): report(k, true_q[k], "true q0")
print()
for k in [148, 200, 264]:
    report(k, k + int(ceil(k**(2/3))) + 1, "q<=k+k^(2/3)+1")
for k in [265, 400, 1000, 1728, 5000, 20000]:
    report(k, k + int(floor((11*k/5)**(2/3))) + 1, "q<=k+(11k/5)^(2/3)+1", step=(1 if k <= 2000 else 7))
