# Test 7 (tied to the argument).  Proposition SC: for 0<x<=x_dag with x*g(r-1)<=1 (kernel nonincreasing on lags 1..r),
#   n * x^t * eps_{t+1} * [ U_{n-1} + (1-x*gamma_k) * sum_{j=k}^{n-2} U_j ] <= 2 U_{n-1}   ==>  d_{n,k} > 0
# (given single crossing at q0 up to row n-1).  The tilt x is free below min(x_dag, 1/g(r-1)).
# Question: for small columns, does a better choice of x cover the rows that the choice x = min(x_dag,1/g(r-1)) left open?
# Also record, for every column tested, which rows after the crossing are covered by
#   P: Theorem P (ii) at x_dag (needs r<=R_i),  S: Proposition SC at the best admissible x on a grid.
from pf import T
from fractions import Fraction as Fr
from math import factorial
t = T(160)
def g(m):
    if m == 1: return Fr(1,2)
    return Fr(m, m+1)*Fr(m, m-1)**(m-1)
def eps(m): return Fr((m-1)**(m-1), factorial(m)) if m>1 else Fr(1)
def run(k, grid=24):
    xdag = Fr(k, k+1)**(k-2)
    xcrit = Fr(k, k+1)**(k-1)
    gam = 1/xdag
    Ri = max(r for r in range(1, k) if all(xdag*g(m) <= 1 for m in range(1, r)))
    q0 = next(n for n in range(k+1, 2*k+1) if t.d(n,k) > 0)
    u = {j: Fr(t.b(j,k-1), factorial(j)) for j in range(k, 2*k)}
    res = []
    for n in range(q0+1, 2*k):
        r = n-k; tt = n-q0
        xmax = min(xdag, 1/g(r-1)) if r >= 2 else xdag
        # (ii) at x_dag
        P_ok = (r <= Ri) and (n*xdag**r*eps(r) <= q0*xdag**(q0-k)*eps(q0-k))
        best = None
        xlo = Fr(1,3)
        for i in range(grid+1):
            x = xmax - (xmax-xlo)*Fr(i, grid)
            Tn = sum(x**(j-(n-1))*u[j] for j in range(k, n-1))/u[n-1]
            lhs = n*x**tt*eps(tt+1)*(1 + (1-x*gam)*Tn)
            m = 2/lhs
            if best is None or m > best[0]: best = (m, x)
        res.append((n, r, P_ok, float(best[0]), float(best[1]/xcrit)))
    return q0, Ri, res
print("k q0 Ri | rows after crossing not covered by P or S | min over rows of max(P, S-margin) summary")
for k in list(range(12, 31, 2)) + [33, 36, 40, 50, 60, 79]:
    q0, Ri, res = run(k)
    unc = [(n, r, round(m,3)) for (n, r, P_ok, m, xr) in res if not (P_ok or m >= 1)]
    sOnly = [(m, n, r, xr) for (n, r, P_ok, m, xr) in res if not P_ok]
    worst = min(sOnly) if sOnly else None
    print(k, q0, Ri, "| uncovered:", unc, "| worst S-margin among rows not covered by P:", (round(worst[0],3), "n=%d r=%d x/x_crit=%.4f" % (worst[1], worst[2], worst[3])) if worst else None)
