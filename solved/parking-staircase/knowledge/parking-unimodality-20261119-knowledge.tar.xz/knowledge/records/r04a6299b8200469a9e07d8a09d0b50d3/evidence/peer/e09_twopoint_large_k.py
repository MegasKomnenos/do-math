# e09 (peer): ends of (KK)(q0,.) and (cKK)(q0,.) for larger columns (vectorized kernel matrices; Cayley numbers only,
# plus the true crossing row q0 from the one-level recursion).  Tied to the question whether the reach of the two
# kernel-only conditions converges to a positive multiple of k^{2/3} beyond the crossing (limit model: (KK) does not).
import numpy as np, sys, time
from kern import column, true_profile, bor
def kernel_matrices(k, top):
    W = top - k + 1
    B = bor(top + 2)
    sizes = np.arange(k, top + 1, dtype=float)
    out = {}
    for c in (k, k + 1):
        H = np.zeros((W, W))                       # H[N-k, j-k] = hh_c(N;j)
        for i in range(W):
            N = k + i
            if i > 0:
                wts = B[N - np.arange(k, N)] * (c / sizes[:i])      # s = k..N-1
                H[i, :i] = wts @ H[:i, :i]
            H[i, i] = N * B[N]
        Hs = H / sizes[:, None]
        G = np.zeros((W, W))                       # G[n-k, j-k] = gg_c(n;j)
        for i in range(W):
            n = k + i
            G[i, :i + 1] = B[n + 1 - np.arange(k, n + 1)] @ Hs[:i + 1, :i + 1]
        out[c] = G
    E = 2 * (out[k + 1] - out[k]) / sizes[None, :]          # E[n-k, j-k] = E_n(j) = e_n(j-1)
    J = out[k + 1][:, 0] / k
    return E, J
def run(k, xmax):
    t0 = time.time()
    sc = k ** (2 / 3)
    top = min(2 * k - 1, k + int(xmax * sc))
    Psi = true_profile(k, top)
    E, J = kernel_matrices(k, top)
    step = -J + E @ Psi[k - 1:top]                 # step_n = -J_n + sum_j E_n(j) Psi_{j-1}
    q0 = k + next(i for i in range(1, top - k + 1) if step[i] > 0)
    Pi = -J[:, None] + np.cumsum(E, axis=1)        # Pi[n-k, S-(k-1)] = Pi_n(S)
    iq = q0 - k
    def KK(n):
        i = n - k
        return bool(np.all(E[i, :iq] * J[iq] >= E[iq, :iq] * J[i] * (1 - 1e-11)))
    def cKK(n):
        i = n - k
        a = Pi[iq, np.minimum(np.arange(0, i), iq - 1)]     # S = k-1..n-2 ; Pi_q(S) frozen for S>=q-2
        b = Pi[i, :i]
        if np.any((a >= 0) & (b < 0)): return False
        H = np.min(b[a > 0] / a[a > 0]) if np.any(a > 0) else np.inf
        L = np.max(b[a < 0] / a[a < 0]) if np.any(a < 0) else -np.inf
        return max(L, 0) <= H * (1 + 1e-11)
    def last(test):
        n = q0 + 1
        while n <= top and test(n): n += 1
        return n - 1
    eK, eC = last(KK), last(cKK)
    fmt = lambda e: ("row %d = %.2f k^(2/3)" % (e, (e - k) / sc)) + (" (scan end)" if e == top else "")
    print("k=%d q0=%d (x=%.3f) scan to row %d (x=%.2f): (KK)(q0,.) holds through %s ; (cKK)(q0,.) through %s   [%.0fs]" % (
        k, q0, (q0 - k) / sc, top, (top - k) / sc, fmt(eK), fmt(eC), time.time() - t0), flush=True)
if __name__ == '__main__':
    for a in sys.argv[1:]:
        k, xmax = a.split(':')
        run(int(k), float(xmax))
