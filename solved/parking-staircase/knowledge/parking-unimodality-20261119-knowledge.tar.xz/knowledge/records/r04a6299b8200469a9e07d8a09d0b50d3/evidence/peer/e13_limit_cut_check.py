# e13 (peer): cross-check of the limit re-entry point of the true profile cut at the crossing (y_D = x0 = 0.59963),
# with the well-conditioned shift form:  eta_cut(x) = -J(x) + int_0^{y_D} 2K(x,y) S(y) dy,  2K(x,y) = L^{-1}[Q_y](x-y).
# Also the small-lag expansion 2K(x,y) = 1 - 2 y sqrt(2 (x-y)/pi) + O(x-y).
import numpy as np
from limf import *
def K2(x, y):
    return talbot(lambda l: Tint(l, lambda mu, l0: 2 * (mu - l0) * np.exp(-(mu - l0) * y)), x - y)
gx, gw = np.polynomial.legendre.leggauss(16)
def eta_cut(x, yD, parts=4):
    edges = np.linspace(0, yD, parts + 1); tot = 0.0
    for i in range(parts):
        a, b = edges[i], edges[i + 1]
        u = 0.5 * (b - a) * gx + 0.5 * (b + a)
        tot += 0.5 * (b - a) * sum(w * K2(x, y) * talbot(Shat, y) for y, w in zip(u, gw))
    return -talbot(Jhat, x) + tot
print("small-lag check at y=0.5: lag, 2K, 1-2y sqrt(2 lag/pi):", [(lag, round(K2(0.5 + lag, 0.5), 4), round(1 - 2 * 0.5 * np.sqrt(2 * lag / np.pi), 4)) for lag in (0.001, 0.004, 0.01)])
for yD in (0.59963, 1.0):
    xs = {0.59963: (3.0, 3.3, 3.38, 3.45, 3.8), 1.0: (8.0, 8.6, 9.2)}[yD]
    print("y_D=%.3f: eta_cut(x)/J(x) at x=%s: %s" % (yD, xs, ["%.4f" % (eta_cut(x, yD) / talbot(Jhat, x)) for x in xs]), flush=True)
