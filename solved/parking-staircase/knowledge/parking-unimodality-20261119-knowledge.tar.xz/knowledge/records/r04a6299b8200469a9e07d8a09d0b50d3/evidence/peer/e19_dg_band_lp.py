# e19 (peer): how far must the diagonal lower bound (Dg)_j be known to force the last first-layer row?
# Bundle: kernel form; profile nonincreasing in [0,1] (mixture of step profiles, weights mu_S >= 0, sum 1);
#         sign pattern with the TRUE crossing row q0 on rows k+1..2k-2;  (Dg)_j for k+1 <= j <= Jmax.
# Quantity: min of the step at row 2k-1, as a multiple of the impulse response J_{2k-1}.
# LP solved by a Mehrotra predictor-corrector interior-point method (numpy, double precision).  For every solve we report
#   primal: objective of the returned point after clipping/renormalising, with its worst constraint violation;
#   dual  : a lower bound certified independently of the solver: with multipliers y_le<=0 (rows eta_j<=0), y_ge>=0, y_eq,
#           min >= y_eq - max_S ( (A^T y)_S - c_S )^+ .
# This re-does the explorer t32 table (k<=148) with another solver and extends it to larger k.
# Usage: python e19_dg_band_lp.py 100:table 120:table 148:table 200 400
import numpy as np, sys, time
from math import exp
from kern import bor, true_profile

def matrices(k, top):
    W = top - k + 1
    B = bor(top + 2)
    sizes = np.arange(k, top + 1, dtype=float)
    out = {}
    for c in (k, k + 1):
        H = np.zeros((W, W))
        for i in range(W):
            N = k + i
            if i > 0:
                H[i, :i] = (B[N - np.arange(k, N)] * (c / sizes[:i])) @ H[:i, :i]
            H[i, i] = N * B[N]
        Hs = H / sizes[:, None]
        G = np.zeros((W, W))
        for i in range(W):
            n = k + i
            G[i, :i + 1] = B[n + 1 - np.arange(k, n + 1)] @ Hs[:i + 1, :i + 1]
        out[c] = G
    E = 2 * (out[k + 1] - out[k]) / sizes[None, :]       # E[n-k, j-k] = e_n(j-1)
    J = out[k + 1][:, 0] / k
    Uco = out[k] / sizes[None, :]                        # cell_n = sum_j Psi_{j-1} Uco[n-k, j-k]
    Pi = -J[:, None] + np.cumsum(E, axis=1)              # Pi[n-k, i]: step at row n of the step profile dying at S = k-1+i
    Uc = np.cumsum(Uco, axis=1)                          # cell at row n of that step profile
    return Pi, Uc, J, E, Uco

def ipm(A, b, c, tol=3e-9, maxit=120):
    m, n = A.shape
    AAT = A @ A.T + 1e-13 * np.eye(m)
    x = A.T @ np.linalg.solve(AAT, b)
    y = np.linalg.solve(AAT, A @ c)
    s = c - A.T @ y
    x = x + max(-1.5 * x.min(), 0.0)
    s = s + max(-1.5 * s.min(), 0.0)
    xs = 0.5 * (x @ s)
    x = x + xs / s.sum()
    s = s + xs / x.sum()
    it = 0
    for it in range(maxit):
        rb = A @ x - b
        rc = A.T @ y + s - c
        mu = x @ s / n
        if max(np.abs(rb).max(), np.abs(rc).max(), mu) < tol:
            break
        good = (x.copy(), y.copy(), s.copy())
        d = x / np.maximum(s, 1e-250)
        M = (A * d) @ A.T
        if not np.all(np.isfinite(M)):
            break
        M[np.diag_indices(m)] += 1e-14 * (1 + np.diag(M).max())
        try:
            L = np.linalg.cholesky(M)
            solve = lambda r, L=L: np.linalg.solve(L.T, np.linalg.solve(L, r))
        except np.linalg.LinAlgError:
            solve = lambda r, M=M: np.linalg.lstsq(M, r, rcond=None)[0]
        def direction(rxs):
            dy = solve(-rb - A @ (rxs / s) - A @ (d * rc))
            ds = -rc - A.T @ dy
            dx = rxs / s - d * ds
            return dx, dy, ds
        dxa, dya, dsa = direction(-x * s)
        ap = min(1.0, (-x[dxa < 0] / dxa[dxa < 0]).min()) if np.any(dxa < 0) else 1.0
        ad = min(1.0, (-s[dsa < 0] / dsa[dsa < 0]).min()) if np.any(dsa < 0) else 1.0
        mua = (x + ap * dxa) @ (s + ad * dsa) / n
        sig = (mua / mu) ** 3
        dx, dy, ds = direction(-x * s - dxa * dsa + sig * mu)
        ap = min(1.0, 0.995 * (-x[dx < 0] / dx[dx < 0]).min()) if np.any(dx < 0) else 1.0
        ad = min(1.0, 0.995 * (-s[ds < 0] / ds[ds < 0]).min()) if np.any(ds < 0) else 1.0
        xn = x + ap * dx
        yn = y + ad * dy
        sn = s + ad * ds
        if not (np.all(np.isfinite(xn)) and np.all(np.isfinite(yn)) and np.all(np.isfinite(sn))):
            x, y, s = good
            break
        x, y, s = xn, yn, sn
    return x, y, s, it

class Problem:
    def __init__(self, k):
        self.k = k
        self.top = top = 2 * k - 1
        self.Pi, self.Uc, self.J, E, Uco = matrices(k, top)
        Psi = true_profile(k, top)
        step = -self.J + E @ Psi[k - 1:top]
        self.q0 = k + next(i for i in range(1, top - k + 1) if step[i] > 0)
        self.rho_true = step[top - k] / self.J[top - k]
        self.p = top - k                                   # death times S = k-1 .. 2k-3 (i = 0..p-1)
        self.gam = (1 + 1 / k) ** (k - 2) / exp(1.0)       # (Dg)_j in Borel normalisation: cell_j + step_j >= (gamma_k/e) cell_{j-1}
    def solve(self, Jmax):
        k, top, p, q0 = self.k, self.top, self.p, self.q0
        Pi, Uc, J = self.Pi[:, :p], self.Uc[:, :p], self.J
        le = [Pi[j - k] / J[j - k] for j in range(k + 1, q0)]                     # eta_j <= 0
        ge = [Pi[j - k] / J[j - k] for j in range(q0, top)]                       # eta_j >= 0, j <= 2k-2
        for j in range(k + 1, Jmax + 1):                                          # (Dg)_j >= 0
            row = Uc[j - k] + Pi[j - k] - self.gam * Uc[j - 1 - k]
            ge.append(row / Uc[j - k, -1])
        Ale = np.array(le)
        Age = np.array(ge)
        c = Pi[top - k] / J[top - k]
        nle, nge = len(le), len(ge)
        m = nle + nge + 1
        n = p + nle + nge
        A = np.zeros((m, n))
        b = np.zeros(m)
        A[:nle, :p] = Ale
        A[:nle, p:p + nle] = np.eye(nle)
        A[nle:nle + nge, :p] = Age
        A[nle:nle + nge, p + nle:] = -np.eye(nge)
        A[-1, :p] = 1.0
        b[-1] = 1.0
        cc = np.concatenate([c, np.zeros(nle + nge)])
        x, y, s, it = ipm(A, b, cc)
        mu = np.clip(x[:p], 0, None)
        mu /= mu.sum()
        viol = max((Ale @ mu).max() if nle else 0.0, (-(Age @ mu)).max() if nge else 0.0, 0.0)
        primal = c @ mu
        yle = np.minimum(y[:nle], 0.0)
        yge = np.maximum(y[nle:nle + nge], 0.0)
        yeq = y[-1]
        dual = yeq - np.clip(Ale.T @ yle + Age.T @ yge + yeq - c, 0, None).max()
        return primal, viol, dual, it

def main(argv):
    for a in argv:
        parts = a.split(":")
        k = int(parts[0])
        t0 = time.time()
        P = Problem(k)
        q0 = P.q0
        sc = k ** (2 / 3)
        norm2 = -P.Pi[P.top - k, 0] / P.J[P.top - k]       # (J - e(k-1))/J : the normaliser used in the explorer report
        print("k=%d q0=%d ; true step/J at row 2k-1 = %.4f ; (J-e(k-1))/J = %.4f" % (k, q0, P.rho_true, norm2), flush=True)
        if len(parts) > 1 and parts[1] == "table":
            cases = [("none", k), ("q0-2", q0 - 2), ("q0", q0), ("q0+1", q0 + 1), ("q0+2", q0 + 2), ("q0+5", q0 + 5),
                     ("q0+(q0-k)", 2 * q0 - k), ("q0+2(q0-k)", 3 * q0 - 2 * k), ("all", P.top)]
            for name, Jm in cases:
                pr, vi, du, it = P.solve(min(Jm, P.top))
                print("   Dg up to %-11s (row %4d): primal %.5f (violation %.1e), certified lower bound %.5f ; explorer normalisation %.4f  [%d its]" % (
                    name, Jm, pr, vi, du, pr / norm2, it), flush=True)
        lo, hi = q0 - 3, min(P.top, q0 + int(3 * sc))       # least Jmax whose certified lower bound is > 0
        prl, vil, dul, _ = P.solve(lo)
        prh, vih, duh, _ = P.solve(hi)
        if not (prl < 0 < duh):
            print("   bracket failed: at row %d primal %.5f (violation %.1e), at row %d dual %.5f" % (lo, prl, vil, hi, duh), flush=True)
            continue
        while hi - lo > 1:
            mid = (lo + hi) // 2
            pr, vi, du, _ = P.solve(mid)
            if du > 0:
                hi = mid
            else:
                if not (pr < 0 and vi < 1e-7):
                    print("   undecided at row %d: primal %.6f (violation %.1e), dual %.6f" % (mid, pr, vi, du), flush=True)
                lo = mid
        pr, vi, du, _ = P.solve(hi)
        pr2, vi2, du2, _ = P.solve(lo)
        print("   J_min = %d = q0%+d = k+%d (%.3f k^(2/3)) : there the min is in [%.5f, %.5f]; one row less: primal %.5f (violation %.1e)   [%.0fs]" % (
            hi, hi - q0, hi - k, (hi - k) / sc, du, pr, pr2, vi2, time.time() - t0), flush=True)

if __name__ == "__main__":
    main(sys.argv[1:])
