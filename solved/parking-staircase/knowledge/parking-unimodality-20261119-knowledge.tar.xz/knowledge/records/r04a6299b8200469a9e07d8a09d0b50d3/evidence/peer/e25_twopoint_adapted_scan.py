# e25 (peer): for which columns do the hypotheses of the two-point argument at the deficit-adapted tilt hold on every
# first-layer row after the crossing?  (Same quantities as e24; here a summary over a range of columns.)
# Reported per column: rows where (D1') fails, (D2') fails, and where neither closing condition (ii), (iii) holds.
# This tests one sentence of the argument (explorer's observation N1: "Theorem P's proof, read at the adapted tilt, runs from
# the crossing to the end of the first layer"); it is not used as a proof step.
import numpy as np, sys, time
from math import lgamma, log
from kern import column, true_profile, bor

def logeps(m):
    return ((m - 1) * log(m - 1) if m > 1 else 0.0) - lgamma(m + 1)

def check(k):
    top = 2 * k - 1
    B = bor(top + 2)
    Psi = true_profile(k, top)
    cell, step, J = column(k, Psi, top, B)
    q0 = next(n for n in range(k + 1, top + 1) if step[n] > 0)
    lgam = (k - 2) * log(1 + 1.0 / k)
    idx = np.arange(k, top + 1)
    f1 = f2 = fb = fii = 0
    worst = -9.0
    le = [logeps(m) for m in range(0, k + 2)]
    for n in range(q0 + 1, top + 1):
        r = n - k; rq = q0 - k; t = n - q0
        lg = le[r] - le[r - 1] if r >= 2 else -1e9
        lz = -max(lgam, lg)
        w = np.exp((lz + 1.0) * (idx - k))
        U = w * cell[k:top + 1]
        V = w * (cell[k:top + 1] + step[k:top + 1])
        h = -np.sum(V[:n - k] - U[:n - k])
        ratio = h / U[n - 1 - k]
        worst = max(worst, ratio)
        if ratio > 1.0: f1 += 1
        if np.sum(V[q0 - k:n - k] - U[q0 - 1 - k:n - 1 - k]) < 0: f2 += 1
        c_ii = log(n) + r * lz + le[r] - (log(q0) + rq * lz + le[rq])
        c_iii = (t + 1) * lz + le[t + 1] - (log(2.0) + lz - log(n))
        if c_ii > 0: fii += 1
        if c_ii > 0 and c_iii > 0: fb += 1
    return q0, f1, f2, fii, fb, worst

if __name__ == "__main__":
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    extra = [int(a) for a in sys.argv[3:]]
    t0 = time.time()
    bad_d = []; bad_ii = []; bad_both = []; wmax = (-9, None)
    ks = list(range(lo, hi + 1)) + extra
    for k in ks:
        q0, f1, f2, fii, fb, worst = check(k)
        if f1 or f2: bad_d.append((k, f1, f2))
        if fii: bad_ii.append(k)
        if fb: bad_both.append((k, fb))
        if worst > wmax[0]: wmax = (worst, k)
    print("columns checked: %d..%d and %s" % (lo, hi, extra))
    print("columns where (D1') or (D2') fails on some row after the crossing: %s" % (bad_d if bad_d else "none"))
    print("columns where (ii) fails on some row: %s" % (bad_ii if bad_ii else "none"))
    print("columns where neither (ii) nor (iii) holds on some row (k, number of rows): %s" % (bad_both if bad_both else "none"))
    print("largest h/U over all rows and columns: %.4f (k=%d)   [%.0fs]" % (wmax[0], wmax[1], time.time() - t0))
