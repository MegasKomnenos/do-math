# Test 3: shape of the resolved partial sums Mtil_n along a column, at tilt 1/e and at the
# row-adapted tilt x_n=(1+1/(n-k))^{-(n-k)} (largest tilt keeping x^i (i+1)^i/i! nonincreasing for i<=n-k).
# Purpose: does the sign-only resolved criterion (Mtil_n<=0 and running minimum) ever apply in the first layer?
from pf import T
import mpmath as mp
mp.mp.dps = 40
t = T(160)
def prof(k):
    iota = mp.mpf(k**(k-2))/mp.factorial(k)
    mu = {s: mp.mpf(2*t.b(s-1,k-1) - (s-1-k)*t.d(s-1,k))/mp.factorial(s) for s in range(k+1, 2*k)}
    out = []
    for n in range(k+1, 2*k):
        r = n-k
        res = []
        for x in (mp.e**(-1), (1+mp.mpf(1)/r)**(-r)):
            M = iota - sum(x**(s-k)*mu[s] for s in range(k+1, n+1))
            res.append(M/iota)
        # sign of mu_n: is M decreasing at n?
        out.append((n, r, float(res[0]), float(res[1]), mu[n] > 0))
    return out
for k in [20, 40, 80]:
    print("k=%d : n r  M(1/e)/iota  M(x_n)/iota  mu_n>0" % k)
    P = prof(k)
    for row in P:
        if row[1] in (1,2,3,5,8,10,12,15,20,25,30,40,50,60,70,79) or row[1]==k-1:
            print("   ", row[0], row[1], "%.4f"%row[2], "%.4f"%row[3], row[4])
