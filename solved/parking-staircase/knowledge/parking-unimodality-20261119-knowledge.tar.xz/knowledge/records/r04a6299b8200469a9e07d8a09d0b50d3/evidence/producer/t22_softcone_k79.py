# Test 22: the float LP of test 21 on a larger column (k=79, true crossing row 98), restricted crossing rows q.
import sys
from t21_softcone_lp_float import columns, solve
k = int(sys.argv[1]); q0 = int(sys.argv[2])
U, E, om, gam_t, top = columns(k)
for n in [int(a) for a in sys.argv[3:]]:
    for use, qs in [(('Pat', 'Dg'), list(range(q0-4, q0+5))), (('Pat',), sorted(set([q0, q0+8, q0+16, (q0+n)//2, n-4, n])))]:
        out = []
        for q in qs:
            if not (k+2 <= q <= n): continue
            st, mu, val, worst = solve(k, q, n, U, E, om, gam_t, use)
            out.append((q, 'empty' if st == 'infeasible' else '%.3e (slack %.0e)' % (val, worst)))
        print("k=%d n=%d (deficit %d) facts=%s: q -> min eta_{n+1}/|impulse|: %s" % (k, n, n-k, '+'.join(use), out))
