# Test 11b: the scan t11 uses double precision.  Recompute the worst (DF+) margin for a few columns with 40-digit arithmetic
# (same definitions; Lambda runs over 1..min(60,rho)) to confirm that rounding does not affect the outcome.
from mpmath import mp, mpf, log, exp, loggamma, floor, ceil
mp.dps = 40
def lg_c(i): return (i-1)*log(mpf(i+1)) - loggamma(i+1)
def lg_eps(m): return ((m-1)*log(mpf(m-1)) if m > 1 else mpf(0)) - loggamma(m+1)
def lg_g(m):
    if m == 1: return log(mpf(1)/2)
    return log(mpf(m)/(m+1)) + (m-1)*log(mpf(m)/(m-1))
def lg_r(m): return (m-1)*log(1+mpf(1)/m)
def column(k):
    lxdag = (k-2)*log(mpf(k)/(k+1)); lgam = -lxdag
    Ri = 1
    for r in range(2, k):
        if lxdag + lg_g(r-1) <= 0: Ri = r
        else: break
    q = k + int(ceil(mpf(k)**(mpf(2)/3))) + 1 if k <= 264 else k + int(floor((mpf(11)*k/5)**(mpf(2)/3))) + 1
    worst = (mpf(10)**9, None, None)
    for n in range(max(q+1, k+Ri+1), 2*k):
        r = n-k; t = n-q; rho = r-1
        lx = -lg_g(rho); x = exp(lx)
        w = [exp(L*lx + lg_c(L)) for L in range(rho+1)]
        W = [w[0]]
        for L in range(1, rho+1): W.append(W[-1]+w[L])
        Rat = [W[L-1]/w[L] for L in range(1, rho+1)]
        zeta = max(mpf(0), exp(lx + lg_r(rho)) - 1)
        y = x*(k-1)/(n-1)
        best = max(Rat); bl = 0; v = []
        for Lam in range(1, min(60, rho)+1):
            i = Lam-1
            v.append(mpf(1) if i == 0 else 1 + y*sum(w[l]*v[i-1-l] for l in range(i)))
            pis = y/(1+zeta)*sum(w[L]*v[Lam-1-L] for L in range(Lam))
            Th_o = max(Rat[Lam-1:]); Th_r = max(Rat[:Lam-1]) if Lam >= 2 else mpf(0)
            if Th_r > Th_o: continue
            val = (Th_o + pis*Th_r)/(1+pis)
            if val < best: best = val; bl = Lam
        m = 2/(n*exp(t*lx + lg_eps(t+1))*(1 + (1-exp(lx+lgam))*best))
        if m < worst[0]: worst = (m, r, bl)
    return q, Ri, worst
for k in [49, 50, 51, 52, 55, 60, 79, 100, 148]:
    q, Ri, worst = column(k)
    print("k=%d qbar=%d Ri=%d worst (DF+) margin = %s at r=%d (Lambda=%d)" % (k, q, Ri, mp.nstr(worst[0], 12), worst[1], worst[2]))
