# e14 (peer): robustness of the failure of (KK_k) (r9faef2b6, Corollary 19) against the value of the reference row.
# Pure Cayley-number computation (no parking-function table): for column k and every reference row n' in a band,
#   lag(n') = (first n > n' at which (KK)(n',n) fails) - n'
# in the feedback form  c_n(s) I_{n'} >= c_{n'}(s) I_n  for all k-1 <= s <= n'-3.
# (KK_k) asks (KK)(n_1,n) for n_1 < n < N_0, N_0 - 1 - n_1 = ceil(2.2 k^{2/3}) - (n_1 - q_0).
# If lag(n') <= ceil(2.2 k^{2/3}) - 20 for every n' in the band, (KK_k) fails for any q_0, n_1 in the band with n_1 - q_0 <= 19.
import numpy as np, sys, time
from math import lgamma, log, exp, ceil
from e09_twopoint_large_k import kernel_matrices
def run(k, lo, hi, xmax=4.4):
    t0 = time.time()
    sc = k ** (2 / 3)
    top = min(2 * k, k + int(xmax * sc))
    W = top - k + 1
    E, J = kernel_matrices(k, top)
    eps = np.zeros(W + 1)
    for m in range(1, W + 1):
        eps[m] = exp(-m + ((m - 1) * log(m - 1) if m > 1 else 0.0) - lgamma(m + 1))
    Eps = np.zeros((W, W))
    for i in range(1, W):
        Eps[i, :i] = eps[i - np.arange(0, i)]
    Cm = Eps @ E; I = Eps @ J
    need = ceil(2.2 * sc)
    lags = []
    for nref in range(lo, hi + 1):
        i1 = nref - k; ncol = nref - k - 1
        n = nref + 1
        while n <= top and bool(np.all(Cm[n - k, :ncol] * I[i1] >= Cm[i1, :ncol] * I[n - k] * (1 - 1e-11))):
            n += 1
        lags.append(n - nref if n <= top else None)
    print("k=%d, reference rows %d..%d: first-failure lags = %s ; ceil(2.2 k^(2/3)) = %d ; max lag = %s  [%.0fs]" % (
        k, lo, hi, lags, need, max(l for l in lags if l is not None) if all(l is not None for l in lags) else "beyond scan", time.time() - t0), flush=True)
if __name__ == '__main__':
    run(2400, 2524, 2552)
    run(3000, 3142, 3172)
    run(2000, 2110, 2138)
