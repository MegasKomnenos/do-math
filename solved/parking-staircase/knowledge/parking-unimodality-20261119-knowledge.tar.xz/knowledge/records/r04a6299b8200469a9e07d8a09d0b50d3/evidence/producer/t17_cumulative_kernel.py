# Test 17 (tied to the argument).  Published kernel form (r9faef2b6 Theorem 15): in the first layer
#     eta_n = -J_n + sum_{s=k-1}^{n-2} e_n(s) Psi_s ,   e_n(s) >= 0,  J_n > 0,  Psi_s = Pr(M_s <= k-2) (Psi_{k-1}=1).
# Published two-point condition for the step (Theorem 16): e_n(s) J_{n'} >= e_{n'}(s) J_n for all s  ==> persistence for EVERY Psi >= 0.
# Here: Psi is nonincreasing in s (stochastic monotonicity), so eta_n = sum_S mu_S * Pi_n(S),  mu_S = Psi_S - Psi_{S+1} >= 0,
#     Pi_n(S) := -J_n + sum_{s=k-1}^{min(S,n-2)} e_n(s)      (the step of the model in which level k-2 dies exactly after size S).
# By Farkas, "eta_n >= 0  ==>  eta_{n+1} >= 0 for every nonincreasing Psi" holds iff there is c >= 0 with
#     Pi_{n+1}(S) >= c * Pi_n(S)   for all S in [k-1, n-1]                      (cKK)(n)
# i.e.  L_n := max{ Pi_{n+1}(S)/Pi_n(S) : Pi_n(S) < 0 }  <=  H_n := min{ Pi_{n+1}(S)/Pi_n(S) : Pi_n(S) > 0 }   (and L_n may be negative).
# Questions: on which rows of the first layer does (cKK)(n) hold?  Compare with the coefficientwise condition (KK).
# Double precision at the critical tilt (ratios between rows are tilt-independent up to a common factor).
import numpy as np
from math import lgamma, log, exp
def kernels(k):
    x = (k/(k+1))**(k-1)
    N = 2*k
    lg_c = lambda i: (i-1)*log(i+1) - lgamma(i+1)                 # log c_i
    om = np.array([exp(s*log(x) + lg_c(s)) for s in range(0, N+1)])                 # omega_s = x^s c_s
    tau = np.array([0.0] + [exp(g*log(x) + (g-1)*log(g) - lgamma(g+1)) for g in range(1, N+1)])   # tau_g = x^g g^(g-1)/g!
    u = np.zeros((N+1, N+1)); e = np.zeros((N+1, N+1)); J = np.zeros(N+1)
    for n in range(k, 2*k):
        for s in range(k-1, n):
            acc = tau[n-s]*om[s]/(s+1)
            for sp in range(s+1, n):
                acc += k*tau[n-sp]*u[sp][s]/(sp+1)
            u[n][s] = acc
        for s in range(k-1, n-1):
            acc = 0.0
            for sp in range(max(s+1, k), n):
                acc += tau[n-sp]*((k+1)*e[sp][s] + 2*u[sp][s])/(sp+1)
            e[n][s] = acc
        acc = tau[n-k+1]*om[k-1]/k
        for sp in range(k, n):
            acc += (k+1)*tau[n-sp]*J[sp]/(sp+1)
        J[n] = acc
    return e, J
print("k | rows n (k+2..2k-2) where coefficientwise (KK)(n,n+1) fails | rows where cumulative (cKK)(n) fails | min over rows of H_n/max(L_n,0+) summary")
for k in [10, 16, 24, 36, 50, 70, 100]:
    e, J = kernels(k)
    kk_fail = []; ckk_fail = []; worst = (9e9, None)
    for n in range(k+2, 2*k-1):
        # coefficientwise
        bad = False
        for s in range(k-1, n-1):
            if e[n+1][s]*J[n] < e[n][s]*J[n+1]*(1-1e-12): bad = True; break
        if bad: kk_fail.append(n)
        # cumulative
        Pn = [-J[n] + e[n][k-1:min(S, n-2)+1].sum() for S in range(k-1, n)]
        Pn1 = [-J[n+1] + e[n+1][k-1:min(S, n-1)+1].sum() for S in range(k-1, n)]
        L = -1e300; H = 1e300; ok = True
        for a, b in zip(Pn, Pn1):
            if a < 0: L = max(L, b/a)
            elif a > 0: H = min(H, b/a)
            else:
                if b < 0: ok = False
        if not ok or max(L, 0.0) > H*(1+1e-12): ckk_fail.append(n)
        if H < 1e299 and L > 0:
            if H/L < worst[0]: worst = (H/L, n)
    fmt = lambda v: (v if len(v) <= 10 else "%d rows %d..%d" % (len(v), v[0], v[-1]))
    print(k, "|", fmt(kk_fail), "|", fmt(ckk_fail), "| min H/L = %.4f at n=%s" % worst)
