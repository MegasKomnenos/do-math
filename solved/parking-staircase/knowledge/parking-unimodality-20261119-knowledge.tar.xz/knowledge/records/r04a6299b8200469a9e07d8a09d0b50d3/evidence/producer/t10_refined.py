# Test 10 (tied to the argument).  Refinement of the data-free bound by the recent trees.
# (a) exact check of the single-tree (forward) identity used:  for k <= n' <= 2k-1,
#       b_{n',k-1} = sum_{t=k}^{n'} C(n',t) * [ (k-1) b_{t-1,k-1} + A_{t-1,k-1} ] * p_{n'-t}.
# (b) Lemma R:  T_n := sum_{j=k}^{n-2}U_j / U_{n-1}  <=  Tbar(Lambda) := (Theta_o + pi*Theta_r)/(1+pi*)   (any 1<=Lambda<=rho),
#       Theta_o = max_{Lambda<=L<=rho} W_{L-1}/w_L,  Theta_r = max_{1<=L<=Lambda-1} W_{L-1}/w_L (0 if Lambda=1),
#       y = x(k-1)/(n-1),  v_0=1, v_i = 1 + y*sum_{l<i} w_l v_{i-1-l},   pi* = y/(1+zeta) * sum_{L=0}^{Lambda-1} w_L v_{Lambda-1-L},
#       zeta = max(0, x*r_rho - 1)   (r_m=(1+1/m)^(m-1)),   rho = n-k-1,  x = min(x_dag, 1/g(rho)).
#     Check against the true T_n from exact tables (k<=79).
# (c) (DF+):  n x^t eps_{t+1} [ 1 + (1-x gamma_k) * min_Lambda Tbar(Lambda) ] <= 2  : which rows r>R_i are covered?  (no table used)
import numpy as np
from math import lgamma, log, floor, ceil, exp, comb, factorial
from fractions import Fraction as Fr
from pf import T
tab = T(160)
# ---------- (a)
bad = 0; cnt = 0
for k in [3, 4, 6, 9, 14, 22, 35]:
    for n1 in range(k, 2*k):
        rhs = sum(comb(n1, t)*((k-1)*tab.b(t-1, k-1) + tab.A(t-1, k-1))*tab.p(n1-t) for t in range(k, n1+1))
        cnt += 1
        if rhs != tab.b(n1, k-1): bad += 1
print("(a) forward identity: %d cases, %d violations" % (cnt, bad))
# ---------- helpers (floats, log space)
NM = 45000
Ls = np.arange(0, NM, dtype=np.float64)
lgc = (Ls-1)*np.log(Ls+1) - np.array([lgamma(i+1) for i in range(NM)])
def lg_eps(m): return ((m-1)*log(m-1) if m > 1 else 0.0) - lgamma(m+1)
def lg_g(m):
    if m == 1: return log(0.5)
    return log(m/(m+1)) + (m-1)*log(m/(m-1))
def lg_r(m): return (m-1)*log(1+1/m)
def Tbar(k, n, lx, LamMax=60):
    rho = n-k-1
    x = exp(lx)
    w = np.exp(Ls[:rho+1]*lx + lgc[:rho+1]); W = np.cumsum(w)
    Rat = W[:-1]/w[1:]                     # Rat[L-1] = W_{L-1}/w_L, L=1..rho
    zeta = max(0.0, exp(lx + lg_r(rho)) - 1)
    y = x*(k-1)/(n-1)
    best = (float(np.max(Rat)), 0)         # Lambda "=0": no refinement
    v = []
    for Lam in range(1, min(LamMax, rho)+1):
        i = Lam-1
        v.append(1.0 if i == 0 else 1 + y*sum(w[l]*v[i-1-l] for l in range(i)))
        pis = y/(1+zeta)*sum(w[L]*v[Lam-1-L] for L in range(Lam))
        Th_o = float(np.max(Rat[Lam-1:]))
        Th_r = float(np.max(Rat[:Lam-1])) if Lam >= 2 else 0.0
        val = (Th_o + pis*Th_r)/(1+pis)
        if val < best[0]: best = (val, Lam)
    return best
def Ri_of(k):
    lxdag = (k-2)*log(k/(k+1)); Ri = 1
    for r in range(2, k):
        if lxdag + lg_g(r-1) <= 0: Ri = r
        else: break
    return Ri, lxdag
# ---------- (b)
print("(b) Lemma R against exact tables: k, rows checked, violations, min (Tbar/T_true) , max (Tbar/T_true)")
for k in [30, 40, 50, 60, 79]:
    Ri, lxdag = Ri_of(k)
    viol = 0; rats = []
    for n in range(k+Ri+1, 2*k):
        rho = n-k-1
        lx = min(lxdag, -lg_g(rho))
        x = exp(lx)
        u = [float(Fr(tab.b(j, k-1), factorial(j))*Fr(10)**60) for j in range(k, n)]   # scaled to avoid underflow
        # true T_n with float weights x^(j-(n-1))
        Tn = sum(exp((j-(n-1))*lx)*u[j-k] for j in range(k, n-1))/u[n-1-k]
        tb, Lam = Tbar(k, n, lx)
        rats.append(tb/Tn)
        if tb < Tn*(1-1e-9): viol += 1
    print("   ", k, len(rats), viol, round(min(rats), 3), round(max(rats), 3))
# ---------- (c)
def report(k, q, label, step=1):
    Ri, lxdag = Ri_of(k); lgam = -lxdag
    rows = range(max(q+1, k+Ri+1), 2*k) if step == 1 else sorted(set(list(range(k+Ri+1, 2*k, step)) + list(range(2*k-40, 2*k))))
    worst = (9e9, None); fails = []
    for n in rows:
        r = n-k; t = n-q; rho = r-1
        lx = min(lxdag, -lg_g(rho))
        tb, Lam = Tbar(k, n, lx)
        lhs = n*exp(t*lx + lg_eps(t+1))*(1 + (1-exp(lx+lgam))*tb)
        m = 2/lhs
        if m < worst[0]: worst = (m, r, Lam)
        if m < 1: fails.append(r)
    print("k=%d q=%d (%s) Ri=%d: rows r>Ri failing (DF+): %s ; worst margin %.3f at r=%d (Lambda=%d)" % (
        k, q, label, Ri, (fails if len(fails) <= 12 else "%d rows: %d..%d" % (len(fails), fails[0], fails[-1])), worst[0], worst[1], worst[2]))
print("(c)")
true_q = {30:42, 40:54, 50:65, 60:77, 79:98, 100:121, 120:143, 148:174}
for k in sorted(true_q): report(k, true_q[k], "true q0")
for k in [148, 200, 264]:
    report(k, k + int(ceil(k**(2/3))) + 1, "q<=k+k^(2/3)+1")
for k in [265, 400, 1000, 1728, 5000]:
    report(k, k + int(floor((11*k/5)**(2/3))) + 1, "q<=k+(11k/5)^(2/3)+1", step=(1 if k <= 1000 else 9))
