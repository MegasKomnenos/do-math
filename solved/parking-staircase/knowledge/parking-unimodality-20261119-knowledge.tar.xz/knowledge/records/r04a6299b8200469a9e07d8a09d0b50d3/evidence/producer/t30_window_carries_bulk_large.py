# Test 30 (tied to the argument).  Same question as test 28 on three larger true columns (rows n <= 2k-1 <= 295, inside the
# range n <= 300 already used in this session):  do the survival sources of the window alone beat the impulse response at
# every later row of the first layer?
# True profile Psi_s = A_{s,k-2}/p_s from the per-level last-car recursion (exact integers, one level only):
#     A_{n,l} = sum_{j=0}^{n-1} C(n-1,j) min(j+1,l+1) A_{j,l} A_{n-1-j,l}.
# Kernels of r9faef2b6 Theorem 15 in double precision at the critical tilt (test 24).
import sys
import numpy as np
from math import comb
from fractions import Fraction as Fr
from t24_reference_row import kernels_vec


def level_column(l, nmax):
    A = [1]
    for n in range(1, nmax + 1):
        if l >= n - 1:
            A.append((n + 1) ** (n - 1))
            continue
        s = 0
        for j in range(n):
            s += comb(n - 1, j) * min(j + 1, l + 1) * A[j] * A[n - 1 - j]
        A.append(s)
    return A


if __name__ == '__main__':
    for k in [int(a) for a in sys.argv[1:]]:
        top = 2 * k - 1
        A = level_column(k - 2, top)
        Psi = np.zeros(2 * k + 1)
        for s in range(k - 1, 2 * k):
            Psi[s] = float(Fr(A[s], (s + 1) ** (s - 1)))
        e, J = kernels_vec(k)
        eta = {n: -J[n] + float(np.dot(e[n][k - 1:n - 1], Psi[k - 1:n - 1])) for n in range(k, 2 * k)}
        q0 = next(n for n in range(k + 1, 2 * k) if eta[n] > 0)
        single = all(eta[n] <= 0 for n in range(k, q0)) and all(eta[n] > 0 for n in range(q0, 2 * k))
        cd = q0 - k
        print("k=%d: crossing row from the kernel form q0=%d (deficit %d), single crossing in the layer: %s ; Psi at q0, q0+cd, q0+2cd, 2k-1: %.3f %.3f %.3f %.3f" % (
            k, q0, cd, single, Psi[q0], Psi[q0 + cd], Psi[min(q0 + 2 * cd, top)], Psi[top]))
        S1 = {}
        for n in range(q0, 2 * k):
            acc = -J[n]
            for S in range(k - 1, n - 1):
                acc += e[n][S] * Psi[S]
                if acc >= 0:
                    S1[n] = S
                    break
        mx = max(S1, key=lambda n: S1[n])
        late = max((n for n in S1 if S1[n] > q0 - 2), default=None)
        first_late = min((n for n in S1 if S1[n] > q0 - 2), default=None)
        print("    max over q0<=n<=2k-1 of S1(n) = %d at n=%d (q0%+d ; %.2f crossing deficits) ; rows where the pre-crossing sources (s<=q0-2) do NOT suffice: %s" % (
            S1[mx], mx, S1[mx] - q0, (S1[mx] - k) / cd, ("none" if first_late is None else "%d..%d" % (first_late, late))))
        for n in sorted(set(min(v, top) for v in [q0, q0 + cd, q0 + 3 * cd, (q0 + top) // 2, top - 20, top])):
            pos = float(np.dot(e[n][k - 1:n - 1], Psi[k - 1:n - 1]))
            pre = float(np.dot(e[n][k - 1:q0 - 1], Psi[k - 1:q0 - 1]))
            win = float(np.dot(e[n][k - 1:min(q0 + cd, n - 2) + 1], Psi[k - 1:min(q0 + cd, n - 2) + 1]))
            print("    row %d (deficit %d): total positive part / impulse = %.3f ; pre-crossing part (s<=q0-2) / impulse = %.3f ; part from s<=q0+cd / impulse = %.3f ; S1 = %d" % (
                n, n - k, pos / J[n], pre / J[n], win / J[n], S1[n]))
