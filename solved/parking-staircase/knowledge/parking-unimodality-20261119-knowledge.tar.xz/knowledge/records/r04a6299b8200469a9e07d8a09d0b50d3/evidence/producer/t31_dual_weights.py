# Test 31 (tied to the argument).  Shape of the dual certificate of test 27 (fact set Pat+Dg, crossing at the true row,
# target = last row of the first layer).  The certificate reads
#     eta_{n+1}  >=  t*|impulse|  +  lam * eta_q  +  sum_j m_j * (V_j - gamma_k U_{j-1}),      m_j >= 0,
# in UNTILTED quantities (U_j = b_{j,k-1}/j!, V_j = b_{j,k}/j!).  Questions: on which rows j is m_j > 0, and are the
# multipliers geometric in j?  If m_j = C z^j the Dg-part is C times the published debt bound at tilt z
# (sum_j z^j (V_j - gamma U_{j-1}) = -h_J + U_J + (1 - z gamma) sum_{i<J} U_i  at tilt z).  We print m_{j+1}/m_j next to
# the diagonal tilt 1/gamma_k and the critical tilt x_k, and the last row of the band next to R_i(k) (largest r with
# g(r-1) <= gamma_k, the deficit up to which the kernel is monotone at the diagonal tilt).
import sys
import numpy as np
from math import log, exp, lgamma
from t21_softcone_lp_float import columns, simplex_float


def eps(m):
    return exp((m - 1) * log(m - 1) - lgamma(m + 1)) if m >= 2 else 1.0


def g(m):
    return eps(m + 1) / eps(m)


def raw_rows(k, q, n, U, E, gam_t):
    Ss = list(range(k - 1, n + 2))
    rows, lab = [], []
    for j in range(k, q):
        rows.append([-E[S][j] for S in Ss]); lab.append(('-eta', j))
    for j in range(q, n + 1):
        rows.append([E[S][j] for S in Ss]); lab.append(('+eta', j))
    for j in range(k + 1, n + 2):
        rows.append([(U[S][j] + E[S][j]) - gam_t * (U[S][j - 1] if j - 1 >= k else 0.0) for S in Ss]); lab.append(('Dg', j))
    return Ss, np.array(rows), lab, np.array([E[S][n + 1] for S in Ss])


if __name__ == '__main__':
    k, q = int(sys.argv[1]), int(sys.argv[2])
    U, E, om, gam_t, top = columns(k)
    x = (k / (k + 1)) ** (k - 1)
    gam = ((k + 1) / k) ** (k - 2)
    n = top - 1
    Ss, G, lab, obj = raw_rows(k, q, n, U, E, gam_t)
    sc = np.abs(G).max(axis=1); sc[sc == 0] = 1.0
    Gs = G / sc[:, None]
    scale = abs(E[k - 1][n + 1])
    c = obj / scale
    m, nS = Gs.shape
    A = np.hstack([Gs.T, np.ones((nS, 1)), -np.ones((nS, 1)), np.eye(nS)])
    b = c.copy(); neg = b < 0; A[neg] *= -1; b[neg] *= -1
    cost = np.concatenate([np.zeros(m), [-1.0, 1.0], np.zeros(nS)])
    st, xx, val = simplex_float(A, b, cost)
    y = np.clip(xx[:m], 0, None)
    t_check = float((c - Gs.T @ y).min())
    # multipliers on the raw tilted rows, then on untilted facts:  row_j(tilted) = x^j * (untilted fact_j)
    mult = y / sc * scale          # eta_{n+1}(tilted) >= t*scale + sum mult_i * row_i(tilted)
    Ri = max(r for r in range(2, k) if g(r - 1) <= gam)
    print("k=%d q=%d target row %d: certified eta/|impulse| >= %.4f ; R_i(k)=%d (row k+R_i=%d) ; 1/gamma_k=%.6f, x_k=%.6f" % (k, q, n + 1, t_check, Ri, k + Ri, 1 / gam, x))
    dg = [(lab[i][1], mult[i] * x ** (lab[i][1] - (n + 1))) for i in range(m) if lab[i][0] == 'Dg' and y[i] > 1e-12 * y.sum()]
    et = [(lab[i][0], lab[i][1], mult[i] * x ** (lab[i][1] - (n + 1))) for i in range(m) if lab[i][0] != 'Dg' and y[i] > 1e-12 * y.sum()]
    print("   eta-facts with weight: %s" % [(a, j) for a, j, w in et])
    js = [j for j, w in dg]
    print("   Dg rows with weight: %d..%d (%d rows; contiguous: %s)" % (min(js), max(js), len(js), len(js) == max(js) - min(js) + 1))
    ratios = [(dg[i + 1][0], dg[i + 1][1] / dg[i][1]) for i in range(len(dg) - 1) if dg[i + 1][0] == dg[i][0] + 1]
    rr = np.array([r for j, r in ratios])
    print("   m_{j+1}/m_j over the band: min %.6f, median %.6f, max %.6f   (first five: %s ; last five: %s)" % (
        rr.min(), float(np.median(rr)), rr.max(), [round(float(v), 5) for v in rr[:5]], [round(float(v), 5) for v in rr[-5:]]))
