# Minimal exact two-phase simplex (Bland's rule) over Fractions:
#   minimize c.x  subject to  A x = b, x >= 0   (requires b >= 0).
# Returns (status, x, value); status in {'optimal', 'unbounded', 'infeasible'}.
from fractions import Fraction as Fr


def simplex(A, b, c):
    m = len(A)
    n = len(A[0])
    T = [list(map(Fr, A[i])) + [Fr(1) if j == i else Fr(0) for j in range(m)] + [Fr(b[i])] for i in range(m)]
    basis = [n + i for i in range(m)]

    def pivot(r, col):
        pv = T[r][col]
        T[r] = [v / pv for v in T[r]]
        for i in range(m):
            if i != r and T[i][col] != 0:
                f = T[i][col]
                T[i] = [a - f * bv for a, bv in zip(T[i], T[r])]
        basis[r] = col

    def run(cost, ncols):
        while True:
            y = [cost[basis[i]] for i in range(m)]
            inb = set(basis)
            enter = None
            for j in range(ncols):
                if j in inb:
                    continue
                rc = cost[j] - sum(y[i] * T[i][j] for i in range(m) if y[i] != 0)
                if rc < 0:
                    enter = j
                    break  # Bland: smallest index
            if enter is None:
                return 'optimal'
            best = None
            row = None
            for i in range(m):
                if T[i][enter] > 0:
                    ratio = T[i][-1] / T[i][enter]
                    if best is None or ratio < best or (ratio == best and basis[i] < basis[row]):
                        best = ratio
                        row = i
            if row is None:
                return 'unbounded'
            pivot(row, enter)

    cost1 = [Fr(0)] * n + [Fr(1)] * m
    run(cost1, n + m)
    if sum(T[i][-1] for i in range(m) if basis[i] >= n) != 0:
        return 'infeasible', None, None
    for i in range(m):
        if basis[i] >= n:
            for j in range(n):
                if T[i][j] != 0 and j not in basis:
                    pivot(i, j)
                    break
    big = Fr(10 ** 9)
    cost2 = list(map(Fr, c)) + [big] * m
    st = run(cost2, n)
    x = [Fr(0)] * n
    for i in range(m):
        if basis[i] < n:
            x[basis[i]] = T[i][-1]
    return st, x, sum(cc * xx for cc, xx in zip(c, x))
