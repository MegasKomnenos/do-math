# v01: validate the peer's table against (i) brute-force simulation n<=7, (ii) the root file's check values.
from ptab import Tab, brute_row
t = Tab(30)
root = {1:[1],2:[2,1],3:[6,7,3],4:[24,51,34,16],5:[120,421,377,253,125],6:[720,3963,4594,3688,2546,1296],7:[5040,42253,62145,57398,46142,32359,16807]}
ok = True
for n in range(1, 8):
    row = [t.b(n, k) for k in range(n)]
    br = brute_row(n)
    ok &= (row == root[n] == br)
    print(n, row == root[n], row == br)
print("all rows n<=7 agree with brute force and the root file:", ok)
