# Peer: floating-point first-layer kernel quantities in Borel normalization (numpy, double precision).
#   Bor(g) = e^{-g} g^{g-1}/g!.
#   hh_c(N;j) = e^{-N} H_c(N,j)/(N-1)!,   hh(j;j) = j Bor(j),   hh(N;j) = sum_{s=j}^{N-1} Bor(N-s) (c/s) hh(s;j)
#   gg_c(n;j) = e^{-(n+1)} G_c(n,j)/n!  = sum_{s=j}^{n} Bor(n+1-s) hh(s;j)/s
# For weights w_j (j>=k):   X_c(N) = w_N N Bor(N) + sum_{s<N} Bor(N-s)(c/s) X_c(s),   sum_j w_j gg_c(n;j) = sum_s Bor(n+1-s) X_c(s)/s.
# Step of the column built from a profile Psi (Psi[s], s>=k-1), in the normalization e^{-(n+1)} d_n/n!:
#   step_n = sum_{j=k}^{n} (2 Psi_{j-1}/j) (gg_{k+1}(n;j) - gg_k(n;j)) - gg_{k+1}(n;k)/k,      impulse J_n = gg_{k+1}(n;k)/k.
# Cells: e^{-(n+1)} b_{n,k-1}/n! = sum_j (Psi_{j-1}/j) gg_k(n;j).
import numpy as np
from math import lgamma, log, exp

def bor(gmax):
    g = np.arange(0, gmax + 1, dtype=float)
    out = np.zeros(gmax + 1)
    for i in range(1, gmax + 1):
        out[i] = exp(-i + (i - 1) * log(i) - lgamma(i + 1))
    return out

def response(k, c, w, top, B):
    """w: dict or array indexed by j (k<=j<=top) of weights. Returns array R[n] = sum_j w_j gg_c(n;j), n=k..top (index n)."""
    X = np.zeros(top + 2)
    R = np.zeros(top + 2)
    inv = np.zeros(top + 2); inv[1:] = 1.0 / np.arange(1, top + 2)
    for N in range(k, top + 1):
        acc = w[N] * N * B[N]
        if N > k:
            s = np.arange(k, N)
            acc += c * np.dot(B[N - s], X[s] * inv[s])
        X[N] = acc
    for n in range(k, top + 1):
        s = np.arange(k, n + 1)
        R[n] = np.dot(B[n + 1 - s], X[s] * inv[s])
    return R

def column(k, Psi, top, B=None):
    """Psi: array indexed by s (needs s=k-1..top-1). Returns (cell, step, J) arrays indexed by n."""
    if B is None:
        B = bor(top + 2)
    w1 = np.zeros(top + 2)
    for j in range(k, top + 1):
        w1[j] = Psi[j - 1] / j
    Rk = response(k, k, w1, top, B)
    Rk1 = response(k, k + 1, w1, top, B)
    wi = np.zeros(top + 2); wi[k] = 1.0 / k
    J = response(k, k + 1, wi, top, B)
    step = 2 * (Rk1 - Rk) - J
    return Rk, step, J

def true_profile(k, top):
    """Psi_s = Pr(M_s <= k-2) for 0<=s<=top by the last-car recursion at the single level l=k-2 (tilted by e^{-s})."""
    l = k - 2
    al = np.zeros(top + 1)   # al[n] = e^{-n} A_{n,l}/n!
    al[0] = 1.0
    wgt = np.minimum(np.arange(0, top + 1) + 1, l + 1).astype(float)
    em1 = exp(-1.0)
    for n in range(1, top + 1):
        j = np.arange(0, n)
        al[n] = em1 * np.dot(wgt[j] * al[j], al[n - 1 - j]) / n
    # c_s e^{-s} = (s+1)^{s-1} e^{-s}/s!
    cs = np.array([exp(-s + (s - 1) * log(s + 1) - lgamma(s + 1)) for s in range(top + 1)])
    return al / cs
