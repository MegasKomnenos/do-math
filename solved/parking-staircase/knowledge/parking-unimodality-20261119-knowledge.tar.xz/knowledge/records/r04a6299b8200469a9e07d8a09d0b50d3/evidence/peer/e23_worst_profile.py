# e23 (peer): what does the worst profile of the band program look like?  (reading "the cut profile is nearly the worst case")
# For column k and Dg known up to row J = J_min(k) - 1 (the last J at which the last row is not forced), take the minimiser of e19
# and compare its profile  Psi^opt_s = sum_{S >= s} mu_S  with the true profile Psi_s.
import numpy as np, sys
from kern import true_profile
import e19_dg_band_lp as L

def run(k, J):
    P = L.Problem(k)
    q0, top, p = P.q0, P.top, P.p
    Pi, Uc, Jv = P.Pi[:, :p], P.Uc[:, :p], P.J
    le = [Pi[j - k] / Jv[j - k] for j in range(k + 1, q0)]
    ge = [Pi[j - k] / Jv[j - k] for j in range(q0, top)]
    for j in range(k + 1, J + 1):
        ge.append((Uc[j - k] + Pi[j - k] - P.gam * Uc[j - 1 - k]) / Uc[j - k, -1])
    Ale, Age = np.array(le), np.array(ge)
    c = Pi[top - k] / Jv[top - k]
    nle, nge = len(le), len(ge)
    m, n = nle + nge + 1, p + nle + nge
    A = np.zeros((m, n)); b = np.zeros(m)
    A[:nle, :p] = Ale; A[:nle, p:p + nle] = np.eye(nle)
    A[nle:nle + nge, :p] = Age; A[nle:nle + nge, p + nle:] = -np.eye(nge)
    A[-1, :p] = 1.0; b[-1] = 1.0
    x, y, s, it = L.ipm(A, b, np.concatenate([c, np.zeros(nle + nge)]))
    mu = np.clip(x[:p], 0, None); mu /= mu.sum()
    prof = np.cumsum(mu[::-1])[::-1]                 # prof[i] = Psi^opt at s = k-1+i
    Psi = true_profile(k, top)
    sc = k ** (2 / 3)
    print("k=%d q0=%d, Dg up to row J=%d (k+%d): min of step/J at row 2k-1 = %.5f" % (k, q0, J, J - k, c @ mu))
    print("   s-k :  " + "  ".join("%6d" % (sv - k) for sv in range(k, min(top - 1, J + 40), max(1, (J - k) // 12))))
    print("   opt :  " + "  ".join("%6.4f" % prof[sv - (k - 1)] for sv in range(k, min(top - 1, J + 40), max(1, (J - k) // 12))))
    print("   true:  " + "  ".join("%6.4f" % Psi[sv] for sv in range(k, min(top - 1, J + 40), max(1, (J - k) // 12))))
    big = [(k - 1 + i, mu[i]) for i in range(p) if mu[i] > 1e-6]
    last = max(sv for sv, w in big if sv < top - 2) if any(sv < top - 2 for sv, w in big) else None
    tail_mass = sum(w for sv, w in big if sv > J + 5)
    print("   largest death times with weight > 1e-6 below the end: last = %s ; mass on death times > J+5: %.2e ; opt profile at s=J-2, J, J+2, J+10: %s" % (
        last, tail_mass, ", ".join("%.4f" % prof[sv - (k - 1)] for sv in (J - 2, J, J + 2, J + 10))))

if __name__ == "__main__":
    for a in sys.argv[1:]:
        k, J = [int(v) for v in a.split(":")]
        run(k, J)
