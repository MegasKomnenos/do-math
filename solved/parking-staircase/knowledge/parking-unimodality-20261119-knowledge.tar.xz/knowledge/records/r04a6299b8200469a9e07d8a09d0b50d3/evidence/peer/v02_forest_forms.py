# v02 (peer): the first-layer kernel form read on the uniform forest.
# (i)   forest representation: sum_F prod_v min(1,(l+1)/t_v) = A_{n,l}                      (sanity, n<=7)
# (ii)  d_{n,k} = sum_F ( 2 P(A|F) - P(B|F) ),  A = {M=k, lowest vertex v with D_v>=k-1 has D_v=k-1},
#                                               B = {M<=k, that lowest vertex has t_v=k}      (k<=n<=2k-1, n<=7)
# (iii) chain functional: d_{n,k} = sum_F W*( (1+1/k)^m + (1-1/k)^m - 2 - (theta/k)(1-1/k)^m ),
#       W = prod_{t_v>k} k/t_v, m = #{v: t_v>k}, theta = #{v: t_v=k} (0 or 1 in the first layer)
# Forests on [n] are enumerated as trees on {0..n} rooted at 0 via Pruefer codes.
from fractions import Fraction as Fr
from itertools import product
from ptab import Tab

def trees(n):
    # all labelled trees on vertices 0..n (n>=1), as parent arrays when rooted at 0
    N = n + 1
    if N == 2:
        yield [None, 0]
        return
    for code in product(range(N), repeat=N - 2):
        deg = [1] * N
        for c in code:
            deg[c] += 1
        adj = [[] for _ in range(N)]
        deg2 = deg[:]
        import heapq
        leaves = [i for i in range(N) if deg2[i] == 1]
        heapq.heapify(leaves)
        for c in code:
            leaf = heapq.heappop(leaves)
            adj[leaf].append(c); adj[c].append(leaf)
            deg2[c] -= 1
            if deg2[c] == 1:
                heapq.heappush(leaves, c)
        u = heapq.heappop(leaves); v = heapq.heappop(leaves)
        adj[u].append(v); adj[v].append(u)
        par = [None] * N
        order = [0]; seen = [False] * N; seen[0] = True
        for x in order:
            for y in adj[x]:
                if not seen[y]:
                    seen[y] = True; par[y] = x; order.append(y)
        yield par, order

def run(nmax):
    t = Tab(nmax)
    ok_i = ok_ii = ok_iii = True
    for n in range(2, nmax + 1):
        acc_A = {}
        acc_ii = {}
        acc_iii = {}
        for item in trees(n):
            par, order = item if isinstance(item, tuple) else (item, [0, 1])
            N = n + 1
            size = [1] * N
            for x in reversed(order):
                if par[x] is not None:
                    size[par[x]] += size[x]
            # (i)
            for l in range(0, n):
                w = Fr(1)
                for v in range(1, N):
                    if size[v] > l + 1:
                        w *= Fr(l + 1, size[v])
                acc_A[l] = acc_A.get(l, 0) + w
            for k in range(2, n):
                if not (k <= n <= 2 * k - 1):
                    continue
                heavy = [v for v in range(1, N) if size[v] >= k]
                # ancestors (proper, excluding virtual root 0)
                def anc(v):
                    out = []
                    x = par[v]
                    while x != 0:
                        out.append(x); x = par[x]
                    return out
                PA = Fr(0); PB = Fr(0)
                for v in heavy:
                    a = anc(v)
                    pa = Fr(1); pb = Fr(1)
                    for w_ in a:
                        pa *= Fr(k + 1, size[w_]); pb *= Fr(k, size[w_])
                    # descendants of v with size >= k must have D <= k-2
                    desc = Fr(1)
                    for u in heavy:
                        if u != v and v in anc(u):
                            desc *= Fr(k - 1, size[u])
                    PA += Fr(1, size[v]) * desc * (pa - pb)
                    if size[v] == k:
                        PB += Fr(1, k) * pa
                acc_ii[k] = acc_ii.get(k, 0) + 2 * PA - PB
                m = sum(1 for v in range(1, N) if size[v] > k)
                th = sum(1 for v in range(1, N) if size[v] == k)
                W = Fr(1)
                for v in range(1, N):
                    if size[v] > k:
                        W *= Fr(k, size[v])
                acc_iii[k] = acc_iii.get(k, 0) + W * (Fr(k + 1, k) ** m + Fr(k - 1, k) ** m - 2 - Fr(th, k) * Fr(k - 1, k) ** m)
        for l in range(0, n):
            ok_i &= (acc_A[l] == t.a(n, l))
        for k in acc_ii:
            ok_ii &= (acc_ii[k] == t.d(n, k))
            ok_iii &= (acc_iii[k] == t.d(n, k))
        print("n=%d: (i) %s  (ii) columns %s: %s  (iii): %s" % (n, all(acc_A[l] == t.a(n, l) for l in range(n)),
              sorted(acc_ii), all(acc_ii[k] == t.d(n, k) for k in acc_ii), all(acc_iii[k] == t.d(n, k) for k in acc_iii)))
    print("ALL: (i) %s (ii) %s (iii) %s" % (ok_i, ok_ii, ok_iii))

if __name__ == '__main__':
    run(7)
