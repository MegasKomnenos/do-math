# Test 28 (tied to the argument).  The dual certificates of tests 23/27 use the diagonal lower bound only in a band of rows
# around the crossing.  Reading: the positivity of the step at far rows is carried by the survival profile of the window.
# Check on TRUE columns (exact table for Psi_s = A_{s,k-2}/p_s; float kernels of r9faef2b6 Theorem 15 at the critical tilt):
#     eta_n = -J_n + sum_{s=k-1}^{n-2} e_n(s) Psi_s          (first layer).
# For each row n > q0 let  S1(n) := min{ S : -J_n + sum_{s<=S} e_n(s) Psi_s >= 0 }  (the sources up to size S1(n) already
# beat the impulse response at row n; later sources are not needed because e_n(s) >= 0, Psi_s >= 0).
# Output: S1(n) along the layer, its maximum, and the share of the positive part coming from s <= q0 and from s <= q0 + (q0-k).
import sys
import numpy as np
from pf import T
from t24_reference_row import kernels_vec

tab = T(160)

if __name__ == '__main__':
    for k in [int(a) for a in sys.argv[1:]]:
        e, J = kernels_vec(k)
        Psi = np.zeros(2 * k + 1)
        for s in range(k - 1, 2 * k):
            Psi[s] = tab.A(s, k - 2) / tab.p(s)
        q0 = next(n for n in range(k + 1, 2 * k) if tab.d(n, k) > 0)
        eta = {n: -J[n] + float(np.dot(e[n][k - 1:n - 1], Psi[k - 1:n - 1])) for n in range(k, 2 * k)}
        sign_ok = all(eta[n] <= 0 for n in range(k, q0)) and all(eta[n] > 0 for n in range(q0, 2 * k))
        print("k=%d q0=%d (crossing deficit %d): kernel form with the true profile reproduces the sign pattern: %s ; Psi at q0, q0+(q0-k), 2k-1: %.3f, %.3f, %.3f" % (
            k, q0, q0 - k, sign_ok, Psi[q0], Psi[min(2 * q0 - k, 2 * k - 1)], Psi[2 * k - 1]))
        S1 = {}
        for n in range(q0, 2 * k):
            acc = -J[n]
            for S in range(k - 1, n - 1):
                acc += e[n][S] * Psi[S]
                if acc >= 0:
                    S1[n] = S
                    break
        mx = max(S1, key=lambda n: S1[n])
        sample = sorted(set([q0, q0 + 1, q0 + 2, q0 + 5, (q0 + 2 * k) // 2, 2 * k - 5, 2 * k - 1]))
        print("    S1(n) at rows %s: %s" % (sample, [S1[n] for n in sample]))
        print("    max over q0<=n<=2k-1 of S1(n) = %d at n=%d  (that is q0%+d ; in units of the crossing deficit: %.2f)" % (
            S1[mx], mx, S1[mx] - q0, (S1[mx] - k) / (q0 - k)))
        for n in sample:
            pos = float(np.dot(e[n][k - 1:n - 1], Psi[k - 1:n - 1]))
            a = float(np.dot(e[n][k - 1:q0 + 1], Psi[k - 1:q0 + 1])) / pos
            b = float(np.dot(e[n][k - 1:min(2 * q0 - k, n - 2) + 1], Psi[k - 1:min(2 * q0 - k, n - 2) + 1])) / pos
            print("    row %d: positive part / impulse = %.3f ; share of the positive part from s<=q0: %.3f, from s<=q0+(q0-k): %.3f" % (n, pos / J[n], a, b))
