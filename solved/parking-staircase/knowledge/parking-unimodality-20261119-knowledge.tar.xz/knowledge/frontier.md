# Frontier

Revision: 120

## root

# 뿌리 명제: 주차함수 최대 변위 개수열의 단봉성

## 정의

$n\ge1$은 정수다. 길이 $n$의 **선호 수열**은 $\alpha=(a_1,\dots,a_n)\in\{1,\dots,n\}^n$이다. 자리 $1,\dots,n$이 한 줄로 놓여 있고 처음에는 모두 비어 있다. 차 $1,2,\dots,n$이 이 순서로 도착하며, 차 $i$는 자리 $a_i$부터 자리 번호가 커지는 방향으로 살펴 처음 만나는 빈자리에 선다. 자리 $a_i,a_i+1,\dots,n$이 모두 차 있으면 차 $i$는 서지 못한다. 모든 차가 서면 $\alpha$를 **주차함수**라 하고, 길이 $n$의 주차함수 전체의 집합을 $\mathrm{PF}_n$으로 적는다. $|\mathrm{PF}_n|=(n+1)^{n-1}$이다.

$\alpha\in\mathrm{PF}_n$에서 차 $i$가 선 자리를 $\mathrm{pos}_i(\alpha)$라 하면 차 $i$의 **변위**는 $d_i(\alpha)=\mathrm{pos}_i(\alpha)-a_i\ge0$이고, $\alpha$의 **최대 변위**는 $M(\alpha)=\max_{1\le i\le n}d_i(\alpha)\in\{0,1,\dots,n-1\}$이다.

$0\le\ell\le n-1$에 대해
$$
b_{n,\ell}=\#\{\alpha\in\mathrm{PF}_n:\ M(\alpha)=\ell\}
$$
로 둔다. 모든 $\ell$에서 $b_{n,\ell}\ge1$이고 $\sum_{\ell=0}^{n-1}b_{n,\ell}=(n+1)^{n-1}$이다.

유한 수열 $(c_0,\dots,c_m)$이 **단봉**이라는 것은, 어떤 $j^*\in\{0,\dots,m\}$이 있어 $c_{j-1}\le c_j$가 $1\le j\le j^*$에서 성립하고 $c_j\ge c_{j+1}$이 $j^*\le j\le m-1$에서 성립하는 것이다. 등호를 허용한다.

## 명제

**모든 정수 $n\ge1$에 대해 수열 $(b_{n,0},b_{n,1},\dots,b_{n,n-1})$은 단봉이다.**

곧 모든 $n\ge1$에 대해 어떤 $\ell^*\in\{0,\dots,n-1\}$이 있어, $1\le\ell\le\ell^*$에서 $b_{n,\ell-1}\le b_{n,\ell}$이고 $\ell^*\le\ell\le n-2$에서 $b_{n,\ell}\ge b_{n,\ell+1}$이다.

## 확인용 값

| $n$ | $b_{n,0},\dots,b_{n,n-1}$ |
|---|---|
| 1 | 1 |
| 2 | 2, 1 |
| 3 | 6, 7, 3 |
| 4 | 24, 51, 34, 16 |
| 5 | 120, 421, 377, 253, 125 |
| 6 | 720, 3963, 4594, 3688, 2546, 1296 |
| 7 | 5040, 42253, 62145, 57398, 46142, 32359, 16807 |

끝값은 모든 $n$에서 $b_{n,0}=n!$, $b_{n,n-1}=n^{n-2}$($n\ge2$)이다.


State: formal_proved

- proved, formal: [r3d3d37acd8a7446b8f47d472502d231a/s-root-lean](records/r3d3d37acd8a7446b8f47d472502d231a/record.json)
- proved, informal: [rc31497e9df27478584efc43f79e164f2/r-split](records/rc31497e9df27478584efc43f79e164f2/record.json) (derived forward through relation rc31497e9df27478584efc43f79e164f2/r-split)
- proved, informal: [r3e8ad56ece2549449ad86ef9412d9cfa/r-staircase](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json) (derived forward through relation r3e8ad56ece2549449ad86ef9412d9cfa/r-staircase)
- proved, informal: [r6af349eb6a0d4ed29b9650ff599e1e90/r-col-mono-root](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json) (derived forward through relation r6af349eb6a0d4ed29b9650ff599e1e90/r-col-mono-root)
- proved, informal: [r496399b680604ffda982aedf9ac9b480/r-root-from-T](records/r496399b680604ffda982aedf9ac9b480/record.json) (derived forward through relation r496399b680604ffda982aedf9ac9b480/r-root-from-T)
- Relation [rc31497e9df27478584efc43f79e164f2/r-split](records/rc31497e9df27478584efc43f79e164f2/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-part (established), proved s1767abe148714e3680363cbb7fcfa85b-right-half (established)] implies proved root
- Relation [r3e8ad56ece2549449ad86ef9412d9cfa/r-staircase](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved root
- Relation [r6af349eb6a0d4ed29b9650ff599e1e90/r-col-mono-root](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved s589ba7955417484889963b15091eaea6-mono (established)] implies proved root
- Relation [r496399b680604ffda982aedf9ac9b480/r-root-from-T](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-target-t (established)] implies proved root
- Relation [r496399b680604ffda982aedf9ac9b480/r-root-from-X](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-cross-positive (open)] implies proved root

## s1767abe148714e3680363cbb7fcfa85b-left-part

왼쪽 부분 (S_L): 모든 정수 n ≥ 1에 대해, 1 ≤ i ≤ ⌈n/2⌉−1 이고 i < j ≤ n−1 이며 d_{n,i} < 0 < d_{n,j} 인 쌍 (i,j)가 없다. 여기서 d_{n,k} = b_{n,k} − b_{n,k−1} (1 ≤ k ≤ n−1)이고 b_{n,ℓ}는 최대 변위가 ℓ인 길이 n의 주차함수의 수다.

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, formal: [r3d3d37acd8a7446b8f47d472502d231a/s-left-part-lean](records/r3d3d37acd8a7446b8f47d472502d231a/record.json)
- proved, informal: [rc31497e9df27478584efc43f79e164f2/r-left-from-L](records/rc31497e9df27478584efc43f79e164f2/record.json) (derived forward through relation rc31497e9df27478584efc43f79e164f2/r-left-from-L)
- Relation [rc31497e9df27478584efc43f79e164f2/r-split](records/rc31497e9df27478584efc43f79e164f2/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-part (established), proved s1767abe148714e3680363cbb7fcfa85b-right-half (established)] implies proved root
- Relation [rc31497e9df27478584efc43f79e164f2/r-left-from-L](records/rc31497e9df27478584efc43f79e164f2/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-increase (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-part

## s1767abe148714e3680363cbb7fcfa85b-right-half

오른쪽 절반 (S_R): 모든 정수 n ≥ 1에 대해 부분수열 (b_{n,ℓ})_{ℓ=⌈n/2⌉−1}^{n−1} 이 단봉이다. 같은 말로, 모든 n ≥ 1에 대해 ⌈n/2⌉ ≤ i < j ≤ n−1 이고 d_{n,i} < 0 < d_{n,j} 인 쌍 (i,j)가 없다 (d_{n,k} = b_{n,k} − b_{n,k−1}).

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, formal: [rebe4c3c586f8412f9ca91016f9ca5936/s-right-half-lean](records/rebe4c3c586f8412f9ca91016f9ca5936/record.json)
- proved, informal: [re8460c24720d4fdeaed189d466393fb7/r-chain-column-right-half](records/re8460c24720d4fdeaed189d466393fb7/record.json) (derived forward through relation re8460c24720d4fdeaed189d466393fb7/r-chain-column-right-half)
- proved, informal: [ra9096d37fc5a49109bb796f28d23e65e/r-SR-from-mono265-assembled](records/ra9096d37fc5a49109bb796f28d23e65e/record.json) (derived forward through relation ra9096d37fc5a49109bb796f28d23e65e/r-SR-from-mono265-assembled)
- proved, informal: [r43fbfedfdc19477aab896641475ff59a/rel-staircase](records/r43fbfedfdc19477aab896641475ff59a/record.json) (derived forward through relation r43fbfedfdc19477aab896641475ff59a/rel-staircase)
- proved, informal: [r496399b680604ffda982aedf9ac9b480/r-SR-from-TR](records/r496399b680604ffda982aedf9ac9b480/record.json) (derived forward through relation r496399b680604ffda982aedf9ac9b480/r-SR-from-TR)
- Relation [rc31497e9df27478584efc43f79e164f2/r-split](records/rc31497e9df27478584efc43f79e164f2/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-part (established), proved s1767abe148714e3680363cbb7fcfa85b-right-half (established)] implies proved root
- Relation [r213dbe848e5c4e8483afbcbfe76addec/r-right-half-from-Z](records/r213dbe848e5c4e8483afbcbfe76addec/record.json), supported: [proved s5f0f1c352b0341ff8368c0880d59ad3a-row-squeeze (open)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [r43fbfedfdc19477aab896641475ff59a/rel-staircase](records/r43fbfedfdc19477aab896641475ff59a/record.json), supported: [proved sce92ef565bb74f57b5f160372b12dacc-col-right-half (established), proved sce92ef565bb74f57b5f160372b12dacc-diag-right-half (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [re8460c24720d4fdeaed189d466393fb7/r-chain-column-right-half](records/re8460c24720d4fdeaed189d466393fb7/record.json), supported: [proved s14729ca7935441058777b96536417512-chain-column (established), proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [r496399b680604ffda982aedf9ac9b480/r-SR-from-TR](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-right-target (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [ra9096d37fc5a49109bb796f28d23e65e/r-SR-from-mono265-assembled](records/ra9096d37fc5a49109bb796f28d23e65e/record.json), supported: [proved s2cc6d28758964f9f86c532d5ef5152b6-mono-265 (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half

## s1767abe148714e3680363cbb7fcfa85b-left-increase

왼쪽 증가 (L): 모든 정수 k ≥ 6과 n ≥ 2k+1에 대해 b_{n,k} ≥ b_{n,k−1} 이다. 여기서 b_{n,ℓ}는 최대 변위가 ℓ인 길이 n의 주차함수의 수다.

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [r13b1cc32f3bc4469adc3257d0c2d662c/s-left-increase-by-citation](records/r13b1cc32f3bc4469adc3257d0c2d662c/record.json)
- proved, formal: [r3d3d37acd8a7446b8f47d472502d231a/s-left-increase-lean](records/r3d3d37acd8a7446b8f47d472502d231a/record.json)
- proved, formal: [r3d3d37acd8a7446b8f47d472502d231a/s-left-increase-lean-reduced](records/r3d3d37acd8a7446b8f47d472502d231a/record.json)
- proved, informal: [ra98af63d956e4b288dd1550e0a4853df/r-L-from-Col](records/ra98af63d956e4b288dd1550e0a4853df/record.json) (derived forward through relation ra98af63d956e4b288dd1550e0a4853df/r-L-from-Col)
- Relation [rc31497e9df27478584efc43f79e164f2/r-left-from-L](records/rc31497e9df27478584efc43f79e164f2/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-increase (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-part
- Relation [rf9e63ea4495b446f8f5d48a74525d8d1/r-left-increase-from-size-split](records/rf9e63ea4495b446f8f5d48a74525d8d1/record.json), supported: [proved s9363cd02c1664922badc06182672ae91-size-convexity (established), proved s9363cd02c1664922badc06182672ae91-wave-bracket (open)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-increase
- Relation [r496399b680604ffda982aedf9ac9b480/r-T-from-L-TR](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-increase (established), proved sccddb292c4544658855ec4b22ff21237-right-target (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t
- Relation [re61cc9dab20e4d54b6adb052a2538c5a/r-critical-brackets-left-increase](records/re61cc9dab20e4d54b6adb052a2538c5a/record.json), supported: [proved sd95debf787d942a9bbd01ab011941d48-critical-base (open), proved sd95debf787d942a9bbd01ab011941d48-column-growth-bound (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-increase
- Relation [ra98af63d956e4b288dd1550e0a4853df/r-L-from-Col](records/ra98af63d956e4b288dd1550e0a4853df/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-increase
- Relation [r69068ac5755e47bf83611f535d8af02c/r-Col-from-L](records/r69068ac5755e47bf83611f535d8af02c/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-increase (established)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-col

## sd7fc9a192dfc4b9193e714f314b156f5-col

(Col) 주차함수의 최대 변위 개수 b_{n,ℓ}(뿌리 명제의 정의: b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수)에 대해 d_{n,k}:=b_{n,k}-b_{n,k-1} (1≤k≤n-1)로 둔다. 모든 정수 n≥2와 1≤k≤n-1에 대해, d_{n,k}≥0이면 d_{n+1,k}≥0이다.

State: informal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [r1c0e811e81ba4853a38d09512246b086/s-col-by-citation](records/r1c0e811e81ba4853a38d09512246b086/record.json)
- proved, informal: [ra98af63d956e4b288dd1550e0a4853df/r-Col-from-T](records/ra98af63d956e4b288dd1550e0a4853df/record.json) (derived forward through relation ra98af63d956e4b288dd1550e0a4853df/r-Col-from-T)
- proved, informal: [r69068ac5755e47bf83611f535d8af02c/r-Col-from-L](records/r69068ac5755e47bf83611f535d8af02c/record.json) (derived forward through relation r69068ac5755e47bf83611f535d8af02c/r-Col-from-L)
- Relation [r3e8ad56ece2549449ad86ef9412d9cfa/r-staircase](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved root
- Relation [r43fbfedfdc19477aab896641475ff59a/rel-col-restrict](records/r43fbfedfdc19477aab896641475ff59a/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established)] implies proved sce92ef565bb74f57b5f160372b12dacc-col-right-half
- Relation [r6af349eb6a0d4ed29b9650ff599e1e90/r-col-mono-root](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved s589ba7955417484889963b15091eaea6-mono (established)] implies proved root
- Relation [rf9e63ea4495b446f8f5d48a74525d8d1/r-col-from-sp](records/rf9e63ea4495b446f8f5d48a74525d8d1/record.json), supported: [proved s9363cd02c1664922badc06182672ae91-sp (open)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-col
- Relation [r496399b680604ffda982aedf9ac9b480/r-T-from-Col-CI](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t
- Relation [ra98af63d956e4b288dd1550e0a4853df/r-L-from-Col](records/ra98af63d956e4b288dd1550e0a4853df/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-increase
- Relation [ra98af63d956e4b288dd1550e0a4853df/r-Col-from-T](records/ra98af63d956e4b288dd1550e0a4853df/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-target-t (established)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-col
- Relation [r69068ac5755e47bf83611f535d8af02c/r-Col-from-L](records/r69068ac5755e47bf83611f535d8af02c/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-increase (established)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-col
- Relation [r3bd6df852c694ee299e0f7581899e222/r-col-from-DR](records/r3bd6df852c694ee299e0f7581899e222/record.json), supported: [proved sd1a039f9ad7c47388167e6d96fd26850-debt-repayment (open)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-col

## sd7fc9a192dfc4b9193e714f314b156f5-diag

(Diag) 주차함수의 최대 변위 개수 b_{n,ℓ}(뿌리 명제의 정의: b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수)에 대해 d_{n,k}:=b_{n,k}-b_{n,k-1} (1≤k≤n-1)로 둔다. 모든 정수 n≥2와 1≤k≤n-1에 대해, d_{n,k}≤0이면 d_{n+1,k+1}≤0이다.

State: informal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [ra172c21a34bb43be9f0df045d6c8937f/s-diag-by-citation](records/ra172c21a34bb43be9f0df045d6c8937f/record.json)
- proved, informal: [ra172c21a34bb43be9f0df045d6c8937f/r-diag-from-ci](records/ra172c21a34bb43be9f0df045d6c8937f/record.json) (derived forward through relation ra172c21a34bb43be9f0df045d6c8937f/r-diag-from-ci)
- Relation [r3e8ad56ece2549449ad86ef9412d9cfa/r-staircase](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved root
- Relation [r43fbfedfdc19477aab896641475ff59a/rel-diag-restrict](records/r43fbfedfdc19477aab896641475ff59a/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved sce92ef565bb74f57b5f160372b12dacc-diag-right-half
- Relation [re8460c24720d4fdeaed189d466393fb7/r-chain-column-right-half](records/re8460c24720d4fdeaed189d466393fb7/record.json), supported: [proved s14729ca7935441058777b96536417512-chain-column (established), proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [r6af349eb6a0d4ed29b9650ff599e1e90/r-diag-mono](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved s589ba7955417484889963b15091eaea6-mono
- Relation [r69068ac5755e47bf83611f535d8af02c/r-T-from-Diag-CI](records/r69068ac5755e47bf83611f535d8af02c/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t
- Relation [ra172c21a34bb43be9f0df045d6c8937f/r-diag-from-ci](records/ra172c21a34bb43be9f0df045d6c8937f/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-diag

## s5f0f1c352b0341ff8368c0880d59ad3a-row-squeeze

행의 조임 판정 (Z): 모든 정수 N≥32에 대해 다음이 성립한다. b_{n,ℓ}를 최대 변위가 ℓ인 길이 n의 주차함수의 수라 하고, r≤1과 r>N에서 u(r)=0, 2≤r≤N에서 u(r)=b_{N-1,N-r}로 둔다. x(r)=u(r-1)-u(r), Bor(m)=e^{-m}m^{m-1}/m! (m≥1), 3≤r≤N-1에서 E(r)=[(N/(N-r))·x(r) - Σ_{γ=1}^{r-2} Bor(γ)·x(r-γ)]/u(r-1), r_1=min{r≥2: u(r+1)≤u(r)}라 하면, r_1+2≤r_2≤⌊(N+3)/2⌋인 모든 정수 r_2에서 E(r_2) ≥ min{Bor(r_2-r_1-1), (Bor(r_2-2)/Bor(r_1-1))·E(r_1+1)}이다.

State: unresolved

Path to root: on a sufficient path to the root: its proof can carry the root

- Relation [r213dbe848e5c4e8483afbcbfe76addec/r-right-half-from-Z](records/r213dbe848e5c4e8483afbcbfe76addec/record.json), supported: [proved s5f0f1c352b0341ff8368c0880d59ad3a-row-squeeze (open)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half

## sce92ef565bb74f57b5f160372b12dacc-col-right-half

오른쪽 절반을 위한 열 방향 계단 명제 (Col$_1$): 정수 $n,k$가 $1\le k\le n-1$과 $n+1\le2k$를 만족하고 $d_{n,k}\ge0$이면 $d_{n+1,k}\ge0$이다. 여기서 $d_{n,k}=b_{n,k}-b_{n,k-1}$이고 $b_{n,\ell}$은 뿌리 명제의 수(최대 변위가 정확히 $\ell$인 길이 $n$의 주차함수의 수)다. 전선의 노드 (Col)의 정의역에 $n+1\le2k$를 더한 것이다.

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [rb18f76a752b6471abdeb2bcbb10b328a/s-col1-by-citation](records/rb18f76a752b6471abdeb2bcbb10b328a/record.json)
- proved, formal: [r27a01811437f4368a2d389bfa94ab44e/s-col1-lean](records/r27a01811437f4368a2d389bfa94ab44e/record.json)
- proved, formal: [r27a01811437f4368a2d389bfa94ab44e/s-col1-lean-table](records/r27a01811437f4368a2d389bfa94ab44e/record.json)
- proved, informal: [r43fbfedfdc19477aab896641475ff59a/rel-col-restrict](records/r43fbfedfdc19477aab896641475ff59a/record.json) (derived forward through relation r43fbfedfdc19477aab896641475ff59a/rel-col-restrict)
- Relation [r43fbfedfdc19477aab896641475ff59a/rel-staircase](records/r43fbfedfdc19477aab896641475ff59a/record.json), supported: [proved sce92ef565bb74f57b5f160372b12dacc-col-right-half (established), proved sce92ef565bb74f57b5f160372b12dacc-diag-right-half (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [r43fbfedfdc19477aab896641475ff59a/rel-col-restrict](records/r43fbfedfdc19477aab896641475ff59a/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established)] implies proved sce92ef565bb74f57b5f160372b12dacc-col-right-half
- Relation [r496399b680604ffda982aedf9ac9b480/r-TR-from-Col1-CI](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sce92ef565bb74f57b5f160372b12dacc-col-right-half (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-right-target

## sce92ef565bb74f57b5f160372b12dacc-diag-right-half

오른쪽 절반을 위한 대각 방향 계단 명제 (Diag$_1$): 정수 $n,k$가 $1\le k\le n-1$과 $n\le2k-1$을 만족하고 $d_{n,k}\le0$이면 $d_{n+1,k+1}\le0$이다. 여기서 $d_{n,k}=b_{n,k}-b_{n,k-1}$이고 $b_{n,\ell}$은 뿌리 명제의 수다. 전선의 노드 (Diag)의 정의역에 $n\le2k-1$을 더한 것이다.

State: informal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [r43fbfedfdc19477aab896641475ff59a/rel-diag-restrict](records/r43fbfedfdc19477aab896641475ff59a/record.json) (derived forward through relation r43fbfedfdc19477aab896641475ff59a/rel-diag-restrict)
- proved, informal: [r692807de92c14aadbf55edb159c65717/r-diag1-from-C-CI](records/r692807de92c14aadbf55edb159c65717/record.json) (derived forward through relation r692807de92c14aadbf55edb159c65717/r-diag1-from-C-CI)
- Relation [r43fbfedfdc19477aab896641475ff59a/rel-staircase](records/r43fbfedfdc19477aab896641475ff59a/record.json), supported: [proved sce92ef565bb74f57b5f160372b12dacc-col-right-half (established), proved sce92ef565bb74f57b5f160372b12dacc-diag-right-half (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [r43fbfedfdc19477aab896641475ff59a/rel-diag-restrict](records/r43fbfedfdc19477aab896641475ff59a/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved sce92ef565bb74f57b5f160372b12dacc-diag-right-half
- Relation [r692807de92c14aadbf55edb159c65717/r-diag1-from-C-CI](records/r692807de92c14aadbf55edb159c65717/record.json), supported: [proved s14729ca7935441058777b96536417512-chain-column (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sce92ef565bb74f57b5f160372b12dacc-diag-right-half

## s14729ca7935441058777b96536417512-chain-column

(C) 사슬 영역의 열 방향 부호 지속: 모든 정수 k ≥ 2와 k+1 ≤ n ≤ 2k−2에 대해, d_{n,k} > 0이면 d_{n+1,k} > 0이다. 여기서 d_{n,k} = b_{n,k} − b_{n,k−1}이고 b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수다(뿌리 명제의 정의).

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [rb18f76a752b6471abdeb2bcbb10b328a/s-chain-column-by-citation](records/rb18f76a752b6471abdeb2bcbb10b328a/record.json)
- proved, formal: [r538f630c19c6415fbdd7d25f93620929/s-chain-column-lean](records/r538f630c19c6415fbdd7d25f93620929/record.json)
- Relation [re8460c24720d4fdeaed189d466393fb7/r-chain-column-right-half](records/re8460c24720d4fdeaed189d466393fb7/record.json), supported: [proved s14729ca7935441058777b96536417512-chain-column (established), proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [r692807de92c14aadbf55edb159c65717/r-diag1-from-C-CI](records/r692807de92c14aadbf55edb159c65717/record.json), supported: [proved s14729ca7935441058777b96536417512-chain-column (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sce92ef565bb74f57b5f160372b12dacc-diag-right-half

## s589ba7955417484889963b15091eaea6-mono

(Mono) 주차함수의 최대 변위 개수 b_{n,ℓ}(뿌리 명제의 정의: b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수)에 대해 d_{n,k}:=b_{n,k}-b_{n,k-1} (1≤k≤n-1)로 둔다. 모든 정수 n≥3과 1≤k≤n-2에 대해, k+1≤j≤n인 모든 정수 j에서 d_{j,k}≤0이면 d_{n,k+1}≤0이다.

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, formal: [r5a5749f372b3434a9ab60fd9c404fff0/s-mono-lean](records/r5a5749f372b3434a9ab60fd9c404fff0/record.json)
- proved, formal: [r5a5749f372b3434a9ab60fd9c404fff0/s-mono-lean-via-chain](records/r5a5749f372b3434a9ab60fd9c404fff0/record.json)
- proved, informal: [r6af349eb6a0d4ed29b9650ff599e1e90/r-diag-mono](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json) (derived forward through relation r6af349eb6a0d4ed29b9650ff599e1e90/r-diag-mono)
- proved, informal: [r496399b680604ffda982aedf9ac9b480/r-Mono-from-CI](records/r496399b680604ffda982aedf9ac9b480/record.json) (derived forward through relation r496399b680604ffda982aedf9ac9b480/r-Mono-from-CI)
- proved, informal: [rdf5f9d9da43245b0a1fd735e5e968b2e/r-mono-from-mono265](records/rdf5f9d9da43245b0a1fd735e5e968b2e/record.json) (derived forward through relation rdf5f9d9da43245b0a1fd735e5e968b2e/r-mono-from-mono265)
- Relation [r6af349eb6a0d4ed29b9650ff599e1e90/r-col-mono-root](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved s589ba7955417484889963b15091eaea6-mono (established)] implies proved root
- Relation [r6af349eb6a0d4ed29b9650ff599e1e90/r-diag-mono](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established)] implies proved s589ba7955417484889963b15091eaea6-mono
- Relation [r496399b680604ffda982aedf9ac9b480/r-Mono-from-CI](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved s589ba7955417484889963b15091eaea6-mono
- Relation [rdf5f9d9da43245b0a1fd735e5e968b2e/r-mono-from-mono265](records/rdf5f9d9da43245b0a1fd735e5e968b2e/record.json), supported: [proved s2cc6d28758964f9f86c532d5ef5152b6-mono-265 (established)] implies proved s589ba7955417484889963b15091eaea6-mono

## s9363cd02c1664922badc06182672ae91-sp

차분의 성장 부등식 (SP): b_{n,ℓ}를 최대 변위가 ℓ인 길이 n의 주차함수의 수, A_{n,ℓ} = Σ_{j≤ℓ} b_{n,j} (A_{0,ℓ} = 1)라 하자. 정수 m ≥ 2와 1 ≤ y ≤ m−1에 대해 𝔞_N = A_{N,y−1}/N! (N ≥ 0), ℛ_N = 𝔞_N + Σ_{t=1}^{N} (y/(t+y))·ℛ_{t−1}·𝔞_{N−t} (N ≥ 0; ℛ_0 = 1), D_m(y) = C(m,y)·(y+1)^{y−1}·(m−y)!·ℛ_{m−y}로 둔다. 모든 정수 m ≥ 2와 1 ≤ y ≤ m−1에 대해 b_{m,y−1}·(b_{m+1,y} − D_m(y)) ≥ b_{m,y}·(b_{m+1,y−1} − D_m(y))이다.

State: unresolved

Path to root: on a sufficient path to the root: its proof can carry the root

- Relation [rf9e63ea4495b446f8f5d48a74525d8d1/r-col-from-sp](records/rf9e63ea4495b446f8f5d48a74525d8d1/record.json), supported: [proved s9363cd02c1664922badc06182672ae91-sp (open)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-col

## s9363cd02c1664922badc06182672ae91-size-convexity

크기 볼록성 (L1°): A_{n,ℓ}를 최대 변위가 ℓ 이하인 길이 n의 주차함수의 수, p_n = (n+1)^{n−1}이라 하자. 모든 정수 k ≥ 12와 n ≥ 2k+1에 대해 A_{n−1,k−1}/p_{n−1} − 2·A_{n,k−1}/p_n + A_{n+1,k−1}/p_{n+1} ≥ 0이다. (같은 말로, 문턱 k를 고정한 확률 Pr(M_n < k)의 n에 대한 둘째 차분이 n ≥ 2k+1에서 음이 아니다.)

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [rfaf06c62ef70496eab6c1f5b1222dffa/s-size-convexity-base](records/rfaf06c62ef70496eab6c1f5b1222dffa/record.json)
- proved, formal: [rabec23737b7b45e498ef30b19dfc93a9/s-size-convexity-lean](records/rabec23737b7b45e498ef30b19dfc93a9/record.json)
- Relation [rf9e63ea4495b446f8f5d48a74525d8d1/r-left-increase-from-size-split](records/rf9e63ea4495b446f8f5d48a74525d8d1/record.json), supported: [proved s9363cd02c1664922badc06182672ae91-size-convexity (established), proved s9363cd02c1664922badc06182672ae91-wave-bracket (open)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-increase

## s9363cd02c1664922badc06182672ae91-wave-bracket

파동 부등식 (L2°): A_{n,ℓ}를 최대 변위가 ℓ 이하인 길이 n의 주차함수의 수, p_n = (n+1)^{n−1}이라 하자. 모든 정수 k ≥ 12와 n ≥ max(2k+1, 41)에 대해 (A_{n,k} + A_{n,k−2})/p_n ≥ A_{n−1,k−1}/p_{n−1} + A_{n+1,k−1}/p_{n+1}이다.

State: unresolved

Path to root: on a sufficient path to the root: its proof can carry the root

- Relation [rf9e63ea4495b446f8f5d48a74525d8d1/r-left-increase-from-size-split](records/rf9e63ea4495b446f8f5d48a74525d8d1/record.json), supported: [proved s9363cd02c1664922badc06182672ae91-size-convexity (established), proved s9363cd02c1664922badc06182672ae91-wave-bracket (open)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-increase

## sccddb292c4544658855ec4b22ff21237-target-t

목표 T: 모든 정수 n≥301과 1≤k≤n−1, k²<(n−k)³인 모든 정수 k에 대해 b_{n,k} ≥ b_{n,k−1}이다. 여기서 b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수(뿌리 명제의 정의)다.

State: informal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [r496399b680604ffda982aedf9ac9b480/r-T-from-Col-CI](records/r496399b680604ffda982aedf9ac9b480/record.json) (derived forward through relation r496399b680604ffda982aedf9ac9b480/r-T-from-Col-CI)
- proved, informal: [r69068ac5755e47bf83611f535d8af02c/r-T-from-Diag-CI](records/r69068ac5755e47bf83611f535d8af02c/record.json) (derived forward through relation r69068ac5755e47bf83611f535d8af02c/r-T-from-Diag-CI)
- proved, informal: [r496399b680604ffda982aedf9ac9b480/r-T-from-L-TR](records/r496399b680604ffda982aedf9ac9b480/record.json) (derived forward through relation r496399b680604ffda982aedf9ac9b480/r-T-from-L-TR)
- Relation [r496399b680604ffda982aedf9ac9b480/r-root-from-T](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-target-t (established)] implies proved root
- Relation [r496399b680604ffda982aedf9ac9b480/r-T-from-L-TR](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-increase (established), proved sccddb292c4544658855ec4b22ff21237-right-target (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t
- Relation [r496399b680604ffda982aedf9ac9b480/r-T-from-Col-CI](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t
- Relation [ra98af63d956e4b288dd1550e0a4853df/r-Col-from-T](records/ra98af63d956e4b288dd1550e0a4853df/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-target-t (established)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-col
- Relation [r69068ac5755e47bf83611f535d8af02c/r-T-from-Diag-CI](records/r69068ac5755e47bf83611f535d8af02c/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t

## sccddb292c4544658855ec4b22ff21237-right-target

오른쪽 목표 (T_R): 모든 정수 n≥301과 ⌈n/2⌉≤k≤n−1, k²<(n−k)³인 모든 정수 k에 대해 b_{n,k} ≥ b_{n,k−1}이다. 여기서 b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수다.

State: informal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [r496399b680604ffda982aedf9ac9b480/r-TR-from-Col1-CI](records/r496399b680604ffda982aedf9ac9b480/record.json) (derived forward through relation r496399b680604ffda982aedf9ac9b480/r-TR-from-Col1-CI)
- Relation [r496399b680604ffda982aedf9ac9b480/r-T-from-L-TR](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved s1767abe148714e3680363cbb7fcfa85b-left-increase (established), proved sccddb292c4544658855ec4b22ff21237-right-target (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t
- Relation [r496399b680604ffda982aedf9ac9b480/r-SR-from-TR](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-right-target (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [r496399b680604ffda982aedf9ac9b480/r-TR-from-Col1-CI](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sce92ef565bb74f57b5f160372b12dacc-col-right-half (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-right-target
- Relation [r21b6d042fd634a489fd8efa89c9ac103/r-TR-from-CI-D-E](records/r21b6d042fd634a489fd8efa89c9ac103/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-curve-increase (established), proved s013ee63e6b024008b3c2a35b5c10639b-first-layer-convexity (established), proved s013ee63e6b024008b3c2a35b5c10639b-first-layer-curvature-bound (open)] implies proved sccddb292c4544658855ec4b22ff21237-right-target

## sccddb292c4544658855ec4b22ff21237-curve-increase

곡선 위의 증가 (CI): 정수 k≥1에 대해 r_c(k)를 r³>k²인 가장 작은 양의 정수 r이라 하자. 모든 정수 k≥260에 대해 n=k+r_c(k)일 때 b_{n,k} > b_{n,k−1}이다. 여기서 b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수다.

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [rdc057f21424e4244a822c8442c8b3a82/s-curve-increase-same-end](records/rdc057f21424e4244a822c8442c8b3a82/record.json)
- proved, formal: [rd4cb2be45b6c4d3eb3936b0bb8f7bc6a/s-curve-increase-lean](records/rd4cb2be45b6c4d3eb3936b0bb8f7bc6a/record.json)
- Relation [r496399b680604ffda982aedf9ac9b480/r-T-from-Col-CI](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-col (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t
- Relation [r496399b680604ffda982aedf9ac9b480/r-TR-from-Col1-CI](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sce92ef565bb74f57b5f160372b12dacc-col-right-half (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-right-target
- Relation [r496399b680604ffda982aedf9ac9b480/r-Mono-from-CI](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved s589ba7955417484889963b15091eaea6-mono
- Relation [r21b6d042fd634a489fd8efa89c9ac103/r-TR-from-CI-D-E](records/r21b6d042fd634a489fd8efa89c9ac103/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-curve-increase (established), proved s013ee63e6b024008b3c2a35b5c10639b-first-layer-convexity (established), proved s013ee63e6b024008b3c2a35b5c10639b-first-layer-curvature-bound (open)] implies proved sccddb292c4544658855ec4b22ff21237-right-target
- Relation [r69068ac5755e47bf83611f535d8af02c/r-T-from-Diag-CI](records/r69068ac5755e47bf83611f535d8af02c/record.json), supported: [proved sd7fc9a192dfc4b9193e714f314b156f5-diag (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sccddb292c4544658855ec4b22ff21237-target-t
- Relation [r692807de92c14aadbf55edb159c65717/r-diag1-from-C-CI](records/r692807de92c14aadbf55edb159c65717/record.json), supported: [proved s14729ca7935441058777b96536417512-chain-column (established), proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sce92ef565bb74f57b5f160372b12dacc-diag-right-half
- Relation [ra172c21a34bb43be9f0df045d6c8937f/r-diag-from-ci](records/ra172c21a34bb43be9f0df045d6c8937f/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-curve-increase (established)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-diag

## sccddb292c4544658855ec4b22ff21237-cross-positive

교차곱의 양성 (X): 모든 정수 n≥3과 1≤k≤n−2에 대해 B⁺_{n,k}·(b_{n,k}−b_{n,k−1}) > B⁻_{n,k}·(b_{n,k+1}−b_{n,k})이다. 여기서 b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수이고, Z_n(j)는 모든 변위가 j보다 작은 길이 n의 주차함수의 수(Z_n(0)=0)이며, K_{n,k}(y)=Σ_F Π_{v: t_v>k} y/t_v (F는 꼭짓점 집합 {1,…,n} 위의 뿌리 있는 표지 숲 전체, t_v는 v와 그 자손의 수), B⁻_{n,k}=K_{n,k}(k−1)−Z_n(k−1), B⁺_{n,k}=K_{n,k}(k+2)−Z_n(k+2)다.

State: unresolved

Path to root: on a sufficient path to the root: its proof can carry the root

- Relation [r496399b680604ffda982aedf9ac9b480/r-root-from-X](records/r496399b680604ffda982aedf9ac9b480/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-cross-positive (open)] implies proved root

## sd95debf787d942a9bbd01ab011941d48-critical-base

(Base) 주차함수의 누적 개수 A_{n,ℓ}(최대 변위가 ℓ 이하인 길이 n의 주차함수의 수; A_{0,ℓ}=1)에 대해 b^T_{m,ℓ} := min(m,ℓ+1)·A_{m-1,ℓ} − min(m,ℓ)·A_{m-1,ℓ-1}로 두고, 정수 k≥2에 대해 r_k := (1+1/k)^{k-1}, x_k := 1/r_k로 둔다. 모든 정수 k≥148과 k+1≤i≤2k+1인 모든 정수 i에 대해 Σ_{m=i}^{2k+1} (b^T_{m,k} − r_k·m·b^T_{m-1,k-1})·x_k^m/m! ≥ 0 이다.

State: unresolved

Path to root: on a sufficient path to the root: its proof can carry the root

- Relation [re61cc9dab20e4d54b6adb052a2538c5a/r-critical-brackets-left-increase](records/re61cc9dab20e4d54b6adb052a2538c5a/record.json), supported: [proved sd95debf787d942a9bbd01ab011941d48-critical-base (open), proved sd95debf787d942a9bbd01ab011941d48-column-growth-bound (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-increase

## sd95debf787d942a9bbd01ab011941d48-column-growth-bound

(CB) 주차함수의 최대 변위 개수 b_{n,ℓ}(뿌리 명제의 정의: b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수)에 대해, 모든 정수 k≥148과 n≥2k+1에서 b_{n,k-1} ≤ (1+1/k)^{k-1}·n·b_{n-1,k-1} 이다.

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [r26911cae02f14f81a380e7f04043ba60/s-column-growth-bound-reduced](records/r26911cae02f14f81a380e7f04043ba60/record.json)
- proved, formal: [r78a97aa6366143f48e5a21471b5204ab/s-column-growth-bound-lean](records/r78a97aa6366143f48e5a21471b5204ab/record.json)
- Relation [re61cc9dab20e4d54b6adb052a2538c5a/r-critical-brackets-left-increase](records/re61cc9dab20e4d54b6adb052a2538c5a/record.json), supported: [proved sd95debf787d942a9bbd01ab011941d48-critical-base (open), proved sd95debf787d942a9bbd01ab011941d48-column-growth-bound (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-left-increase

## s013ee63e6b024008b3c2a35b5c10639b-first-layer-convexity

첫 층의 대각 볼록성 (D): A_{n,ℓ}는 최대 변위가 ℓ 이하인 길이 n의 주차함수의 수(A_{0,ℓ}=1; n≥1이고 ℓ<0이면 0)이고 x_k=(k/(k+1))^{k−1}이다. 모든 정수 k≥301과 k+1≤t≤2k−1에 대해 (k+1)·x_k²·A_{t,k} − 2k(t+1)·x_k·A_{t−1,k−1} + (k−1)·t(t+1)·A_{t−2,k−2} ≥ 0이다.

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [r26911cae02f14f81a380e7f04043ba60/s-first-layer-convexity-structural](records/r26911cae02f14f81a380e7f04043ba60/record.json)
- proved, formal: [r8a9fd8d84b8a42dfae7af780e65b092e/s-node-D-lean-tree](records/r8a9fd8d84b8a42dfae7af780e65b092e/record.json)
- proved, formal: [r8a9fd8d84b8a42dfae7af780e65b092e/s-node-D-lean-theoremA](records/r8a9fd8d84b8a42dfae7af780e65b092e/record.json)
- Relation [r21b6d042fd634a489fd8efa89c9ac103/r-TR-from-CI-D-E](records/r21b6d042fd634a489fd8efa89c9ac103/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-curve-increase (established), proved s013ee63e6b024008b3c2a35b5c10639b-first-layer-convexity (established), proved s013ee63e6b024008b3c2a35b5c10639b-first-layer-curvature-bound (open)] implies proved sccddb292c4544658855ec4b22ff21237-right-target

## s013ee63e6b024008b3c2a35b5c10639b-first-layer-curvature-bound

첫 층의 곡률 상계 (E): A_{n,ℓ}는 최대 변위가 ℓ 이하인 길이 n의 주차함수의 수(A_{0,ℓ}=1; n≥1이고 ℓ<0이면 0), x_k=(k/(k+1))^{k−1}, r_c(k)는 r³>k²인 가장 작은 양의 정수 r이다. 모든 정수 k≥301과 k+r_c(k)+1≤t≤2k−1에 대해 (k+1)·x_k²·A_{t,k} − 2k(t+1)·x_k·A_{t−1,k−1} + (k−1)·t(t+1)·A_{t−2,k−2} ≤ (t+1)·x_k·(A_{t−1,k} − A_{t−1,k−2})이다.

State: unresolved

Path to root: on a sufficient path to the root: its proof can carry the root

- Relation [r21b6d042fd634a489fd8efa89c9ac103/r-TR-from-CI-D-E](records/r21b6d042fd634a489fd8efa89c9ac103/record.json), supported: [proved sccddb292c4544658855ec4b22ff21237-curve-increase (established), proved s013ee63e6b024008b3c2a35b5c10639b-first-layer-convexity (established), proved s013ee63e6b024008b3c2a35b5c10639b-first-layer-curvature-bound (open)] implies proved sccddb292c4544658855ec4b22ff21237-right-target

## s2cc6d28758964f9f86c532d5ef5152b6-mono-265

(Mono_265) 주차함수의 최대 변위 개수 b_{n,ℓ}(뿌리 명제의 정의: b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수)에 대해 d_{n,k}:=b_{n,k}−b_{n,k−1} (1≤k≤n−1)로 둔다. 모든 정수 k≥265와 n≥k+2에 대해, k+1≤j≤n인 모든 정수 j에서 d_{j,k}≤0이면 d_{n,k+1}≤0이다. (전선의 노드 (Mono)의 진술을 열 k≥265로 제한한 것이다.)

State: formal_proved

Path to root: on a sufficient path to the root: its proof can carry the root

- proved, informal: [r7ce45a38dbe5465f8c4743ade1788843/s-mono265-reduced](records/r7ce45a38dbe5465f8c4743ade1788843/record.json)
- proved, formal: [r3e5dcd7efa4b413b98e1597120a4dc18/s-mono265-lean](records/r3e5dcd7efa4b413b98e1597120a4dc18/record.json)
- Relation [ra9096d37fc5a49109bb796f28d23e65e/r-SR-from-mono265-assembled](records/ra9096d37fc5a49109bb796f28d23e65e/record.json), supported: [proved s2cc6d28758964f9f86c532d5ef5152b6-mono-265 (established)] implies proved s1767abe148714e3680363cbb7fcfa85b-right-half
- Relation [rdf5f9d9da43245b0a1fd735e5e968b2e/r-mono-from-mono265](records/rdf5f9d9da43245b0a1fd735e5e968b2e/record.json), supported: [proved s2cc6d28758964f9f86c532d5ef5152b6-mono-265 (established)] implies proved s589ba7955417484889963b15091eaea6-mono

## sd1a039f9ad7c47388167e6d96fd26850-debt-repayment

(DR) 첫 층의 빚 갚기: 모든 정수 k≥160에 대해 Σ_{j=k}^{2k} x_k^j·(b_{j,k}−b_{j,k−1})/j! ≥ 0이다. 여기서 x_k=(k/(k+1))^{k−2}이고 b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수(뿌리 명제의 정의; ℓ≥n이면 0)다. 같은 말로, 모든 정수 k≥160에 대해 정수 Σ_{j=k}^{2k}(b_{j,k}−b_{j,k−1})·k^{(k−2)j}·(k+1)^{(k−2)(2k−j)}·(2k)!/j!가 음이 아니다.

State: unresolved

Path to root: on a sufficient path to the root: its proof can carry the root

- Relation [r3bd6df852c694ee299e0f7581899e222/r-col-from-DR](records/r3bd6df852c694ee299e0f7581899e222/record.json), supported: [proved sd1a039f9ad7c47388167e6d96fd26850-debt-repayment (open)] implies proved sd7fc9a192dfc4b9193e714f314b156f5-col

# Questions

## q0

The root problem itself, taken as a whole.

Grounds: An explorer holding this question investigates the root proposition, its objects and the mathematics accumulated around them without a narrower focus.

State: resolved
Source: the root statement

- Resolved by the root's formal settlement, not by an explanation: node root is formal_proved through [r3d3d37acd8a7446b8f47d472502d231a/s-root-lean](records/r3d3d37acd8a7446b8f47d472502d231a/record.json)

## op-finite-rate-factor

극한에서는 결손 Y^{3/2}가 「율 A를 한 번 뽑은 지수 시계 E/A」로 접히고, A의 밀도가 로그오목이어서 단봉성이 한 보조정리로 나온다. 유한한 n의 무거운 사슬(기울인 Borel 갱신열 위의 균등 표식 최솟값)에서 이 율 A에 해당하는 대상, 곧 사슬의 무거운 간격들을 독립인 율 하나로 모으고 나머지를 로그오목으로 남기는 분해는 무엇인가.

Grounds: 갱신평활화 갈래는 행이 「첫 간격의 법칙 ∗ 나무 행」의 합성곱 꼴임을 보였으나, 나무 행이 큰 n에서 로그오목이 아니고 단봉성은 합성곱에 닫히지 않아 귀납이 막혔다. 연속극한 갈래는 극한에서 무거운 꼬리가 독립 인자 V^{-1/3} 하나에 모이고 눈금 불변성(Euler 관계 E[B̄_x | A_x] = (3/(2x)) A_x)이 종속성을 푼다는 것을 보였다. 유한 n에는 눈금 불변성이 없다. 이 분해가 있으면 오른쪽 절반의 단봉성이 극한의 논증과 같은 길로 닫힐 수 있다.

State: open
Source: operator publication [q08a427624b114d7a809bc9d4e5705875](questions/q08a427624b114d7a809bc9d4e5705875/questions.json)

## op-column-sign-persistence

열 방향 부호 지속 (C) 「d_{n,k}>0이고 n+1≤2k−1이면 d_{n+1,k}>0」(d_{n,k}=b_{n,k}−b_{n,k−1})은 어떤 원천열의 정칙성에서 따르며, 그 정칙성은 Borel 간격의 완전 단조성(기하 법칙의 혼합)에서 나오는가.

Grounds: 보렐사슬 갈래는 d_{k+r,k}/(k+r)! = Σ_{j≤r} h_{r−j} c_j (h_i=(i+1)^i/i!, c_0=−k^{k−2}/k!)라는 열의 결함 갱신 방정식을 증명했고, (C)가 그 해의 부호 지속임을 보였다. 핵 Bor·Ren이 로그볼록이어서 문턱 나무의 음의 충격이 멱법칙으로만 잊히고, 단일 교차 보조정리의 무게 비가 반대로 움직여 순서 논법이 모두 실패했다. (C)와 대각 짝 (D) 「d_{n,k}≤0 ⇒ d_{n+1,k+1}≤0」이 서면 오른쪽 절반이 로그오목성 없이 닫힌다(n≤300 정확, n≤1200 부동소수에서 위반 없음).

State: resolved
Source: operator publication [q08a427624b114d7a809bc9d4e5705875](questions/q08a427624b114d7a809bc9d4e5705875/questions.json)

- Resolved by [r94b2a3124da4483190eecf816e103ac5/qr-column-sign-persistence-s1306f38](records/r94b2a3124da4483190eecf816e103ac5/record.json) through claim r94b2a3124da4483190eecf816e103ac5/p-answer

## op-tilted-base

임계 기울임 x_k=(k/(k+1))^{k−1}으로 더한 나무 곡률의 기저 B_k(2k+1)=Σ_{t=k}^{2k+1} δ_t x_k^t/t! (δ_t=(k+1)b_{t−1,k}−(k−1)b_{t−1,k−1}, δ_k=−k^{k−2})가 k≥186에서 양인 까닭을 상수 없는 균형으로 적을 수 있는가. 곧 음의 몫 k^{−3/2} 눈금과 양의 몫 k^{−4/3} 눈금이 k^{1/6} 비율로만 갈리는 이 비교를 어떤 구조가 정하는가.

Grounds: 왼쪽절반 갈래의 정리 A는 (A1) δ_t의 첫 층 단일 교차와 (A3) B_k(2k+1)≥0만 서면 n≥2k+1의 모든 행이 귀납으로 따라옴을 증명했고, 기울인 환경 계수 A_{N,k−1}x_k^N/N!의 비증가는 모든 k≥2에서 선다. 기저는 k≤2000에서 정확히 k≥186일 때 양이고(k≤220 정확, 그 위 부동소수), k≤185는 계산으로만 닫혔다. 이 질문이 풀리면 왼쪽 절반이 첫 층의 단일 교차 하나로 줄어든다.

State: open
Source: operator publication [q08a427624b114d7a809bc9d4e5705875](questions/q08a427624b114d7a809bc9d4e5705875/questions.json)

## op-two-regimes

오른쪽 절반은 임계 영역 r≲2n^{2/3}(행이 로그오목, 비의 단조성 성립)과 벌크 r≳2.4n^{2/3}(행이 「큰 간격 하나」의 멱법칙 윤곽을 따라 로그볼록, 모든 비의 단조성이 깨짐)으로 갈린다. 두 영역에서 증가(d>0)를 하나의 논증이 품으려면 어떤 양을 보아야 하는가. 특히 벌크에서 d>0이 크기가 거의 같은 두 양(동률과 막힘)의 차라는 사실을 부호만으로 다루는 구조가 있는가.

Grounds: 세 갈래가 독립으로 같은 경계(결손 ≈2.3–2.4 n^{2/3}, 극한에서 z_c=2.1447)를 얻었고, 누적 개수의 로그오목성(n=780), 우도비·TP2·이득/손실 비·원천별 부등식 (G)_d(n≈7485)·열 방향 크기 단조성(n=122)이 모두 이 경계 안쪽 벌크에서 깨졌다. 계산 범위에서 깨지지 않은 것은 부호와 교차 횟수만을 말하는 명제(Col)·(C), (Diag)·(D), (X1)·(X2), (Col⁺⁺)뿐이다. 두 영역을 잇는 로그오목형 구조는 없으므로, 상수 없는 증명은 벌크에서 부호만을 말하는 명제여야 한다.

State: open
Source: operator publication [q08a427624b114d7a809bc9d4e5705875](questions/q08a427624b114d7a809bc9d4e5705875/questions.json)

## op-one-chain-two-directions

왼쪽 절반의 남은 명제(첫 층 단일 교차, 기울인 기저 양성)는 단일 사슬의 법칙을 수준 k를 고정하고 크기 t를 따라 본 것이고, 오른쪽 절반의 남은 명제((C)·(D))는 같은 법칙을 크기 n을 고정하고 수준을 따라 본 것이다. 이 두 방향을 한 대상에 대한 한 명제로 적을 수 있는가. 예컨대 (n,k) 평면 전체에서 d_{n,k}의 부호 영역이 계단 모양이라는 것(자유탐색의 (Col)∧(Diag), 봉우리가 n이 하나 늘 때 0칸 또는 1칸 움직임)이 그런 명제인가.

Grounds: 자유탐색 갈래는 (Col)∧(Diag)에서 모든 행의 단봉성이 따르고 그 역도 성립함을 증명했으며(정리 A), 조건부 판 (Col⁺⁺) b_{n+1,k}/b_{n+1,k−1} ≥ min(1, b_{n,k}/b_{n,k−1})가 (Col)과 나무 행의 (Col)(곧 첫 층 단일 교차)을 함께 함의함을 보였다(n≤2500에서 예외 없음, 미증명). 두 방향이 하나로 적히면 두 절반을 따로 다루는 틀 자체가 사라진다.

State: open
Source: operator publication [q08a427624b114d7a809bc9d4e5705875](questions/q08a427624b114d7a809bc9d4e5705875/questions.json)

## s1306f38b633143c3b8596cd614e1761a-feedback-sign

열 방정식의 되먹임 합이 한 번 음이 아니게 된 뒤 다시 음이 되지 않는다는 것은, 큰 열의 정리가 닿지 않는 범위(드러난 크기의 열, 첫 층의 끝과 그 밖의 행)에서 무엇이 주는가. 정수 k≥2, n≥k+1에 대해 Mem_n(k):=Σ_{j=k}^{n−1} C(n,j)·C_{n−j,k}·d_{j,k}로 둔다. 여기서 C(n,j)는 이항계수, d_{j,k}=b_{j,k}−b_{j,k−1} (b_{j,ℓ}는 최대 변위가 정확히 ℓ인 길이 j의 주차함수의 수), C_{m,k}는 모든 변위가 k보다 작은 길이 m의 소인 주차함수의 수다. 같은 말로 Mem_n(k)=d_{n,k}−(k+1)d_{n−1,k}−2b_{n−1,k−1}−X_{n,k} (X_{n,k}≥0은 게시된 열 방정식 r6af349eb/c01-column-equation의 수이고 n<2k이면 0). q_0(k)는 d_{n,k}>0인 가장 작은 n≥k+1, n_1(k)는 Mem_n(k)≥0인 가장 작은 n≥k+1이다. 알려진 것은 다음과 같다. (1) [계산] 계산한 모든 열에서 Mem_n(k)는 n에 대해 부호를 꼭 한 번 바꾼다: k+1≤n<n_1(k)에서 음이고 n≥n_1(k)인 계산한 모든 행에서 음이 아니다. (2) [증명됨] k+1≤n≤2k−1이고 d_{n−1,k}<0이면 Mem_n(k)<0이다. (3) [증명됨] 모든 k≥2, n≥k+2에서 Mem_n(k)/n! ≥ L_n(k):=Σ_{t=k}^{n−1} ξ^{Dg}_t·A_{n−t,k−1}/(n−t)!이다. 여기서 A_{m,ℓ}은 최대 변위가 ℓ 이하인 길이 m의 주차함수의 수(A_{0,ℓ}=1), ξ^{Dg}_k=−k^{k−2}/k!, ξ^{Dg}_{k+1}=−(k−1)b_{k,k−1}/(k+1)!, t≥k+2에서 ξ^{Dg}_t=[(k+1)(1+1/k)^{k−2}(t−1)b_{t−2,k−1}−(k−1)b_{t−1,k−1}]/t!이다. L_n(k)에는 열 k의 수가 없다. (4) [증명됨; 문턱은 드러나지 않는다] 어떤 정수 k_*와 상수 K가 있어 모든 k≥k_*에서, k+1≤n<n_1(k)에서 Mem_n(k)<0, n_1(k)<n≤1.85k−1에서 Mem_n(k)>0이고 |n_1(k)−q_0(k)−𝖼·k^{1/3}|≤K이다 (𝖼=2G′(x_0)/((e−1)|G‴(x_0)|)=0.6108…; G와 x_0는 게시된 r790d81e5/p-limit-shape의 극한 함수와 그 변곡점). 그 가운데 n+1≥k+C·k^{2/3}(C는 어떤 상수)인 행에서는 L_n(k)>0이다. (5) [계산] 표본한 열 k≥34에서 L_n(k)>0은 n=q_0(k)+8과 q_0(k)+17 사이의 행에서 시작해 본 범위의 끝까지(첫 층 밖의 행 3.2k까지) 끊기지 않는다. 묻는 것은 하나다. (4)가 닿지 않는 범위, 곧 드러난 문턱 위의 모든 열과 첫 층의 끝 1.85k≤n≤2k와 첫 층 밖 n>2k에서, n≥n_1(k)인 모든 행에서 Mem_n(k)≥0이라는 것을 주는 논증은 무엇인가. 계산이 가리키는 답은 (3)의 하계가 교차에서 조금 떨어진 모든 행에서 양이라는 것이다. 그것이 그 범위에서 서는지, 선다면 열 k−1의 어떤 성질에서 나오는지가 이 물음의 알맹이다. 답으로 인정되는 것은 다음 가운데 하나다. (가) 드러난 k_0와 드러난 행의 범위(예: 모든 k≥k_0과 n≥k+⌊2k/5⌋+2)에서 Mem_n(k)≥0의 증명. 더 센 진술 L_n(k)≥0의 증명도 답이다. (나) Mem_n(k) 또는 L_n(k)를 그 범위에서 부호가 정해진 항들의 합으로 가르는 항등식과 그 부호의 논증. (다) 반례: Mem_n(k)≥0이 된 뒤 다시 음이 되는 자리 (n,k).

Grounds: 추측에 기댄 질문이다. 증명된 것은 진술의 (2), (3), (4)이고(이 기록의 주장 p-front (다), p-feedback-one-level, p-feedback-sign-large-k) (1)과 (5)는 계산이다. 증거의 범위. (1): 개정 39의 r3bd6df852c694ee299e0f7581899e222의 주장 c-mplus(정확한 유리수로 k=3,…,80의 열 열여섯, n≤200; 60자리 부동소수로 k=100, 160, 264, 400의 행 3.2k까지), 이 기록의 탐색 세션(정확한 정수로 3≤k≤48, n≤150; 90자리 부동소수로 k=20, 60, 100, 200)과 동료(정확한 정수로 2≤k≤30의 모든 열, n≤64; 배정밀도로 k=100, 400, 1600, 6400, 25600의 창의 행)가 얻은 같은 무늬다(주장 c-nf-observed, p-feedback-window-observed). 겹치는 열에서 값이 맞는다. r3bd6df85…가 세운 범위 「k≥40, n≥k+⌊2k/5⌋+2」는 k=40에서 행의 여유 0으로 시작한다(되먹임 합이 음인 마지막 행이 창의 끝 57과 같다; 그 기록의 검토). n_1(k)−q_0(k)는 유계가 아니다: 계산한 열에서 1(k=2)에서 19(k=25600)이고, (4)에 따라 0.61·k^{1/3}으로 자란다. (5): 정확한 유리수로 k=20, 24, 30, 34, 36, 38, 40, 50, 60(행 3k까지), 50자리로 k=50, 100, 200의 첫 층, 배정밀도로 k=100, 200, 400, 1600, 6400의 첫 층과 k=40, 50, 60, 100, 160, 264, 349의 행 3.2k까지(주장 p-feedback-one-level-observed). k≤30에서는 L_n(k)>0이 늦게 시작하거나(k=20, 24: 첫 층 밖에서야) 한 번 끊긴다(k=30: n=61, 62, 63). 표본한 열 k≥34에서는 끊기지 않는다. 열 160, 264, 349에서 접합부 뒤의 최솟값은 충격의 항의 1.43, 1.55, 1.57배다. 본 열은 이것이 전부다. 경위: r3bd6df85…는 같은 대상에 대한 질문(sd1a039f9ad7c47388167e6d96fd26850-feedback-sign)을 제안했고, 그 검토는 「중요하고 중복이 아니다」라고 보면서 수정을 요구했다. 이 제안은 그 요구 다섯에 맞춘 것이다: (1) 물음을 하나로 줄이고 답으로 인정되는 것을 적었다; (2) 노드 (DR)과의 함의를 어느 방향으로도 주장하지 않는다; (3) 범위를 「빚이 갚아진 뒤」와 묶지 않았다; (4) 다른 게시된 기록에서 다른 진술의 이름인 꼬리표 (M⁺)를 쓰지 않았다; (5) 증거의 범위와 k=40에서의 여유 0을 적었다. 그 뒤 이 기록이 증명한 것 때문에 물음이 좁아졌다. 그 제안의 첫 물음 「이 부호를 정하는 구조는 무엇인가」에는 큰 열의 첫 층의 대부분에서 답이 생겼다: 되먹임 합은 한 수준 하계에서 꼭대기 항을 뺀 양 L_n(k) 이상이고(주장 p-feedback-one-level), 그 양은 열 k−1의 감소의 지속(게시된 rb6c0db0…의 정리 6.2)에서 양이다(주장 p-feedback-far-large-k). 창 안에서는 국소 극한 정리가 부호가 바뀌는 자리까지 준다(주장 p-feedback-window-large-k). 그 제안의 둘째 물음이 요구하던 입력(열 k−1의 뒤의 칸을 앞선 칸으로 위에서 누르는 한계)이 여기서는 칸마다의 한계가 아니라 가까운 과거에 대한 평균의 꼴로 든다는 것도 드러났다. 그래서 남는 물음은 범위에 대한 것 하나다. 왜 물을 만한가: 게시된 판정들(r6af349eb의 보조정리 A와 S⁺, r69068ac5의 정리 F와 G, r3bd6df85…의 정리 H, 이 기록의 한 줄 판정)은 모두 이 합을 음의 양으로 아래에서 누르고 원천으로 이기려 하는데, 실제 열에서 창 뒤의 되먹임 합은 원천의 한계의 서너 배인 양수다(r3bd6df85…의 9.2절). 되먹임 합이 음이 아닌 행에서는 d_{n−1,k}≥0이면 d_{n,k}>0이다. 그래서 이 부호가 접합부 뒤의 행에서 서면 노드 (Col)에 남은 띠(열 160≤k≤349, 행 2k+3≤n<N_k; r3bd6df85…/p-remainder)가 닫힌다(주장 p-feedback-one-level (라)). 그 띠의 크기의 열 셋에서 L_n(k)는 띠의 행 전부에서 양이다(계산). 다만 L_n(k)≥0을 그 띠에서 요구하면 행마다 부등식 하나씩이어서 노드 (DR)보다 다루기 쉽다고 볼 근거가 없고, 요구하는 입력이 r3bd6df85…의 세 판정이 멈춘 것과 같은 종류이므로, 이 기록은 그것을 노드로 제안하지 않고 질문으로 적는다. 무엇이 모자라는가(exposition.md 9.5절): 사슬 영역의 끝에서는 나무 질량의 감소율의 증명된 값 2/k가 필요한 2.67/k에 못 미치고(rb6c0db0…이 본 열에서의 값은 3.4/k–3.5/k; 셈), 사슬 영역 밖에서는 열 k−1의 감소와 칸의 하계가 필요한 정밀도로 증명되어 있지 않다. 정리의 문턱이 드러나지 않는 것은 국소 극한 정리의 상수 때문이다. 기존 질문과의 관계: op-column-sign-persistence는 원천열의 정칙성을 묻고(이 기록이 그 해결을 제안한다), 이 질문은 되먹임의 부호를 묻는다. 모드의 말로는 op-tilted-base가 한 모드 ς=(1+1/k)^{k−1}에서의 부호 Ξ_{2k+1}≥0, (C)가 ν-평균 ∫Ξdν의 부호의 지속, 이 질문이 ∫ς·Ξdν의 부호의 지속을 묻는다(ν는 전역 용어집의 Borel 무게의 모멘트 측도, Ξ_m(ς):=Σ_{t=k}^{m}ξ_t·ς^{m−t}, ξ_t는 나무 곡률의 계수; 첫 층에서 Mem_n(k)/n!=∫ς·Ξ_{n−1}dν; 주장 p-front (가)). 되먹임 합이 음이 아니라는 것은 (C)보다 센 진술이다. 이 기록은 순서 구조만으로는 지속이 나오지 않는다는 것을 보였고(주장 p-order-insufficient), 큰 열의 증명도 열 k−1의 크기의 정보를 쓴다.

State: resolved
Source: [r94b2a3124da4483190eecf816e103ac5](records/r94b2a3124da4483190eecf816e103ac5/record.json)

- Resolved by [r9faef2b6f9804ae4910f22b51ee669cb/qr-feedback-sign](records/r9faef2b6f9804ae4910f22b51ee669cb/record.json) through claim r9faef2b6f9804ae4910f22b51ee669cb/p-answer

## Question proposals review did not admit

A proposal marked revise lacked specificity or clarity; the review reason beside it says what would make it a question. A declined proposal duplicated an existing question or did not meet the bar of importance.

- declined (duplicate of op-tilted-base): 나무 곡률의 가중합 Σ_{t=k}^{n_0} ω_t δ_t를 「문턱 위 초과 a를 고정한 궤도」로 다시 묶으면 아래 경계항 Lo, 궤도 항들의 합 In = Σ_a D_a, 꼭대기 경계항 Tp로 정확히 갈린다. (1) 임계 기울임 ω_t = x_k^t/t!와 접합부 무게 ω_t = c_{n−t}/t! (k < n ≤ 2k+1)에서 모든 궤도 항이 음이 아니라는 것은, 가벼운 숲의 계수 λ_b(y) = c_{y+b−1} − Σ_{g=0}^{b−2} c_g c_{y+b−2−g}에 무게를 곱한 함수가 성질 K를 가진다는 것(추측 K)으로 환원되어 있다. 임계 기울임에서는 그 가운데 볼록성이 증명되었다(λ_b가 Cayley 계수의 합성곱이고, 둘째 차분이 기울인 Cayley 수열 f(m) = x_k^m c_m의 첫 차분들의 곱의 합이다). 남은 것은 (k−1)W(k+1) < (k+1)W(k−1)인 (k,b), 계산한 범위에서는 b < b_1(k) ≈ 0.46k에서의 로그볼록 꼴 부등식 (W(k+1)/(k+1))^{k+1}(W(k−1)/(k−1))^{k−1} ≥ (W(k)/k)^{2k}, W(z) = x_k^z λ_b(z)이다. 접합부 무게의 경우는 임계 기울임의 경우에서 따른다(정리 P12). 그래서 남은 것은 이 부등식 하나이고, 기울임을 떼어 내면 「g_b(z) = λ_b(z)/c_{z−1}에 대해 M_g(k,b) = (k+1)log(g_b(k+1)/g_b(k)) + (k−1)log(g_b(k−1)/g_b(k)) ≥ −(k−3)φ(k), φ(k) = k·log(1+1/k) + (k−1)·log(1−1/k)」라는, 가벼운 숲의 개수만에 대한 진술이다(명제 P13). 이 부등식을 모든 k에서 증명할 수 있는가? 또 첫째 경우 (k−1)W(k+1) ≥ (k+1)W(k−1)이 성립하는 b의 범위를 계산 없이 정할 수 있는가? (2) 그때 남는 음의 몫인 꼭대기 경계항, 곧 끊는 크기의 나무가 수준 k−1을 정확히 달성하는 무게와 한 칸의 대각 차분을, 궤도 항의 누적이나 끊는 자리 위의 나무 곡률의 합과 견주는 비교는 첫 층 벌크의 행 모양(오른쪽 절반의 대상)에 대한 정량 정보 없이 설 수 있는가? 설 수 없다면 그 비교에 필요한 가장 작은 정보는 무엇인가? — review: 중복으로 받아들이지 않는다. 제안의 근거 문단 스스로 「op-tilted-base가 묻는 기울인 기저의 부호를 정하는 구조는 이 분해의 In 대 Tp이고, (1)과 (2)가 그 질문의 남은 부분」이라고 적는다. (2)는 임계 기울임에서 n_0 = 2k+1로 읽으면 B_k(2k+1) ≥ 0의 비교 그 자체이고, 접합부 무게로 읽으면 노드 (L)의 첫 행의 핵심이다. (1)의 가벼운 숲 부등식은 같은 질문의 양의 몫이 어떤 구조로 양인지를 묻는 하위 문제여서 op-tilted-base의 범위 안에 있고, 그것이 풀려도 첫 행의 무게에서 In과 |Tp|가 2–4% 안에서 지워지므로 어느 행도 닫히지 않는다. 지금으로서는 따로 세울 독립된 무게가 보이지 않는다. 이것은 내용에 대한 거부가 아니다. 아무도 맡지 않은 op-tilted-base를 맡는 탐색자에게 이 기록의 7.5–7.8절이 가장 정확한 출발점이다. 그 탐색자가 알아야 할 문면의 결함: (1)의 「모든 k」는 k ≥ 3이어야 하고(k = 2, b = 1에서 M_g = 0.104 < 0.118로 거짓), 임계 기울임의 「모든 궤도 항」은 P5의 범위 a ≤ k+1(n_0 ≤ 2k+2)로, 접합부 무게는 k+2 ≤ n ≤ 2k+1로 읽어야 한다. 하위 검토 A는 받아들임, B와 C는 수정 요구를 권했고, 그 판단과 다르게 정한 까닭은 피드백 1.2절과 7.3절에 적었다. — [rc31497e9df27478584efc43f79e164f2](records/rc31497e9df27478584efc43f79e164f2/record.json)
- declined (duplicate of op-tilted-base): 임계 기울임에서의 대각 볼록성은 유한한 모든 크기에서 성립하는가, 그리고 첫 층에서 그것을 주는 함수 하나의 부등식을 증명할 수 있는가? 정확히는 다음과 같다. A_{n,ℓ}을 최대 변위가 ℓ 이하인 길이 n의 주차함수의 수(A_{0,ℓ}=1), p_j를 길이 j의 주차함수의 수, x_k=(k/(k+1))^{k-1}, ω_j=p_j x_k^j/j!, 그리고 1≤ρ≤c+1에서 S_ρ(c)=(x_k/(c+ρ))Σ_{j=ρ-1}^{c} min(j+1,c) ω_j ω_{c+ρ-1-j}라 하자. (첫 층) 모든 정수 k≥2와 1≤ρ≤k에서 다음이 성립하는가: S_ρ(k+1) < ((k+1)/(k-1))S_ρ(k-1)이면 S_ρ(k+1)^{k+1} S_ρ(k-1)^{k-1} k^{2k} ≥ (k+1)^{k+1}(k-1)^{k-1} S_ρ(k)^{2k}이다. (볼록성 S_ρ(k+1)+S_ρ(k-1) ≥ 2S_ρ(k)는 이 기록의 보조정리 V로 증명되어 있다. 그것과 이 기록의 명제 R3에 따라 이것이 서면 N_c(t)=min(t,c)A_{t-1,c-1}에 대해 k+1≤t≤2k+1인 모든 t에서 x_k^2 N_{k+1}(t+1) - 2(t+1) x_k N_k(t) + t(t+1) N_{k-1}(t-1) ≥ 0이 따른다.) (전체) 같은 부등식이 모든 k≥2와 t≥k+1에서 성립하는가(추측 DC의 나무 질량 판; 핵 질량 판은 N≥k+1에서 x_k^2 A_{N+1,k} - 2(N+1) x_k A_{N,k-1} + N(N+1) A_{N-1,k-2} ≥ 0)? 그리고 이 볼록성을 성립하게 하는 구조는 무엇인가. 이 기록의 4.8절은 「결손 n+1-M_n의 생존 확률은 사슬 위의 인자 (c+a)/(c+b)들의 곱을 음이 아닌 무게로 섞은 것이고, 그런 곱에 기울인 Cayley 무게를 곱하면 Cayley 수의 지수 3/2가 1보다 커서 크기에 대해 볼록하다」고 설명하고, 첫 층에서는 명제 R3이 이 설명을 정확한 환원으로 만든다. 첫 층 밖에서도 그렇게 할 수 있는가? — review: 받아들이지 않는다(중복: op-tilted-base). 이 검토가 진행되는 동안 같은 대상을 다룬 기록 rc31497e9df27478584efc43f79e164f2가 공표되었다(전선 개정 2). 그 기록의 궤도 항 D_a는 이 후보의 대각 둘째 차분 DC^T(k+a)와 같은 양이다. 그 기록도 첫 층에서 그 비음성을 함수 하나(가벼운 숲의 바닥 인자 x_k^zλ_b)의 성질 K로 환원하고, 볼록성 절반을 증명했으며, 남은 부등식 하나를 추측으로 남겼다. 그 기록의 검토는 같은 내용의 질문 제안을 op-tilted-base의 중복으로 받아들이지 않았다. 그 하위 문제는 op-tilted-base가 묻는 '양의 몫이 어떤 구조로 양인가'의 범위 안에 있다. 그것이 풀려도 기저의 부호나 어느 행도 닫히지 않는다. 두 질문을 함께 열어 두면 두 탐색자가 같은 하위 문제로 향한다. 이 검토도 같은 판단에 이른다. 이 후보에서도 추측 DC가 주는 것은 기저 ≥ -J뿐이다. 이 질문의 '(전체)' 부분, 곧 첫 층 밖의 대각 볼록성은 op-tilted-base의 2k+1 절단을 넘는다. 그러나 그것이 기저 밖에서 무엇을 정하는지가 아직 보이지 않아 따로 세울 무게가 없다. 이것은 내용의 가치에 대한 거부가 아니다. op-tilted-base를 맡는 탐색자는 두 기록의 첫 층 환원을 함께 출발점으로 삼아야 한다. 이 기록의 것은 명제 R3과 보조정리 V이고, 다른 기록의 것은 정리 P5와 P9다. 두 환원은 다른 함수(S_ρ와 x_k^zλ_b)를 쓰므로, 남은 두 부등식 가운데 어느 쪽이 더 다루기 쉬운지도 물을 만하다. 그 탐색자를 위해 근거의 수치 문장 셋을 바로잡는다. (1) '정리 A′에 남은 유일한 가정'은 과하다. 기저는 접미 합 조건 (4.2)의 i=k인 항목 하나다. (2) '상대 여유가 k^{-2}의 0.7–0.8배 아래로 내려가지 않는다'는 k≥30의 표본에서 본 값이다. DC·k²/u_N(k)의 최솟값은 k=2에서 0.36, k=3에서 0.45, k=10에서 0.62, k=30에서 0.68이다. (3) 'k≤6400에서 배정밀도'와 '(k≤12800)'은 표본 범위다. k≤8에서 R3 가정의 여유는 0.23–0.36이다. 세 하위 검토는 다른 기록이 공표되기 전의 전선을 보고 받아들임(A, C) 또는 근거 수정 후 재제안(B)을 권했다. 판정이 그와 다른 까닭은 피드백 2.2절과 7절에 적었다. — [r3e8ad56ece2549449ad86ef9412d9cfa](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json)
- declined (duplicate of op-two-regimes): 조임 판정 (Z)는 왜 성립하는가. 행 N의 질량 셀 u(r)=e^{-N}b_{N-1,N-r}/N! 은 r≤(N+2)/2에서 핵이 Borel 질량 Bor인 갱신 방정식 (N/(N-r))u(r) = (Bor*u)(r) + S(r)을 만족하고, 그 조임량 E(r)=[(N/(N-r))x(r)-(Bor*x)(r)]/u(r-1) (x(r)=u(r-1)-u(r))이 봉우리 r_1 뒤의 모든 r_2≤(N+2)/2에서 E(r_2) ≥ min{Bor(r_2-r_1-1), (Bor(r_2-2)/Bor(r_1-1))·E(r_1+1)} 을 만족하면 (b_{N-1,ℓ})이 ⌈(N-2)/2⌉≤ℓ≤N-2에서 단봉이다(증명된 함의. 범위를 r_2≤⌊(N+3)/2⌋까지 넓히면 결론이 전선의 노드 「오른쪽 절반」과 꼭 같고, 이 기록은 그 판정을 노드로 제안한다. 다만 E를 방정식의 원천으로 읽을 수 있는 것은 단일 사슬 범위 r≤(N+2)/2에서다). 균질 Lomax 모형에서는 E가 상수여서 이 부등식이 자명하고 그것이 단봉성의 증명 전부다. 실제 행에서 E가 상수에서 벗어나는 몫은 대각 방향의 양(명시적인 확률의 비 둘과 대각 방향의 결함의 증분)이다. 묻는 것: 봉우리 바로 뒤에서 E가 핵의 비 Bor(r_2-2)/Bor(r_1-1)보다 빨리 줄지 않는다는 것과 접합부까지 E가 양이라는 것은 이웃한 행 사이의 어떤 구조에서 나오는가. 계산에서는 E가 접합부를 지나 왼쪽 절반의 깊은 곳까지 양인데(접합부가 E/μ의 골이다), 행 방정식이 선형이 아닌 그 범위에서 E가 양인 까닭은 무엇이고 그 범위의 끝은 큰 N에서 어디로 가는가. 같은 물음의 균질한 판: 걸음마다 확률 θ로 울리는 기하 표식 모형에서 조임량은 E(r)=θ(1-θ)^{-r}(1+w(r-1))이고(w는 위험률 가운데 뿌리가 아닌 점들의 몫), 첫 울림의 법칙 φ가 다시 오르려면 뿌리를 뺀 사슬의 첫 울림의 법칙 C=g*φ가 먼저 내렸다가 올라야 한다. 간격 법칙 g가 비증가이고 로그오목이면 그런 일이 없고 φ는 단봉이다(이 기록의 정리 B.2). g가 비증가이지만 로그오목이 아닐 때, 특히 행의 핵인 Borel 법칙처럼 로그볼록일 때, C=g*φ가 단봉인 까닭은 무엇인가. — review: 받아들이지 않는다(중복: op-two-regimes). 중심 물음(봉우리 뒤 E가 핵의 비보다 빨리 줄지 않고 접합부까지 양인 까닭이 이웃한 행 사이의 어떤 구조에서 오는가)은 이 기록이 op-two-regimes에 내놓은 후보 답(양 E와 조임)이 남긴 몫이다. 그 답을 완성하는 일이 곧 (Z)가 왜 서는지를 보이는 일이어서, 두 질문을 함께 열면 다음 탐색자들이 같은 대상으로 향한다. 풀리면 오른쪽 절반이 닫힌다는 무게는 이번에 받아들인 노드 (Z)가 나른다. 나머지 두 물음은 따로 세울 무게가 없다. 접합부 너머의 E의 양성은 논증 범위 밖을 잰 계산에서 나왔고 증명된 연결이 없으며, 기하 표식 모형의 Borel 경우는 인수인계 갱신평활화 보고 추측 19의 균질 모형 몫(그 모형의 첫 발화 법칙이 C=g*φ)과 같은 진술이고 행과의 증명된 연결이 없다. 문면에 틀린 전제도 있다(행에서 T_1, T_2는 대각 방향의 양이 아니다; 근거가 드는 c-Z-observed의 구절이 틀렸다). 내용을 부정하는 판단이 아니다. op-two-regimes를 맡는 탐색자는 이 기록의 E와 (Z)에서, 피드백 2.5–2.6절의 바로잡음과 함께 출발해야 한다. op-two-regimes가 (Z)를 정하지 않은 채 닫힌 뒤 E의 정칙성에 대한 이해가 따로 필요해지면, 중심 물음 하나로 좁히고 전제를 바로잡아 다시 제안할 수 있다(피드백 4.3절). — [r213dbe848e5c4e8483afbcbfe76addec](records/r213dbe848e5c4e8483afbcbfe76addec/record.json)
- declined (duplicate of op-two-regimes): 크기가 하나 다른 두 숲 행을 잇는 전이 비 q_N(r) = [Pr(M_{n+1}≤k) − Pr(M_n≤k−1)]/Pr(M_n=k) (n=N−1, k=n−r)는 계산한 모든 크기에서 오른쪽 절반 2≤r≤⌊N/2⌋−1에서 볼록이고(둘째 차분이 음이 아니고), 그 볼록성은 사슬이 하나뿐인 범위의 끝에서 사라진다. 이 볼록성은 무거운 사슬의 법칙의 어떤 구조에서 오는가. 임계 창에서는 q_N이 앞선 차수에서 일차식이어서 곡률의 부호가 눈금 다음 차수로 정해지는데, 그 차수의 정보를 주는 구조는 무엇인가. 그리고 행이 증가하는 범위(봉우리 왼쪽)에서 단봉성이 다음 크기로 넘어가는 것은 무엇이 정하는가. — review: 받아들이지 않는다(중복: op-two-regimes). 이 기록은 op-two-regimes의 「어떤 양을 보아야 하는가」에 전이 비 q_N을 답으로 내놓고, 「부호만으로 다루는 구조」는 q_N의 볼록성을 조건으로만 있다고 적었다(0.4, 9.1절). 제안의 첫째·둘째 물음(볼록성은 사슬의 어떤 구조에서 오는가, 임계 창의 다음 차수)은 그 조건을 증명하는 일이고, 셋째 물음(행이 증가하는 쪽)은 같은 답의 다른 절반이다. op-two-regimes는 게시 뒤 다시 열리고 그것을 맡는 탐색자가 8절에서 출발해 할 일이 이 질문의 내용이다. 개정 4의 r213dbe848e5c4e8483afbcbfe76addec 검토도 그 기록이 op-two-regimes에 내놓은 후보 답(조임량 E와 판정 (Z))이 왜 서는가를 묻는 제안을 op-two-regimes의 중복으로 판정했으므로, 두 후보 답을 한 질문 아래 둔다. 내용은 op-column-sign-persistence와도 겹친다. 원래 좌표로 Col*는 「d_{n,k−1}≥0, d_{n,k}≥0이고 q_N이 볼록이면 d_{n+1,k}≥0」으로 그 질문의 (C)에 이웃 칸의 가정을 더한 꼴이고, (8.3′)은 그 근거의 대각 짝 (D), 곧 개정 3부터 전선의 마디 (Diag)의 셀별 충분조건이다(하위 검토 A와 C는 이 겹침으로 op-column-sign-persistence를 들었다). 근거의 「그 둘과 겹치지 않는다」는 바로 앞 문장과 어긋난다. 내용을 부정하는 판단은 아니다. 맡는 탐색자에게는 8절, 관찰 Q, r213dbe8의 E와 (Z), 그리고 검토자의 시험(볼록성이 N=120,160,200의 벌크 셀에서도 성립; 봉우리의 N²Δ²q_N이 0.868, 0.770, 0.703, 0.648, 0.625, 0.605로 줄되 폭이 작아짐)이 출발점이고, 같은 곡률 배열을 이미 잰 자유탐색 보고 3절을 함께 읽어야 한다(피드백 7절). — [r535d20f3d6cc4384838c89248eb27bbe](records/r535d20f3d6cc4384838c89248eb27bbe/record.json)
- declined: 균질 이산 모형(간격 법칙 f가 비증가인 갱신열의 각 점이 걸음마다 독립으로 확률 θ로 발화)에서 뿌리 없는 계의 첫 발화 걸음의 법칙(숲 법칙)은 왜 단봉인가, 또는 반례가 있는가. 숲 법칙이 덩이 법칙과 같은 f에서 나왔다는 사실은 어떤 부등식으로 쓰이는가. 좁혀진 꼴: 숲이 감소하는 동안 숲의 위험률이 봉우리 직전의 값 아래로 떨어지는 골이 왜 생기지 않는가. — review: 받아들이지 않는다(중요성). 질문은 구체적이고 전선의 어느 질문과도 같지 않지만, 중요성의 문턱을 넘지 못한다. (1) 대상이 핵심이 아니다. 균질 모형은 넘겨받은 갱신평활화 보고가 끝 효과와 크기 의존을 없앤 이상화이고(그 보고는 「균질 모형에서 증명한 것은 주차함수의 행에 대한 진술이 아니다」라고 적는다), 근거도 주차 행으로 옮겨진다는 것이 추측이라고 적는다. 주차 숲 행에서 두 점 논증이 막힌 뒤 이상화된 모형의 숲 법칙을 따로 묻는 것은, 핵심을 조각내 떼어 내거나 막혔을 때 시도의 대상이 아닌 작은 것으로 물러나지 말라는 셋째 상시 조건에 어긋난다. 답이 뿌리에 무엇을 주는지도 근거에 없다. (2) 범위가 주차 모형과 맞지 않는다. 주차 사슬의 간격 법칙(Borel)은 로그볼록인데 진술은 비증가인 모든 f를 묻고, 로그볼록이 아닌 법칙의 반례는 질문에 답하되 주차 행에 대해 아무것도 말하지 않는다. 로그볼록 경우는 갱신평활화 보고 추측 19가 이미 적은 물음이고 제안은 그것을 인용하지 않는다. (3) 떼어 내려는 장애(로그오목이 아닌 덩이·나무 법칙과 첫 간격 법칙의 합성곱이 단봉을 지키는가)는 op-finite-rate-factor의 근거가 적은 바로 그 장애이고, 그 질문은 그것을 실제 주차 사슬에서 넘을 분해를 묻는다. 정리 H1, 명제 H3·H4, 보조정리 D는 그 재료로 기록에 남는다. 하위 검토 A와 B는 받아들이기를(둘 다 셋째 조건에 비추면 받아들이지 않는 것도 일관된다고 적음), C는 범위·연결·추측 19와의 관계를 밝혀 다시 내기를 권했다. 개정 4의 r213dbe8(op-finite-rate-factor의 기록)이 바로 이 모형들을 대리 모형으로 다루었고, 그 검토도 기하 표식 모형의 Borel 경우(추측 19의 균질 모형 몫)를 행과 증명된 연결이 없다는 이유로 따로 세우지 않았다. 이 기록의 정리 H1이 뿌리 있는 쪽을 증명했으므로 그 모형에서 남는 것은 이 질문의 뿌리 없는 쪽이다. 다시 낸다면 주차 숲 행 자체, 곧 (P1)로 나무 행에서 숲 행으로 건너가는 걸음에서 무엇이 단봉성을 실어 나르는지를 묻고 op-finite-rate-factor와의 관계를 밝히는 꼴이 핵심을 마주하는 물음이 될 것이다(피드백 7절). — [r535d20f3d6cc4384838c89248eb27bbe](records/r535d20f3d6cc4384838c89248eb27bbe/record.json)
- declined (duplicate of op-column-sign-persistence): 대각 증분 Δ^T_k(s) = 𝗏_{k−1}(s−1) − 𝗏_k(s) = k·A_{s−1,k−1}/s^{s−1} − (k−1)·A_{s−2,k−2}/(s−1)^{s−2} (s ≥ k), 곧 수준과 크기를 함께 하나씩 올릴 때 나무의 넘김 확률 (크기 s의 나무가 수준 k 이상일 확률 𝗏_k(s) = 1 − k·A_{s−1,k−1}/s^{s−1})이 줄어드는 폭은 첫 층 k+1 ≤ s ≤ 2k+1에서 크기에 대해 어떻게 변하며, 그 변화를 누르는 구조는 무엇인가. 가장 날카로운 꼴은 대각 비교 (DI)다: 결손 r ≥ 1을 고정했을 때 (j+1)·α^{(j)}_{j+r} (α^{(j)}_s = 𝗏_j(s) − 𝗏_j(s−1))은 왜 수준 j에 대해 비감소인가. 같은 말로 왜 α^{(k−1)}_{s−1} ≤ (1+1/k)·α^{(k)}_s, 곧 Δ^T_k(s) − Δ^T_k(s−1) ≤ α^{(k)}_s/k인가(k ≥ 3, k+1 ≤ s ≤ 2k+2; s = k+1에서 등호). 그리고 대각 증분은 왜 봉우리를 하나만 가지는가. — review: 받아들이지 않는다(중복: op-column-sign-persistence). 제안의 근거 문단 스스로 「op-column-sign-persistence의 남은 부분을 좁힌 것」이라고 적는다. 이 기록은 그 질문의 해결을 제안하지 않으므로, 게시 뒤 그 질문을 맡는 탐색자가 이 기록에서 출발해 할 일이 곧 이 물음이다. 기존 질문은 (C)가 어떤 원천열의 정칙성에서 따르는지를 묻는다. 이 기록은 원천을 크기 방향 증분과 대각 증분으로 갈라 앞의 것을 나무 수준에서 정리 9.3으로 답했다. 그러므로 대각 증분의 정칙성을 묻는 것은 그 질문의 나머지다. 두 질문을 함께 열면 두 탐색자가 같은 대상으로 향한다. 앞선 검토들도 같은 꼴의 제안을 같은 까닭으로 받아들이지 않았다. 근거에는 증명된 연결로 받쳐지지 않는 문장도 있다. 「(C)에서 남는 것이 대각 증분의 진술로 모인다」와 「답이 (C)의 먼 범위에 닿아 오른쪽 절반에 중요하다」가 그렇다. 명제 9.5–10.4가 Δ^T에서 끌어내는 것은 나무 곡률과 나무 질량의 진술이고, (C)의 원천의 가름에서 크기 방향 몫(숲 수준의 𝖿)의 단봉성은 증명되지 않았다(피드백 3.1절). (DI)에서 증명되어 따르는 먼 범위의 나무 곡률의 양성이 닿는 곳은 오히려 왼쪽 증가의 입력 (A1)과, op-one-chain-two-directions가 꼽은 첫 층 단일 교차다. 「대각 증분은 왜 봉우리를 하나만 가지는가」는 넘겨받은 왼쪽절반 보고가 숲 쪽에서 추측 (L2)로 이미 적은 것과 같은 종류의 물음이다. 내용을 부정하는 판단은 아니다. op-column-sign-persistence를 맡는 다음 탐색자에게는 다음이 가장 정확한 출발점이다: 10.4절의 (DI)와 그 귀납이 멈춘 자리, 맨 위 자리 s=2k+2에서 수준 k−1 쪽이 결손 좌표 식의 범위 밖이라는 점, 극한 U(r). r213dbe8의 조임량의 벗어남, r535d20f의 ε_N, 이 기록의 Δ^T, 왼쪽절반 보고의 머묾 질량 ς가 모두 수준과 크기를 함께 옮길 때의 양으로 나타난다. 그 수렴에서 출발하는 질문이라면 여러 질문에 걸친 물음이 될 수 있다(피드백 6.3절). — [re8460c24720d4fdeaed189d466393fb7](records/re8460c24720d4fdeaed189d466393fb7/record.json)
- revise: 임계 창의 격자 보정. 열 k의 교차 초과 r_0(k)=q_0(k)−k (q_0(k)=min{n≥k: b_{n,k}>b_{n,k−1}})에 대해 r_0(k)^{3/2}/k는 극한값 z_1^{3/2}=0.464(z_1=0.5996은 극한 밀도의 최빈값)로 위에서 내려오고, 계산한 범위(k≤534)에서 그 차는 상대 크기 약 4.6·k^{−1/3}이다. 이 일차 보정의 계수는 정확히 무엇인가. 곧 극한의 방정식 (E1)과 그 유한한 꼴 사이의 항들(대기열 워크의 최댓값의 격자 보정 −2/3, 길이가 k가 아니라 k+r이라는 것, 대각 기울임과 1/e의 차, 크기를 하나 늘릴 때 최대 변위가 머무는 흐름) 가운데 무엇이 참 교차의 자리에 얼마씩 남는가. 그 보정이 양이라는 것, 곧 유한한 k의 봉우리가 극한의 봉우리보다 깊다는 것은 구조에서 나오는가. 그리고 그 이해에서 모든 k≥77에 대한 고른 한계 r_0(k)^{3/2}<k가 나오는가. — review: 수정 요구. 대상은 중요하다: 여러 기록이 같은 k^{−1/3}의 유한 크기 보정 앞에서 멈추고(이 기록의 (K) 6917, RT 교차곱 판정 191, 정리 5.9의 해석 r≥256과 C8, RP의 비명시 문턱), 규칙 1 아래 (CI_mid)를 닫으려면 그 보정을 다루어야 하며, 기존 질문 여섯과 거절 목록에 같은 물음이 없다. 고칠 것: (1) 마지막 물음의 부등식 「모든 k≥77에서 r_0(k)^{3/2}<k」는 기록된 행에서 k=77–82, 84–89, 92–96, 102, 103의 열아홉 열에서 거짓이다(기록 자신의 표도 k=80에서 u_0=1.04). 계산 범위에서 k≥77부터 서는 것은 (CI)의 꼴 r_0(k)≤r_c(k), 곧 (r_0−1)³≤k²이고, 그것은 노드 (CI)와 다른 세션의 구획이 나르는 진술이어서 질문의 중심이 아니다. (2) 첫 물음(일차 보정의 계수)은 RP가 남긴 c_1(x)의 닫힌 꼴에서 걸음의 영점의 이동으로 정해지는 어림 문제이고, RP 9.3절과 그 검토는 그런 항목을 질문의 꼴이 아니라고 보았다. 다시 낸다면 「유한한 k의 봉우리가 극한보다 깊다는 보정의 부호가 어떤 구조에서 나오는가」를 중심에 두고 c_1과의 관계를 밝혀야 한다. (3) 근거의 RP 관찰 P23은 문면 그대로는 검토에서 지지되지 않았다(걸음과 생존 확률로 한정하면 지지); 그 지위를 적고, 「위에서 내려온다」는 단조가 아닌 추세(톱니)로 적어야 한다. (4) 물음 넷을 하나로 좁히고 답의 기준(예: r_0(k)^{3/2}≤k(z_1^{3/2}+a·k^{−1/3}) 꼴의 유한한 k의 정리)을 그 물음에 맞추어야 한다(피드백 7절). — [ra98af63d956e4b288dd1550e0a4853df](records/ra98af63d956e4b288dd1550e0a4853df/record.json)
- revise: 열 방정식의 되먹임 합은 왜 창 뒤에서 음이 아닌가. 정수 k≥1, n≥k+1에 대해 Mem_n(k):=Σ_{j=k}^{n−1} C(n,j)·C_{n−j,k}·d_{j,k}로 둔다. 여기서 C(n,j)는 이항계수, d_{j,k}=b_{j,k}−b_{j,k−1} (b_{j,ℓ}는 최대 변위가 정확히 ℓ인 길이 j의 주차함수의 수)이고, C_{m,k}는 모든 변위가 k보다 작은 길이 m의 소인 주차함수의 수다(A_{k−1}(x)=Σ_n A_{n,k−1}x^n/n!에 대해 1/A_{k−1}(x)=1−Σ_{m≥1}C_{m,k}x^m/m!; A_{n,ℓ}는 최대 변위가 ℓ 이하인 길이 n의 주차함수의 수). 같은 말로 Mem_n(k)=d_{n,k}−(k+1)b_{n−1,k}+(k−1)b_{n−1,k−1}−X_{n,k} (X_{n,k}≥0은 게시된 열 방정식 r6af349eb/c01-column-equation의 수). 추측 (M⁺): 모든 정수 k≥40과 n≥k+⌊2k/5⌋+2에서 Mem_n(k)≥0. 묻는 것은 둘이다. (1) 이 부호를 정하는 구조는 무엇인가. 첫 층(n≤2k−1)에서 이 진술은 「마지막 차가 마지막 자리에 서지 않는 주차함수의 행이 수준 k에서 오른다」와 같고, 「앞 행의 걸음을, 가장 큰 나무가 작을수록 큰 무게 (1+1/(n−L))^{n−L−1}로 다시 재도 음이 아니다」와도 같다. 이것을 직접 보이는 조합적이거나 확률적인 논증이 있는가. (2) 증명에 필요해 보이는 입력, 곧 열 k−1의 뒤의 셀 b_{j,k−1}을 같은 열의 앞선 셀들의 양의 결합으로 위에서 누르는 한계(이 기록의 식 (10.5)에서는 음의 부분합 |P_t|의 위쪽 한계)는 어떤 꼴로 얻어지는가, 아니면 그것 없이 부호를 정하는 길이 있는가. — review: 중요하고 중복이 아니다. 실제 열에서 창 뒤의 기억은 원천 한계의 3–4배인 양수다. 여러 판정이 같은 자리에서 멈추는 까닭을 묻는다. op-column-sign-persistence, op-tilted-base와 다르다. 그러나 진술의 구체성과 정확성이 모자라 수정을 요구한다. (1) 물음이 둘이다. 둘째(열 k−1의 뒤의 셀을 앞선 셀로 위에서 누르는 한계의 꼴)는 생산 세션이 보고 6절에서 따로 낸 셋째 질문 제안을 밝히지 않고 접어 넣은 것이고, 노드 (CB)와 같은 종류다. 하나로 좁히고 무엇이 답으로 인정되는지 적어야 한다. (2) 근거의 「(DR)은 (M⁺)보다 약하다」에 증명이 없다. 어느 방향의 함의도 증명되지 않았고, (M⁺)가 주는 단일 교차는 h_{2k}≤0을 주지 않는다. (3) 「빚이 갚아진 뒤에 되먹임이 왜 양인지」는 물음의 범위와 맞지 않는다. (M⁺)는 n≥k+⌊2k/5⌋+2, 곧 빚이 갚아지기 전부터다(k=160에서 226행부터, 갚아지는 행은 266). (4) 꼬리표 「(M⁺)」는 게시된 r6af349eb(따름 W17, W21)와 r5a649edf((M⁺)_{n,k})에서 다른 진술의 이름이다. (5) 증거의 범위(정확한 값은 k≤80, n≤200; 부동소수는 네 열의 행 3.2k까지)와, k=40에서 행의 여유가 0이라는 것을 적어야 한다(피드백 5.4절). — [r3bd6df852c694ee299e0f7581899e222](records/r3bd6df852c694ee299e0f7581899e222/record.json)
- revise: 첫 층의 자리 (n,k) (k≥2, k+2≤n≤2k−1; r=n−k, N=n+1)에서 사슬 합 Λ_m(y;N)=Σ_{S⊆{1,…,m−1}} Π_{토막}a_토막·Π_{s∈S} y/(N−s) (a_j=j^{j−1}/j!)만으로 정해지는 수 θ*_k(n)=(Σ_{m=1}^{r}π_m ε_m)/(ε_{r+1}·Σ_{m=1}^{r}π_m), ε_m=Λ_m(k+2;N)/Λ_m(k+1;N)−1, π_m=γ_k^{−m}·Λ_m(k+1;N)/(N−m), γ_k=(1+1/k)^{k−2}는 계산한 모든 자리에서 0.24와 0.59 사이에 있고 2/3을 넘지 않는다. 그 까닭은 무엇인가. 어림으로는 「문턱을 하나 올릴 때 사슬 합이 자라는 비율 ε_m이 길이의 제곱근처럼 자라고, 핵의 무게 π_m이 길이의 역제곱근처럼 준다」는 두 사실에서 값 1/2이 나온다. 이 기록은 그 물음을 다음으로 좁혔다. 열 k에서 δ=1/(k+1), ĉ_g=γ_k^{−g}·a_g, b(j)=Σ_{g=1}^{j−k}ĉ_g/(j+1−g), κ_j(i)=(k+1)·ĉ_{j−i}·b(i)/((i+1)·b(j)) (k+1≤i≤j−1)로 두고 선형 재귀 t(j)=1+Σ_i κ_j(i)·t(i), t(j)·x(j)=δ·(t(j)−1)+(1+δ)·Σ_i κ_j(i)·t(i)·x(i) (t(k+1)=1, x(k+1)=0)의 해를 잡으면, x(n)=(Σ_{m=1}^{r}π_m ε_m)/(Σ_{m=1}^{r}π_m)이고, θ*_k(n) ≤ 2/3은 사슬 합이 나오지 않는 부등식 (C): 3·x(n) ≤ 2·δ·μ_0(r+1, (r−1)/(2(k+1))), μ_0(x,η)=(√((4+xη)²+12(x−1))−(4+xη))/3에서 따른다(증명됨). (C)는 계산한 자리에서 선다(관찰). 간격의 무게가 ĉ_g이고 행 i에 내릴 때마다 인자 (k+1)/(i+1)이 붙는 이 갱신 사슬에서, 해 t(n)의 크기와 한 걸음의 낙차 t(j)−Σ_i κ_j(i)·t(i)²/(t(j)−1)을, 기울임이 약한 자리와 임계 창(r가 k^{2/3}의 크기)과 벌크(r가 k의 크기)에서 함께 서는 부등식으로 누르는 구조가 있는가. 있다면 (C)가, 따라서 θ*_k(n) ≤ 2/3이 계산 없이 증명되는가. 그리고 경계항 쪽과 합친 판정 3θ*_k(n) ≤ 2+η_k(n) (η_k(n)=(γ_k·Λ_r(k+2;N)/Λ_{r+1}(k+1;N)−1)/ε_{r+1})이 k≥10의 첫 층 전체에서 서는 것(관찰)도 같은 구조에서 나오는가. — review: 수정 요구. 중요하고 중복이 아니다. 전선의 질문 여섯과 받아들이지 않은 제안에 교차 앞의 문턱 증분 θ*를 묻는 것이 없다. 판정 (S)는 문턱이 없고 (Mono)의 작은 열(21≤k≤264)을 구조로 덮는 길의 한가운데를 겨눈다. 그러나 구체성과 정확성이 모자란다. (1) 진술 안의 「(C)는 계산한 자리에서 선다(관찰)」는 후보 자신의 p-one-layer-observations (3)과 어긋난다. k=10, 15, 20, 30, 60, 100, 120의 첫 층의 끝(r=k−1)에서 (C)의 비는 1.002–1.040으로 1을 넘는다. 계산한 범위에서 (C)가 서는 곳은 띠와 열 10≤k≤264의 교차 앞의 5672곳이다. (2) 묻는 범위가 없다. 「기울임이 약한 자리, 임계 창, 벌크에서 함께」 (C)를 묻는 것은 벌크의 끝에서 (C)가 거짓이므로 물음이 되지 않는다. 교차 앞의 자리, 띠, 첫 층 전체의 θ*≤2/3이나 (S) 가운데 무엇을 어느 범위에서 묻는지 밝혀야 한다. (M2)가 k≤17의 교차 앞 40곳에서 서지 않으므로 작은 열에서 목표가 (C)인지 (S)인지도 밝혀야 한다. (3) 물음이 넷이다(왜 1/2 둘레인가, t를 누르는 구조가 있는가, (C)가 증명되는가, (S)도 같은 구조에서 나오는가). 하나로 좁히고 무엇이 답으로 인정되는지 적어야 한다. (4) 꼬리표 (C)가 전선의 노드 (C)의 이름과 같다. 덧붙여 근거에서 고칠 것이 있다. 「(C)의 비 0.78 이하」는 k=2000에서 0.7835이고, 「k=1000, 2000의 띠에서 θ*≤0.473」은 표본의 말이다(띠 전체 최댓값 0.4747, 0.4775). 「265 아래를 구조로 덮는 길은 어느 기록에도 없다」는 조건 없는 증명에 한정해야 한다. 조건부의 길로 r692807de/p-theorem-C-conditional과 r6af349eb의 c21, c22, c26이 있다. 열마다의 교차 상계로는 ra98af63d/p-resolvent-criterion과 시도의 「보편 교차 한계」가 있다. op-finite-rate-factor의 「기울인 Borel 갱신열」과의 관계도 적어야 한다(피드백 7절). — [rb3d5f156b5ad4538ae8905092806d88b](records/rb3d5f156b5ad4538ae8905092806d88b/record.json)
- revise: 작은 열에서 교차가 「다음 열이 따라 내린다」는 한 걸음의 판정이 서는 창 안에 있다는 것을, 주차함수의 표 없이 주는 논증은 무엇인가. b_{n,ℓ}은 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수, d_{n,k}=b_{n,k}−b_{n,k−1}, q_0(k)는 d_{n,k}>0인 가장 작은 n≥k+1(교차 행), τ(k)=q_0(k)−k다. 알려진 것은 다음과 같다. (1) [증명됨; 상수가 드러나 있지 않다] 어떤 상수 C, k_0가 있어 k≥k_0에서 |τ(k)+1−x_0·k^{2/3}−c·k^{1/3}|≤C이다. x_0=0.5996252는 극한 밀도의 봉우리의 자리, c=1.4881688이다(rc693abe9…/p-crossing-second-term). c>0이라는 것은 수치값에서 읽은 것이다. (2) [증명됨] 드러난 손 상계는 열 k≥97에만 있고 헐겁다: 97≤k≤124에서 τ(k)≤⌈k/3⌉−1, 125≤k≤264에서 τ(k)≤⌈k/4⌉−1, k≥265에서 τ(k)≤⌊(11k/5)^{2/3}⌋+1. (3) [증명됨] 교차 앞에서 다음 열의 차분이 따라 내린다는 한 걸음은 재귀 없는 닫힌 유한합의 부등식 N_k(r)≥0으로 줄고, 그 부등식은 결손 r≤35와 드러난 문턱 이상의 열에서 손으로 증명된다(이 기록의 정리 1, 8, 10). 여기서 정수 k≥3, r≥2에 대해 μ_k(r)=γ_k+2/(k+1)−(1+1/r)^r+(6k/((k+1)(k+2)))·(1−1/r)^{r−1}+[r≥3]·(3ξ_k/(k+3))·(r−1)(r−2)^{r−2}/r^{r−1}, ξ_k=9/2−4/(k+1)−(2γ_k+6k/(k+1))/(k+2), γ_k=(1+1/k)^{k−2}, N_k(r)=μ_k(r)−Σ_{j=2}^{r−1}((j−1)/(k+j+1))·(C(r,j)·j^j·(r−j)^{r−j}/r^r)·μ_k(j)이다(k와 r의 유리수). N_k(r)<0인 가장 작은 r≥2를 r_N(k)라 하면, 열 k의 (Mono)의 사례는 τ(k)≤r_N(k)에서 따른다. (4) [계산; 논문의 표 C5의 범위] 열 21≤k≤96에서 τ(k)≤r_N(k)이고, 그 여유는 열 21, 22에서 한 행, 나머지 열에서 2–6행이다. E(k):=τ(k)+1−x_0·k^{2/3}−c·k^{1/3}은 그 열들에서 2.10과 3.33 사이를 톱니 꼴로 움직이고(단조가 아니다), 같은 식으로 잰 창의 끝 r_N(k)+1−x_0·k^{2/3}−c·k^{1/3}은 4.12 이상이다. (5) [계산; 증명 아님] 대각 아래 한계(정리 Dg: b_{n,k}≥γ_k·n·b_{n−1,k−1}, γ_k=(1+1/k)^{k−2})의 여유를 0으로 둔 닫힘 모형(꽉 찬 궤적)의 교차는 열 14≤k≤152에서 참 교차의 0–2행 뒤에 있고, 여유에 대한 응답이 음이 아니면 그것이 교차의 상계다(이 기록의 appendix.md A절). (6) [증명됨과 계산] 판정의 창은 넓힐 수 있다. 열 k≥3과 정수 m≥2에 대해 W^{(m)}_r=Φ_r+Σ_{j=1}^{r−1}Bor(r−j)·[((k+2)/(k+j+1))·W^{(m)}_j+[j≤m]·3D_j/(k+j+1)] (1≤r≤k−1)로 둔다. 여기서 Bor(i)=e^{−i}i^{i−1}/i!, Φ_r=(γ_k+2/(k+1)−1)·Bor(r)−e·Bor(r+1), D_j=−e^{−j}·(k!/((k+j)!·k^{k−2}))·d_{k+j,k}다(열 k의 처음 m행의 차분만 든다; 그 행들은 k의 닫힌 식이다). [증명됨] 2≤r≤k−1이고 m+1≤l≤r−1인 모든 l에서 d_{k+l,k}≤0이며 W^{(m)}_r≥0이면 d_{k+r,k+1}≤d_{k+r,k}이고(정리 1의 m행 꼴), 창이 넓으면 한 열의 교차의 상계가 그 아래 열들의 상계가 된다(명제 13: q_0(K)≤Q≤2k−1이고 k≤i<K인 열마다 어떤 m에서 W^{(m)}_r≥0 (2≤r≤Q−i)이면 q_0(k)≤…≤q_0(K)이고 그 열들의 (Mono)의 사례가 모두 성립한다). [계산; 정확한 유리수, 열 14≤k≤96] W^{(3)}_r≥0은 열 23까지는 첫 층 끝까지, 열 24–96에서는 교차 결손보다 열한 행 이상 뒤까지 서고, m≤6이면 W^{(m)}_r≥0이 열 96까지 첫 층 전체(r≤k−1)에서 선다.그 창 아래에서는 게시된 손 상계 q_0(97)≤129와 표의 부호 셋(d_{81,64}>0, d_{54,40}>0, d_{39,27}>0)이면 열 21–96에 충분하다. 그러나 손으로 증명된 창은 m=2의 일차 한계의 것((3)의 N_k(r)≥0)뿐이고, W^{(m)}의 부호를 그보다 깊이 재는 손 논증이 없다. 묻는 것은 하나다. 열 21≤k≤96에서(또는 드러난 범위의 모든 k에서) 「교차가 판정의 창 안에 있다」를 주는, 주차함수의 표를 쓰지 않는 논증은 무엇인가. 답으로 인정되는 것은 다음 가운데 하나다. (가) 지금 증명된 창에 닿는 날카로운 상계 τ(k)≤r_N(k). 예컨대 τ(k)^{3/2}≤k·(x_0^{3/2}+a·k^{−1/3}) 꼴의 드러난 유한한 k의 정리로서 열 21≤k≤96에서 a<3.99인 것(참 교차가 요구하는 것은 a≥3.51). 같은 내용의 다른 꼴, 예컨대 τ(k)+1≤x_0·k^{2/3}+c·k^{1/3}+C에서 C<4.12인 것도 답이다. (나) 꽉 찬 궤적의 부호와 응답의 양성의 증명, 또는 교차의 자리를 정하는 다른 구조의 논증으로서 같은 결론을 주는 것. (다) 넓은 창: 어떤 m에서 W^{(m)}_r≥0을 일차 한계보다 깊이 주는 손 논증과, 그 창에 닿는 표 없는 교차의 상계(헐거워도 되고, 명제 13에 따라 열마다 따로 있을 필요가 없다). (라) 그런 논증이 설 수 없음을 보이는 사실. — review: 고쳐 내라(revise). 중요하고(r44512889 검토 6.5절과 아홉째 조건의 끝 문단이 이 「왜」를 물었다) 중복이 아니다(전선의 질문 일곱 가운데 유한한 작은 열에서 교차의 자리를 표 없이 정하는 논증을 묻는 것이 없다; 가장 가까운 ra98af63d의 「임계 창의 격자 보정」은 revise였고, rb3d5f156의 step-response-two-thirds는 한 걸음 쪽을 묻는다). 고칠 것은 넷이다. (1) 두 창을 섞었다. 진술 (가)는 r≤r_N(k)−1을 「지금 증명된 창」이라 하고 근거는 「지금 손으로 증명된 창이 참 교차에서 한두 행」이라 하지만, r_N은 닫힌 꼴의 유리수 N_k(r)를 정확히 셈해 정한 창이고, 정리 10이 손으로 덮는 영역은 문턱 κ(r)가 표의 τ로 정해져 r≤τ(k)−1(여유 0행)이다. 예: (21,11)은 r_N(21)=12라서 정확한 창 안이지만 κ(11)=26이고 N^♭_k(11)≥0은 k≥22에서야 선다. 그래서 답 (가)를 얻어도 τ(k)≤r≤T(k)−1의 N_k(r)≥0이 따로 든다(해설 6.1절이 스스로 적은 것). 답의 꼴마다 어느 창에 닿아야 하는지, 그 틈을 손으로 주어야 하는지 명시적 유리수의 기계 셈도 받는지를 밝혀야 한다. (2) 알려진 것 (2) 「드러난 손 상계는 열 k≥97에만 있고 헐겁다」가 거짓이다: 열 125–128, 131, 132에서 ⌈k/4⌉−1은 창에 닿고, 게시된 표 없는 상계 reea223c…/p-crossing-bound(k≥253에서 q_0(k)≤k+r_c(k); k≥537은 rc693abe9…/c-ci-537, 개정 89의 rdc057f2의 (CI)의 해)가 빠졌는데 97≤k≤264에서 r_c≤r_N−1이어서 열 253–264에서 창 안이다. 아래 한계 rc693abe9…/p-still-negative도 알려진 것에 들 만하다. (3) 근거의 과장: 「세 자리에 같이 쓰인다」(다른 두 자리의 부호 43개는 τ≤r_c를 요구하는데 열 82–96에서 r_c=19–21, r_N=25–27이어서 τ≤r_N 꼴의 답은 그것을 주지 않는다), 「열 k≤76에서는 (CI)의 꼴이 거짓」(k=64–66, 71–74에서 τ=r_c), ra98af63d 판정의 넷을 「따랐다」(그 둘째의 중심을 옮겼다). (4) 「(또는 드러난 범위의 모든 k에서)」의 뜻, 진술 (4)의 2.10(참 최솟값 2.0993), 그리고 얼린 뒤 개정 93에 게시된 r418c4ecc…의 교차 행의 끼움(k+r^U≤q_0≤k+r^E)과의 관계를 밝혀야 한다(피드백 7절). — [rdf5f9d9da43245b0a1fd735e5e968b2e](records/rdf5f9d9da43245b0a1fd735e5e968b2e/record.json)

