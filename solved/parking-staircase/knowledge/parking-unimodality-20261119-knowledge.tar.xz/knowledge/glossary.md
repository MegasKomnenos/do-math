# Global glossary

Research revision: 120

Use primary names in new writing. Historical names and symbols below are scoped to their linked definitions.
Definitions retain their source wording; consult the [frontier](frontier.md) for current node status.

## 누적 개수

Symbol: A_{n,k}

정수 n ≥ 1, k ≥ 0에 대해 A_{n,k} := #{α ∈ PF_n : M(α) ≤ k}. 약속으로 A_{0,k} := 1 (모든 k), n ≥ 1이고 k < 0이면 A_{n,k} := 0. b_{n,k} = A_{n,k} − A_{n,k−1}.

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-cumulative

Historical name/symbol: 누적 개수와 열의 차분 (A_{n,ℓ}, p_n, d_{n,k}) — [local definition](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json) — r3e8ad56ece2549449ad86ef9412d9cfa/g02-cumulative-count
Historical name/symbol: 문턱, 문턱 누적 개수 (k, Z_n(k)) — [local definition](records/rbbb706e129cd4230bbd4b7c916ead789/record.json) — rbbb706e129cd4230bbd4b7c916ead789/threshold-count

## 한 칸 차분

Symbol: d_{n,k}

정수 n ≥ 1, k ≥ 1에 대해 d_{n,k} := b_{n,k} − b_{n,k−1} = A_{n,k} − 2A_{n,k−1} + A_{n,k−2}. 행 n의 단봉성은 d_{n,1},…,d_{n,n−1}에서 엄격한 음수 뒤에 엄격한 양수가 오지 않는다는 것이다.

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-step-difference

## Cayley 계수

Symbol: c_m

정수 m ≥ 0에 대해 c_m := (m+1)^{m−1}/m! (c_0 = 1). p_m := (m+1)^{m−1} = |PF_m|. 꼭짓점 m개의 뿌리 나무의 수를 m!로 나눈 것은 c_{m−1}이다.

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-cayley

## 나무 곡률

Symbol: δ_t, ξ_t

열 k ≥ 2를 고정했을 때 δ_t := τ_{t,k} − 2τ_{t,k−1} + τ_{t,k−2} (t ≥ 1). t < k에서 0, δ_k = −k^{k−2}, t ≥ k+1에서 δ_t = (k+1)b_{t−1,k} − (k−1)b_{t−1,k−1}. ξ_t := δ_t/t!, C_k(x) := T_k − 2T_{k−1} + T_{k−2} = Σ_{t≥k} ξ_t x^t.

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-tree-curvature

## 기울인 기저

Symbol: B_k(n), n_B(k)

열 k ≥ 2, n ≥ k에 대해 B_k(n) := Σ_{t=k}^{n} ξ_t x_k^t. n_B(k) := min{n ≥ 2k+1 : B_k(n) ≥ 0} (없으면 ∞).

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-tilted-base

## 결과 순열과 용량

Symbol: t_s(σ)

주차함수 α의 결과 순열 σ는 자리 s에 선 차의 번호 σ(s)다. 자리 s의 용량은 t_s(σ) := 1 + #{자리 s의 바로 왼쪽에 연달아 놓인, 번호가 σ(s)보다 작은 차}. 결과 순열이 σ일 때 자리 s의 차의 변위는 0,…,t_s−1의 어느 값이든 될 수 있고 자리마다 독립이다. 자리 s의 부모를 오른쪽에서 처음 만나는 번호가 더 큰 차의 자리로 두면 용량은 부분나무의 크기다.

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-capacity

## 성질 K

y ≥ 2이고 W가 {y−1,y,y+1}에서 양수인 함수일 때, 모든 θ ≥ 0에서 W(y+1)e^{−θ/(y+1)} + W(y−1)e^{−θ/(y−1)} ≥ 2W(y)e^{−θ/y}이면 W가 y에서 성질 K를 가진다고 한다. θ = 0이 볼록성이다. 합과, ∫e^{−θ/z}μ(dθ) (μ는 [0,∞) 위의 양의 측도) 꼴의 인자를 곱하는 것에 닫혀 있다. 성질 K*는 (W(y+1)/(y+1))^{y+1}(W(y−1)/(y−1))^{y−1} ≥ (W(y)/y)^{2y}라는 조건이고(W(z)/z가 1/z에 대해 세 점 로그볼록), 성질 K를 함의한다. 추측 K는 z ↦ x_k^z λ_b(z)와 z ↦ c_{N_0−z}λ_b(z)가 k에서 성질 K를 가진다는 추측이다(범위는 본문 7.5절). 뒤의 것은 앞의 것에서 따른다(정리 P12).

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-property-K

## 소인 주차함수, 소인 행, 소인 곡률

Symbol: C_{m,c}, π_c, b^P_{m,ℓ}, d^P_{m,k}, δ_k

길이 m≥1의 주차함수 가운데 모든 변 1≤i≤m-1이 건너지는 것을 소인 주차함수라 한다(길이 1의 주차함수 (1)은 소인). 정수 c≥0에 대해 C_{m,c}는 모든 변위가 c보다 작은 길이 m의 소인 주차함수의 수, π_c=Σ_{m≥1}C_{m,c}x^m/m! (π_0=0), δ_k=π_{k+1}-π_k. 0≤ℓ≤m-1에 대해 b^P_{m,ℓ}=C_{m,ℓ+1}-C_{m,ℓ}는 최대 변위가 정확히 ℓ인 길이 m의 소인 주차함수의 수이고 (b^P_{m,ℓ})_{ℓ=0}^{m-1}을 소인 행이라 한다. d^P_{m,k}=b^P_{m,k}-b^P_{m,k-1} (ℓ≥m이면 b^P_{m,ℓ}=0)을 소인 곡률이라 한다.

Membership: permanent
Source: [local definition](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json) — r3e8ad56ece2549449ad86ef9412d9cfa/g05-prime-parking-function

Historical name/symbol: 소 주차함수의 생성함수와 소 곡률 (Π_k, χ_k) — [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-prime

## 계단 명제 (Col), (Diag), 봉우리 지표

Symbol: (Col), (Diag), pk_n

(Col): 모든 n≥2와 1≤k≤n-1에서, d_{n,k}≥0이면 d_{n+1,k}≥0이다. (Diag): 모든 n≥2와 1≤k≤n-1에서, d_{n,k}≤0이면 d_{n+1,k+1}≤0이다. pk_n=#{k: 1≤k≤n-1, d_{n,k}>0}.

Membership: permanent
Source: [local definition](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json) — r3e8ad56ece2549449ad86ef9412d9cfa/g09-staircase-statements

## 임계 기울임

Symbol: x_c, λ_c, S(c)

정수 c≥1에 대해 x_c=(c/(c+1))^{c-1}, λ_c=1/x_c. a_c의 계수 z_N=A_{N,c-1}/N!에 대해 z_c/z_{c-1}=λ_c이고, 정리 K에 따라 z_N x^N이 N에 비증가가 되는 가장 큰 x가 x_c다. S(c)=Σ_{n=2}^{c+1}n^{n-1}x_c^n/n!.

Membership: permanent
Source: [local definition](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json) — r3e8ad56ece2549449ad86ef9412d9cfa/g13-critical-tilt

Historical name/symbol: 임계 성장비와 임계 기울임 (𝔯, x_k) — [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-critical-tilt

## 대각 둘째 차분, 대각 볼록성

Symbol: DC^T(t), DC(N)

기울임 x>0과 수준 k≥2에서 기울인 나무 질량 n_c(t)=min(t,c)A_{t-1,c-1}x^t/t!와 기울인 핵 질량 u_N(c)=A_{N,c-1}x^N/N!에 대해, 크기와 수준을 함께 하나 올린 값, 가운데 값, 함께 하나 내린 값의 둘째 차분 DC^T(t)=n_{k+1}(t+1)-2n_k(t)+n_{k-1}(t-1), DC(N)=u_{N+1}(k+1)-2u_N(k)+u_{N-1}(k-1)을 대각 둘째 차분이라 한다. 대각 볼록성은 임계 기울임 x=x_k=(k/(k+1))^{k-1}에서 모든 t≥k+1 (N≥k+1)에 대해 이 값이 음이 아니라는 진술이다(추측 DC). 대각 방향은 결손 n+1-M_n의 문턱을 고정하고 크기를 움직이는 방향이다.

Membership: permanent
Source: [local definition](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json) — r3e8ad56ece2549449ad86ef9412d9cfa/g18-diagonal-convexity

Historical name/symbol: 초과와 궤도 함수, 초과 고정 분해 (D_a, Lo, In, Tp) — [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-excess-orbit

## Borel 질량

Symbol: Bor(m), 𝗋(m), τ_N, λ_N, T, U

τ_N=N^{N-1}/N!, λ_N=N^{N-2}/N! (N≥1), T(x)=Σ_{N≥1}τ_N x^N, U(x)=Σ_{N≥1}λ_N x^N (형식적 멱급수; T=x e^T, U=T-T²/2, x∂_x U=T). Bor(m)=e^{-m}m^{m-1}/m! (m≥1), Bor(m)=0 (m≤0); Σ_{m≥1}Bor(m)=1. 이웃한 값의 비 𝗋(m)=Bor(m+1)/Bor(m)=e^{-1}(1+1/m)^{m-1}은 m에 대해 증가하고 1보다 작으므로 Bor는 감소하고 로그볼록이며, Bor(m) ≤ (2π)^{-1/2}m^{-3/2}. Ren(m)=e^{-m}m^m/m! (m≥0). 수열의 합성곱은 (a*c)(N)=Σ_{γ≥1}a(γ)c(N-γ).

Membership: permanent
Source: [local definition](records/r213dbe848e5c4e8483afbcbfe76addec/record.json) — r213dbe848e5c4e8483afbcbfe76addec/borel-mass

## 단일 사슬 범위

Symbol: s<N≤2s+2

수준 s≥1과 크기 N이 s<N≤2s+2를 만족하는 범위. 이 범위에서 [x^N]W_s가 선형 방정식 x∂_x W̃ - sT W̃ = R_s의 해의 계수와 같고(처음 어긋나는 크기가 N=2s+3), 길이 N-1의 주차함수에 길이가 s를 넘는 바깥 블록이 많아야 하나 있다. 수준에 대한 둘째 차분을 쓰는 식의 범위는 N≤2s다. 행 N에서는 결손 r=N-s≤(N+2)/2, 곧 수준 ℓ=s≥⌈(N-2)/2⌉에 해당한다. n=N-1이 짝수이면 전선의 노드 「오른쪽 절반」의 범위(결손 r≤⌊(N+3)/2⌋)보다 한 걸음 좁다.

Membership: permanent
Source: [local definition](records/r213dbe848e5c4e8483afbcbfe76addec/record.json) — r213dbe848e5c4e8483afbcbfe76addec/single-chain-range

Historical name/symbol: 오른쪽 절반 (이 기록에서) — [local definition](records/r535d20f3d6cc4384838c89248eb27bbe/record.json) — r535d20f3d6cc4384838c89248eb27bbe/right-half-here

## 블록, 바깥 블록, 결과 순열

Symbol: t_v, 𝖡_n

결과 순열은 전역 용어 「결과 순열과 용량」의 것이다(어느 차가 어느 자리에 섰는가). 차 v가 설 때 v의 자리 바로 왼쪽으로 이어진 찬 자리들과 v의 자리를 합친 구간이 v의 블록이고 그 길이가 t_v다(결과 순열만으로 정해지고, v가 선 자리의 「용량」과 같은 수다). 두 블록은 서로소이거나 한쪽이 다른 쪽을 품는다. 다른 블록에 품기지 않는 블록이 바깥 블록이다. 결과 순열이 주어지면 변위들은 독립이고 d_v는 {0,…,t_v-1}에서 균등하다. 𝖡_n은 길이 n의 균등한 주차함수의 가장 긴 블록의 길이.

Membership: permanent
Source: [local definition](records/r213dbe848e5c4e8483afbcbfe76addec/record.json) — r213dbe848e5c4e8483afbcbfe76addec/block

## 생존 질량, 질량 셀, 셀의 열

Symbol: a(N,s), β(N,s), κ_s(N), 𝔰_s(N), ρ_1(N)

N≥1, s≥1에서 a(N,s)=e^{-N}A(N-1,s-1)/N! = (Bor(N)/N)·Pr(M_{N-1}<s) (생존 질량), β(N,s)=e^{-N}b_{N-1,s}/N! = a(N,s+1)-a(N,s) (질량 셀). 수준 s를 고정한 N↦β(N,s)가 셀의 열, r↦β(N,N-r)이 결손으로 적은 행 N이다. κ_s(N)=Bor(N)-Σ_{i=s+1}^{N-1}Bor(i)Bor(N-i), 𝔰_s(N)=Σ_{S=s+1}^{N-1}Bor(N-S)a(S,s+1) (셀의 열의 원천; s+1<N≤2s+2에서 (s+1)𝔰_s(N)=N a(N,s+1)-κ_s(N)), ρ_1(N)=-(𝔰_s(N)-𝔰_s(N-1))/β(N-1,s) (s+3≤N≤2s+2). β(N+1,s)≥β(N,s)는 b_{N,s}≥e(N+1)b_{N-1,s}와 같다.

Membership: permanent
Source: [local definition](records/r213dbe848e5c4e8483afbcbfe76addec/record.json) — r213dbe848e5c4e8483afbcbfe76addec/mass-cell

## 조임, 조임량, 단조 기억, 판정 (Z)

Symbol: E(N), x(N), μ(N), Λ, (Z), (Z_N)

g가 {1,2,…} 위의 비증가인 음이 아닌 수열이고 u≥0(어떤 자리 아래에서 0)가 구간 I에서 m(N)u(N)=Σ_{γ≥1}g(γ)u(N-γ)+S(N) (m>0)을 만족할 때: 감소분 x(N)=u(N-1)-u(N), μ(N)=m(N)-m(N-1), 조임량 E(N)=μ(N)-(S(N)-S(N-1))/u(N-1) (u(N-1)>0인 N에서). 차분한 방정식은 Σ_γ g(γ)x(N-γ)=m(N)x(N)-E(N)u(N-1). u가 N_1까지 오르고 그 뒤 내리다가 N_2에서 다시 오른다면 g(N_2-N_1-1)>E(N_2)이고 E(N_2)<Λ·E(N_1+1), Λ=max{g(N_2-j)/g(N_1+1-j): j≤N_1, x(j)≠0, g(N_1+1-j)>0}≤1. 이 두 부등식으로 오름 전환을 막는 논증이 조임이다. 둘째 부등식의 바탕, 곧 봉우리에서 오름 구간의 기억 Σ_{j≤N_1}g(N_1+1-j)|x(j)|가 E(N_1+1)u(N_1) 이하이고 그 뒤로는 g가 비증가이므로 줄기만 한다는 사실이 단조 기억이다. 판정 (Z)는 봉우리 뒤의 모든 N_2에서 E(N_2)≥min{g(N_2-N_1-1), Λ·E(N_1+1)}이라는 조건이다. 행 N에서는 u(r)=β(N,N-r), m(r)=N/(N-r), g=Bor, Λ=Bor(r_2-2)/Bor(r_1-1)이고, E(r)=[(N/(N-r))x(r)-(Bor*x)(r)]/u(r-1)은 행의 수만으로 정해진다. 그때의 판정을, r_2의 범위 r_1+2≤r_2≤R과 함께, (Z_N)으로 적는다(R=⌊(N+3)/2⌋이면 결론이 전선의 노드 「오른쪽 절반」의 n=N-1의 경우다). 균질 Lomax 모형에서는 E≡2ε.

Membership: permanent
Source: [local definition](records/r213dbe848e5c4e8483afbcbfe76addec/record.json) — r213dbe848e5c4e8483afbcbfe76addec/squeeze

Historical name/symbol: 두 점 보조정리 (보조정리 T) — [local definition](records/r535d20f3d6cc4384838c89248eb27bbe/record.json) — r535d20f3d6cc4384838c89248eb27bbe/two-point-lemma

## 나무 수

Symbol: τ_{t,k}, T_k

t ≥ 1, k ≥ 0에 대해 τ_{t,k} := min(t,k+1)·A_{t−1,k} (k < 0이면 0). 마지막 차가 맨 끝 자리 t에 서는 길이 t의 주차함수 가운데 최대 변위가 k 이하인 것의 수이고, 꼭짓점마다 무게 min(1,(k+1)/t_v)를 준 [t] 위의 뿌리 나무의 무게 합과 같다. T_k(x) := Σ_{t≥1} τ_{t,k}x^t/t!, F_k = exp(T_k).

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-tree-number

Historical name/symbol: 닫힌 주차함수 (Θ(N,s), Θ_s(x)) — [local definition](records/r213dbe848e5c4e8483afbcbfe76addec/record.json) — r213dbe848e5c4e8483afbcbfe76addec/closed-parking-function
Historical name/symbol: 나무형 급수와 나무 곡률 (T_c, N_c(t), ℬ_k, δ^T_t(k)) — [local definition](records/r3e8ad56ece2549449ad86ef9412d9cfa/record.json) — r3e8ad56ece2549449ad86ef9412d9cfa/g07-tree-series
Historical name/symbol: 지수 구조 (정리 P) — [local definition](records/r535d20f3d6cc4384838c89248eb27bbe/record.json) — r535d20f3d6cc4384838c89248eb27bbe/exponential-structure

## 전이 비

Symbol: q_N

N≥2, 1≤r≤N−1에 대해 q_N(r)=[φ_{N+1}(r+1)−φ_N(r+1)]/m_N(r). 원래 기호로 n=N−1, k=n−r에서 [Pr(M_{n+1}≤k)−Pr(M_n≤k−1)]/Pr(M_n=k). 분자 ε_N(r)을 (생존의) 대각 증분, c_N(r)=φ_N(r)−φ_{N+1}(r+1)=(1−q_N(r))·m_N(r)을 열 감소분이라 한다. m_{N+1}(r)=(1−q_N(r))·m_N(r)+q_N(r−1)·m_N(r−1). 모든 셀에서 0≤q_N(r)≤1이고(정리 S), M_{n+1}−M_n∈{0,1}인 어떤 짝지음에서도 q_N(r)=Pr(M_{n+1}=M_n | M_n=k)이다.

Membership: permanent
Source: [local definition](records/r535d20f3d6cc4384838c89248eb27bbe/record.json) — r535d20f3d6cc4384838c89248eb27bbe/transfer-ratio

Historical name/symbol: 대각 증분(숲 수준) (κ_N(ℓ)) — [local definition](records/r21b6d042fd634a489fd8efa89c9ac103/record.json) — r21b6d042fd634a489fd8efa89c9ac103/g-kappa
Historical name/symbol: 머무름 흐름과 진술 (E½) (Δ_n(K), R_n) — [local definition](records/r45979fd0c72c4e47b1b84c69db6c07d5/record.json) — r45979fd0c72c4e47b1b84c69db6c07d5/stay-flow
Historical name/symbol: 흐름과 머무를 확률 (J_n(k), stay_n(k)) — [local definition](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json) — r6af349eb6a0d4ed29b9650ff599e1e90/g11-flow
Historical name/symbol: 머무는 흐름, 올라가는 흐름 (ς_n(k), λ_n(c)) — [local definition](records/rbd60d0cff05f491db76133d43d573e2f/record.json) — rbd60d0cff05f491db76133d43d573e2f/stay-up-flows

## 접합부

열 k에서 n이 2k+1을 막 넘긴 행들, 행 n에서는 수준 ⌈n/2⌉−1 근처. 왼쪽 부분에서 b_{n,k} ≥ b_{n,k−1}의 여유가 가장 작은 곳이고, 계산한 범위에서 행의 이웃비가 극소가 되는 자리다. 엄밀한 경계를 가진 용어가 아니라 자리를 가리키는 이름이다.

Membership: permanent
Source: [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-junction

## 여분 자리 족, 허용 목록, (r,m)의 행

Symbol: c^{(r)}_{m,ℓ}

정수 m≥1, r≥1. 차 m대가 뿌리 명제의 규칙으로 자리 1,…,m+r−1의 줄에 주차한다. 선호 수열 α∈{1,…,m+r−1}^m이 허용 목록이라는 것은 m대가 모두 서는 것이고, 그때 r−1자리가 빈다. 허용 목록의 수는 r(m+r)^{m−1}이다. 0≤ℓ≤m−1에 대해 c^{(r)}_{m,ℓ}은 최대 변위가 정확히 ℓ인 허용 목록의 수이고 수열 (c^{(r)}_{m,0},…,c^{(r)}_{m,m−1})이 (r,m)의 행이다. r=1이면 뿌리 명제의 행 (b_{m,ℓ})이다. 이 모형들 전체가 여분 자리 족이다. 이 족에서 문자 r은 원 위의 빈자리의 수(같은 말로 숲의 나무 하나의 무게)이고 결손이 아니다. 균등한 허용 목록의 변위의 다중집합은 [m] 위의 숲에 r^{#나무}에 비례하는 확률을 준 법칙 아래에서 부분나무 크기 위의 독립 균등 표식의 다중집합과 같은 법칙을 가지며, (r,m)의 행을 r(m+r)^{m−1}로 나눈 것은 길이 m+r−1의 균등한 주차함수에서 처음 m대의 최대 변위의 법칙이다.

Membership: permanent
Source: [local definition](records/r6473edca25384dc79286473a00ead1c2/record.json) — r6473edca25384dc79286473a00ead1c2/spare-spot-family

## 자리 (n,k)의 결손

Symbol: r = n−k

한 칸 차분 d_{n,k} (1≤k≤n−1)의 자리 (n,k)에 대해 r = n−k. 행의 마지막 자리 k = n−1에서 1이다. 인수인계 문서와 기록 r535d20f3d6cc4384838c89248eb27bbe의 결손과 같은 수이고, 기록 r213dbe848e5c4e8483afbcbfe76addec의 결손(= n+1−ℓ)은 같은 셀에서 하나 크다. 논문은 여분 자리 모형을 다루는 곳에서만 글자 r을 빈자리의 수로 쓴다.

Membership: permanent
Source: [local definition](records/rbbb706e129cd4230bbd4b7c916ead789/record.json) — rbbb706e129cd4230bbd4b7c916ead789/position-deficit

## 시각 t의 블록, 블록을 닫다

원 위의 주차 과정에서 차 몇 대가 선 순간에, 연달아 찬 자리들의 극대인 줄과 그 줄 바로 다음(시계 방향)의 빈자리를 합친 것을 블록이라 한다. 빈자리 앞이 빈자리이면 그 빈자리 하나가 크기 1의 블록이다. 블록의 크기에는 그 빈자리가 포함된다. 블록들은 원을 가르고, 크기의 합은 N이며, 블록의 수는 빈자리의 수다. 차가 블록을 닫는다는 것은 그 블록을 끝내는 빈자리를 채운다는 것이고, 그때 그 블록은 시계 방향 다음 블록과 한 블록이 된다(보조정리 2.2). 차가 닫는 블록은 전역 용어 「블록, 바깥 블록, 결과 순열」이 그 차의 블록이라 부르는 구간과 같고 그 크기가 t_v다.

Membership: permanent
Source: [local definition](records/rbbb706e129cd4230bbd4b7c916ead789/record.json) — rbbb706e129cd4230bbd4b7c916ead789/block-in-time

## 이력 숲, 감소 숲

Symbol: Ψ(σ)

[n]의 순열 σ(결과 순열)에 대해 이력 숲 Ψ(σ)는 자리의 집합 [n] 위의 뿌리 숲으로, 자리 i의 부모는 σ_j>σ_i인 가장 작은 j>i이고 그런 j가 없으면 i는 뿌리이며, 자리 i에는 차 σ_i가 라벨로 붙는다. 자리 i의 부분나무는 자리 i−h_i+1,…,i이고(h_i는 용량) 그 크기가 그 차가 닫은 블록의 크기다. 라벨 집합 [n] 위의 숲 가운데 모든 꼭짓점이 자기 자식들보다 큰 라벨을 가진 것을 감소 숲이라 하고, σ ↦ Ψ(σ)는 [n]의 순열에서 [n] 위의 감소 숲으로 가는 전단사다(명제 2.4). 이력 숲의 뿌리들을 원의 자리 n+1의 가상 뿌리에 잇고 차 t+1,…,n 위의 변을 지우면 차 t대 뒤의 블록들이 나온다.

Membership: permanent
Source: [local definition](records/rbbb706e129cd4230bbd4b7c916ead789/record.json) — rbbb706e129cd4230bbd4b7c916ead789/history-forest

## 균등 숲, 가상 뿌리, 균등 숲의 표식

Symbol: F, D_v

[n] 위의 뿌리 숲은 꼭짓점 집합이 [n]이고 성분마다 뿌리가 하나 정해진 숲이다(자식들 사이에 순서가 없다). 그 수는 p_n = (n+1)^{n−1}이다. 모든 뿌리를 덧붙인 꼭짓점 0(가상 뿌리)에 이으면 {0,…,n} 위의 뿌리가 0인 나무가 되고 그런 나무가 모두 한 번씩 나온다. 균등 숲은 그 p_n개 가운데 하나를 균등하게 뽑은 것이다. 뿌리 숲 F가 주어졌을 때 표식 (D_v)_{v∈F}는 독립이고 D_v가 {0,…,t_v−1}에서 균등한 변수들이다(같은 말로 D_v = ⌊U_v t_v⌋, U_v는 [0,1) 위의 독립인 균등 변수). 균등 숲 F에 대해 다중집합 {(t_v, D_v)}는 균등한 주차함수의 (차가 닫은 블록의 크기, 그 차의 변위)의 다중집합과 같은 법칙을 가지고, 최대 변위는 max_v D_v의 법칙을 가진다(정리 2.6(b), 따름정리 2.7). 균등 숲의 라벨은 차의 번호가 아니다.

Membership: permanent
Source: [local definition](records/rbbb706e129cd4230bbd4b7c916ead789/record.json) — rbbb706e129cd4230bbd4b7c916ead789/uniform-forest-marks

## 부분나무 크기 무게, 문턱 무게

Symbol: g, Φ_g(F), Z_n[g], F_g, g_k

양의 정수 위의 함수 g(값은 유리수를 품는 가환환)와 뿌리 숲 F에 대해 Φ_g(F) = ∏_{v∈F} g(t_v), Z_n[g] = Σ_F Φ_g(F) (합은 [n] 위의 뿌리 숲 전체; Z_0[g] = 1), F_g(x) = Σ_{n≥0} Z_n[g] x^n/n!. 변위의 한 함수 w의 곱 ∏_i w(d_i)를 주차함수에 걸쳐 더한 것은 g(t) = (1/t) Σ_{d<t} w(d)인 Z_n[g]다. 문턱 무게는 g_k(t) = min(1, k/t)이고 Z_n[g_k] = Z_n(k). F_{g_k}는 기록 rc31497e9df27478584efc43f79e164f2의 F_{k−1}이다.

Membership: permanent
Source: [local definition](records/rbbb706e129cd4230bbd4b7c916ead789/record.json) — rbbb706e129cd4230bbd4b7c916ead789/subtree-size-weight

Historical name/symbol: 문턱 무게, 문턱 가중 법칙 (g_y, Φ_g, Z_n[g], Z_n(y)) — [local definition](records/r3dc4f6e9f36d435d8ad1f57fd92ec352/record.json) — r3dc4f6e9f36d435d8ad1f57fd92ec352/threshold-weighted-law
Historical name/symbol: 문턱 기울임 법칙 ($\mathbb E_y$) — [local definition](records/r790d81e586524894a2220b314fcfab51/record.json) — r790d81e586524894a2220b314fcfab51/threshold-tilted-law
Historical name/symbol: 문턱 무게, 문턱 범함수, 기울인 법칙 (g_y, Φ_g, Z_n[g], Z_n(y), E_y) — [local definition](records/re6ac5d71df9e4920851b6a28b19d1501/record.json) — re6ac5d71df9e4920851b6a28b19d1501/threshold-functional-tilted-law

## 얼린 다항식, 곡률항, 경계항, 교차곱

Symbol: K_{n,k}(y), C_∓, B_∓, S_{n,k}

정수 1≤k≤n−1과 실수 y에 대해 K_{n,k}(y)=Σ_F Π_{v: t_v>k} y/t_v ([n] 위의 뿌리 있는 표지 숲 F 전체에 대한 합, t_v는 v와 그 자손의 수). 누적 개수 y↦Z_n(y)=Σ_F Π_v min(1,y/t_v)의 구간 [k,k+1] 위의 다항식 조각을 실수 전체로 연장한 것이고 계수가 음이 아니다. Z_n(j)=A_{n,j−1} (정수 j≥1), Z_n(0)=0. 곡률항 C_-=K(k+1)−2K(k)+K(k−1), C_+=K(k+2)−2K(k+1)+K(k); 경계항 B_-=K(k−1)−Z_n(k−1), B_+=K(k+2)−Z_n(k+2) (C_+, B_+는 k≤n−2에서). d_{n,k}=C_-−B_-, d_{n,k+1}=C_+−B_+가 모든 자리에서 성립한다. 교차곱 S_{n,k}=B_+C_-−B_-C_+=B_+·d_{n,k}−B_-·d_{n,k+1} (1≤k≤n−2). S_{n,k}>0은 b_{n,k}>(B_+·b_{n,k−1}+B_-·b_{n,k+1})/(B_++B_-)와 같다. 넘겨받은 자료의 이름은 얼린 용량 다항식(스플라인 조각), 넘침 Γ^∓, 경계 응답 부등식이다.

Membership: permanent
Source: [local definition](records/r496399b680604ffda982aedf9ac9b480/record.json) — r496399b680604ffda982aedf9ac9b480/g-frozen-polynomial

Historical name/symbol: 얼린 다항식과 그 곡률항·경계항 (K_{n,k}(y), C_{n,k}, E_{n,k}) — [local definition](records/re6ac5d71df9e4920851b6a28b19d1501/record.json) — re6ac5d71df9e4920851b6a28b19d1501/frozen-polynomial

## 곡선, 곡선 앞, 곡선 뒤

Symbol: k=(n−k)^{3/2}

자리 (n,k) (1≤k≤n−1)가 k²<(n−k)³을 만족하면 곡선 앞에 있다고 하고, k²≥(n−k)³이면 곡선 뒤에 있다고 한다. 곡선은 결손 r=n−k가 k^{2/3}인 자리들이고 극한 법칙의 눈금 1에 해당한다. 한 행 안에서 곡선 앞은 수준이 낮은 쪽이다. 곡선 뒤의 영역은 행 방향 (n,k)→(n,k+1)과 대각 방향 (n,k)→(n+1,k+1)으로 닫혀 있고, 곡선 앞의 영역은 열 방향 (n,k)→(n+1,k)로 닫혀 있다.

Membership: permanent
Source: [local definition](records/r496399b680604ffda982aedf9ac9b480/record.json) — r496399b680604ffda982aedf9ac9b480/g-curve

## 목표 T, 오른쪽 목표, 곡선 위의 증가

Symbol: T, (T_R), (CI)

목표 T: 모든 정수 n≥301과 1≤k≤n−1, k²<(n−k)³인 모든 정수 k에서 b_{n,k}≥b_{n,k−1} (논문 추측 5.11; 뿌리의 충분조건이고 동치는 아니다). 오른쪽 목표 (T_R): 같은 부등식을 ⌈n/2⌉≤k에 제한한 것. 곡선 위의 증가 (CI): 모든 정수 k≥260에서, r³>k²인 가장 작은 양의 정수 r=r_c(k)에 대해 n=k+r_c(k)에서 b_{n,k}>b_{n,k−1}. 논문은 목표 T를 (a) 왼쪽 영역 2k+1≤n<21k², (b) 한가운데 k=⌈n/2⌉, (c) 곡선 앞의 첫 층 k>⌈n/2⌉의 세 부분으로 가른다(모두 n≥301). (T_R)은 (b)와 (c)의 논리곱이다.

Membership: permanent
Source: [local definition](records/r496399b680604ffda982aedf9ac9b480/record.json) — r496399b680604ffda982aedf9ac9b480/g-target-t

## 곡률과 손실 (걸음의 Taylor 분해)

Symbol: V_{n,k}, L_{n,k}

정수 1≤k≤n−1에 대해, 문턱 범함수 Z_n(y)=Σ_F Π_v min(1,y/t_v) (실수 y>0; 합은 [n] 위의 뿌리 숲, t_v는 부분나무 크기; 정수 k에서 Z_n(k)=A_{n,k−1})는 정수 사이의 각 구간에서 다항식이고, 곡률은 V_{n,k}=∫_{k−1}^{k+1}(1−|y−k|)Z_n''(y)dy, 손실은 L_{n,k}=(1/k)Σ_F Π_{t_v>k}(k/t_v)·#{v: t_v=k} = Z_n'(k−)−Z_n'(k+)다(L은 k=n에서도 정의된다). 둘 다 양수이고 d_{n,k}=V_{n,k}−L_{n,k}다. 손실은 rc31497e…의 J_n(k)와 같은 수다. 전역 용어집의 「나무 곡률」 δ_t, 「소인 곡률」과는 다른 양이고, 얼린 다항식의 분해 d=C_{n,k}−E_{n,k}(동률–막힘 항등식)와는 V≥C, L≥E의 관계에 있다.

Membership: permanent
Source: [local definition](records/re6ac5d71df9e4920851b6a28b19d1501/record.json) — re6ac5d71df9e4920851b6a28b19d1501/curvature-loss

## 핵 기울임과 대각 기울임

Symbol: x*_k, x†_k

핵 기울임 x*_k:=(k/(k-1))((k-2)/(k-1))^{k-2}=(1-1/(k-1)^2)x_{k-2} (k≥3; x*_2:=2): 되먹임 핵 x^m C_{m,k}/m!이 모든 m≥1에서 비증가가 되는 가장 큰 x. 대각 기울임 x†_k:=1/γ_k=(k/(k+1))^{k-2}=(1+1/k)x_k: 정리 Dg가 「기울인 대각 결손 U_{j-1}-V_j≤0」이 되는 기울임. x_k는 공유 용어집의 임계 기울임이고 k≥3에서 x_k<x*_k≤x†_k (등호는 k=3).

Membership: permanent
Source: [local definition](records/r6af349eb6a0d4ed29b9650ff599e1e90/record.json) — r6af349eb6a0d4ed29b9650ff599e1e90/g05-three-tilts

## Borel 무게의 모멘트 측도

Symbol: $\nu$

$\varsigma(v)=\frac{\sin v}ve^{v\cot v}$ ($0<v<\pi$)의 역함수 $v(\varsigma)$로 정의한 $(0,e)$ 위의 측도 $\nu(d\varsigma)=\pi^{-1}v(\varsigma)d\varsigma$. $\gamma_g=g^{g-1}/g!=\int_0^e\varsigma^{g-1}\nu(d\varsigma)$ ($g\ge1$), 곧 Cayley 계수 $c_m=\int_0^e\varsigma^m\nu(d\varsigma)$ ($m\ge0$)이다(보조정리 P1). $\tilde J$는 $\nu$의 일계수 직교 다항식의 삼항 점화식 계수로 만든 삼중대각 행렬($\tilde J_{j,j+1}=1$, $\tilde J_{jj}=\alpha_j$, $\tilde J_{j,j-1}=\beta_j$)이다.

Membership: permanent
Source: [local definition](records/r43fbfedfdc19477aab896641475ff59a/record.json) — r43fbfedfdc19477aab896641475ff59a/borel-measure

## 꼭짓점 역전수와 라벨 모형

Symbol: I_v(F), M(F), Ach(F), Π_ℓ(F)

𝔽_n은 꼭짓점 집합 [n] 위의 뿌리 숲의 집합(|𝔽_n| = (n+1)^{n−1}), sub(v)는 v와 그 자손들의 집합, t_v = |sub(v)|. 꼭짓점 역전수 I_v(F) := #{u ∈ sub(v): u < v} (0 ≤ I_v ≤ t_v−1; 시도의 보고는 「지역 역전수」라 불렀고 문헌의 vertex inversion number다). M(F) := max_v I_v(F), 달성 꼭짓점의 집합 Ach(F) := {v: I_v(F) = M(F)}. 수준 무게 Π_ℓ(F) := Π_v min(1,(ℓ+1)/t_v) (ℓ ≥ 0)는 F의 모양에 균등한 라벨을 붙였을 때 M ≤ ℓ일 확률이다. b_{n,ℓ} = #{F ∈ 𝔽_n: M(F) = ℓ}. 같은 정의를 전순서가 있는 임의의 유한 꼭짓점 집합 위의 뿌리 숲에도 쓴다.

Membership: permanent
Source: [local definition](records/rf9e63ea4495b446f8f5d48a74525d8d1/record.json) — rf9e63ea4495b446f8f5d48a74525d8d1/g-vertex-inversion

Historical name/symbol: 꼭짓점 반전수 (ι_v) — [local definition](records/rbbb706e129cd4230bbd4b7c916ead789/record.json) — rbbb706e129cd4230bbd4b7c916ead789/vertex-inversion-number

## 표준 수열

Symbol: $(\rho_j)$

수열 $(s_j)_{j\ge0}$, $s_0\ne0$에 대해 $(j+1)s_{j+1}=\sum_{i=0}^j\rho_is_{j-i}$ ($j\ge0$)로 정해지는 수열 $(\rho_j)_{j\ge0}$. 생성함수로 $zS'(z)/S(z)=\sum_j\rho_jz^{j+1}$. $\mathbb Z_{\ge0}$ 위의 확률 법칙이 이산 자기분해가능하다는 것은 표준 수열이 음이 아니고 비증가라는 것과 같다(Steutel–van Harn).

Membership: permanent
Source: [local definition](records/re61cc9dab20e4d54b6adb052a2538c5a/record.json) — re61cc9dab20e4d54b6adb052a2538c5a/canonical-sequence

Historical name/symbol: 정준 핵 (g_n(γ), h=g-1) — [local definition](records/re85cbef4a34742f4a0a7651067259725/record.json) — re85cbef4a34742f4a0a7651067259725/canonical-kernel

## 대각 괄호와 열 괄호

Symbol: (DB), (CB)

$k\ge2$, $n\ge k+1$에 대해, 전역 용어집의 임계 기울임 $x_k$의 역수 $\mathfrak r_k:=\lambda_k=(1+\frac1k)^{k-1}$(이 기록은 임계 성장비라 부른다)로 한 칸 차분을 $d_{n,k}=[b_{n,k}-\mathfrak r_kn\,b_{n-1,k-1}]+[\mathfrak r_kn\,b_{n-1,k-1}-b_{n,k-1}]$로 가를 때 앞의 것이 대각 괄호, 뒤의 것이 열 괄호다. $(\mathrm{DB}_{n,k})$는 대각 괄호가 음이 아니라는 명제, $(\mathrm{CB}_{n,k})$는 열 괄호가 음이 아니라는 명제(열 $k-1$의 임계 성장 한계)다. $(\mathrm{CB}_{n,k})$는 임계 기울임 $\mathsf x_k$에서 「수준 $k-1$ 이하의 핵 질량의 한 칸 감소분이 수준 $k-2$ 이하의 핵 질량의 한 칸 감소분 이상」이라는 것과 같다. 노드 (CB)는 「모든 $k\ge148$, $n\ge2k+1$에서 $(\mathrm{CB}_{n,k})$」이다.

Membership: permanent
Source: [local definition](records/re61cc9dab20e4d54b6adb052a2538c5a/record.json) — re61cc9dab20e4d54b6adb052a2538c5a/critical-brackets

## 대각 괄호의 기저

Symbol: (Base)

$k\ge2$, $n_0\ge k+1$에 대해, 전역 용어집의 임계 기울임 $\mathsf x_k$로 기울인 나무 괄호 $\tau_m\mathsf x_k^{\,m}$, $\tau_m:=(b^T_{m,k}-\mathfrak r_km\,b^T_{m-1,k-1})/m!$의 접미합 $\sum_{m=i}^{n_0}\tau_m\mathsf x_k^{\,m}$ ($k+1\le i\le n_0$)이 모두 음이 아니라는 조건. 전역 용어집의 기울인 기저와는 $\mathsf B_k(n_0)=\sum_{m=k+1}^{n_0}\tau_m\mathsf x_k^{\,m}-b^T_{n_0,k-1}\mathsf x_k^{\,n_0}/n_0!$의 관계다. 노드 (Base)는 「모든 $k\ge148$에서 $n_0=2k+1$의 이 조건」이다.

Membership: permanent
Source: [local definition](records/re61cc9dab20e4d54b6adb052a2538c5a/record.json) — re61cc9dab20e4d54b6adb052a2538c5a/critical-base

## Euler 결함

Symbol: U_y(N)

y ≥ 1, N ≥ y+1에 대해 U_y(N) := ((N−y)/N)·P_{y+1}(N) + (y/N)·P_y(N) − P_{y+1}(N+1). Euler 부등식의 위쪽 Pr(M_{n+1} ≤ k) − Pr(M_n ≤ k−1) ≤ ((n−k+1)/(n+1))·Pr(M_n = k)은 n = N−1, k = y로 놓아 U_y(N) ≥ 0과 같다. 전이 비로는 U_y(N) = ((r+1)/N − q_N(r))·m_N(r), r = N−1−y.

Membership: permanent
Source: [local definition](records/rbc6a3c2f72094ecc9bc6f8e683900bf6/record.json) — rbc6a3c2f72094ecc9bc6f8e683900bf6/g-euler-defect

## 대각 교차곱, (GL), (GL_top)

Symbol: (GL), (GL_top)

첫 층의 자리 (n,k)에서 대각 교차곱 부등식은 C_−(n+1,k+1)·B_−(n,k) ≤ C_−(n,k)·B_−(n+1,k+1), 같은 말로 Gain_{N+1}(y+1)·Loss_N(y) ≥ Gain_N(y)·Loss_{N+1}(y+1) (N = n+1, y = k), 곧 결손을 고정했을 때 동률 대 막힘의 비 Loss/Gain이 크기에 대해 늘지 않는다는 것이다. 전역 용어 「얼린 다항식, 곡률항, 경계항, 교차곱」의 행 방향 교차곱 S_{n,k} = B_+C_− − B_−C_+ > 0(노드 (X))의 대각 방향 짝이다. 비 R_n(k) := C_−(n,k)/B_−(n,k)로 적으면 R_{n+1}(k+1) ≤ R_n(k)다. (GL)은 이 부등식이 y ≥ 3, y+2 ≤ N ≤ 2y의 모든 자리에서 성립한다는 시도의 추측이고 (N,y) = (30,15)에서 거짓이다. (GL_top)은 d_{n,k} ≤ 0인 첫 층의 자리에서만 성립한다는 추측이고 그 자리의 (Diag)를 함의한다. k ≥ 2(r+1)^{3/2} + 8(r+1)인 자리(정리 P2)와 r ≥ 600, k ≥ r^{3/2}인 자리(정리 P8)에서는 부등식이 엄격하게 성립한다.

Membership: permanent
Source: [local definition](records/rbc6a3c2f72094ecc9bc6f8e683900bf6/record.json) — rbc6a3c2f72094ecc9bc6f8e683900bf6/g-diagonal-cross-product

## 끼임 성질

Symbol: (SW_n)

정수 n ≥ 1에 대해 (SW_n): 어떤 κ > 0이 있어 모든 0 ≤ ℓ ≤ n에서 min(b_{n,ℓ−1}, b_{n,ℓ}) ≤ b_{n+1,ℓ}/κ ≤ max(b_{n,ℓ−1}, b_{n,ℓ}) (b_{n,−1} = b_{n,n} = 0). 추측이다(2 ≤ n ≤ 29에서 정확 확인). 행 n이 단봉이고 (SW_n)이 서면 행 n+1이 단봉이고 봉우리가 0칸 또는 1칸 움직인다.

Membership: permanent
Source: [local definition](records/rbc6a3c2f72094ecc9bc6f8e683900bf6/record.json) — rbc6a3c2f72094ecc9bc6f8e683900bf6/g-sandwich

Historical name/symbol: 끼임 ((INT)_n, (INT), M^-_n, M^+_n) — [local definition](records/rb631a853ad394807bf00eb9ea82b4de6/record.json) — rb631a853ad394807bf00eb9ea82b4de6/g-interlacing

## 합성, 절단 집합, 부분의 수

Symbol: S, Q

정수 m≥1의 합성은 단위 칸 m개로 된 선분을 이어진 부분들로 자르는 방법이다. 합성을 그 절단 집합 S⊆{1,…,m−1}(부분들의 부분합 가운데 0과 m 사이에 있는 것들)과 같은 것으로 본다. 부분들은 {0}∪S∪{m}의 이웃한 원소 사이의 간격이고, 부분의 수는 Q=|S|+1이다. 주차 문제에서는 단일 사슬 범위(n≤2k+1)에서 가장 아래의 무거운 꼭짓점의 결손을 m이라 할 때, 그 위의 무거운 꼭짓점들의 결손 N−t_v (N=n+1)가 절단점이다.

Membership: permanent
Source: [local definition](records/r3dc4f6e9f36d435d8ad1f57fd92ec352/record.json) — r3dc4f6e9f36d435d8ad1f57fd92ec352/composition-cut-set

## 절단 인자를 가진 Cayley 합성의 법칙

Symbol: 𝒲_λ, ℙ_λ, 𝔼_λ, ℙ_1, ℙ_ρ, T_{m,q}

a_j=j^{j−1}/j! (용어집 「Borel 질량」의 τ_j, 「Cayley 계수」의 c_{j−1}). 양의 인자 λ=(λ_s)_{1≤s≤m−1}에 대해 절단 집합 S⊆{1,…,m−1}의 무게는 𝒲_λ(S)=∏_{부분} a_{부분}·∏_{s∈S} λ_s이고, ℙ_λ는 {1,…,m−1}의 부분집합 위에서 𝒲_λ에 비례하는 확률 법칙, 𝔼_λ는 그 기댓값이다. ℙ_1은 모든 인자가 1인 법칙, ℙ_ρ는 모든 인자가 상수 ρ>0인 법칙이다. T_{m,q}=[z^m]T(z)^q=(q/m)·m^{m−q}/(m−q)! (1≤q≤m)은 𝒲_1 아래에서 부분이 q개인 합성들의 전체 질량이고 Σ_{q=1}^m T_{m,q}=m·a_m이다. 주차 문제의 문턱 인자는 λ_s=y/(N−s)다. 넘겨받은 원고 5장의 타일 측도와 같은 대상이다(유색 길이 1 타일의 위치가 절단점, d=m−1).

Membership: permanent
Source: [local definition](records/r3dc4f6e9f36d435d8ad1f57fd92ec352/record.json) — r3dc4f6e9f36d435d8ad1f57fd92ec352/cayley-composition-law

Historical name/symbol: 균질한 사슬, 문턱 윤곽의 사슬 (Z_m(h), Υ_m(h), ℙ_h, η, a) — [local definition](records/r44512889b9024c73b64e5639c1a85837/record.json) — r44512889b9024c73b64e5639c1a85837/homogeneous-chain
Historical name/symbol: 합성 위의 법칙, 지우기 규칙 (W_λ, P_λ, Q, T_{m,q}, s_m, D_m) — [local definition](records/r496399b680604ffda982aedf9ac9b480/record.json) — r496399b680604ffda982aedf9ac9b480/g-composition-law
Historical name/symbol: 끊는 점, 끊는 점의 집합 위의 무게, 합성의 합 Λ (𝒲_λ(S), ℙ_λ, Λ_m(y;N)) — [local definition](records/re6ac5d71df9e4920851b6a28b19d1501/record.json) — re6ac5d71df9e4920851b6a28b19d1501/cut-point-weight

## 생일 법칙과 D_m

Symbol: P_j, s_m, D_m

m의 합성 위의 ℙ_1 아래에서 Pr(Q≥j)=P_j=(m)_j/m^j (1≤j≤m; (m)_j=m(m−1)⋯(m−j+1)). s_m=𝔼Q=Σ_{j=1}^m P_j. m≥2에서 D_m=𝔼Q(Q−1)(Q−2)/𝔼Q(Q−1)=3((m+2)s_m−3m)/(2(m−s_m)). D_m≤(3/2)(s_m−1)<(19/10)√m이고 D_m≤D_{m+1}이다(보조정리 4.4). 넘겨받은 원고의 생일 법칙 bd_d와 같은 법칙이다(d=m−1, 유색 타일 수 j=Q−1).

Membership: permanent
Source: [local definition](records/r3dc4f6e9f36d435d8ad1f57fd92ec352/record.json) — r3dc4f6e9f36d435d8ad1f57fd92ec352/birthday-law

## 나무 행

Symbol: y_{t,ℓ}

정수 t≥1, ℓ≥0에 대해 y_{t,ℓ} := τ_{t,ℓ} − τ_{t,ℓ−1} (τ는 전역 용어 「나무 수」이고 τ_{t,−1}=0). 0≤ℓ≤t−1에서 y_{t,ℓ} = (ℓ+1)·A_{t−1,ℓ} − ℓ·A_{t−1,ℓ−1}이고(A는 전역 용어 「누적 개수」), ℓ≥t에서 y_{t,ℓ}=0이다. 마지막 차가 맨 끝 자리 t에 서는 길이 t의 주차함수 가운데 최대 변위가 정확히 ℓ인 것의 수이고, Σ_{ℓ=0}^{t−1} y_{t,ℓ} = t^{t−1}이다. 수열 (y_{t,0},…,y_{t,t−1})을 크기 t의 나무 행이라 한다. 전역 용어 「나무 곡률」은 열 k≥2에서 δ_t = y_{t,k} − y_{t,k−1}이다. 기록마다의 표기: r535d20f3d6cc4384838c89248eb27bbe와 r6473edca25384dc79286473a00ead1c2의 y_{t,k}(앞 기록은 이것을 나무 셀이라 부르고, 결손 좌표로 정규화한 y_{t,t−1−x}/t^{t−1}을 나무 행이라 부른다), r43fbfedfdc19477aab896641475ff59a의 β^{(t)}_ℓ, re8460c24720d4fdeaed189d466393fb7의 나무 질량 B^T_ℓ(t) = e^{−t}·y_{t,ℓ}/t!, r6473edca25384dc79286473a00ead1c2의 θ_t(ℓ) = y_{t,ℓ}/t^{t−1}.

Membership: permanent
Source: [local definition](organizations/ofa6ce5cc5dbf42448a0db79601b305b2/organization.json) — ofa6ce5cc5dbf42448a0db79601b305b2/tree-row

Historical name/symbol: 나무 행 ($\beta^{(t)}$) — [local definition](records/r43fbfedfdc19477aab896641475ff59a/record.json) — r43fbfedfdc19477aab896641475ff59a/tree-row
Historical name/symbol: 나무 셀 (y_{t,k}) — [local definition](records/r535d20f3d6cc4384838c89248eb27bbe/record.json) — r535d20f3d6cc4384838c89248eb27bbe/tree-cell
Historical name/symbol: 나무의 열 ($B_k$, $b^T_{n,k}$) — [local definition](records/re61cc9dab20e4d54b6adb052a2538c5a/record.json) — re61cc9dab20e4d54b6adb052a2538c5a/tree-column

## 교차 행

Symbol: q_0(k)

열 k≥1에 대해 q_0(k) := min{n ≥ k+1 : d_{n,k} > 0} (d는 전역 용어 「한 칸 차분」; 그런 n이 없으면 ∞). 열 k의 한 칸 차분이 처음 양이 되는 행이다. 전선의 노드 (Mono)는 「모든 k≥1에서 q_0(k) ≤ q_0(k+1)」과 같은 진술이다(r6af349eb6a0d4ed29b9650ff599e1e90의 검토 6.1절). 기록마다의 표기: r6af349eb6a0d4ed29b9650ff599e1e90의 q_0(k)(교차 초과는 r_0(k) = q_0(k) − k), re8460c24720d4fdeaed189d466393fb7의 n_1 = N_1 − 1, r6473edca25384dc79286473a00ead1c2의 q_0^{(r)}(k)에서 r=1인 경우. 나무 곡률이 처음 양이 되는 크기(re8460c24720d4fdeaed189d466393fb7의 t_1)는 다른 수다.

Membership: permanent
Source: [local definition](organizations/ofa6ce5cc5dbf42448a0db79601b305b2/organization.json) — ofa6ce5cc5dbf42448a0db79601b305b2/crossing-row

## 무거운 꼭짓점의 수와 문턱 꼭짓점의 수

Symbol: χ_y(F), ν_k(F)

뿌리 숲 F와 실수 y>0에 대해 χ_y(F)=#{v: t_v>y} (무거운 꼭짓점의 수), 정수 k≥1에 대해 ν_k(F)=#{v: t_v=k} (문턱 꼭짓점의 수). 결과 순열로는 용량이 y보다 큰 자리의 수와 용량이 정확히 k인 자리의 수다(rc31497e…의 N_σ, j_σ).

Membership: permanent
Source: [local definition](records/re6ac5d71df9e4920851b6a28b19d1501/record.json) — re6ac5d71df9e4920851b6a28b19d1501/heavy-threshold-counts

Historical name/symbol: 무거운 꼭짓점, 가벼운 꼭짓점, 문턱 꼭짓점 ($\chi_y(F)$, $\nu_k(F)$) — [local definition](records/r790d81e586524894a2220b314fcfab51/record.json) — r790d81e586524894a2220b314fcfab51/heavy-vertex
Historical name/symbol: 문턱, 무거운 꼭짓점, 가벼운 숲 — [local definition](records/rc31497e9df27478584efc43f79e164f2/record.json) — rc31497e9df27478584efc43f79e164f2/g-threshold-heavy

## 거꾸로 가는 전이 비

Symbol: 𝗉̂_n(k), 𝗉̂^T_s(k)

n≥2, 0≤k≤n−1에서 𝗉̂_n(k)=[Pr(M_n≤k)−Pr(M_{n−1}≤k−1)]/Pr(M_n=k). M_n−M_{n−1}∈{0,1}인 짝지음에서 Pr(M_{n−1}=k | M_n=k)와 같다. 나무 판 𝗉̂^T_s(k)는 M_n 자리에 나무(마지막 차가 마지막 칸에 서는 주차함수)의 최대 변위 M^T_s를 넣은 것이다. 탐색의 줄어들 확률은 𝗉_s(y)=𝗉̂^T_{s+1}(s−y)이고, 첫 기록 8.3절의 거꾸로 가는 비 p_N(r)은 𝗉̂_n(k) (N=n, r=n−1−k)다. 분자 Pr(M_n≤k)−Pr(M_{n−1}≤k−1)은 기록 r6af349eb6a0d4ed29b9650ff599e1e90의 흐름 J_n(k)이고, 그 기록의 머무를 확률(첫 기록의 앞으로 가는 비)은 같은 분자를 Pr(M_{n−1}=k)로 나눈 것이다. 관찰 R은 (R1) 𝗉̂_{n+1}(k+1)≤𝗉̂_n(k), (R3) 𝗉̂_{n+1}(k)≥𝗉̂_n(k), (R4) 𝗉̂_n(k+1)≤𝗉̂_n(k)가 2≤n≤300의 모든 칸에서 성립한다는 계산 관찰이다.

Membership: permanent
Source: [local definition](records/rb9ca489721054b348b41d527c3d0197c/record.json) — rb9ca489721054b348b41d527c3d0197c/reverse-transfer-ratio

## 여크기

Symbol: $g_v$, $C_m$

$[n]$ 위의 뿌리 숲의 꼭짓점 $v$에 대해 $g_v=N-t_v$ ($N=n+1$, $t_v$는 가지 부분나무의 크기). 가상 뿌리를 단 나무에서 $v$의 가지 부분나무 밖에 있는 꼭짓점의 수이고 $1\le g_v\le n$이다. 여크기가 $N/2$보다 작은 꼭짓점들은 한 사슬에 놓이고 여크기가 서로 다르다. $C_m=\#\{v:g_v\le m\}$. 인수인계 문서 3절의 여크기 $G_v$와 같고, 논문은 「꼭짓점의 결손(deficit of a vertex)」이라 부른다. 자리 $(n,k)$의 결손 $n-k$와는 다른 양이다.

Membership: permanent
Source: [local definition](records/r790d81e586524894a2220b314fcfab51/record.json) — r790d81e586524894a2220b314fcfab51/co-size

## 무늬, 출현, 층

Symbol: $\mathfrak p$, $\varrho$, $t_u$, $\gamma_u$, $c_u$

$N=n+1$. 무늬는 뿌리 $\varrho$를 가진 유한한 뿌리 나무 $\mathfrak p$로서, 뿌리가 아닌 마디 $u$마다 양의 정수 $t_u$와 자식형 또는 자손형이라는 형이 붙은 것이다. $t_\varrho=N$으로 두고 $\gamma_u=t_u-\sum t_{u'}$ (합은 $\mathfrak p$에서 $u$의 자식 $u'$에 걸침)로 두며 모든 $u$에서 $\gamma_u\ge1$을 요구한다. $c_u$는 $u$의 자식 가운데 자손형인 것의 수다. $\{0,\dots,n\}$ 위의, 뿌리가 $0$인 뿌리 나무 $\tau$ 안에서 $\mathfrak p$의 출현은 마디에서 꼭짓점으로 가는 사상 $u\mapsto v_u$로서 $v_\varrho=0$이고, 뿌리가 아닌 마디 $u$와 그 부모 $u^-$마다: $v_u$의 부분나무의 꼭짓점이 $t_u$개이고, $v_u$가 $v_{u^-}$의 진자손이며($u$가 자식형이면 자식), 부모가 같은 서로 다른 마디의 $v_u$, $v_{u'}$의 부분나무가 서로소인 것이다. 마디 $u$의 층은 $v_u$의 부분나무의 꼭짓점 가운데 $u$의 자식 $u'$들의 $v_{u'}$의 부분나무에 들지 않는 것들의 집합이고, 꼭짓점이 $\gamma_u$개이며 $v_u$를 품고 연결되어 있다.

Membership: permanent
Source: [local definition](records/r790d81e586524894a2220b314fcfab51/record.json) — r790d81e586524894a2220b314fcfab51/pattern

## 뼈대, 덤불, 계수 κ_k

Symbol: $S_k(z)$, $\kappa_k(j)$

$k\ge1$을 정수, $F$를 가상 뿌리 $0$을 단 $[n]$ 위의 숲이라 하자. $t_v>k$인 꼭짓점들과 $0$은 나무를 이루고(무거운 꼭짓점의 조상은 무겁다) 이것을 $F$의 뼈대라 한다. 뼈대의 꼭짓점 $u$와, $u$의 자식 가운데 부분나무의 꼭짓점이 $k$개 이하인 것들의 부분나무를 합친 것을 $u$의 덤불이라 한다. $S_k(z)=\sum_{t=1}^ka_tz^t$ ($a_t=t^{t-1}/t!$), $\kappa_k(j)=[z^j]\,z\,e^{S_k(z)}$. $j!\,\kappa_k(j)$는 뿌리의 모든 자식의 부분나무가 꼭짓점 $k$개 이하인, 꼭짓점 $j$개의 뿌리 라벨 나무의 수이고, $j\le k+1$이면 $\kappa_k(j)=a_j$다. $k+1\le j\le2k+2$에서 $\kappa_k(j)=a_j-\sum_{i=1}^{j-k-1}a_ia_{j-i}$이고, 이것은 공개 기록 rc31497e9df27478584efc43f79e164f2의 「가벼운 숲의 계수」 $\lambda_{j-k}(k)$와 같다. 7절의 핵 $\kappa_N(s)$(아래 항목)는 첨자와 인자가 다른 별개의 대상이다.

Membership: permanent
Source: [local definition](records/r790d81e586524894a2220b314fcfab51/record.json) — r790d81e586524894a2220b314fcfab51/skeleton

## 임계 창, 벌크, 한가운데

행 n의 자리 (n,k)를 결손 r=n−k의 크기로 가리키는 느슨한 이름들이다(전역 용어 「자리 (n,k)의 결손」). 임계 창은 결손이 n^{2/3}의 유계 배수인 자리들, 곧 극한 법칙의 눈금 z=r/n^{2/3}이 유계인 범위다. 행의 봉우리와 전역 용어 「곡선」(k=(n−k)^{3/2}, 눈금 z=1)이 여기에 있다. 벌크는 오른쪽 절반(k≥⌈n/2⌉) 가운데 결손이 n^{2/3}보다 훨씬 큰 자리들이다. 운영자 질문 op-two-regimes는 두 영역의 경계를 r≈2n^{2/3}와 r≈2.4n^{2/3} 사이쯤으로 적는다. 한가운데는 k=⌈n/2⌉인 자리, 곧 n=2k이거나 n=2k−1인 자리다. 전역 용어 「접합부」(열 k에서 n이 2k+1을 막 넘긴 행들)는 그 바로 왼쪽이다. 어느 것도 정확한 경계를 가진 정의가 아니고 기록마다 경계를 다르게 잡는다. 이 조직화의 모듈 설명에서 자리를 가리키는 데만 쓴다.

Membership: permanent
Source: [local definition](organizations/o99bd36617a1c49b6bdef5592a1dc941f/organization.json) — o99bd36617a1c49b6bdef5592a1dc941f/row-regions

## 첫 간격 무게

Symbol: β_N

N≥2, 1≤g≤N−1에 대해 β_N(g)=C(N,g)·g^{g−1}·(N−g)^{N−g−1}/N^{N−1}=Bor(g)·Bor(N−g)/Bor(N), Bor(j)=e^{−j}·j^{j−1}/j!. 길이 N−1의 균등한 주차함수에서 크기 N−g인 나무(마지막 차가 마지막 칸에 서는 연속 토막)가 맨 위에 있는 개수의 기댓값. 1≤g≤⌊(N+1)/2⌋에서 비증가이고 β_{N+1}(g)≤β_N(g), β_{N+1}(g+1)≤β_N(g), Σ_{g=1}^{N−1} β_N(g)=2(N−1)/N.

Membership: permanent
Source: [local definition](records/r535d20f3d6cc4384838c89248eb27bbe/record.json) — r535d20f3d6cc4384838c89248eb27bbe/first-gap-weight

Historical name/symbol: 다리 무게와 꼬리 합 (𝗾_L(i), 𝗧_L(j)) — [local definition](records/re8460c24720d4fdeaed189d466393fb7/record.json) — re8460c24720d4fdeaed189d466393fb7/g-bridge-weights

## 넘김 확률, 나무의 넘김 확률, 넘김 증분

Symbol: 𝗌(N), 𝗎(N), 𝖿(N), χ(N), 𝗏(s), α_s, χ^T(s), s_χ

수준 k ≥ 2, 크기 좌표 N ≥ 1에서 𝗌(N) := Pr(M_{N−1} < k) = S_k(N)/Bor(N), 넘김 확률 𝗎(N) := 1 − 𝗌(N) (최대 변위가 k 이상일 확률), 𝖿(N) := 𝗎(N) − 𝗎(N−1), χ(N) := 𝖿(N−1) − 𝖿(N). 나무의 넘김 확률 𝗏(s) := 1 − τ_{s,k−1}/s^{s−1} (크기 s의 나무 가운데 수준이 k 이상인 것의 비율; s ≤ k에서 0, s ≥ k에서 1 − (k/s)𝗌(s)), 넘김 증분 α_s := 𝗏(s) − 𝗏(s−1) (s ≥ k+1) = k[A_{s−2,k−1}/(s−1)^{s−2} − A_{s−1,k−1}/s^{s−1}], χ^T(s) := α_{s−1} − α_s (s ≥ k+2), χ^T(k+1) := −α_{k+1}. s_χ := min{s ∈ [k+2, 2k+2] : χ^T(s) > 0} (없으면 2k+3). 수준을 밝힐 때는 아래 첨자 j를 붙인다(𝗎_j, 𝗏_j).

Membership: permanent
Source: [local definition](records/re8460c24720d4fdeaed189d466393fb7/record.json) — re8460c24720d4fdeaed189d466393fb7/g-exceedance

## 지속의 창, 먼 행, 깊은 행

열 k의 행 n을 가리키는 느슨한 이름들이다. 지속의 창은 r6af349eb6a0d4ed29b9650ff599e1e90의 따름 P1이 한 칸 차분 d_{n,k}의 부호 변화가 많아야 한 번임을 증명한 행 k≤n≤k+R_s(k)+1이다. 이 조직화의 설명문은 이것을 「따름 P1의 창」이나 「교차 뒤의 창」이라 적고, 문맥이 분명한 곳에서는 그냥 「창」이라 적는다(rb631a853ad394807bf00eb9ea82b4de6이 「지속의 창」이라 부른다). R_s(k)=max{R≤k−2: 1≤r≤R인 모든 r에서 (k+r+1)·x†_k·g(r)≤k+r} (x†_k는 전역 용어 「핵 기울임과 대각 기울임」의 대각 기울임, g(r)=ε_{r+1}/ε_r, ε_m=(m−1)^{m−1}/m!)이고, k≥3이면 R_s(k)≥⌊2k/5⌋이며 크기는 0.47k쯤이다. 기록들은 창의 끝을 흔히 결손 ⌊2k/5⌋+1로 적는다. 먼 행은 창을 지난 행이다. r69068ac5755e47bf83611f535d8af02c와 r425e458e24d0488980f871f2046aceb5에서는 창의 끝에서 한가운데 n=2k까지의 행(첫 층의 먼 행)이고, r6c69820c7ee5409fbdaea5c28410bda2에서는 n≥k+⌊2k/5⌋+2인 모든 행이어서 접합부와 왼쪽 부분을 품는다. 깊은 행은 접합부를 지난 n≥2k+3쯤의, 왼쪽 부분의 행이다. 어느 것도 정확한 경계를 가진 정의가 아니고 기록마다 경계를 다르게 잡는다. 열의 교차 행 q_0(k)(전역 용어 「교차 행」)가 창 안에 있다는 것은 따름 P1이 말하지 않고, k≥265에서는 ra98af63d956e4b288dd1550e0a4853df의 들머리 정리가 준다. 전역 용어 「임계 창, 벌크, 한가운데」는 같은 자리들을 행 쪽에서 결손의 눈금으로 가리키는 이름이고, 「창」이라는 낱말이 그쪽에서는 임계 창을 뜻한다. 이 조직화의 모듈 설명에서 자리를 가리키는 데 쓴다.

Membership: permanent
Source: [local definition](organizations/o396680701eb24dddb332c325413603fa/organization.json) — o396680701eb24dddb332c325413603fa/column-regions

## 열의 단일 교차

정수 k≥1에 대해, 열 k가 (모든 행에서) 단일 교차라는 것은 q_0(k)<∞이고 k≤n<q_0(k)인 모든 n에서 d_{n,k}≤0, n≥q_0(k)인 모든 n에서 d_{n,k}>0이라는 것이다(d_{n,k}=b_{n,k}−b_{n,k−1}; q_0(k)는 전역 용어 「교차 행」). 「행 N까지 단일 교차」는 같은 조건을 n≤N에서만 요구한다.

Membership: permanent
Source: [local definition](records/r3bd6df852c694ee299e0f7581899e222/record.json) — r3bd6df852c694ee299e0f7581899e222/single-crossing

## 첫 간격의 생존

Symbol: R_N(b)

정수 N≥2와 1≤b≤N에 대해 R_N(b)=1−Σ_{g=1}^{b−1}β_N(g)다. β_N은 전역 용어 「첫 간격 무게」다(1≤g≤N−1에서 β_N(g)=Bor(g)·Bor(N−g)/Bor(N); 꼭짓점 N−1개의 균등한 뿌리 숲에서 꼭짓점 N−g개인 나무의 기대 개수). b≤(N+2)/2이면 R_N(b)는 그 숲에서 가장 큰 나무의 꼭짓점 수가 N−b 이하일 확률이다. 그 범위에서는 꼭짓점이 N−b개보다 많은 나무가 둘일 수 없기 때문이다. b≥(N+3)/2에서는 이 읽기가 서지 않는다(예: R_5(4)=−11/125, R_N(N)=(2−N)/N). b≤(N+1)/2이면 R_N(b)=1/N+(1/2)·Σ_{g=b}^{N−b}β_N(g)다. 같은 대상이 기록마다 다른 이름과 정규화로 적혀 있다. a_j=j^{j−1}/j!로 적으면 다음과 같다. (1) 전역 용어 「뼈대, 덤불, 계수 κ_k」의 κ_k(j)에 대해, b≤(N+2)/2이면 R_N(b)=κ_{N−b}(N)/a_N이다. 그 범위 밖에서는 두 수가 다르다(κ_k(j)/a_j는 언제나 0과 1 사이에 있다). (2) 전역 용어 「생존 질량, 질량 셀, 셀의 열」의 κ_s(N)=Bor(N)−Σ_{i=s+1}^{N−1}Bor(i)·Bor(N−i)에 대해, 1≤s≤N−1인 모든 s에서 κ_s(N)=Bor(N)·R_N(N−s)다. (3) rc31497e9df27478584efc43f79e164f2의 바닥 인자 λ_b(y)=a_{y+b}−Σ_{g=1}^{b−1}a_g·a_{y+b−g}에 대해, 1≤b≤y+2이면 λ_b(y)=a_{y+b}·R_{y+b}(b)다(r5050c217d0224b48a0038f0aa69ff5aa 명제 12). (4) r425e458e24d0488980f871f2046aceb5의 ω_z(b)=λ_b(z)/a_{z+b}는 R_{z+b}(b)다. (5) r535d20f3d6cc4384838c89248eb27bbe의 R_N(r)=1−Σ_{g≤r}β_N(g)는 여기의 R_N(r+1)이다. 이름과 기호 R_N(b)는 r5050c217d0224b48a0038f0aa69ff5aa의 것이다. 그 기록의 지역 용어 항목은 확률 읽기를 1≤b≤N 전체에 적어 검토에서 승인되지 않았고, 이 항목은 그 범위를 고쳐 적고 다른 기록의 표기와의 대응을 더한 것이다. 대조: (1)의 등식과 그 범위 밖의 어긋남, (2), (3), 꼬리 합의 식을 N≤30에서 정확한 유리수로 확인했다(output/check_identities.py의 2a–2e).

Membership: permanent
Source: [local definition](organizations/oa1057fd073bf402194a3d80124b20770/organization.json) — oa1057fd073bf402194a3d80124b20770/first-gap-survival

## 열의 빚 (열 밀도)

Symbol: h_n(x)

정수 k≥2와 기울임 x>0에 대해, 열 k의 기울인 차분을 η_j=x^j·d_{j,k}/j! (j≥k)로 적는다(d_{j,k}=b_{j,k}−b_{j,k−1}은 전역 용어 「한 칸 차분」이고 d_{k,k}=−b_{k,k−1}<0이다). 행 n≥k에서 열 k의 빚은 h_n(x)=−Σ_{j=k}^{n}η_j다(h_{k−1}=0). 수준 k−1과 k의 기울인 셀 U_j=x^j·b_{j,k−1}/j!, V_j=x^j·b_{j,k}/j!로는 h_n(x)=Σ_{j=k}^{n}(U_j−V_j)다. 빚은 양으로 출발하고, 교차 행 q_0(k)(전역 용어) 앞에서는 줄지 않으며, 열 k가 단일 교차(전역 용어)이면 교차 행부터 준다. 값이 기울임에 달려 있으므로 빚에 대한 진술은 기울임과 함께 적어야 한다. 「행 T에서 빚이 갚아졌다」는 h_T(x)≤0이라는 것이다. r6af349eb6a0d4ed29b9650ff599e1e90이 「열 밀도」 h_j라는 이름으로 들인 양이고(그 기록의 지역 용어 「기울인 양」), 기록마다의 표기는 다음과 같다. r82bc8844b699400b81d2a37138a362fb의 부분합 E_J는 임계 기울임 x_k에서의 −h_J이고, 그 기록의 얼린 빚 𝒟(T)는 h_T(x_k)의 상계다(k≥3, k≤T≤2k+1). r3bd6df852c694ee299e0f7581899e222의 남은 빚 h_j는 같은 양이고, 그 기록의 「빚이 갚아진다」와 전선의 노드 (DR)(모든 k≥160에서 h_{2k}≤0)은 대각 기울임 x†_k=(k/(k+1))^{k−2}에서의 진술이다. r3e1c5b9d6c784cbe84596957e15c0973의 열 밀도(빚) h_n과 r78da6136f4f842cb80b3b584f35da05e의 −E_T는 임계 기울임에서의 것이다. 증명되어 있는 한계는 기울임마다 다르다. 대각 기울임에서는 모든 행 j≥k에서 h_j≤U_j다(r3bd6df852c694ee299e0f7581899e222의 (D1); r6af349eb6a0d4ed29b9650ff599e1e90의 대각 아래 한계에서 나온다). 임계 기울임에서는 k≥148, k≤n≤2k+1에서 h_n≤U_n+U_{n−1}이고(r78da6136f4f842cb80b3b584f35da05e의 따름정리 11), k≥151에서는 n=2k+2에서도 그렇다(r3e1c5b9d6c784cbe84596957e15c0973의 따름 Θ1; 그 주장의 동료의 주에 따르면 r78da6136f4f842cb80b3b584f35da05e의 따름을 쓰면 k≥148에서 선다). 뒤의 기록의 정리 Θ는 k≥3의 모든 행에서 h_n=U_n+U_{n−1}−Ξ_n이라는 등식을 준다(Ξ_n은 그 기록의 두 칸 여유). 글자 U_j, V_j는 이 기록들이 열 방정식에 쓰는 기울인 셀이고, 전역 용어 「Borel 질량」의 U(x), 「Euler 결함」의 U_y(N), 「곡률과 손실」의 V_{n,k}와 다른 대상이다.

Membership: permanent
Source: [local definition](organizations/o4b1ccda390ca4110b1a30c0bc707ad52/organization.json) — o4b1ccda390ca4110b1a30c0bc707ad52/column-debt

Historical name/symbol: 빚 (h_J) — [local definition](records/r1d80f357ea1240aba957dca6d67e35e7/record.json) — r1d80f357ea1240aba957dca6d67e35e7/debt

## 열 방정식의 앞쪽 꼴과 풀린 꼴

정수 k≥2와 k+1≤n≤2k−1(차분의 단일 사슬 범위)에서 한 칸 차분 d_{n,k}=b_{n,k}−b_{n,k−1}이 만족하는 한 방정식의 두 꼴이다. p_m=(m+1)^{m−1} (p_0=1)이고 δ_t는 전역 용어 「나무 곡률」이다(δ_k=−k^{k−2}; t≥k+1에서 δ_t=(k+1)b_{t−1,k}−(k−1)b_{t−1,k−1}=k·d_{t−1,k}+b_{t−1,k}+b_{t−1,k−1}). 앞쪽 꼴은 d_{n,k}=Σ_{t=k}^{n} C(n,t)·p_{n−t}·δ_t다. 정규화하면 핵이 Borel 질량 Bor인 갱신 방정식이고(r213dbe848e5c4e8483afbcbfe76addec 2절, re8460c24720d4fdeaed189d466393fb7 명제 3.1), 미지수인 차분이 원천에 양의 계수로만 들어 있다. 모든 n≥k에서 서는 부등식 d_{n,k} ≥ Σ_{t=k}^{n} C(n,t)·A_{n−t,k−1}·δ_t (한 나무 하계; rc31497e9df27478584efc43f79e164f2)의 등호의 경우다. 풀린 꼴은 d_{n,k}=−C(n,k)·(n+1−k)^{n−k}·k^{k−2}+Σ_{t=k+1}^{n} C(n,t)·(n+1−t)^{n−t}·[2b_{t−1,k−1}−(t−k−1)·d_{t−1,k}]다. 앞쪽 꼴을 그 핵에 대해 푼 것이어서 정규화하면 핵이 갱신 밀도 Ren=Σ_{j≥1}Bor^{*j}가 된다. 음의 항은 문턱 나무의 충격 하나이고, 미지수가 음의 계수 −(t−k−1)로 원천 안에 들어 있어서 k≤j≤n−1에서 d_{j,k}≤0이면 합의 모든 항이 음이 아니다. 풀린 꼴의 출처는 ra98af63d956e4b288dd1550e0a4853df 보조정리 8.3의 식 (D)와 rc693abe9ba4f4ad7960846fd64f6c53b 정리 1이고(두 기록이 따로 얻었다), 넘겨받은 보렐사슬 보고의 합성곱 꼴과 같은 식이다. 「풀린 꼴」은 ra98af63d…의 이름, 「앞쪽 꼴」은 rc693abe9…의 이름이고, 그 기록의 시도는 풀린 꼴을 퍼텐셜 꼴이라 불렀다. 두 기록이 풀린 꼴을 가리키는 식 번호 (D)는 전선의 노드 「첫 층의 대각 볼록성 (D)」와 다른 것이다. 2≤k≤15, k+1≤n≤min(2k−1,30)의 105자리에서 두 꼴이 같은 정수를 주고 n=2k에서는 둘 다 등식이 아니라는 것을 대조했다(output/check_identities.py의 1, 2번).

Membership: permanent
Source: [local definition](organizations/o396680701eb24dddb332c325413603fa/organization.json) — o396680701eb24dddb332c325413603fa/column-equation-forms

## 되먹임 합

Symbol: Mem_n(k)

정수 k≥2와 n≥k+1에 대해 Mem_n(k):=Σ_{j=k}^{n−1}C(n,j)·C_{n−j,k}·d_{j,k}. 여기서 C(n,j)는 이항계수, d_{j,k}=b_{j,k}−b_{j,k−1}은 전역 용어 「한 칸 차분」, C_{m,k}는 모든 변위가 k보다 작은 길이 m의 소인 주차함수의 수(전역 용어 「소인 주차함수, 소인 행, 소인 곡률」)다. 열 k의 앞선 행들의 차분이 행 n의 차분에 되먹여지는 합이고, 열 방정식(r6af349eb6a0d4ed29b9650ff599e1e90의 주장 c01-column-equation)은 d_{n,k}=2·b_{n−1,k−1}+(k+1)·d_{n−1,k}+Mem_n(k)+X_{n,k}로 적힌다. X_{n,k}는 그 주장이 정하는 음이 아닌 정수이고 n<2k이면 0이다. 그래서 Mem_n(k)≥0이고 d_{n−1,k}≥0인 행에서는 d_{n,k}>0이다. 기울임 x>0에서 기울인 기억 Σ_{j=k}^{n−1}κ_{n−j}·η_j(κ_m=x^m·C_{m,k}/m!, η_j=x^j·d_{j,k}/j!)는 x^n·Mem_n(k)/n!이어서, 부호가 기울임과 무관하다. 기록마다의 표기: r3bd6df852c694ee299e0f7581899e222의 Mem_n(같은 합을 기울인 것이 mem_n이다. 창 뒤의 행에서 이 합이 음이 아니라는 그 기록의 추측이 (M⁺)다), r94b2a3124da4483190eecf816e103ac5의 순 되먹임 Σ′_n(그 기록의 9절에서는 Mem_n; 관찰 (NF)는 이 합이 행에 대해 부호를 꼭 한 번, 음에서 음이 아닌 쪽으로 바꾼다는 것이다). 뒤의 기록과 전선의 질문은 Mem_n(k)≥0인 가장 작은 n≥k+1을 n_1(k)로 적는다. 전역 용어 「교차 행」 항목에 re8460c24720d4fdeaed189d466393fb7의 표기로 적힌 n_1(교차 행 q_0(k)와 같은 수)과 다른 수다. 수준 k−1의 열의 수만으로 적히는 하계가 있다. 모든 k≥2, n≥k+2에서 Mem_n(k)/n!≥L_n(k):=Σ_{t=k}^{n−1}ξ^{Dg}_t·A_{n−t,k−1}/(n−t)!이다(r94b2a3124da4483190eecf816e103ac5의 명제 13; 그 기록의 𝖥^♮_n은 L_n(k)에 n!/(n+1)^{n−1}을 곱한 것이다). 여기서 A_{m,ℓ}은 전역 용어 「누적 개수」(A_{0,ℓ}=1), ξ^{Dg}_k=−k^{k−2}/k!, ξ^{Dg}_{k+1}=−(k−1)·b_{k,k−1}/(k+1)!, t≥k+2에서 ξ^{Dg}_t=[(k+1)·(1+1/k)^{k−2}·(t−1)·b_{t−2,k−1}−(k−1)·b_{t−1,k−1}]/t!이다. 이 L_n(k)는 전역 용어 「곡률과 손실 (걸음의 Taylor 분해)」의 손실 L_{n,k}와 다른 양이다.

Membership: permanent
Source: [local definition](organizations/oa301f238a2084abcbbd3760a3cb311b1/organization.json) — oa301f238a2084abcbbd3760a3cb311b1/feedback-sum

## 누적 대각 괄호 (임계 기울임의 것과 대각 기울임의 것)

Symbol: C(J), C†(J)

정수 k≥3과 J≥k에 대해 두 양을 가른다. 임계 기울임의 누적 대각 괄호는 C(J):=Σ_{j=k+1}^{J}(b_{j,k}−𝔯_k·j·b_{j−1,k−1})·x_k^j/j!이다(x_k=(k/(k+1))^{k−1}은 전역 용어 「임계 기울임」, 𝔯_k=1/x_k=(1+1/k)^{k−1}은 임계 성장비). 전역 용어 「대각 괄호와 열 괄호」의 대각 괄호를 임계 기울임으로 기울여 열을 따라 더한 것이고, 항이 음이 아니라는 것은 그 항목의 명제 (DB)여서 항의 부호가 미리 정해져 있지 않다. 대각 기울임의 누적 대각 괄호는 C†(J):=Σ_{j=k+1}^{J}(b_{j,k}−γ_k·j·b_{j−1,k−1})·(x†_k)^j/j!이다(x†_k=(k/(k+1))^{k−2}은 전역 용어 「핵 기울임과 대각 기울임」의 대각 기울임, γ_k=1/x†_k=(1+1/k)^{k−2}). 항마다 대각 아래 한계(r6af349eb6a0d4ed29b9650ff599e1e90의 정리 Dg)의 여분이어서 음이 아니다. 두 양은 성장비의 상수가 달라서 서로 다른 양이고, 전역 용어의 「대각 괄호」는 앞의 것의 항만을 가리킨다. 어느 쪽에서나 그 기울임 x의 기울인 셀 U_j=x^j·b_{j,k−1}/j!, V_j=x^j·b_{j,k}/j!로 항이 V_j−U_{j−1}이고, 열의 빚(용어 「열의 빚 (열 밀도)」의 h_J(x))과 h_J(x)=U_J−(그 기울임의 누적 대각 괄호)로 이어진다(J≥k; V_k=0에서 나오는 망원합이다). 임계 기울임에서 이 등식은 r43a26ea30aef43618568925b5700f5e6의 정리 N (가)이고 r3e1c5b9d6c784cbe84596957e15c0973의 정리 Θ (가)와 같은 내용이다(뒤의 기록의 두 칸 여유는 Ξ_n=C(n)+U_{n−1}). 대각 기울임에서는 r43a26ea30aef43618568925b5700f5e6의 식 (7.1)이고 r3bd6df852c694ee299e0f7581899e222의 식 (10.6)이다. 기록마다의 표기: r43a26ea30aef43618568925b5700f5e6은 2–6절에서 C(J)와 C†(J)를 위와 같이 쓰고, 7절에서는 †를 떼어 대각 기울임의 것을 C(m), 그 항을 Δ_j로 적으며 Δ_j도 「대각 괄호」라 부른다. r3bd6df852c694ee299e0f7581899e222은 대각 기울임의 항을 정리 Dg의 여분이라 부른다. r94b2a3124da4483190eecf816e103ac5의 대각 결함 U_{i−1}−V_i는, 기울임 대신 확률 정규화(U_i=b_{i,k−1}/(i+1)^{i−1}, V_i=b_{i,k}/(i+1)^{i−1})에서 적은 같은 꼴의 항의 부호를 바꾼 것이고, 그 기록의 확률 정규화의 빚과 같은 망원합으로 이어진다.

Membership: permanent
Source: [local definition](organizations/oa301f238a2084abcbbd3760a3cb311b1/organization.json) — oa301f238a2084abcbbd3760a3cb311b1/cumulative-diagonal-bracket

## 극한 함수 θ와 Θ

Symbol: L(u), θ(u), Θ(u)

A=∫_0^1 max_{s≤t}B_s dt를 표준 브라운 운동 B의 상한 과정의 넓이라 하고 L(u)=E e^{−uA} (u≥0)로 둔다. 길이 n의 균등한 주차함수의 최대 변위를 M_n이라 하면, 임계 창에서 Pr(n−M_n≥ρ)의 극한, 곧 극한 생존함수는 눈금 x=ρ/N^{2/3} (N=n+1)에서 S(x)=L(x^{3/2})이다(이 인스턴스 안의 증명은 r790d81e586524894a2220b314fcfab51에 있다). u>0에서 θ(u)=−u·L′(u)/L(u)=u·E[A·e^{−uA}]/E[e^{−uA}], Θ(u)=−u·L″(u)/L′(u)=u·E[A²·e^{−uA}]/E[A·e^{−uA}]로 둔다. u·θ′(u)=θ(u)·(1+θ(u)−Θ(u))다. 결손의 눈금 x와는 u=x^{3/2}으로 이어진다. θ는 임계 창에서, 크기를 하나 늘릴 때 그 확률이 느는 상대 폭에 N을 곱한 것의 극한이다(rd5e24622fa784c26a708cce1d9f1fa2b 3.12절). Θ는 rb631a853ad394807bf00eb9ea82b4de6의 명제 9.35의 Θ(u)이고, r21b6d042fd634a489fd8efa89c9ac103과 rb6c0db0d90c04163b190d24f07a92c72가 L(u)로 적은 함수다. rd5e24622fa784c26a708cce1d9f1fa2b는 이 함수를 Θ로, Laplace 변환을 L로 적는다(이 항목의 표기). 기록들이 이 함수들로 적은 문턱은 다음과 같다(눈금의 값은 수치다). Θ=1/3: 극한 밀도의 봉우리, 곧 창의 선두 차수에서 행의 봉우리(x=0.5996). Θ=θ+1/3: 극한 생존함수가 x에 대해 로그오목인 범위의 끝(x=1.3085). Θ=1: 창의 선두 차수에서 임계 성장비의 대각 괄호의 부호가 바뀌는 자리(rb631a853ad394807bf00eb9ea82b4de6의 명제 9.35; u=1.7586, x=1.457). Θ=2: 무게를 뗀 대각 오목성 (DCc)의 선두 차수의 경계(r21b6d042fd634a489fd8efa89c9ac103의 읽기이고 발견적이다; u=9.4297, x=4.463). Θ=1+θ: 극한 생존함수가 log x에 대해 로그오목인 범위의 끝, 곧 결손의 위험률 순서 (HR-F)의 창 극한이 깨지기 시작하는 자리(u=15.551, x=6.2303). Θ의 최댓값 2.0978은 u=24.753(x=8.49)에 있고, 극한 밀도가 log x에 대해 로그오목인 범위의 끝이다. 증명되어 있는 것: u→∞에서 θ(u)→1, Θ(u)→2이고 두 함수 모두 극한값에 위에서 다가간다. 그래서 충분히 큰 모든 u에서 Θ(u)>2다. 또 Θ−2가 θ−1보다 커서, 충분히 큰 모든 u에서 Θ(u)>1+θ(u), 곧 θ′(u)<0이다(rd5e24622fa784c26a708cce1d9f1fa2b의 보조정리 R2; 계산을 쓰지 않는다).

Membership: permanent
Source: [local definition](organizations/o4b1ccda390ca4110b1a30c0bc707ad52/organization.json) — o4b1ccda390ca4110b1a30c0bc707ad52/limit-theta-functions

## 소인 주차함수의 넘김 비율 (잘린 비율, 핵이 잃는 몫)

Symbol: Δ_s, r_s, 1−θ_{k+s}

정수 k≥2와 s≥0에 대해, 길이 k+s의 소인 주차함수(전역 용어 「소인 주차함수, 소인 행, 소인 곡률」) 가운데 변위가 k 이상인 차가 있는 것의 비율 1−C_{k+s,k}/(k+s−1)^{k+s−1}. 여기서 C_{m,k}는 모든 변위가 k보다 작은 길이 m의 소인 주차함수의 수이고 (m−1)^{m−1}(0^0=1)은 길이 m의 소인 주차함수 전체의 수다. s=0에서 0이고 s=1에서 (1+1/k)^k/(k+1)이다. 기울임과 무관한 수이고, 기울임 x의 소인 핵(되먹임 핵) κ_m=x^m·C_{m,k}/m!이 자르지 않은 핵 x^m·(m−1)^{m−1}/m!에서 모자라는 상대적인 몫이다. 같은 수가 네 기록에 다른 이름으로 있다. rc28b26529119411089bf631e19b5a354의 잘린 비율 Δ_s; r43a26ea30aef43618568925b5700f5e6의 「핵이 잃는 몫」 r_s(k≥3, 0≤s≤k−1에서 정의); r5050c217d0224b48a0038f0aa69ff5aa의 명제 L11의 θ_K(길이 K의 균등한 소인 주차함수의 모든 변위가 y 이하일 확률)에서 y=k−1, K=k+s로 둔 1−θ_{k+s}; rdd38d9882731440285cfecc3f97c9ebf의 𝖯_N=κ^free_N−κ_N(임계 기울임의 것)을 κ^free_N으로 나눈 것(N=k+s). 수준 k가 기호에 드러나지 않으므로 여러 수준을 함께 쓸 때에는 수준을 밝혀 적어야 한다. 증명되어 있는 것은 다음과 같다. (1) θ_K는 K에 대해 늘지 않고 θ_{a+b}≤θ_a·θ_b다(r5050c217d0224b48a0038f0aa69ff5aa의 명제 L11; 모든 y≥0). 곧 넘김 비율은 s에 대해 줄지 않는다(r43a26ea30aef43618568925b5700f5e6의 보조정리 KL (가)가 0≤s≤k−1에서 같은 것을 준다). (2) 계수가 음이 아닌 재귀. θ의 재귀는 명제 L11에 있고, 그것을 여수의 꼴로 적은 잘림의 점화식은 rc28b26529119411089bf631e19b5a354의 주장 c-truncation-recurrence에 있다(0≤s≤k−1). (3) 아래 한계. r43a26ea30aef43618568925b5700f5e6의 보조정리 KL (다)와 rc28b26529119411089bf631e19b5a354의 주장 c-truncation-bound(보조정리 K3)이고, 대각 기울임에서 핵이 길이 k를 넘은 뒤 골의 높이 아래로 내려오는 걸음 수의 한계가 여기서 나온다(그 기록들의 범위에서 차례로 k^{2/3}의 1.65배, 0.9배쯤). (4) 위 한계. 𝖯_N은 닫힌 생성함수를 가진 비교 수열 P̂_N 이하다(rdd38d9882731440285cfecc3f97c9ebf의 주장 c-comparison-sequence; 그 수열이 변위가 k 이상인 차의 수를 센 무게라는 읽기는 그 기록이 작은 경우의 전수 계산으로 확인한 것이다). 전역 용어 「넘김 확률, 나무의 넘김 확률, 넘김 증분」의 나무의 넘김 확률 𝗏(s)는 나무에 대한 같은 종류의 비율이고 다른 양이다. 대조: 2≤k≤11, 길이 min(40, 3k+3) 이하에서 네 정의가 같은 수라는 것, s=1의 닫힌 꼴, 명제 L11의 재귀와 잘림의 점화식, 단조성과 준승법성을 정확한 유리수로 확인했다(output/check_identities.py의 1번).

Membership: permanent
Source: [local definition](organizations/ocee41092f2944e2190cb1ef62ab62ff1/organization.json) — ocee41092f2944e2190cb1ef62ab62ff1/prime-exceedance-fraction

## 달리는 최솟값의 자리, 창 항등식과 창 판정

Symbol: c_0, ∇v_N

대상은 유한 기억의 갱신 방정식이다. g가 {1,2,…} 위의 비증가인 음이 아닌 수열(핵), s가 수열(원천), v가 어떤 정수 i_0 아래에서 0인 음이 아닌 수열이고, N≥i_0인 모든 정수 N에서 N·v_N=Σ_{γ≥1}g(γ)·v_{N−γ}+s_N이라 하자. 뒤로 잰 감소분을 ∇v_N:=v_{N−1}−v_N, ∇s_N:=s_{N−1}−s_N으로 적는다. 창 항등식: N≥i_0+1이고 i_0≤b≤N−1인 모든 정수 b에서 N·∇v_N=(1−g(N−b))·v_{N−1}+∇s_N+Σ_{i=b}^{N−2}(g(N−1−i)−g(N−i))·(v_i−v_{N−1})+Σ_{i=i_0}^{b−1}(g(N−1−i)−g(N−i))·v_i이다(rdd38d9882731440285cfecc3f97c9ebf의 보조정리 A; b를 창의 시작이라 한다. 마지막 합의 항은 모두 음이 아니다). 창 판정: 더하여 ∇s_N≥0, g(N−b)≤1이고 b≤i≤N−2인 모든 i에서 v_{N−1}≤v_i이면 N·∇v_N≥(1−g(N−b))·v_{N−1}≥0이다(같은 기록의 따름 A1). 여기서 「창」은 되돌아보는 첨자의 구간 [b, N−2]이고 전역 용어 「임계 창, 벌크, 한가운데」의 임계 창이나 「지속의 창, 먼 행, 깊은 행」의 창과 다른 말이다. 원천 s가 비증가이고 핵의 값이 1 이하인 뒤처짐이 있다고 하고, 그 첫 뒤처짐을 c_0:=min{γ≥1: g(γ)≤1}로 적는다(rdd38d9882731440285cfecc3f97c9ebf의 글자다. 이 항목 안에서만 쓰고, 전역 용어 「Cayley 계수」의 c_0=1과 다른 수다). 정수 m≥i_0+c_0−1이 i_0≤i≤m−1인 모든 i에서 v_m≤v_i를 만족하면 m을 달리는 최솟값의 자리라 한다. 한 자리의 값이 그 앞의 모든 값 이하라는 조건이고, 전역 용어 「조임, 조임량, 단조 기억, 판정 (Z)」의 조임이 가정하는 내림 구간보다 약한 가정이다. rdd38d9882731440285cfecc3f97c9ebf의 정리 9는 소인 셀의 열, 곧 k≥3, x_k=(k/(k+1))^{k−1}, i_0=k, v_m=(C_{m,k}−C_{m,k−1})·x_k^m/m!, g(γ)=(k−1−γ)·γ^{γ−1}·x_k^γ/γ! (1≤γ≤k−2; 그 밖에서 0)인 경우에, 달리는 최솟값의 자리 m부터 그 열이 비증가이고 모든 N>m에서 v_N≤(1−(1−g(N−k))/N)·v_{N−1}임을 증명하고, 그런 자리가 언제나 있음을 증명한다. 같은 기록의 따름 A2는 그 열에 대해 조건을 짧은 창으로 바꾼 꼴이다. 정수 m≥k+c_0−1이 m−c_0+1≤i≤m−1인 모든 i에서 v_m≤v_i를 만족하면 그 열은 m부터 비증가다.

Membership: permanent
Source: [local definition](organizations/oa301f238a2084abcbbd3760a3cb311b1/organization.json) — oa301f238a2084abcbbd3760a3cb311b1/running-minimum-position

Historical name/symbol: 달리는 최솟값의 자리 (m, d_0) — [local definition](records/r26ac4ba8285745c0ab84a4c90cdb106d/record.json) — r26ac4ba8285745c0ab84a4c90cdb106d/running-minimum-position

## Euler 비와 두 쪽 Euler 부등식, 강한 꼴 (Q′)

Symbol: θ_N(r), (LE_c), (LE), (Q′)

전역 용어 「전이 비」 q_N(r) (N≥2, 1≤r≤N−1; 차의 수 n=N−1, 수준 k=n−r에서 q_N(r)=[Pr(M_{n+1}≤k)−Pr(M_n≤k−1)]/Pr(M_n=k))에 대해 Euler 비를 θ_N(r):=N·q_N(r)/(r+1)로 둔다. 이름과 기호는 r535d20f3d6cc4384838c89248eb27bbe의 지역 용어 「Euler 비」의 것이다. 위쪽 Euler 부등식은 θ_N(r)≤1, 곧 q_N(r)≤(r+1)/N이고, 전역 용어 「Euler 결함」으로는 U_y(N)≥0이다(y=N−1−r). 상수 0<c<1의 아래쪽 Euler 부등식 (LE_c)는 자리 (n,y) (n≥2, 1≤y≤n−1)에서 Pr(M_{n+1}≤y)−Pr(M_n≤y−1) ≥ c·((n+1−y)/(n+1))·Pr(M_n=y)라는 부등식이다. N=n+1, r=n−y로 적으면 θ_N(r)≥c이고, Euler 결함으로는 U_y(N)≤(1−c)·((r+1)/N)·m_N(r)이다((LE_c)의 이름과 진술은 r055dd905547946cebcdd01d1c1e6fbf8의 것이다). (LE)는 c=1/2의 부등식이 수준 y≥1의 모든 자리에서 선다는 진술이다. 첫 층은 y≤n≤2y+1인 자리이고, 같은 말로 N≥3, 1≤r≤N/2, r≤N−2인 자리다. Euler 부등식의 강한 꼴 (Q′)는 정수 ℓ≥0과 차의 수 N≥ℓ+1에 대한 부등식 A_{N+1,ℓ} ≤ (p_{N+1}/p_N)·A_{N,ℓ} − (p_{ℓ+1}/p_ℓ)·b_{N,ℓ}이고(p_m=(m+1)^{m−1}), ℓ≥1에서는 전이 비로 q_{N+1}(N−ℓ) ≤ 1−r̂_ℓ/r̂_N (r̂_m=p_{m+1}/p_m)과 같다((Q′)라는 이름은 r21b6d042fd634a489fd8efa89c9ac103의 것이다). 이름의 주의. r535d20f3d6cc4384838c89248eb27bbe는 「Euler 부등식의 아래쪽」이라는 말을 q_N≥0, 곧 여기의 상수 0의 경우에 쓴다(그 기록의 정리 S). rae49544d67ce43ec83edd26297876f60의 지역 용어 「Euler 비」 e_0(r)는 다른 양이고 그 기록 6절의 반증된 추측에만 쓰인다. 기록마다의 좌표. r055dd905547946cebcdd01d1c1e6fbf8은 자리 (n,y)와 나무 좌표의 Ω^c_k(z)≥0을 쓴다(자리 (n,y)=(k+z−2,k−1)의 (LE_c)다). rae49544d67ce43ec83edd26297876f60은 차의 수 n과 수준 ℓ의 자리 (n,ℓ)에서 F_n(ℓ)=Pr(M_n≤ℓ), m_n(ℓ)=Pr(M_n=ℓ), κ_n(ℓ)=F_{n+1}(ℓ)−F_n(ℓ−1), λ_n(ℓ)=F_n(ℓ)−F_{n+1}(ℓ)로 전이 비를 𝔮_n=κ_n(ℓ)/m_n(ℓ)=q_{n+1}(n−ℓ)로 적고, 정리들을 차의 수 N과 결손 r=N−ℓ로 적는다. 그 좌표에서 위쪽 Euler 부등식은 𝔮_N≤(r+1)/(N+1)이고 (Q′)는 λ_N(ℓ)≥(r̂_ℓ/r̂_N)·m_N(ℓ)이다. r45979fd0c72c4e47b1b84c69db6c07d5의 머무름 흐름 Δ_n(K)=F_n(K)−F_{n−1}(K−1)은 전이 비의 분자이고, 그 기록의 진술 (E½) 「모든 K≥1, n≥K+2에서 q_n(r)≥(r+1)/(2n) (r=n−1−K)」는 (LE)와 같은 진술이다. 전역 용어 「거꾸로 가는 전이 비」는 같은 분자를 큰 쪽 행의 셀로 나눈 것이다. 개정 59까지 증명된 범위는 다음과 같다(뒤의 기록이 바꿀 수 있다). 위쪽 Euler 부등식은 모든 자리에서 선다(r5050c217d0224b48a0038f0aa69ff5aa의 주장 p-euler-all-sizes). (Q′)는 모든 ℓ≥0, N≥ℓ+1에서 선다(rae49544d67ce43ec83edd26297876f60의 주장 c-theorem-W; 바닥 N≤299는 길이 300 이하의 정확한 행에서 읽는다). 두 위쪽 한계 가운데 (Q′)가 더 작은 것은, 그 기록의 따름정리 W1에 따르면, N이 수준 ℓ에만 달린 문턱(큰 ℓ에서 3ℓ+10쯤)보다 작은 자리다. ℓ=1에서는 그런 문턱이 없고 모든 N에서 (Q′)가 더 작다. (LE_{1/2})는 첫 층의 모든 자리에서 선다(r055dd905547946cebcdd01d1c1e6fbf8의 주장 p-lower-euler-half; 표와 기계 계산을 쓰지 않는다). 상수 1/2은 결손 1의 대각선의 극한에서 닿아, 첫 층 전체에서 서는 상수로는 더 키울 수 없다(주장 c-le-ends). 수준 y=1과 y=2에서는 (LE_{1/2})가 모든 크기에서 선다(주장 p-le-row1, p-le-deep). 수준 0에서는 θ_{n+1}(n)=(1−1/(n+2))^n이어서 n≥4에서 1/2보다 작다. (LE) 자체는 추측이다. 크기에 대해서는, 차의 수 N≥100과 결손 1≤r≤N/100에서 |(N+1)·q_{N+1}(r)/r−2/3| ≤ 51/√r+108·r/N이고(rae49544d67ce43ec83edd26297876f60의 주장 p-theorem-E), r/N=α가 0에서 떨어진 첫 층에서는 (N+1)·q_{N+1}(r)/r이 π(α)=(2−3α+2α²)/(3−6α+4α²)로 수렴한다(주장 p-bulk-profile; 문턱이 명시적이지 않다). 대조: 두 좌표의 자리의 집합이 같다는 것, 𝔮_n=q_{n+1}(n−ℓ), (Q′)의 두 꼴과 맨 위 행 N=ℓ+1의 등호, 수준 0의 닫힌 꼴, 그리고 N≤30에서 위의 부등식들이 서는 것을 정확한 유리수로 확인했다(이 조직화의 출력의 check_identities.py의 1번; 작은 크기의 대조이고 정리의 근거가 아니다).

Membership: permanent
Source: [local definition](organizations/o55831e5d12e248a4832b313ca1519a95/organization.json) — o55831e5d12e248a4832b313ca1519a95/euler-ratio-two-sided

Historical name/symbol: 아래쪽 Euler 부등식 ((LE_c), (LE)) — [local definition](records/r055dd905547946cebcdd01d1c1e6fbf8/record.json) — r055dd905547946cebcdd01d1c1e6fbf8/lower-euler

## 대각 비와 대각 초과(세 가지 쓰임), 평균 대각 초과, 필요 초과

Symbol: ϑ(N,k), e(N,k), ē_J, 𝗇_k(z)

정수 k≥2와 N≥k+1에 대해 (정규화한) 대각 비는 ϑ(N,k):=b_{N,k}/(γ_k·N·b_{N−1,k−1}), γ_k=(1+1/k)^{k−2}다(r6af349eb6a0d4ed29b9650ff599e1e90의 지역 용어 「대각 아래 한계와 정규화한 대각 비」). 대각 아래 한계(그 기록의 정리 Dg)는 ϑ(N,k)≥1이고 등호는 N=k+1에서만 선다. 「대각 초과」라는 이름은 세 기록에서 서로 다른 세 양에 쓰인다. (1) e(N,k):=k·(ϑ(N,k)−1)≥0 (r1d80f357ea1240aba957dca6d67e35e7). 기울임과 무관한 수이고, 이 조직화의 글은 이것을 대각 초과라 부른다. (2) 기울임 x>0에서의 기울인 항 Δ_j:=V_j−U_{j−1} (j≥k+1; U_j=x^j·b_{j,k−1}/j!, V_j=x^j·b_{j,k}/j!) (r055dd905547946cebcdd01d1c1e6fbf8). 전역 용어 「누적 대각 괄호」의 항을 임의의 기울임에서 적은 것이고 V_j−U_{j−1}=U_{j−1}·(x·γ_k·ϑ(j,k)−1)이다. 대각 기울임 x=1/γ_k에서는 U_{j−1}·e(j,k)/k여서 음이 아니고, 다른 기울임에서는 부호가 미리 정해져 있지 않다. r3bd6df852c694ee299e0f7581899e222의 「정리 Dg의 여유」 Δ_j(x)=V_j−x·γ_k·U_{j−1}=(x·γ_k/k)·U_{j−1}·e(j,k)는 모든 기울임에서 음이 아닌 다른 양이고, 대각 기울임에서만 (2)와 같다. (3) 누적의 Δ^A(n,k):=A_{n−1,k}−n·γ_k·A_{n−2,k−1}≥0 (r6af349eb6a0d4ed29b9650ff599e1e90). 기울임 z>0과 J≥k+1에 대해 U_j=z^j·b_{j,k−1}/j!, V_j=z^j·b_{j,k}/j!, μ_J:=Σ_{N=k}^{J−1}U_N, 평균 대각 비 ϑ̄_J:=Σ_{N=k+1}^{J}U_{N−1}·ϑ(N,k)/μ_J, 평균 대각 초과 ē_J:=k·(ϑ̄_J−1), 필요 초과 𝗇_k(z):=k·(1/(z·γ_k)−1)로 둔다(r1d80f357ea1240aba957dca6d67e35e7의 이름이다). 전역 용어 「열의 빚 (열 밀도)」의 h_J(z)에 대해 h_J(z)=U_J−Σ_{N=k+1}^{J}(V_N−U_{N−1})=U_J+(1−z·γ_k·ϑ̄_J)·μ_J이고, 따라서 h_J(z)≤U_J는 ē_J≥𝗇_k(z)와 같다(둘째 등식은 r3bd6df852c694ee299e0f7581899e222의 식 (10.6)과 같은 등식이다). 𝗇_k는 대각 기울임 x†_k=1/γ_k에서 0이고 임계 기울임 x_k에서 1이다. 개정 59까지 증명된 것은 다음과 같다(모두 r1d80f357ea1240aba957dca6d67e35e7의 주장이고, 뒤의 기록이 바꿀 수 있다). 임계 창의 고정한 구간에서 e(N,k)는 전역 용어 「극한 함수 θ와 Θ」의 Θ(u)로 오차 O(N^{−1/3})로 수렴한다(u=x^{3/2}, x=(N−k+1)/N^{2/3}; 주장 p-excess-limit-and-mean (나); 상수가 명시적이지 않다). 극한 밀도 𝖿=𝖦′ (𝖦(x)=1−E e^{−x^{3/2}·A})로 평균한 Θ는 정확히 1이다(같은 주장 (다)). 평균 대각 초과는 창 안에서 기울임에 달리지 않는 증가 함수 Ē(x)=1−2x·𝖿(x)/(3·𝖦(x))로 수렴하고(주장 p-window-debt-profile), 결손이 3k/5를 넘는 행에서 결손에 맞춘 기울임의 평균 대각 초과의 하극한은 1 이상이다(주장 p-asymptotic-debt-bound). 대조: (2)의 등식, 정리 Dg의 여유와의 관계, 빚의 두 등식과 동치, 필요 초과의 두 값을 k≤12, 행 30 이하, 네 가지 기울임에서 정확한 유리수로 확인했다(이 조직화의 출력의 check_identities.py의 2번).

Membership: permanent
Source: [local definition](organizations/o55831e5d12e248a4832b313ca1519a95/organization.json) — o55831e5d12e248a4832b313ca1519a95/diagonal-ratio-excess

Historical name/symbol: 열 초과와 분리 수준, 분리 수준의 창 (c(n,k), c*(k), λ, λ↑(k)) — [local definition](records/rc4c34a9279734e0d9a84d7cf250519b4/record.json) — rc4c34a9279734e0d9a84d7cf250519b4/g-column-excess-separator

## 무게 달린 대각 둘째 차분

Symbol: Δ_ψ(N)

수준 k≥3과 임계 기울임 x=x_k=(k/(k+1))^{k−1}(전역 용어 「임계 기울임」)에서, 이웃한 세 수준의 기울인 누적을 ẑ⁺_i=x^i·A_{i,k}/i!, ẑ_i=x^i·A_{i,k−1}/i!, ẑ′_i=x^i·A_{i,k−2}/i!로 적는다(A는 전역 용어 「누적 개수」; 전역 용어 「대각 둘째 차분, 대각 볼록성」의 기울인 핵 질량 u_i(k+1), u_i(k), u_i(k−1)이다). 정수 N≥k−1에서 정의된 양의 함수 ψ(크기만의 무게)에 대해 Δ_ψ(N):=ψ(N+1)·ẑ⁺_{N+1}−2ψ(N)·ẑ_N+ψ(N−1)·ẑ′_{N−1} (N≥k). 배열 ψ(N)·ẑ_N을 크기와 수준을 함께 하나 올리는 방향으로 본 둘째 차분이다. 「무게 ψ가 허락된다」는 것은 모든 N≥k에서 Δ_ψ(N)≥0이라는 뜻이다. 이름과 틀은 rf03311556d4043bf8f2d5a6f23d54a21의 것이다(그 기록의 지역 용어 항목은 검토에서 승인되지 않았다. 그 기록은 무게 max(N,2k+1)을 Ψ로 적는데 전역 용어 「이력 숲, 감소 숲」의 Ψ(σ)와 글자가 같아, 이 항목은 그 글자를 쓰지 않는다). 무게마다 알려진 것은 다음과 같다. (1) ψ≡1이면 Δ_ψ(N)은 전역 용어의 핵 질량 꼴 대각 둘째 차분 DC(N)이다. k≤N≤2k에서 DC(N)≥0이라는 것은 k≥148에서 정리이고(r78da6136f4f842cb80b3b584f35da05e의 주장 c-kernel-form), 모든 N에서 그렇다는 것이 추측 DC의 핵 질량 꼴이다(증명되지 않았다). (2) ψ(N)=N이면 Δ_ψ(N)=N·DC(N)+𝖾_N이다(𝖾_N:=ẑ⁺_{N+1}−ẑ′_{N−1}). k≥3이고 k≤M≤2k인 모든 M에서 DC(M)≥0이면 모든 N≥k에서 이 양이 음이 아니고(rf03311556d4043bf8f2d5a6f23d54a21의 정리 F, 주장 c-theorem-F), 같은 말로 x_k²·A_{N+1,k}−2N·x_k·A_{N,k−1}+N(N−1)·A_{N−1,k−2}≥0이다. (3) ψ(N)=max(N,2k+1)은 k≥148에서 허락된다(같은 기록의 정리 M, 주장 c-theorem-M). (4) 전역 용어의 나무 질량 꼴 DC^T는 수준에 달린 계수를 가져 이 틀의 사례가 아니다. 다만 ψ_T(N)=(1+1/k)^N/(N+1)에 대해 (x·k/((N+1)·ψ_T(N)))·Δ_{ψ_T}(N)=DC^T(N+1)+x·ẑ′_{N−1}/((k+1)·N) (N≥k)이어서, 나무 질량 꼴이 음이 아닌 크기에서는 무게 ψ_T의 차분도 음이 아니다(뒤의 문장은 그 기록의 검토가 적은 것이고, 등식은 이 조직화가 정의에서 유도해 대조한 것이다). 열의 걸음과 잇는 등식은 이렇다. ψ(k−1)=ψ(k)이면 모든 J≥k에서 Σ_{n=k}^{J}ψ(n)·η_n=Σ_{N=k}^{J−1}Δ_ψ(N)−ψ(J)·U_J−ψ(J−1)·U_{J−1}+[ψ(J−1)·ẑ_{J−1}−ψ(J)·ẑ_J]이다(η_n=x^n·d_{n,k}/n!, U_j=x^j·b_{j,k−1}/j!; rf03311556d4043bf8f2d5a6f23d54a21의 보조정리 B, 주장 c-weighted-debt). ψ≡1이면 좌변은 전역 용어 「열의 빚 (열 밀도)」의 임계 기울임의 값의 부호를 바꾼 것 −h_J(x_k)이고, 등식은 r82bc8844b699400b81d2a37138a362fb의 보조정리 D0이다. 이때 U_J+U_{J−1}−h_J(x_k)=Σ_{N=k}^{J−1}DC(N)+ẑ_{J−1}−ẑ_J이고 ẑ는 크기에 대해 늘지 않으므로, 무게 1의 누적 Σ_{N=k}^{J−1}DC(N)이 음이 아니면(rf03311556d4043bf8f2d5a6f23d54a21의 추측 P°) h_J(x_k)≤U_J+U_{J−1}이다. 대조: 3≤k≤12, 크기 39 이하에서 (2)의 관계식, (4)의 등식, 세 무게에서의 보조정리 B의 등식을 정확한 유리수로 확인했고, 그 열들에서 첫 층의 DC≥0이 서며 (2)와 (3)의 결론이 선다는 것을 보았다(output/check_identities.py의 2번; 작은 열의 대조이고 정리의 범위 k≥148의 확인이 아니다).

Membership: permanent
Source: [local definition](organizations/ocee41092f2944e2190cb1ef62ab62ff1/organization.json) — ocee41092f2944e2190cb1ef62ab62ff1/weighted-diagonal-second-difference

Historical name/symbol: 무게 달린 대각 둘째 차분, 무게 Ψ (Δ_ψ(N), Ψ(N)) — [local definition](records/rf03311556d4043bf8f2d5a6f23d54a21/record.json) — rf03311556d4043bf8f2d5a6f23d54a21/g-weighted-diagonal-difference

## 기울인 핵 질량의 크기 방향 둘째 차분과 국소 기울임

Symbol: u_N, w_N, D_N, C_N, x_{n+1}

문턱 c≥2(수준으로는 열 k=c)와 기울임 x>0에 대해 기울인 핵 질량은 u_N:=x^N·A_{N,c−1}/N! (N≥0)이고(전역 용어 「대각 둘째 차분, 대각 볼록성」의 u_N(c)다), w_N:=x^N·p_N/N! (p_N=(N+1)^{N−1})은 제약이 없는 같은 양이다. Pr(M_N<c)=u_N/w_N이고 N≤c에서 u_N=w_N이다. 감소분은 D_N:=u_N−u_{N+1}, 크기 방향 둘째 차분은 C_N:=D_{N−1}−D_N=u_{N−1}−2u_N+u_{N+1} (N≥1)이다. 이름과 기호는 r0bffe377b14b432b8c55bf022b2c419e의 것이다. 그 기록의 지역 용어집은 검토에서 승인되지 않았다. 그 기록의 글자 β_c, δ_c(n), E_N, N_χ는 전역 용어의 같은 글자와 다른 양이어서 이 항목은 그 글자들을 쓰지 않는다. 크기 n≥1의 국소 기울임은 x_{n+1}=((n+1)/(n+2))^n, 곧 전역 용어 「임계 기울임」의 식 x_m=(m/(m+1))^{m−1}에 m=n+1을 넣은 값이고, w_{n+1}=w_n이 되는 기울임이다. 문턱이 아니라 크기에 달려 있고 n+1>c이면 x_{n+1}<x_c다. 국소 기울임에서 w_n·[Pr(M_{n−1}<c)−2·Pr(M_n<c)+Pr(M_{n+1}<c)]=C_n−(1−x_{n+1}/x_n)·u_{n−1}이다. 그래서 전선의 노드 (L1°)의 부등식(문턱 k=c, 크기 n)은 국소 기울임에서 C_n≥(1−x_{n+1}/x_n)·u_{n−1}이라는 것과 같다. 대각 방향과의 관계. 같은 기울임 x에서 수준 k=c의 핵 질량 꼴 대각 둘째 차분 DC(N)=u_{N+1}(c+1)−2u_N(c)+u_{N−1}(c−1)에 대해 DC(N)=C_N+(V_{N+1}−U_{N−1})이다(U_j=x^j·b_{j,c−1}/j!, V_j=x^j·b_{j,c}/j!). 정의에서 바로 나오는 등식이고, r82bc8844b699400b81d2a37138a362fb의 기호로는 DC(N)=Δ²ẑ_N+(U⁺_{N+1}−U_{N−1})이다. 곧 대각 둘째 차분은 크기 방향 둘째 차분에 두 칸 떨어진 대각 괄호 하나를 더한 것이다. r0bffe377b14b432b8c55bf022b2c419e가 이 양에 대해 증명한 것은 다음과 같다(주장 c-identities, c-theorem-S, p-local-step). 모든 기울임과 N≥2c−1에서 (N+1)·C_N=Σ_{l=0}^{c−2}𝔟_l·D_{N−2−l}+x·c·Q_N−(x·c+x−2)·D_{N−1}이다. 여기서 𝔟_l은 Cayley 수만의 계수이고, Q_N=Σ_{i=c−1}^{N−1−c}D_i·D_{N−2−i}는 무거운 성분이 둘인 배치의 몫이며 x≤x_c이면 음이 아니다. 첫 층 c+1≤N≤2c−1에는 같은 꼴의 식이 따로 있다. 기울임이 (1−1/c)^{c−1} 이하이고 그 기록의 Cayley 수만의 조건 (Y1)과 C_c≤0이 서면, C_N은 N≥c에서 부호를 꼭 한 번, 음이 아닌 쪽으로 바꾼다(정리 S). 크기 n≥2c의 국소 기울임에서, n 바로 앞의 J칸에서 C_m≥0이고 닫힌 식의 조건 둘이 서면 자리 (n,c)에서 (L1°)의 부등식이 선다(정리 3.3; 필요한 J는 c^{2/3}의 눈금이다). 대조: Pr(M_N<c)=u_N/w_N, w_{n+1}=w_n, 국소 기울임의 등식, DC(N)=C_N+(V_{N+1}−U_{N−1})을 c≤12, 크기 30 이하에서 정확한 유리수로 확인했다(이 조직화의 출력의 check_identities.py의 3번).

Membership: permanent
Source: [local definition](organizations/o55831e5d12e248a4832b313ca1519a95/organization.json) — o55831e5d12e248a4832b313ca1519a95/size-direction-second-difference

Historical name/symbol: 국소 기울임 (x_{n+1}) — [local definition](records/r0bffe377b14b432b8c55bf022b2c419e/record.json) — r0bffe377b14b432b8c55bf022b2c419e/local-tilt
Historical name/symbol: 기울인 핵 질량, 감소분, 둘째 차분 (u_N, w_N, D_N, C_N) — [local definition](records/r0bffe377b14b432b8c55bf022b2c419e/record.json) — r0bffe377b14b432b8c55bf022b2c419e/tilted-kernel-mass
Historical name/symbol: 기울인 핵 질량, 감소분, 둘째 차분 (u_N, w_N, D_N, C_N) — [local definition](records/rfaf06c62ef70496eab6c1f5b1222dffa/record.json) — rfaf06c62ef70496eab6c1f5b1222dffa/tilted-kernel-mass

## 교차곱의 판정 함수 𝖦(r,k)

Symbol: 𝖦(r,k)

정수 r≥2와 실수 k>1에 대해 𝖦(r,k):=k·(1/(2r)−1/(3r²))−5/2+(1/2)·μ_0(X_−)+2(1−1/k)·μ_0(X_mid)−(k/(k−1))·D_r이다. 여기서 X_−=r(r+1)/(k−1), X_mid=r(r+2)/(2k), μ_0(X)=(√((4+X)²+12(r−1))−(4+X))/3, D_r=3((r+2)·s_r−3r)/(2(r−s_r)), s_r=Σ_{j=1}^{r} r(r−1)⋯(r−j+1)/r^j이다(s_r은 길이 r의 합성 위의 생일 법칙 아래 부분의 수의 평균이다; 전역 용어 「생일 법칙과 D_m」). 정의는 r04646f8dd4cb4f2d949b348da4200cf3의 주장 c-criterion(명제 4.1)의 것이고, 그 기록의 지역 용어 「판정 함수」와 같은 함수다. 이름에 「교차곱의」를 붙인 것은 r496399b680604ffda982aedf9ac9b480의 지역 용어 「판정 함수」 M(r,k)와 가르기 위해서다(M(r,k)는 μ_0(X_−)의 항이 없고 다른 법칙의 평균이 드는 앞선 꼴이다). 글자 𝖦는 r69068ac5755e47bf83611f535d8af02c와 r3bd6df852c694ee299e0f7581899e222의 갱신열 𝖦_s와 다른 대상이다. 쓰임: (n,k)가 첫 층의 자리(k≥3, k+2≤n≤2k−1)이고 r=n−k일 때 𝖦(r,k)≥0이면 그 자리의 교차곱 S_{n,k}=B_+C_−−B_−C_+가 양이다(전역 용어 「얼린 다항식, 곡률항, 경계항, 교차곱」; 같은 주장). r≥2를 고정하면 𝖦(r,k)는 실수 k>1에 대해 증가한다(같은 주장). 양임이 증명된 범위는 다음과 같고, 증명은 모두 계산을 쓰지 않는다. (1) 정수 r≥10, k≥r^{3/2} (r04646f8dd4cb4f2d949b348da4200cf3의 주장 p-criterion-no-computation, 정리 4.2 (다)). (2) 정수 2≤r≤9, k≥86 (같은 주장, (라)). 같은 r에서 실수 k≥82 (r670ca907a6f44697854fcb5c4c15c735의 주장 p-G-small-deficit; 2≤r≤5에서 2.31 이상, 6≤r≤9에서 1.58 이상). (3) 정수 r≥2, 실수 k≥max(265, (5/11)·r^{3/2}). 정수 k≥265에서는 r≤⌊(11k/5)^{2/3}⌋과 같은 말이다(r04646f8dd4cb4f2d949b348da4200cf3의 따름 4.3 (i); r7ce45a38dbe5465f8c4743ade1788843의 주장 c-lemma-A가 틀 둘로 다시 증명했고, 2≤r≤13에서 2.33보다 크고 r≥14에서 0.083·√r−0.1533 이상이다). (4) 정수 125≤k≤264, 2≤r≤⌈k/4⌉−2 (r670ca907a6f44697854fcb5c4c15c735의 주장 c-G-entry-range; r≥14에서 0.0678·√r−0.0144 이상). 곡선 k=r^{3/2} 위의 값은 r=10에서 0.3606, r=9에서 0.170이고 r≤8에서 음이다(r04646f8dd4cb4f2d949b348da4200cf3의 관찰). 대조: 이 정의로 셈한 값이 기록들이 적은 참값(r=2,…,9의 𝖦(r,82), 곡선 위의 r=9, 10의 값, (4)의 영역의 정수 칸 6440곳의 최솟값 1.3278)과 맞는다는 것을 보았다(이 조직화의 출력의 check_identities.py의 3번; 옮겨 적은 식의 대조이고 어느 정리의 확인도 아니다).

Membership: permanent
Source: [local definition](organizations/o5c57e4d280844068adf25c27dff42ca6/organization.json) — o5c57e4d280844068adf25c27dff42ca6/cross-product-criterion-function

## 대각 방향의 우도비 조건 (이웃비의 대각 단조성)

Symbol: ϱ_n(k)

정수 n≥2, 1≤k≤n−1에 대해 행의 이웃비를 ϱ_n(k):=b_{n,k}/b_{n,k−1}로 둔다. 자리 (n,k)에서의 대각 방향의 우도비 조건은 ϱ_{n+1}(k+1)≤ϱ_n(k), 같은 말로 b_{n+1,k+1}·b_{n,k−1}≤b_{n+1,k}·b_{n,k}다. d_{n,k}≤0이 ϱ_n(k)≤1과 같으므로, 이 조건이 한 자리에서 서면 그 자리에서 노드 (Diag)의 함의 「d_{n,k}≤0이면 d_{n+1,k+1}≤0」이 선다. 같은 말로 d_{n+1,k+1}/(n+1)!≤μ·d_{n,k}/n!, μ=b_{n+1,k}/((n+1)·b_{n,k−1})이고, μ/γ_k는 전역 용어 「대각 비와 대각 초과」의 대각 비 ϑ(n+1,k)다(γ_k=(1+1/k)^{k−2}). 이름의 주의: r692807de92c14aadbf55edb159c65717의 관찰 o-dr과 r42f12423681f4495b4256c27190ab94b는 이 조건을 「(DR)_{n,k}」로 적는다. 전선의 노드 「(DR) 첫 층의 빚 갚기」(대각 기울임에서 첫 층의 차분의 기울인 합이 음이 아니라는 것)와 이름만 같고 다른 진술이다. 그래서 이 조직화의 글은 꼬리표 (DR)을 노드에만 쓰고 이 조건은 이름으로 부른다. 같은 조건의 다른 이름: 넘겨받은 인수인계 문서 6절의 「행 사이 우도비의 단조성(결손 좌표 판)」, rb631a853ad394807bf00eb9ea82b4de6의 대각 방향 우도비 단조성, rd5e24622fa784c26a708cce1d9f1fa2b의 「결손을 맞춘 셀의 순서」(r42f12423681f4495b4256c27190ab94b의 지역 용어 「대각 방향의 우도비 조건 (DR)과 셀의 승수」와 주장 o-cell-member가 이 대응을 적는다). 개정 76까지 알려진 것은 다음과 같다(뒤의 기록이 바꿀 수 있다). 모든 자리의 진술로는 거짓이다. 행 n≤299의 정확한 계산에서 결손 n−k≤2인 자리(n≥4)는 모두 깨지고, 결손이 3 이상이고 d_{n,k}≤0인 자리에서 깨지는 것은 n≤15의 11곳뿐이며, d_{n,k}>0인 자리에서는 (n,k)=(177,89)에서 처음 깨지고 깨지는 띠가 행과 함께 넓어진다(r692807de92c14aadbf55edb159c65717의 관찰 o-dr). 큰 크기의 임계 창에서는 정리다. N=n+1로 두고 0<a<b, b^{3/2}<u_2이면(u_2≈9.4297은 전역 용어 「극한 함수 θ와 Θ」의 Θ가 2에 이르는 자리이고 눈금으로 x≈4.4634다), 충분히 큰 n에서 a·N^{2/3}≤N−k≤b·N^{2/3}인 모든 자리에서 조건이 엄격히 선다(r42f12423681f4495b4256c27190ab94b의 주장 p-dr-window-limit의 따름 P8; 문턱은 드러나지 않는다). 그 창 극한은 N³·[b_{n+1,k}·b_{n,k}−b_{n+1,k+1}·b_{n,k−1}]/(p_n·p_{n+1})→𝖿(x)²·(d/dx)Θ(x^{3/2}) (x=(N−k)/N^{2/3}, 𝖿는 결손의 극한 밀도)이고, 정리는 「Θ(u)<2이면 Θ′(u)>0」(같은 기록의 주장 p-theta-derivative)에서 나온다. 극한에서의 뜻은 극한 밀도가 log x에 대해 로그오목이라는 것이다(rd5e24622fa784c26a708cce1d9f1fa2b의 해설의 읽기; 눈금 8.49 너머에서 깨진다). d_{n,k}≤0인 자리로 좁힌 조건의 모든 크기에 대한 증명은 없다. n≤29의 첫 층의 음의 자리에서는 이 조건이 전역 용어 「대각 교차곱, (GL), (GL_top)」의 부등식보다 세다는 것이 r42f12423681f4495b4256c27190ab94b의 관찰이다(증명이 아니다). 대조: 3≤n≤29에서 깨지는 자리(결손 1은 행 3–29, 결손 2는 행 4–29, 결손 3은 행 6–15, 결손 4는 행 9; 결손 3 이상의 11곳은 모두 d_{n,k}≤0인 자리)를 이 조직화의 출력의 check_identities.py가 확인했다.

Membership: permanent
Source: [local definition](organizations/o59c24d38fcff47d5a4f1e352aaeb5b51/organization.json) — o59c24d38fcff47d5a4f1e352aaeb5b51/diagonal-likelihood-ratio-condition

## 첫 층의 응답 꼴: 원천 응답, 충격 응답, 충격의 족

Symbol: X_k(n), ι_k(n), ι^{(y)}_k(n), Φ_n(k)

정수 k≥2와 n≥k에 대해 N=n+1, a_j=j^{j−1}/j!, λ_k=a_k/k로 두고, Λ_m(y;N)을 전역 용어 「절단 인자를 가진 Cayley 합성의 법칙」의 사슬 합이라 하자(m의 모든 합성에 걸친 합이고, 토막마다 a_γ를, 자르는 점 s마다 y/(N−s)를 곱한다). 실수 y>0에 대해 충격의 족을 ι^{(y)}_k(n):=λ_k·Λ_{n−k+1}(y;N)으로 두고, 충격 응답을 ι_k(n):=ι^{(k+1)}_k(n), 원천 응답을 X_k(n):=2·Σ_{j=k}^{n−1}Λ_{n−j}(k+1;N)·b_{j,k−1}/(j+1)!로 둔다. 이름과 기호는 rb3d5f156b5ad4538ae8905092806d88b의 지역 용어 「응답 연산자, 충격 응답, 원천 응답」의 것이고, n!·ι^{(y)}_k(n)은 그 기록의 G_k(y;n)이다. 첫 층의 응답 꼴은 등식 d_{n,k}=n!·(X_k(n)−ι_k(n)) (k≤n≤2k−1; n=k에서는 d_{k,k}:=−p_{k−1})이다. n≥2k에서는 서지 않는다. 같은 등식의 다른 이름은 다음과 같다. rb3d5f156b5ad4538ae8905092806d88b의 수준 재귀 (R1′)(주장 c-level-recursion). r9faef2b6f9804ae4910f22b51ee669cb의 핵 꼴(주장 p-kernel-form; 그 기록의 「충격의 응답」 𝖩_n은 x_k^n·ι_k(n)이고 x_k는 임계 기울임이다). r42f12423681f4495b4256c27190ab94b의 생존 꼴(주장 p-survival-form; 원천 응답을 X_k(n)=2·Σ_{l=k}^{n−1}V_l·𝒜_{n+1−l}, V_l=A_{l−1,k−2}/l!, 𝒜_m=Λ_m(k+1;N)−Λ_m(k;N)으로 적는다. 원천이 행에 달리지 않는 생존 확률의 수열이 된다). reea223c540234d0c91b5e4c095d261e8의 첫 층의 꼴(주장 c-first-layer-forms; 그 기록이 「충격」이라 부르는 B_+(n,k−1)). 전역 용어 「얼린 다항식, 곡률항, 경계항, 교차곱」의 말로는 k+1≤n≤2k−1에서 n!·X_k(n)=C_+(n,k−1), n!·ι_k(n)=B_+(n,k−1)이고, 응답 꼴은 모든 자리에서 서는 분해 d_{n,k}=C_+(n,k−1)−B_+(n,k−1)의 첫 층의 꼴이다. 차분을 양의 몫과 음의 몫으로 가르는 세 분해의 빼는 항은 충격의 족의 세 값이다. 동률 빼기 막힘 d_{n,k}=C_−(n,k)−B_−(n,k)에서 B_−(n,k)=n!·ι^{(k−1)}_k(n) (k+1≤n≤2k−1), 전역 용어 「곡률과 손실 (걸음의 Taylor 분해)」에서 손실 L_{n,k}=n!·ι^{(k)}_k(n) (k+1≤n≤2k), 그리고 위의 B_+(n,k−1)=n!·ι^{(k+1)}_k(n)이다(rb3d5f156b5ad4538ae8905092806d88b의 해설 2.5절, r42f12423681f4495b4256c27190ab94b의 주장 p-impulse-family). 응답 비는 Φ_n(k):=X_k(n)/ι_k(n)=1+d_{n,k}/(n!·ι_k(n))이고(r42f12423681f4495b4256c27190ab94b의 지역 용어), d_{n,k}≤0은 Φ_n(k)≤1과 같다. 부등식 (M_y): d_{n+1,k+1}/((n+1)!·ι^{(y+1)}_{k+1}(n+1)) ≤ d_{n,k}/(n!·ι^{(y)}_k(n)) (k≥3, k+2≤n≤2k−1)에서 y=k−1이 전역 용어 「대각 교차곱, (GL), (GL_top)」의 부등식이고 y=k+1이 응답 비의 대각 단조성 Φ_{n+1}(k+1)≤Φ_n(k)다(같은 기록의 명제 P1). 이름의 주의: 「충격」과 글자 ι는 기록마다 다른 정규화의 양에 쓰인다. r3e8ad56ece2549449ad86ef9412d9cfa와 r5016e7b5d9604b8c86fdaa0bcb509dbb의 ι는 임계 기울임을 곱한 p_{k−1}·x_k^k/k!, rc693abe9ba4f4ad7960846fd64f6c53b의 sh는 Bor(y)/y, re8460c24720d4fdeaed189d466393fb7의 ι는 Bor(k)/k다. 이 항목의 ι_k(n)은 그 충격에 문턱 꼭짓점의 조상 사슬의 인자가 붙은 것이다. 대조: 위의 등식과 범위를 이 조직화의 출력의 check_identities.py가 2≤k≤12, n≤30(얼린 다항식은 n≤16)에서 정확한 유리수로 확인했다.

Membership: permanent
Source: [local definition](organizations/o59c24d38fcff47d5a4f1e352aaeb5b51/organization.json) — o59c24d38fcff47d5a4f1e352aaeb5b51/first-layer-response-form

## 성질 K의 기울임 꼴, 옮긴 판정, 여유

Symbol: (K*_β), Λ_{y−β}[W], Ξ

전역 용어 「성질 K」를 다시 적는 세 꼴이다. 정수 y≥2와 세 점 y−1, y, y+1에서 양인 W를 둔다(전역 항목의 성질 K: 모든 θ≥0에서 W(y+1)·e^{−θ/(y+1)}+W(y−1)·e^{−θ/(y−1)} ≥ 2·W(y)·e^{−θ/y}). (1) 기울임 꼴. W가 y에서 성질 K를 가진다는 것은 모든 실수 λ≥0에서 e^λ·W(y+1)+e^{−λ}·W(y−1) ≥ 2·e^{λ/y}·W(y)라는 것과 같다(θ=(y²−1)·λ로 두고 e^{yλ}를 곱한 것; r26911cae02f14f81a380e7f04043ba60의 주장 p-tilt-form). 같은 꼴의 부등식을 한 수열의 이웃한 세 값에 대해, 기준 k를 자리 n과 무관하게 고정하고 적은 것, 곧 「모든 λ≥0에서 e^λ·f(n+1)+e^{−λ}·f(n−1) ≥ 2·e^{λ/k}·f(n)」을 그 기록은 「f가 자리 n에서 기울인 볼록성을 가진다」고 부른다(n=k이면 f의 성질 K다). (2) 옮긴 판정. 실수 0≤β<y−1에 대해 세 점 범함수를 Λ_{y−β}[W]:=(y−β+1)·log(W(y+1)/(y−β+1))+(y−β−1)·log(W(y−1)/(y−β−1))−2(y−β)·log(W(y)/(y−β))로 두고, Λ_{y−β}[W]≥0을 원점을 β만큼 옮긴 판정 (K*_β)라 한다(r11eea2a4da4b404a83e6b40b0c63710e의 주장 c-shifted-criterion). 같은 말로 V_β(z)=W(z)/(z−β)가 V_β(y+1)^{y+1−β}·V_β(y−1)^{y−1−β} ≥ V_β(y)^{2(y−β)}를 만족한다는 것이다. β=0이 전역 항목의 성질 K*다. (K*_β)가 서면 W는 y에서 성질 K를 가진다. β=0의 범함수 Λ_y[W]는 r26911cae02f14f81a380e7f04043ba60의 Ξ와 같은 수다. (3) 여유. 실수 ε≥0에 대해 「모든 θ≥0에서 W(y+1)·e^{−θ/(y+1)}+W(y−1)·e^{−θ/(y−1)}−2·W(y)·e^{−θ/y} ≥ ε·W(y)·e^{−θ/y}」이면 W가 y에서 여유 ε의 성질 K를 가진다고 한다(r11eea2a4da4b404a83e6b40b0c63710e의 주장 p-K-margin; ε=0이 성질 K). 기울임 꼴로는 모든 λ≥0에서 e^λ·W(y+1)+e^{−λ}·W(y−1) ≥ (2+ε)·e^{λ/y}·W(y)다. Λ_{y−β}[W]≥μ≥0이면 W는 여유 2·(e^{μ/(2(y−β))}−1)의 성질 K를 가진다(같은 주장). β=0에서 이것은 r26911cae02f14f81a380e7f04043ba60의 주장 p-tilt-form의 (나), 곧 「모든 실수 λ에서 e^λ·W(y+1)+e^{−λ}·W(y−1) ≥ 2·e^{λ/y}·W(y)·e^{Ξ/(2y)}」가 주는 것과 같은 한계이고, 여유를 떼면 전역 항목이 적는 「성질 K*는 성질 K를 함의한다」다(rc31497e9df27478584efc43f79e164f2의 보조정리 P10). 여유는 합에 대해 가장 작은 것으로 닫혀 있고, ∫e^{−θ/z}μ(dθ) 꼴의 인자를 곱해도 줄지 않는다. 기호의 주의: 범함수의 글자 Λ는 r11eea2a4da4b404a83e6b40b0c63710e의 것이고 전역 용어 「조임, 조임량, 단조 기억, 판정 (Z)」의 Λ와 다르다. 그 기록은 여유의 글자로 ε을, 판정의 여유의 글자로 λ를 쓴다. 대조: (1)의 바꿈, Λ_y[W]=Ξ, (K*_β)에서 성질 K가 따른다는 것과 (3)의 여유의 한계를 양의 세 점 수열 여럿에서 수로 대조했다(이 조직화의 출력의 check_identities.py의 1번; 옮겨 적은 식의 대조이고 정리의 근거가 아니다).

Membership: permanent
Source: [local definition](organizations/ob18a630d9f984d1ab8f9e86019e6d917/organization.json) — ob18a630d9f984d1ab8f9e86019e6d917/property-K-forms

## 임계 창의 극한 함수들: 얼린 모멘트와 흐름 함수, 극한 교차곱 W와 (X)_lim, (SP)의 극한 Σ^SP, 부등식 (Y)와 (Y′)

Symbol: S, f, m_j, β_j, ν, W, Σ^SP, 𝔥, 𝔾, z_1, z_𝗁

B를 표준 브라운 운동, B̄_t=max_{s≤t}B_s, 𝒜_z=∫_0^z B̄_t dt (z≥0), τ_b=inf{t: B_t>b}라 하자. 𝒜_z는 z^{3/2}·A와 같은 법칙을 가진다(A=𝒜_1은 전역 용어 「극한 함수 θ와 Θ」의 넓이). 극한 생존함수는 S(z)=E e^{−𝒜_z}=L(z^{3/2})이고(L은 그 전역 항목의 Laplace 변환), 극한 밀도는 f=−S′다. 길이 n의 균등한 주차함수에서 결손을 N^{2/3}으로 나눈 것(N=n+1)의 극한 법칙의 생존함수와 밀도다. 정수 j≥0에 대해 얼린 모멘트는 m_j(z)=E[B̄_z^j·e^{−𝒜_z}] (m_0=S, m_1=f), 흐름 함수는 β_j(z)dz=∫_0^∞ b^j·E[e^{−𝒜_{τ_b}}; τ_b∈dz]db, 곧 최댓값이 시각 z에 오르는 사건을 그때의 높이의 j제곱과 무게 e^{−𝒜}로 센 것이다(이름과 정의는 r496399b680604ffda982aedf9ac9b480의 지역 용어 「얼린 모멘트, 흐름 함수, 극한의 교차곱」의 것이다). m_j′=j·β_{j−1}−m_{j+1}이고, 따라서 m_2=β_0−f′, m_3=2β_1−β_0′+f″이다. ν(z)=(2π)^{−1/2}·z^{−3/2}는 최댓값 과정의 역과정의 Lévy 밀도다. 극한 교차곱은 W=f″·m_2+f′·m_3, (SP)의 극한 함수는 Σ^SP=f′²−f·f″−β_0·f′=−(f″·m_1+f′·m_2)다. 진술의 이름: (X)_lim은 「모든 z>0에서 W(z)<0」, (Y)는 「m_3·β_0≤2β_1·m_2」, (Y′)은 「f′<0인 z에서 f″·β_0≤2|f′|·β_1」이다. f′<0인 z에서 (Y)이면 (Y′)이고 (Y′)이면 W<0이다(r5ad280a55db34afd8043818c2c9f9ce3의 주장 p-one-yardstick; 그 함의에는 β_0>0과 β_0′<0이 쓰이고 둘은 r496399b680604ffda982aedf9ac9b480의 증명된 사실이다). z_1=0.5996…은 f′의 하나뿐인 영점, 곧 극한 밀도의 최빈점이다(r790d81e586524894a2220b314fcfab51의 x_0). z_𝗁=sup{T: (0,T]에서 𝗁≤3/2}이고 𝗁(z)=z·f(z)/S(z)는 눈금을 맞춘 위험률이다(정의는 r467bd8587572468bb2b0ab4736461042의 주장 p-weighted-limit, 한계 3.1797<z_𝗁<3.1910은 r5ad280a55db34afd8043818c2c9f9ce3의 주장 p-hazard-range; (0, 3.26]에서 𝗁=3/2인 점은 z_𝗁 하나뿐이다). 쌍극 응답은 𝔥=β_1+β_0′이고 닫힌 꼴이 𝔥=S/4−ν/2다(아래의 국소 항등식과 같은 식이다). Green 연산자 𝔾는 r790d81e586524894a2220b314fcfab51의 극한 연산자 𝔏의 역을 핵이 음이 아닌 연산자로 적은 것이다. 음이 아닌 가측 함수 s에 대해 (𝔾s)(z)=E∫_0^∞ 1{τ_t<z}·exp(−∫_0^t (z−τ_r)dr)·s(z−τ_t)dt이고(τ는 B̄의 역과정), m_3=3·𝔾m_2, β_1=𝔾β_0다(두 이름과 정의는 r76c6be0e0cc84f61a5323a3a0726fbd9의 지역 용어 「Green 연산자」, 「쌍극 응답」의 것이고 그 기록의 용어집은 승인되지 않았다. 𝔾는 rbc6a3c2f72094ecc9bc6f8e683900bf6의 지역 기호 𝔾_q(y)나 게시된 유한한 Green 핵들과 다른 대상이고, 쌍극 응답 𝔥는 위험률 𝗁와 다른 함수다). 유한한 쪽과의 대응. 임계 창에서 눈금을 맞춘 손실과 곡률(전역 용어 「곡률과 손실 (걸음의 Taylor 분해)」)의 극한이 β_0와 m_2라는 것은 r790d81e586524894a2220b314fcfab51의 정리다(그 기록의 ℓ과 𝗏). 막힘(경계항 B_−)과 동률(곡률항 C_−)에 대한 같은 대응도 정리다(같은 기록의 주장 p-limit-identification: 창의 콤팩트 구간에서 N^{4/3}·B_−(n,k)/p_n→β_0, N^{4/3}·C_−(n,k)/p_n→m_2이고 오차는 O(N^{−1/3})다; p_n=(n+1)^{n−1}, N=n+1; r496399b680604ffda982aedf9ac9b480은 이 대응을 발견적으로 적었다). 발견적으로 남은 것은 이웃한 두 수준의 경계항의 차 B_+−B_−의 대응이다. 대각선의 번호 q→∞에서 눈금을 맞춘 막힘과 동률의 윤곽이 두 극한 측도로 약하게 수렴한다는 것은 rb9e33ce773f645c88abddadbd1253200의 주장 p-limit-tie-block이고 앞의 정리에 기댄다. 전선의 노드 (SP)의 양변의 차를 눈금 맞춘 것은 창의 콤팩트 구간에서 Σ^SP로 수렴한다(r790d81e586524894a2220b314fcfab51의 정리 P18). 노드 (X)의 교차곱 자체의 창 극한 정리는 없다. 동률 대 막힘의 비 R_n(k)=C_−(n,k)/B_−(n,k)(전역 용어 「대각 교차곱, (GL), (GL_top)」)의 극한 꼴은 R_∞=m_2/β_0다. 기록마다의 표기. 눈금 z는 r790d81e586524894a2220b314fcfab51과 전역 항목의 x, r2c0e1ffcef154926b343549af83820a2의 ξ이고, u=z^{3/2}다. S는 r213dbe848e5c4e8483afbcbfe76addec, r496399b680604ffda982aedf9ac9b480, rb9e33ce773f645c88abddadbd1253200, r76c6be0e0cc84f61a5323a3a0726fbd9의 ψ다. f는 r790d81e586524894a2220b314fcfab51의 G′(G=1−S)이고 여러 기록의 𝖿다. β_0는 r790d81e586524894a2220b314fcfab51의 ℓ이고, rb9e33ce773f645c88abddadbd1253200은 β_j를 ℓ_j로 적는다(그 기록의 β_x는 Cayley 수다). 넓이 A를 r2c0e1ffcef154926b343549af83820a2은 𝖠로, 그 밀도를 ϱ로 적고, rb9e33ce773f645c88abddadbd1253200은 밀도를 p_A로 적는다. g(u)=E[A·e^{−uA}]로 f(z)=(3/2)·z^{1/2}·g(z^{3/2})다. 전역 항목의 함수로는 𝗁(z)=(3/2)·θ(z^{3/2})이고 z·f′(z)/f(z)=(1−3Θ(z^{3/2}))/2다(뒤의 것이 r467bd8587572468bb2b0ab4736461042의 눈금 기울기 s(z)). r5ad280a55db34afd8043818c2c9f9ce3은 전역의 L(u)를 Φ(u)로 적고 ζ=f″/|f′|를 쓴다. 개정 88까지 증명된 것(뒤의 기록이 바꿀 수 있다). 모든 z>0에서 W<0이고 Σ^SP>0이다. r5ad280a55db34afd8043818c2c9f9ce3이 둘을 증명했다(주장 c-limit-inequalities는 구간 연산을 쓰고, p-limit-inequalities-proved는 쓰지 않는다. 뒤의 증명은 봉우리 너머 z≥z_1에서, 눈금 방정식 S″=(z²/2)·S′+(5z/4)·S−(2πz)^{−1/2}, β_0″=(z²/2)·β_0′+(5z/4)·β_0+3ν/(4z)와 국소 항등식에서 두 교차곱이 따르는 일계 선형 방정식을 얻고 그 원천의 부호를 읽는다. 0<z≤z_1에는 넓이의 모멘트의 손 계산을 쓴다). rb9e33ce773f645c88abddadbd1253200의 주장 p-xlim은 W<0의 다른 증명이고 눈금 방정식을 쓰지 않는다(닫힌 꼴 β_0(z)=𝖼⋆·z^{−1/2}·E[A^{1/3}·e^{−z^{3/2}·A}], 𝖼⋆=(2π)^{−1/2}/E[A^{1/3}]과 로그오목 밀도의 모멘트 부등식 둘, 넓이의 밀도의 닫힌 꼴에서 나오는 부등식 하나를 쓴다. 새로 증명한 것은 f′<0인 쪽이다). r76c6be0e0cc84f61a5323a3a0726fbd9은 0<z≤x*(4/3)에서 W<0을 양의 핵과 두 점 논법으로 증명했고(x*(4/3)는 전역 항목의 Θ에 대해 Θ(x^{3/2})=4/3인 하나뿐인 x, 곧 z^{3/2}·f(z)가 최대인 눈금이고 1.9771<x*(4/3)<1.9786이다), 모든 z>z_1에서 (Y′)이 엄격히 선다는 것을 증명했다(주장 p-yprime). 앞선 범위는 r04646f8dd4cb4f2d949b348da4200cf3의 주장 c-limit-form(0<z≤(4/5)^{2/3}=0.862에서, 그리고 f가 [0,z]에서 줄지 않는 z에서 W<0)과 r2c0e1ffcef154926b343549af83820a2(z≤1.53)이다. (Y)는 추측이다. 국소 항등식 S=4·(β_0′+β_1)+2ν는 r5ad280a55db34afd8043818c2c9f9ce3의 주장 p-local-identities다. 이 정리들은 극한 대상에 대한 것이고 유한한 n의 (X)나 (SP)를 함의하지 않는다. (SP)에 대해서는 창의 콤팩트 구간마다 충분히 큰 n에서 선다는 것만 나오고 문턱이 드러나지 않는다. 대조: 이 항목이 옮겨 적은 대수의 관계(m_2, m_3의 식, Σ^SP의 두 꼴, W=β_0·(f″+λ_B·f′), λ_B=2β_1/β_0−β_0′/β_0, 세 진술의 함의의 방향)를 기호 계산으로 확인했다(이 조직화의 출력의 check_identities.py의 1번; 옮겨 적은 식의 대조이고 어느 정리의 근거도 아니다).

Membership: permanent
Source: [local definition](organizations/o6d3d44f9bf134acbbade2dd9e5c9ac00/organization.json) — o6d3d44f9bf134acbbade2dd9e5c9ac00/window-limit-functions

