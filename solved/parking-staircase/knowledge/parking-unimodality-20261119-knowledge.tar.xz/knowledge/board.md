# Research work and occupied sections

Research revision: 120

Saved pipeline state, not process liveness. Sections and questions remain occupied through peer and review.

- p2167fe7b86664a838e0d078c08fda08a · producer: s94cb875423fc49009199f622d4d135f8 · formalizer · review · nodes: s1767abe148714e3680363cbb7fcfa85b-left-increase
  Section s94cb875423fc49009199f622d4d135f8-1 on s1767abe148714e3680363cbb7fcfa85b-left-increase (session s94cb875423fc49009199f622d4d135f8): the whole node
- p254dbab59c044c07b80af9d6edc708fd · producer: sc329f3c1b97744428053542411288a21 · explore · review · question: op-one-chain-two-directions
- p6c4ac560058c497685a2bfd78e6f0190 · producer: s4b23c05d86dd4c63a2f80ebd1dfced4e · attempt · producing · nodes: sccddb292c4544658855ec4b22ff21237-cross-positive
  Section s4b23c05d86dd4c63a2f80ebd1dfced4e-1 on sccddb292c4544658855ec4b22ff21237-cross-positive (session s4b23c05d86dd4c63a2f80ebd1dfced4e): 노드 (X)의 진술을 자리 n ≤ 2k로 제한한 것: 모든 정수 n ≥ 3과 n/2 ≤ k ≤ n−2인 모든 정수 k에 대해 B⁺_{n,k}·(b_{n,k}−b_{n,k−1}) > B⁻_{n,k}·(b_{n,k+1}−b_{n,k})이다. 기호는 노드 (X)의 것 그대로다(b_{n,ℓ}는 최대 변위가 정확히 ℓ인 길이 n의 주차함수의 수, Z_n(j)는 모든 변위가 j보다 작은 길이 n의 주차함수의 수, K_{n,k}(y)=Σ_F Π_{v: t_v>k} y/t_v, B⁻_{n,k}=K_{n,k}(k−1)−Z_n(k−1), B⁺_{n,k}=K_{n,k}(k+2)−Z_n(k+2)). 이 범위는 부분나무 크기가 k 이상인 꼭짓점들이 한 사슬에 놓이는 자리들이고, 행의 오른쪽 절반에 해당한다.
- pae9b0bae0afa4b75b1a33794967712a7 · producer: sed88fe750a4346709ae4e27f52d707e4 · formalizer · peer · nodes: sce92ef565bb74f57b5f160372b12dacc-diag-right-half
  Section sed88fe750a4346709ae4e27f52d707e4-1 on sce92ef565bb74f57b5f160372b12dacc-diag-right-half (session sed88fe750a4346709ae4e27f52d707e4): the whole node
- p6ddc6d0526a44004a0458c5a646cba54 · producer: s90c27140b22d41e4947e770a17dc847b · explore · producing · question: q0
- pe9d60b2e01d6460abac8af7361879de3 · producer: sba0fa8f976924c4487b250f8890fd750 · formalizer · producing · nodes: sd7fc9a192dfc4b9193e714f314b156f5-col
  Section sba0fa8f976924c4487b250f8890fd750-1 on sd7fc9a192dfc4b9193e714f314b156f5-col (session sba0fa8f976924c4487b250f8890fd750): the whole node
- pf028d5390b4248c797566b7a3454ef0a · producer: s4605313d27e24a2ebfd4ab37b52357e7 · formalizer · producing · nodes: sccddb292c4544658855ec4b22ff21237-right-target
  Section s4605313d27e24a2ebfd4ab37b52357e7-1 on sccddb292c4544658855ec4b22ff21237-right-target (session s4605313d27e24a2ebfd4ab37b52357e7): the whole node
- p4380119d9455490f8eff261b31523e27 · producer: se5c3bd6d13ba4c9882b30e3cc94152bb · formalizer · producing · nodes: sd7fc9a192dfc4b9193e714f314b156f5-diag
  Section se5c3bd6d13ba4c9882b30e3cc94152bb-1 on sd7fc9a192dfc4b9193e714f314b156f5-diag (session se5c3bd6d13ba4c9882b30e3cc94152bb): the whole node
