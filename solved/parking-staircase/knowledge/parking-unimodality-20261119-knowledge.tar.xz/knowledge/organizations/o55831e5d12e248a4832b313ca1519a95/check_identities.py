# -*- coding: utf-8 -*-
"""Organizer session s90e5c2914bb24b18ac8c66340ac89ffa (batch frozen at research revision 59).

Exact small-size checks of the correspondences written into the local glossary entries
and area notes of this organization.  Standard library only; rows n <= 31.
It is not evidence for any theorem and does not extend any table: it only confirms that
the formulas copied into the entries denote the same numbers as the definitions they are
attributed to.

Run:  python -I check_identities.py
"""
from fractions import Fraction as Fr
from math import comb, factorial

NMAX = 31
failures = 0


def check(name, ok):
    global failures
    if not ok:
        failures += 1
    print(("ok   " if ok else "FAIL ") + name)


# ---- counts: A[n][l] = #{parking functions of length n with max displacement <= l}
def build_A(nmax):
    A = [[0] * (nmax + 2) for _ in range(nmax + 1)]
    for l in range(nmax + 2):
        A[0][l] = 1
    for n in range(1, nmax + 1):
        for l in range(nmax + 2):
            # last car parks at spot j+1 with j cars to its left: min(j+1, l+1) admissible preferences
            A[n][l] = sum(comb(n - 1, j) * min(j + 1, l + 1) * A[j][l] * A[n - 1 - j][l] for j in range(n))
    return A


A = build_A(NMAX)
p = [(n + 1) ** (n - 1) if n >= 1 else 1 for n in range(NMAX + 1)]


def Acum(n, l):
    if n == 0:
        return 1
    if l < 0:
        return 0
    return A[n][min(l, NMAX + 1)]


def b(n, l):
    return Acum(n, l) - Acum(n, l - 1)


def F(n, l):
    return Fr(Acum(n, l), p[n])


def P(n, l):
    return Fr(b(n, l), p[n])


root_rows = {1: [1], 2: [2, 1], 3: [6, 7, 3], 4: [24, 51, 34, 16], 5: [120, 421, 377, 253, 125],
             6: [720, 3963, 4594, 3688, 2546, 1296], 7: [5040, 42253, 62145, 57398, 46142, 32359, 16807]}
check("0. rows n<=7 agree with the table of the root statement; row sums are (n+1)^(n-1) for n<=30",
      all([b(n, l) for l in range(n)] == row for n, row in root_rows.items())
      and all(sum(b(n, l) for l in range(n)) == p[n] for n in range(1, NMAX)))

# ---------------------------------------------------------------------------------------------
# 1. Transfer ratio, Euler ratio, the two Euler inequalities, (Q'), and the coordinates of records
# ---------------------------------------------------------------------------------------------


def q_global(N, r):
    """global glossary: q_N(r) = [Pr(M_{n+1}<=k) - Pr(M_n<=k-1)] / Pr(M_n=k),  n=N-1, k=n-r."""
    n = N - 1
    k = n - r
    return (F(n + 1, k) - F(n, k - 1)) / P(n, k)


ok_range = ok_upper = True
for N in range(2, NMAX):
    for r in range(1, N):
        q = q_global(N, r)
        ok_range &= (0 <= q <= 1)
        ok_upper &= (q <= Fr(r + 1, N))
check("1a. 0 <= q_N(r) <= 1 on all cells 2<=N<=30, 1<=r<=N-1", ok_range)
check("1b. upper Euler inequality q_N(r) <= (r+1)/N (Euler ratio <= 1) on the same cells", ok_upper)

# r055dd905 Theorem 3.12 in (n,y) coordinates and in (N,r) coordinates
ok_first = True
cells_ny = set()
for y in range(1, NMAX):
    for n in range(y + 1, min(2 * y + 1, NMAX - 1) + 1):   # n=y gives Pr(M_n=y)=0 (empty statement)
        lhs = F(n + 1, y) - F(n, y - 1)
        rhs = Fr(1, 2) * Fr(n + 1 - y, n + 1) * P(n, y)
        ok_first &= (lhs >= rhs)
        cells_ny.add((n + 1, n - y))
cells_Nr = {(N, r) for N in range(3, NMAX + 1) for r in range(1, N - 1) if 2 * r <= N}
check("1c. first-layer lower Euler inequality (y>=1, y<=n<=2y+1) holds on all such cells with n<=30", ok_first)
check("1d. the cell set {y>=1, y+1<=n<=2y+1} equals {N>=3, 1<=r<=N/2, r<=N-2} under N=n+1, r=n-y",
      cells_ny == cells_Nr)

# conjecture (LE) of r055dd905 = statement (E1/2) of r45979fd: Euler ratio >= 1/2 at every cell with level >= 1
viol = [(N, r) for N in range(3, NMAX) for r in range(1, N - 1) if q_global(N, r) < Fr(r + 1, 2 * N)]
check("1e. Euler ratio >= 1/2 at every cell with level y=N-1-r >= 1, N<=30 (an observation at this size)", not viol)
lvl0 = [N for N in range(2, NMAX) if q_global(N, N - 1) < Fr(N, 2 * N)]
check("1f. at level 0 the constant 1/2 fails exactly from n=N-1>=4 on (N<=30), and theta(n,0)=(1-1/(n+2))^n",
      lvl0 == list(range(5, NMAX)) and all(q_global(n + 1, n) == Fr(n + 1, n + 2) ** n
                                           for n in range(1, NMAX - 1)))

# rae49544 coordinates: position (n,l), kappa_n(l)=F_{n+1}(l)-F_n(l-1), m_n(l)=Pr(M_n=l), fq_n = kappa/m = q_{n+1}(n-l)
ok_coord = all((F(n + 1, l) - F(n, l - 1)) / P(n, l) == q_global(n + 1, n - l)
               for n in range(2, NMAX - 1) for l in range(0, n - 1))
check("1g. the transfer ratio of rae49544 at position (n,l) equals the global q_{n+1}(n-l)", ok_coord)


def rhat(m):
    return Fr(p[m + 1], p[m])


# (Q'): A_{N+1,l} <= (p_{N+1}/p_N) A_{N,l} - (p_{l+1}/p_l) b_{N,l}; equality exactly on the top row N=l+1
ok_q = ok_eq = ok_w1 = True
for l in range(0, NMAX - 2):
    for N in range(l + 1, NMAX):
        lhs = Acum(N + 1, l)
        rhs = Fr(p[N + 1], p[N]) * Acum(N, l) - Fr(p[l + 1], p[l]) * b(N, l)
        ok_q &= (lhs <= rhs)
        ok_eq &= ((lhs == rhs) == (N == l + 1))
        if l >= 1:
            fq = (F(N + 1, l) - F(N, l - 1)) / P(N, l)
            ok_w1 &= (fq <= 1 - rhat(l) / rhat(N))
check("1h. (Q') holds on all cells 0<=l<=28, l+1<=N<=30", ok_q)
check("1i. equality in (Q') exactly on the top row N=l+1 (N<=30)", ok_eq)
check("1j. (Q') in ratio form: transfer ratio <= 1 - rhat_l/rhat_N (l>=1)", ok_w1)

# ---------------------------------------------------------------------------------------------
# 2. Diagonal ratio, the three objects called diagonal excess, cumulative diagonal bracket, column debt
# ---------------------------------------------------------------------------------------------


def gamma(k):
    return Fr(k + 1, k) ** (k - 2)


def theta_ratio(N, k):          # normalized diagonal ratio of r6af349eb / r1d80f357
    return Fr(b(N, k), 1) / (gamma(k) * N * b(N - 1, k - 1))


ok_dg = ok_eq = True
for k in range(2, 15):
    for N in range(k + 1, NMAX):
        t = theta_ratio(N, k)
        ok_dg &= (t >= 1)
        ok_eq &= ((t == 1) == (N == k + 1))
check("2a. Theorem Dg: diagonal ratio >= 1 (k<=14, N<=30), equality exactly at N=k+1", ok_dg and ok_eq)

ok_term = ok_debt = ok_equiv = ok_r3 = True
for k in range(2, 13):
    for z in (1 / gamma(k), Fr(k, k + 1) ** (k - 1), Fr(1, 3), Fr(2, 5)):
        def U(j, z=z, k=k):
            return z ** j * Fr(b(j, k - 1), factorial(j))

        def V(j, z=z, k=k):
            return z ** j * Fr(b(j, k), factorial(j))

        for J in range(k + 1, min(2 * k + 3, NMAX - 1) + 1):
            h = -sum(V(i) - U(i) for i in range(k, J + 1))                       # column debt h_J(z)
            S = sum(V(N) - U(N - 1) for N in range(k + 1, J + 1))               # cumulative diagonal bracket at tilt z
            mu = sum(U(N) for N in range(k, J))
            thbar = sum(U(N - 1) * theta_ratio(N, k) for N in range(k + 1, J + 1)) / mu
            ebar = k * (thbar - 1)
            need = k * (1 / (z * gamma(k)) - 1)
            ok_debt &= (h == U(J) - S) and (h == U(J) + (1 - z * gamma(k) * thbar) * mu)
            ok_equiv &= ((h <= U(J)) == (ebar >= need))
            for j in range(k + 1, J + 1):
                e = k * (theta_ratio(j, k) - 1)
                ok_term &= (V(j) - U(j - 1) == U(j - 1) * (z * gamma(k) * theta_ratio(j, k) - 1))
                ok_r3 &= (V(j) - z * gamma(k) * U(j - 1) == (z * gamma(k) / k) * U(j - 1) * e)
check("2b. bracket term V_j-U_{j-1} = U_{j-1}(z*gamma_k*theta(j,k)-1) at four tilts", ok_term)
check("2c. slack of Theorem Dg (r3bd6df85): V_j - z*gamma_k*U_{j-1} = (z*gamma_k/k) U_{j-1} e(j,k)", ok_r3)
check("2d. debt identities h_J = U_J - sum(V_j-U_{j-1}) = U_J + (1 - z*gamma_k*thetabar_J) mu_J", ok_debt)
check("2e. h_J <= U_J  <=>  mean diagonal excess >= needed excess k(1/(z*gamma_k)-1)", ok_equiv)
check("2f. needed excess is 0 at the diagonal tilt and 1 at the critical tilt",
      all(k * (1 / ((Fr(k, k + 1) ** (k - 2)) * gamma(k)) - 1) == 0
          and k * (1 / ((Fr(k, k + 1) ** (k - 1)) * gamma(k)) - 1) == 1 for k in range(2, 40)))
# cumulative excess of r6af349eb: Delta^A(n,k) = A_{n-1,k} - n*gamma_k*A_{n-2,k-1} >= 0
check("2g. cumulative diagonal excess A_{n-1,k} - n*gamma_k*A_{n-2,k-1} >= 0 (k<=14, n<=31)",
      all(Acum(n - 1, k) - n * gamma(k) * Acum(n - 2, k - 1) >= 0 for k in range(2, 15) for n in range(k + 2, NMAX + 1)))

# ---------------------------------------------------------------------------------------------
# 3. Tilted kernel mass: size-direction second difference, local tilt, relation to the diagonal one
# ---------------------------------------------------------------------------------------------


def xcrit(m):
    return Fr(m, m + 1) ** (m - 1)


ok_ratio = ok_local = ok_dc = ok_wflat = True
for c in range(2, 13):
    for n in range(c + 1, NMAX - 1):
        for x in (xcrit(n + 1), xcrit(c), Fr(1, 3)):
            def u(N, x=x, c=c):
                return x ** N * Fr(Acum(N, c - 1), factorial(N))

            def w(N, x=x):
                return x ** N * Fr(p[N], factorial(N))

            C = u(n - 1) - 2 * u(n) + u(n + 1)
            ok_ratio &= (F(n, c - 1) == u(n) / w(n))
            # diagonal second difference at level k=c:  DC(n) = u_{n+1}(c+1) - 2u_n(c) + u_{n-1}(c-1)
            up = x ** (n + 1) * Fr(Acum(n + 1, c), factorial(n + 1))
            um = x ** (n - 1) * Fr(Acum(n - 1, c - 2), factorial(n - 1))
            DC = up - 2 * u(n) + um
            Vn1 = x ** (n + 1) * Fr(b(n + 1, c), factorial(n + 1))
            Un1 = x ** (n - 1) * Fr(b(n - 1, c - 1), factorial(n - 1))
            ok_dc &= (DC == C + Vn1 - Un1)
        x = xcrit(n + 1)                       # local tilt of size n

        def u(N, x=x, c=c):
            return x ** N * Fr(Acum(N, c - 1), factorial(N))

        def w(N, x=x):
            return x ** N * Fr(p[N], factorial(N))

        ok_wflat &= (w(n + 1) == w(n))
        C = u(n - 1) - 2 * u(n) + u(n + 1)
        conv = F(n - 1, c - 1) - 2 * F(n, c - 1) + F(n + 1, c - 1)
        ok_local &= (w(n) * conv == C - (1 - xcrit(n + 1) / xcrit(n)) * u(n - 1))
check("3a. Pr(M_N<c) = u_N/w_N at any tilt", ok_ratio)
check("3b. the local tilt x_{n+1} makes w_{n+1}=w_n", ok_wflat)
check("3c. w_n*(phi_{n-1}-2phi_n+phi_{n+1}) = C_n - (1-x_{n+1}/x_n) u_{n-1} at the local tilt", ok_local)
check("3d. DC(N) = C_N + (V_{N+1} - U_{N-1}) at any tilt (level k=c; cells of levels c and c-1)", ok_dc)

# (L1°) on the small part of its domain that rows <= 31 reach (k=12, 13, 14; an observation, not the theorem)
ok_l1 = all(F(n - 1, k - 1) - 2 * F(n, k - 1) + F(n + 1, k - 1) >= 0
            for k in (12, 13, 14) for n in range(2 * k + 1, NMAX))
check("3e. the (L1°) inequality on the cells k=12,13,14, 2k+1<=n<=30", ok_l1)

print("failures:", failures)
