# -*- coding: utf-8 -*-
"""조직화 o(세션 sde75b216…)의 대조 계산.

연구의 증거가 아니다. 모듈 설명과 지역 용어집에서 「같은 수」, 「같은 식」이라고
적기 전에 정의를 맞대어 본 것이고, 범위는 모두 n <= 30 안이다(정확한 정수/유리수).

표: A[n][k] = 최대 변위가 k 이하인 길이 n의 주차함수의 수(마지막 차 재귀),
    b[n][k] = A[n][k] - A[n][k-1], d[n][k] = b[n][k] - b[n][k-1].
"""
import sys, io
from fractions import Fraction as Fr
from math import comb, factorial

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
NMAX = 30

# ---- 표 -------------------------------------------------------------------
A = [[0] * (NMAX + 2) for _ in range(NMAX + 1)]
for k in range(NMAX + 2):
    A[0][k] = 1
for k in range(NMAX + 2):
    for n in range(1, NMAX + 1):
        A[n][k] = sum(comb(n - 1, t - 1) * min(t, k + 1) * A[t - 1][k] * A[n - t][k]
                      for t in range(1, n + 1))

def Aof(n, k):
    if n == 0:
        return 1
    if k < 0:
        return 0
    return A[n][min(k, NMAX + 1)]

def b(n, k):
    return Aof(n, k) - Aof(n, k - 1)

def d(n, k):
    return b(n, k) - b(n, k - 1)

def p(n):
    return 1 if n == 0 else (n + 1) ** (n - 1)

root_rows = {1: [1], 2: [2, 1], 3: [6, 7, 3], 4: [24, 51, 34, 16],
             5: [120, 421, 377, 253, 125], 6: [720, 3963, 4594, 3688, 2546, 1296],
             7: [5040, 42253, 62145, 57398, 46142, 32359, 16807]}
for n, row in root_rows.items():
    assert [b(n, l) for l in range(n)] == row, n
for n in range(1, NMAX + 1):
    assert Aof(n, n - 1) == p(n)
print("표: 뿌리 파일의 행 n<=7, 합 (n+1)^(n-1) 일치")

def delta(t, k):
    """전역 용어 「나무 곡률」 δ_t (열 k)."""
    if t < k:
        return 0
    if t == k:
        return -k ** (k - 2)
    return (k + 1) * b(t - 1, k) - (k - 1) * b(t - 1, k - 1)

# ---- 1. 열 방정식의 앞쪽 꼴 (한 나무 식; 핵 Bor) ------------------------------
cnt = 0
for k in range(2, 16):
    for n in range(k + 1, min(2 * k - 1, NMAX) + 1):
        rhs = sum(comb(n, t) * p(n - t) * delta(t, k) for t in range(k, n + 1))
        assert d(n, k) == rhs, (n, k)
        cnt += 1
print("1. 앞쪽 꼴 d_{n,k} = Σ_{t=k}^{n} C(n,t)·p_{n-t}·δ_t (k+1<=n<=2k-1):", cnt, "자리 일치")

# 같은 식의 정규화한 꼴(rc693abe9 용어 resolved-form의 '앞쪽 꼴'): 인자 대조
#   Bor(N-t)·[..]/t 에 e^N (N-1)! 을 곱하면 C(n,t)·p_{n-t} (N=n+1)
for n in range(3, 12):
    for t in range(1, n + 1):
        N = n + 1
        lhs = Fr((N - t) ** (N - t - 1), factorial(N - t)) * Fr(factorial(N - 1), t * factorial(t - 1))
        assert lhs == comb(n, t) * p(n - t)
print("   정규화 인자: Bor(N-t)/t · e^N (N-1)!/(e^t (t-1)!) = C(n,t)·p_{n-t} 확인")

# ---- 2. 열 방정식의 풀린 꼴 (핵 Ren) -----------------------------------------
cnt = 0
for k in range(2, 16):
    for n in range(k + 1, min(2 * k - 1, NMAX) + 1):
        K = lambda n_, t_: comb(n_, t_) * (n_ + 1 - t_) ** (n_ - t_)
        rhs = -K(n, k) * k ** (k - 2) + sum(
            K(n, t) * (2 * b(t - 1, k - 1) - (t - k - 1) * d(t - 1, k)) for t in range(k + 1, n + 1))
        assert d(n, k) == rhs, (n, k)
        cnt += 1
print("2. 풀린 꼴 d_{n,k} = -K(n,k)k^{k-2} + Σ_{t=k+1}^{n} K(n,t)[2b_{t-1,k-1} - (t-k-1)d_{t-1,k}],"
      " K(n,t)=C(n,t)(n+1-t)^{n-t} (k+1<=n<=2k-1):", cnt, "자리 일치")

# 범위의 끝: n = 2k 에서는 두 꼴 모두 등식이 아니다(한가운데의 보정항이 붙는다)
bad_f = bad_r = 0
for k in range(2, 16):
    n = 2 * k
    if n > NMAX:
        break
    f = sum(comb(n, t) * p(n - t) * delta(t, k) for t in range(k, n + 1))
    K = lambda n_, t_: comb(n_, t_) * (n_ + 1 - t_) ** (n_ - t_)
    r = -K(n, k) * k ** (k - 2) + sum(
        K(n, t) * (2 * b(t - 1, k - 1) - (t - k - 1) * d(t - 1, k)) for t in range(k + 1, n + 1))
    bad_f += (d(n, k) != f)
    bad_r += (d(n, k) != r)
print("   n=2k (k=2..15): 앞쪽 꼴이 어긋나는 열", bad_f, "개, 풀린 꼴이 어긋나는 열", bad_r, "개")

# ---- 3. 교차 행 q_0(k)와 n_0(k) (부등호가 다른 두 정의) -----------------------
def q0(k):
    for n in range(k + 1, NMAX + 1):
        if d(n, k) > 0:
            return n
    return None

def n0(k):
    for n in range(k + 1, NMAX + 1):
        if d(n, k) >= 0:
            return n
    return None

zeros = [(n, k) for n in range(2, NMAX + 1) for k in range(1, n) if d(n, k) == 0]
print("3. n<=30에서 0인 한 칸 차분:", zeros, "; q_0(k)와 n_0(k)가 다른 열:",
      [k for k in range(1, NMAX) if q0(k) != n0(k)])
print("   q_0(k), k=1..20:", [q0(k) for k in range(1, 21)])

# ---- 4. 곡선 앞의 첫 결손 r_c(k) = floor(k^{2/3})+1 ---------------------------
def rc(k):
    r = 1
    while r ** 3 <= k * k:
        r += 1
    return r

def icbrt_floor(m):
    x = int(round(m ** (1.0 / 3)))
    while x ** 3 > m:
        x -= 1
    while (x + 1) ** 3 <= m:
        x += 1
    return x

assert all(rc(k) == icbrt_floor(k * k) + 1 for k in range(1, 20000))
print("4. r_c(k) = ⌊k^{2/3}⌋+1 (k<20000) 확인; r_c(260..264) =", [rc(k) for k in range(260, 265)],
      "; r_c(537) =", rc(537), "; 536 < 66^{3/2} < 537:", 536 ** 2 < 66 ** 3 < 537 ** 2)
print("   n = k + r_c(k) <= 600 인 가장 큰 k:", max(k for k in range(260, 700) if k + rc(k) <= 600),
      "; k=546의 k+r_c(k) =", 546 + rc(546))

# ---- 5. 창의 끝과 수준 ⌈5(n-1)/7⌉ --------------------------------------------
# K(n) := n-k <= ⌊2k/5⌋+1 인 가장 작은 k 가 ⌈5(n-1)/7⌉ 이라는 산술
def Kn(n):
    k = 1
    while n - k > (2 * k) // 5 + 1:
        k += 1
    return k
assert all(Kn(n) == -(-5 * (n - 1) // 7) for n in range(2, 5000))
print("5. n-k <= ⌊2k/5⌋+1 인 가장 작은 k 는 ⌈5(n-1)/7⌉ (n<5000) 확인")

# ---- 6. (CI_mid)의 범위의 열과 행의 수 ---------------------------------------
print("6. 265<=k<=9999: 열", 9999 - 265 + 1, "개, 필요한 가장 큰 행 n =", 9999 + rc(9999))

# ---- 7. 한 나무 하계: 모든 n에서 부등식, n<=2k-1에서 등호 ----------------------
cnt = eq = 0
for k in range(2, NMAX):
    for n in range(k + 1, NMAX + 1):
        rhs = sum(comb(n, t) * Aof(n - t, k - 1) * delta(t, k) for t in range(k, n + 1))
        assert d(n, k) >= rhs, (n, k)
        cnt += 1
        if n <= 2 * k - 1:
            assert d(n, k) == rhs
            eq += 1
        assert all(delta(t, k) == k * d(t - 1, k) + b(t - 1, k) + b(t - 1, k - 1) for t in range(k + 1, n + 1))
print("7. 한 나무 하계 d_{n,k} >= Σ_t C(n,t)·A_{n-t,k-1}·δ_t:", cnt, "자리(등호", eq, "자리);"
      " δ_t = k·d_{t-1,k} + b_{t-1,k} + b_{t-1,k-1} 확인")

# ---- 8. 끼임 성질 (SW_n) (rbc6a3c2f/g-sandwich) 과 (INT)_n (rb631a853/g-interlacing) ----
# 두 정의는 같은 술어다: 어떤 κ>0 이 있어 모든 0<=l<=n 에서
#   min(b_{n,l-1}, b_{n,l}) <= b_{n+1,l}/κ <= max(b_{n,l-1}, b_{n,l}),  b_{n,-1}=b_{n,n}=0.
def bb(n, l):
    return b(n, l) if 0 <= l <= n - 1 else 0

def sw_interval(n):
    lo = max(Fr(b(n + 1, l), max(bb(n, l - 1), bb(n, l))) for l in range(0, n + 1))
    his = [Fr(b(n + 1, l), min(bb(n, l - 1), bb(n, l))) for l in range(0, n + 1) if min(bb(n, l - 1), bb(n, l)) > 0]
    hi = min(his) if his else None
    return lo, hi

def int_interval(n):  # M^-_n, M^+_n of rb631a853: X_k=b_{n,k}, Y_k=b_{n+1,k}
    X = lambda k_: bb(n, k_)
    Y = lambda k_: b(n + 1, k_)
    Mm = max(Fr(Y(k_), max(X(k_ - 1), X(k_))) for k_ in range(0, n + 1))
    Mp = min([Fr(Y(k_), min(X(k_ - 1), X(k_))) for k_ in range(1, n)] or [None]) if n >= 2 else None
    return Mm, Mp

holds = []
for n in range(1, NMAX):
    a_ = sw_interval(n)
    b_ = int_interval(n)
    assert a_ == b_, n
    holds.append(a_[1] is None or a_[0] <= a_[1])
print("8. (SW_n) 과 (INT)_n: κ의 구간 [M^-_n, M^+_n] 이 1<=n<=29 에서 같다; 성립하는 n:",
      sum(holds), "/", len(holds))

# ---- 9. 창의 길이 R_s(k) (r6af349eb c12) >= ⌊2k/5⌋ ---------------------------
def eps(m):
    return Fr((m - 1) ** (m - 1), factorial(m)) if m > 1 else Fr(1)
def g(m):
    return eps(m + 1) / eps(m)
def Rs(k):
    x = Fr(k, k + 1) ** (k - 2)
    R = 0
    for r in range(1, k - 1):
        if (k + r + 1) * x * g(r) <= k + r:
            R = r
        else:
            break
    return R
vals = [Rs(k) for k in range(3, 16)]
assert vals == [1, 2, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7], vals
assert all(Rs(k) >= (2 * k) // 5 for k in range(3, 120))
print("9. R_s(3..15) =", vals, "; 3<=k<120 에서 R_s(k) >= ⌊2k/5⌋; R_s(30,50,100) =", Rs(30), Rs(50), Rs(100))
print("모두 맞았다.")
