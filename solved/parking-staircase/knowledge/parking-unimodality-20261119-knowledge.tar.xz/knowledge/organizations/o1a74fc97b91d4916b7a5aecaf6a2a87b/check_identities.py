# -*- coding: utf-8 -*-
"""조직화 세션 s57f6f77080594a34958b2ef419135a9e의 대조 스크립트.

이 조직화가 색인과 areas-r64의 글에 옮겨 적은 식과 좌표의 대응을 작은 경우에서 정확한 유리수로
대조한다. 크기는 모두 30 이하이고(둘째 상시 조건: 논증의 특정한 걸음을 작은 예에서 확인하는 계산),
어느 정리의 근거도 아니다. 표는 마지막 차 재귀로 만들고, 소인 주차함수의 수는 1-1/A의 계수로 만든다.

실행: python check_identities.py  (몇 초; 실패가 있으면 종료 코드 1)
"""
import io
import sys
from fractions import Fraction as Fr
from itertools import combinations
from math import comb, factorial, gamma, pi, sqrt, e, log

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
NMAX = 30
FAILS = []


def report(tag, ok, scope):
    print(('PASS ' if ok else 'FAIL ') + tag + ' | ' + scope)
    if not ok:
        FAILS.append(tag)


# ---------------------------------------------------------------- tables
def table_A(nmax):
    """A[k][n] = 최대 변위가 k 이하인 길이 n의 주차함수의 수 (마지막 차 재귀)."""
    A = {}
    for k in range(0, nmax + 2):
        col = [1]
        for n in range(nmax):
            col.append(sum(min(j + 1, k + 1) * comb(n, j) * col[j] * col[n - j] for j in range(n + 1)))
        A[k] = col
    return A


A = table_A(NMAX)


def Acnt(n, k):
    if k < 0:
        return 0
    return A[min(k, NMAX + 1)][n]


def p(n):
    return Fr(n + 1) ** (n - 1) if n >= 1 else Fr(1)


def b(n, l):
    return Acnt(n, l) - Acnt(n, l - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


def F(n, l):
    return Fr(Acnt(n, l)) / p(n)


def prime_counts(c, mmax):
    """C[m] = 모든 변위가 c보다 작은 길이 m의 소인 주차함수의 수 (1-1/A_{c-1}의 계수)."""
    a = [Fr(Acnt(n, c - 1), factorial(n)) for n in range(mmax + 1)]
    inv = [Fr(1)]
    for n in range(1, mmax + 1):
        inv.append(-sum(a[j] * inv[n - j] for j in range(1, n + 1)))
    out = [0]
    for m in range(1, mmax + 1):
        val = -inv[m] * factorial(m)
        assert val.denominator == 1
        out.append(int(val))
    return out


PC = {c: prime_counts(c, NMAX) for c in range(0, 16)}


def C(m, c):
    if c <= 0:
        return 0
    return PC[min(c, 15)][m] if c <= 15 else None


def P(m):
    return 1 if m == 1 else (m - 1) ** (m - 1)


def psi(m):
    return Fr(m + 1, m) ** (m - 1) if m >= 1 else Fr(1)


def ehat(m):
    return Fr(m + 1, m) ** m if m >= 1 else Fr(1)


# sanity: free values and row sums
ok = all(C(m, c) == P(m) for c in range(1, 12) for m in range(1, c + 1))
ok &= all(sum(b(n, l) for l in range(n)) == (n + 1) ** (n - 1) for n in range(1, 13))
ok &= [b(7, l) for l in range(7)] == [5040, 42253, 62145, 57398, 46142, 32359, 16807]
report('0 표와 소인 수의 바탕', ok, 'm≤c≤11에서 C_{m,c}=(m−1)^{m−1}; n≤12의 행의 합; n=7의 행')

# ---------------------------------------------------------------- 1. 전이 비의 좌표, (E½)와 (LE)
ok = True
cells_E = set()
cells_LE = set()
for n in range(3, NMAX + 1):
    for K in range(1, n - 1):                      # K≥1, n≥K+2
        cells_E.add((n, K))
        num = F(n, K) - F(n - 1, K - 1)            # 머무름 흐름 Δ_n(K)
        cell = F(n - 1, K) - F(n - 1, K - 1)       # Pr(M_{n−1}=K)
        ehalf = num / cell >= Fr(n - K, 2 * n)
        # 전역 좌표: N=n, r=n−1−K, n′=N−1, k=n′−r
        N, r = n, n - 1 - K
        n1, k = N - 1, (N - 1) - r
        q_glob = (F(n1 + 1, k) - F(n1, k - 1)) / (F(n1, k) - F(n1, k - 1))
        ok &= (q_glob == num / cell) and (k == K)
        # (LE_{1/2}) 자리 (n′,y)=(n−1,K)
        y = K
        le = F(n1 + 1, y) - F(n1, y - 1) >= Fr(1, 2) * Fr(n1 + 1 - y, n1 + 1) * (F(n1, y) - F(n1, y - 1))
        ok &= (le == ehalf) and ehalf
for n1 in range(2, NMAX):
    for y in range(1, n1):                         # n′≥2, 1≤y≤n′−1
        cells_LE.add((n1 + 1, y))
ok &= cells_E == cells_LE
# K=0: Pr(M_n=0 | M_{n−1}=0) = (n/(n+1))^{n−1}; 1/2 아래로 내려가는 첫 n
first = next(n for n in range(2, 30) if F(n, 0) / F(n - 1, 0) < Fr(1, 2))
ok &= all(F(n, 0) / F(n - 1, 0) == Fr(n, n + 1) ** (n - 1) for n in range(2, 20)) and first == 5
report('1 머무름 흐름=전이 비의 분자, (E½)≡(LE)', ok,
       'n≤30: q_n(r)[r45979fd0]=q_N(r)[용어집] (N=n, r=n−1−K); 두 진술의 자리의 집합과 참값이 같다; '
       '그 범위에서 (E½)가 선다; 수준 0에서는 n=5부터 깨진다')

# ---------------------------------------------------------------- 2. Lean의 kap과 용어집의 κ_k(j)
def a_c(t):
    return Fr(t ** (t - 1), factorial(t)) if t >= 1 else Fr(0)


ok = True
sharp = True
for k in range(1, 8):
    J = 2 * k + 4
    S = [Fr(0)] + [a_c(t) if t <= k else Fr(0) for t in range(1, J + 1)]
    E = [Fr(1)] + [Fr(0)] * J                     # exp(S): E' = S'E
    for n in range(1, J + 1):
        E[n] = sum(j * S[j] * E[n - j] for j in range(1, n + 1)) / n
    for j in range(1, J + 1):
        glob = E[j - 1]                            # [z^j] z·e^{S_k(z)}
        kap = a_c(j) - sum(a_c(i) * a_c(j - i) for i in range(k + 1, j))
        if j <= 2 * k + 2:
            ok &= glob == kap
        elif j == 2 * k + 3:
            sharp &= glob != kap
report('2 kap k t = κ_k(t)', ok and sharp, 'k≤7: t≤2k+2에서 같고 t=2k+3에서 다르다')

# ---------------------------------------------------------------- 3. 첫 소인 토막의 법칙과 결합의 정리
ok = True
for n in range(2, 15):
    kap_n = {s: Fr(comb(n, s) * P(s)) * p(n - s) / p(n) for s in range(1, n + 1)}
    kap_m = {s: Fr(comb(n - 1, s) * P(s)) * p(n - 1 - s) / p(n - 1) for s in range(1, n)}
    ok &= sum(kap_n.values()) == 1
    for s in range(1, n):
        g = Fr(P(s + 1), factorial(s + 1)) / Fr(P(s), factorial(s))
        ok &= kap_n[s] / kap_m[s] == psi(n - s) / psi(n) <= 1
        ok &= kap_n[s + 1] / kap_m[s] == g / psi(n) < 1
for L in range(2, 15):
    rho = lambda LL, s: Fr(comb(LL - 1, s) * s * P(s)) * p(LL - 1 - s) / P(LL)
    ok &= sum(rho(L, s) for s in range(1, L)) == 1
    for s in range(1, L):
        ok &= rho(L + 1, s + 1) / rho(L, s) == ehat(s - 1) / ehat(L - 1) < 1
        ok &= rho(L + 1, s) / rho(L, s) == psi(L - s) / ehat(L - 1) <= Fr(L - 1, L)
report('3a 법칙 ϰ_n, ρ_L의 합과 이웃비', ok, 'n, L≤14')


def Njoint(n, l, r):
    return sum(comb(n, s) * C(s, l + 1) * Acnt(n - s, l) for s in range(r, n + 1))


ok = all(Njoint(n, l, 1) == Acnt(n, l) for n in range(1, 13) for l in range(0, 12))
for n in range(2, 13):
    for l in range(0, 12):
        for r in range(1, n + 1):
            ok &= Fr(Njoint(n, l + 1, r)) / p(n) >= Fr(Njoint(n - 1, l, r)) / p(n - 1)
v1 = Fr(Njoint(3, 2, 2)) / p(3) <= Fr(Njoint(2, 2, 2)) / p(2)           # 변형 1, (3,2,2)
v2 = Fr(Njoint(2, 1, 2)) / p(2) >= Fr(Njoint(1, 0, 1)) / p(1)           # 변형 2, (2,0,1)
report('3b 결합 단조성(정리 18)과 거짓인 두 변형', ok and (not v1) and (not v2),
       'n≤12, ℓ≤11, 모든 r; 변형은 (3,2,2), (2,0,1)에서 거짓')

ok = True
for c in range(1, 12):
    for m in range(1, 16):
        ok &= C(m + 1, c) * P(m) <= C(m, c) * P(m + 1) <= C(m + 1, c + 1) * P(m)
eqs = []
for k in range(2, 11):
    for m in range(k + 1, 22):
        lhs = C(m, k + 1) - C(m, k)
        rhs = psi(k) * (m - 1) * (C(m - 1, k) - C(m - 1, k - 1))
        ok &= lhs >= rhs
        if lhs == rhs:
            eqs.append((k, m))
        ok &= lhs >= Fr(k + 1, k) ** (k - 2) * m * (C(m - 1, k) - C(m - 1, k - 1))   # (PDg)
ok &= eqs == [(k, k + 1) for k in range(2, 11)]
for k in range(2, 11):                               # 따름 23: s≥k+2에서 참, s=k+1에서 거짓
    ok &= all(C(s, k + 1) > psi(k) * s * C(s - 1, k) for s in range(k + 2, 22))
    ok &= not (C(k + 1, k + 1) > psi(k) * (k + 1) * C(k, k))
report('3c 정리 16, 정리 20 (PDg⁺), (PDg), 따름 23', ok, 'c≤11, m≤15; 2≤k≤10, m≤21; 등호는 m=k+1뿐')

ok = True
for n in range(3, NMAX + 1):                         # (8.5)
    for K in range(1, n - 1):
        ok &= Acnt(n, K) >= p(n) / p(n - 1) * Acnt(n - 1, K - 1) + Fr(n - 1 - K, n - 1) * Acnt(n - 1, K)
report('3d 정량 꼴 (8.5)', ok, 'K≥1, K+2≤n≤30')

# ---------------------------------------------------------------- 4. 한 사슬 보조정리에서 나오는 열의 식
ok = True
for k in range(2, 11):
    for n in range(k + 1, 2 * k):
        delta = lambda t: -k ** (k - 2) if t == k else (k + 1) * b(t - 1, k) - (k - 1) * b(t - 1, k - 1)
        ok &= d(n, k) == sum(comb(n, t) * int(p(n - t)) * delta(t) for t in range(k, n + 1))
        ok &= d(n, k) == (k + 1) * d(n - 1, k) + 2 * b(n - 1, k - 1) + sum(
            comb(n, m) * P(m) * d(n - m, k) for m in range(1, n - k + 1))
for l in range(1, 11):
    for n in range(l + 1, 2 * l + 2):
        ok &= b(n, l) == Acnt(n - 1, l) + l * b(n - 1, l) + sum(
            comb(n, m) * P(m) * b(n - m, l) for m in range(1, n - l))
for k in range(2, 12):
    for n in range(k + 1, 2 * k + 1):
        ok &= b(n, k) >= Fr(k + 1, k) ** (k - 2) * n * b(n - 1, k - 1)
report('4 앞쪽 꼴, 열 방정식, 수준 0의 열 방정식, 대각 아래 한계 (Lean의 범위)', ok,
       '2≤k≤10, k+1≤n≤2k−1; 1≤l≤10, l+1≤n≤2l+1; 2≤k≤11, k+1≤n≤2k')

# ---------------------------------------------------------------- 5. 임계 기울임의 기저 둘레의 항등식 (r5016e7b5)
ok = True
for k in range(2, 9):
    x = Fr(k, k + 1) ** (k - 1)
    T = 3 * k + 2
    n_ = lambda c, t: Fr(min(t, c) * Acnt(t - 1, c - 1)) * x ** t / factorial(t)
    xi = lambda t: n_(k + 1, t) - 2 * n_(k, t) + n_(k - 1, t)
    iota = Fr(k ** (k - 2)) * x ** k / factorial(k)
    Jt = lambda t: iota if t == k else 2 * n_(k, t) - n_(k - 1, t) - n_(k - 1, t - 1)
    DCT = lambda t: n_(k + 1, t + 1) - 2 * n_(k, t) + n_(k - 1, t - 1)
    yt = lambda t, l: n_(l + 1, t) - n_(l, t)
    Dbr = lambda s: yt(s + 1, k) - yt(s, k - 1)
    Dl = lambda X: n_(k, X) - n_(k - 1, X - 1)
    B = lambda X: sum(xi(s) for s in range(k, X + 1))
    Cacc = lambda X: sum(DCT(t) for t in range(k + 1, X))
    ok &= xi(k) == -iota and xi(k + 1) == Jt(k) - Jt(k + 1)
    ok &= all(xi(t) == DCT(t - 1) + Jt(t - 1) - Jt(t) for t in range(k + 2, T))
    ok &= all(B(X) == Cacc(X) - Jt(X) for X in range(k + 1, T))
    ok &= Dbr(k) == -iota / (k + 1)
    ok &= all(Dbr(s) == DCT(s) + Dl(s) - Dl(s + 1) for s in range(k + 1, 2 * k + 1))
    Tk = sum(Dbr(s) for s in range(k, 2 * k + 1))
    ok &= Tk == Cacc(2 * k + 1) - Dl(2 * k + 1) == B(2 * k + 1) + yt(2 * k + 1, k - 1)
    # 명제 8: 𝔪(T)=𝖤(T)−Σ DC^T, 𝖩(T)=𝖤(T)−DC^T(T)
    Ebd = lambda t: n_(k + 1, t + 1) - n_(k - 1, t)
    ok &= all(-B(t) == Ebd(t) - sum(DCT(u) for u in range(k + 1, t + 1)) and Jt(t) == Ebd(t) - DCT(t)
              for t in range(k + 1, T - 1))
report('5a (S), 재배열 B=C−𝖩, 명제 8, 보조정리 23 (가), 𝖳(k)의 두 식', ok, '2≤k≤8, 크기 3k+1까지')

ok = True
for k in range(2, 8):                               # 보조정리 26
    for x in (Fr(1, 3), Fr(2, 5)):
        qm = lambda m: Fr(C(m, k + 1) - 2 * C(m, k) + C(m, k - 1), factorial(m))
        xi0 = lambda t: Fr((min(t, k + 1) * Acnt(t - 1, k) - 2 * min(t, k) * Acnt(t - 1, k - 1)
                            + min(t, k - 1) * Acnt(t - 1, k - 2)), factorial(t))
        V = lambda N: 1 - sum(Fr(P(j), factorial(j)) * x ** j for j in range(1, N + 1))
        lhs = sum(qm(m) * x ** m for m in range(k, 2 * k + 1))
        rhs = sum(xi0(t) * x ** t * V(2 * k - t) for t in range(k, 2 * k + 1))
        corr = Fr(1, 2) * (Fr(k ** (k - 2), factorial(k)) * x ** k) ** 2
        ok &= lhs == rhs - corr and (corr != 0)
        lhs1 = sum(qm(m) * x ** m for m in range(k, 2 * k))
        rhs1 = sum(xi0(t) * x ** t * V(2 * k - 1 - t) for t in range(k, 2 * k))
        ok &= lhs1 == rhs1                           # 크기 2k−1까지는 보정항 없이
report('5b 나무–소인 관계를 크기 2k까지 늘인 식(보조정리 26)', ok, '2≤k≤7, x=1/3, 2/5; 2k−1까지는 보정항 없이 같다')

# ---------------------------------------------------------------- 6. (CB) 둘레의 식 (r26ac4ba8, rdd38d98)
ok = True
for k in range(3, 9):
    x = Fr(k, k + 1) ** (k - 1)
    M = 3 * k
    kap = lambda m: Fr(C(m, k)) * x ** m / factorial(m)
    kam = lambda m: Fr(C(m, k - 1)) * x ** m / factorial(m)
    chi = lambda m: kap(m) - kam(m)
    W = lambda g: Fr(g ** (g - 1)) * x ** g / factorial(g)
    u = lambda N: Fr(Acnt(N, k - 1)) * x ** N / factorial(N)
    um = lambda N: Fr(Acnt(N, k - 2)) * x ** N / factorial(N)
    Up = lambda N: Fr(b(N, k - 1)) * x ** N / factorial(N)
    Epr = lambda L: sum(u(i) * um(L - i) for i in range(L + 1))
    ok &= chi(k) == W(k) / k and chi(k + 1) == chi(k) * (1 - (1 + 2 * x) / (k + 1))
    ok &= all(N * kap(N) <= (N - 1) * kap(N - 1) for N in range(k + 1, M))
    ok &= all(kap(L) <= kap(k) * k / L for L in range(k, M))
    ok &= all(N * chi(N) <= (N - 1 + (k - 2) * x) * chi(N - 1) for N in range(k + 1, M))
    ok &= all(Epr(L) == 2 * Fr((L + 2) ** (L - 1)) * x ** L / factorial(L) if L >= 1 else Epr(L) == 1
              for L in range(0, k))
    ok &= Epr(k - 1) == Fr(k * k, k * k - 1) * Epr(k - 2)
    ok &= Epr(k) == 2 * Fr((k + 2) ** (k - 1)) * x ** k / factorial(k) - W(k) / k
    ok &= all(Up(n) == sum(Epr(n - N) * chi(N) for N in range(k, n + 1)) for n in range(k, M))
    for N in range(0, 2 * k):                        # (10.2)
        dd = lambda i: u(i) - u(i + 1)
        dm = lambda i: um(i) - um(i + 1)
        rhs = u(N + 1) + sum((i + 1) * dd(i) * um(N - i) for i in range(N + 1)) + sum(
            i * dm(i) * u(N - i) for i in range(1, N + 1))
        ok &= (N + 1) * Epr(N) - N * Epr(N + 1) == rhs
report('6 소인 셀의 열, 조화 한계, 한 걸음 성장 한계, 곱 핵의 닫힌 값과 (10.2)', ok, '3≤k≤8, 크기 3k 미만')

# ---------------------------------------------------------------- 7. 빚의 기울임 바꿈 (r45979fd0 명제 1)
ok = True
for k in (3, 4, 5):
    y, rho = Fr(1, 3), Fr(1, 2)
    x = rho * y
    h = lambda t, n: -sum(t ** i * Fr(d(i, k), factorial(i)) for i in range(k, n + 1))
    ok &= all(h(x, n) == rho ** n * h(y, n) + (1 - rho) * sum(rho ** j * h(y, j) for j in range(k, n))
              for n in range(k, 20))
report('7 빚의 기울임 바꿈 항등식', ok, 'k=3, 4, 5; y=1/3, ρ=1/2; n<20')

# ---------------------------------------------------------------- 8. 합성의 법칙: 행렬 항등식, 비, 식 (P)
ok = True
for m in range(2, 9):
    idx = range(m + 1)
    G = [[a_c(j - i) if j > i else Fr(0) for j in idx] for i in idx]
    mul = lambda X, Y: [[sum(X[i][l] * Y[l][j] for l in idx) for j in idx] for i in idx]
    dG = [[G[i][j] * (j - i) for j in idx] for i in idx]          # δG = GX − XG
    left, right = mul(dG, G), mul(G, dG)
    target = [[dG[i][j] - G[i][j] for j in idx] for i in idx]
    ok &= left == right == target
    Tq = {}
    Pw = [[Fr(int(i == j)) for j in idx] for i in idx]
    for q in range(1, m + 1):
        Pw = mul(Pw, G)
        Tq[q] = Pw[0][m]
    ok &= all(q * m * Tq[q + 1] == (q + 1) * (m - q) * Tq[q] for q in range(1, m))
report('8a (δG)G=G(δG)=δG−G와 T_{m,q}의 이웃비', ok, 'm≤8')

ok = True
for m in range(2, 8):
    for Nv in (Fr(2 * m - 1, 2), Fr(m), Fr(3 * m, 2)):           # N>m−1
        def Vq(q):                                               # 부분이 q개인 합성 (절단 q−1개)
            tot = Fr(0)
            for cuts in combinations(range(1, m), q - 1):
                pts = (0,) + cuts + (m,)
                w = Fr(1)
                for i in range(q):
                    w *= a_c(pts[i + 1] - pts[i])
                for s in cuts:
                    w /= (Nv - s)
                tot += w
            return tot
        for q in range(1, m):
            shat = Nv - (q + 1) * (m - q) * Vq(q) / (q * m * Vq(q + 1))
            acc = Fr(0)
            for cuts in combinations(range(1, m), q):
                pts = (0,) + cuts + (m,)
                w = Fr(1)
                for i in range(q + 1):
                    w *= a_c(pts[i + 1] - pts[i])
                for s in cuts:
                    w /= (Nv - s)
                for kk in range(q):
                    uk = pts[kk + 2] - pts[kk]
                    mid = Fr(pts[kk] + pts[kk + 2], 2)
                    xk = pts[kk + 1] - mid
                    acc += (kk + 1) * (q - kk) * w * uk * xk * xk / (Nv - mid)
            ok &= shat - Fr(m, 2) == acc / Vq(q + 1) / (q * m) and shat >= Fr(m, 2)
report('8b 가운데 인자의 견줌의 틈의 식 (P)', ok, 'm≤7, 모든 q, N=m−1/2, m, 3m/2')

# ---------------------------------------------------------------- 9. 넘김 비율의 극한 윤곽 (r1169863f)
Ren = lambda n: e ** (-n) * n ** n / factorial(n) if n >= 1 else 1.0
Bor = lambda i: Ren(i) / i
Nt = lambda t: sum(Ren(i - 1) / i for i in range(1, t + 1))
Rs = lambda s: sum(e - Nt(t) for t in range(0, s))
Pinf_ren = lambda s: sum(Ren(j) * Rs(s - j) for j in range(0, s))
Pinf = lambda s: e * s + sum((s - 1 - j) * (j / (j + 1)) * Ren(j) for j in range(1, s - 1))
ok = all(abs(Pinf(s) - Pinf_ren(s)) < 1e-9 for s in range(1, 25))
ok &= abs(Pinf(1) - e) < 1e-12 and abs(Pinf(2) - 2 * e) < 1e-12 and abs(Pinf(3) - (3 * e + 1 / (2 * e))) < 1e-12
ok &= abs(Pinf(4) - (4 * e + 1 / e + 4 / (3 * e * e))) < 1e-12
ok &= all(abs(Pinf(s + 1) - (Rs(s + 1) + sum(Bor(j) * Pinf(s + 1 - j) for j in range(1, s + 1)))) < 1e-9
          for s in range(1, 20))
c0 = 4 / (3 * sqrt(2 * pi))
ok &= all(e * s <= Pinf(s) + 1e-12 and Pinf(s) <= e * s + c0 * (s - 1) ** 1.5 + 1e-12 for s in range(1, 60))
report('9a P^∞_s의 닫힌 꼴, 갱신 꼴, 처음 값, 양쪽 한계', ok, 's<25 (한계는 s<60); 부동소수')

ok = True
for k in range(2, 13):
    for s in range(1, k + 1):
        if k + s > NMAX:
            continue
        Delta = 1 - Fr(C(k + s, k), P(k + s))
        val = float((k + s) * Delta)
        ok &= val <= Pinf(s) + 1e-12 and val / Pinf(s) >= 1 - 8 * s ** 1.5 / k - 1e-12
    ok &= 1 - Fr(C(k + 1, k), P(k + 1)) == Fr(k + 1, k) ** k / (k + 1)
report('9b 윤곽의 위쪽 덮개와 아래쪽 율, s=1의 닫힌 값', ok, '2≤k≤12, 1≤s≤k, k+s≤30')

# ---------------------------------------------------------------- 10. 옮겨 적은 상수
cs = 2 * 3 ** (1 / 3) * gamma(4 / 3)
cJ = 3 * e ** 1.5 / (2 * sqrt(2 * pi))
c2 = -3.3316
EY = 1.5 ** (1 / 3) * gamma(5 / 3) * gamma(1 / 6) * gamma(2 / 3) / (gamma(5 / 6) * gamma(1 / 3))
checks = [
    (cs, 2.57579, 1e-5), (EY, cs, 1e-9), (23 / 18 * cs, 3.2913, 1e-4), (cJ, 2.6819, 1e-4),
    (cJ - c2, 6.0135, 1e-4), (cJ / 3 - c2, 4.2256, 1e-4), (23 / 18 * cs / e, 1.2108, 1e-4),
    ((cJ - c2) / e - e ** 0.5 / sqrt(2 * pi), 1.5545, 1e-4), (4 * cs / sqrt(pi), 5.81295, 1e-5),
    (4 / sqrt(pi), 2.2568, 1e-4), (2 / sqrt(pi), 1.1284, 1e-4), (2 * e ** 1.5 / sqrt(2 * pi), 3.5758, 1e-4),
    (2 * e ** 1.5 / sqrt(2 * pi), 4 / 3 * cJ, 1e-12), (e ** 1.5 / (2 * sqrt(2 * pi)), 0.8940, 1e-4),
    (c0, 0.53192, 1e-5), (1 / (e * log(2)), 0.5307, 1e-4), (sqrt(2 / pi) * (-1.17559 - 3), c2, 1e-4),
    (-3 * sqrt(2 / pi), -2.3937, 1e-4), (sqrt(2 / pi) * -1.17559, -0.9380, 1e-4),
]
ok = all(abs(v - w) < tol for v, w, tol in checks)
ok &= 1.1e19 < (50.02 / 0.0335) ** 6 < 1.2e19 and 2 * 159 * 160 == 50880
kz = ((cJ - c2) / (23 / 18 * cs)) ** 6            # 두 항의 식 3.2913k^{-1/3}−6.0135k^{-1/2}의 영점
ok &= 36 < kz < 38
report('10 옮겨 적은 상수', ok,
       'c_*, E[Y]의 곱 꼴, (23/18)c_*, c_𝖩, c_𝖩−c_2, c_𝖩/3−c_2, 1.2108, 1.5545, 5.81295, 4/√π, 2/√π, '
       '3.5758=(4/3)c_𝖩, 0.8940, c_0, 1/(e·log2), c_2의 두 몫, (50.02/0.0335)^6, 50880, 두 항의 식의 영점 k≈%.1f' % kz)

print()
print('실패: %d' % len(FAILS) + ('' if not FAILS else ' -> ' + '; '.join(FAILS)))
sys.exit(1 if FAILS else 0)
