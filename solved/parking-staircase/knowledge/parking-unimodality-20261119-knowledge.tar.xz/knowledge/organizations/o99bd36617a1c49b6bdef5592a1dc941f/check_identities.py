# -*- coding: utf-8 -*-
"""셋째 조직화가 용어를 묶거나 대응을 적기 전에 확인한 등식들.

연구의 증거로 쓰려는 계산이 아니다. 용어집의 병합과 모듈 설명의 사전이
가리키는 「같은 수」가 정의를 맞대었을 때 실제로 같은 수인지를 작은 크기에서
정확한 정수와 유리수로 대조한다. 누적 개수 A_{n,k}는 마지막 차 재귀로 구하고,
뿌리 파일의 표(n=4, 7)와 대조한 뒤에 쓴다.

확인하는 것
 (1) 나무 행: 조직화 출력의 y_{t,l} = tau_{t,l} - tau_{t,l-1} 이
     re61cc9dab…의 b^T_{n,k}, r43fbfedf…의 beta^{(t)}_l, r535d20f…의 나무 셀과 같은 수.
 (2) 표준 수열과 정준 핵: 같은 수열에서 g(gamma) = rho_{gamma-1}.
 (3) 얼린 다항식: K_{n,k}(k)=Z_n(k), K_{n,k}(k+1)=Z_n(k+1), d = C_- - B_-,
     교차곱의 두 꼴, 그리고 re6ac5d71…의 C_{n,k}, E_{n,k}가 같은 식이라는 것.
 (4) 손실: L_{n,k} = Z_n'(k-) - Z_n'(k+) = G_k(k) 이고 B_- <= L, d = V - L 의 V >= C_-.
 (5) 교차 행 q_0(k) 와 re61cc9dab…의 n*(k) 가 표의 범위에서 같은 수(영인 차분이 없다).
 (6) 대각 괄호와 열 괄호의 합이 한 칸 차분이라는 것, 기울인 기저와 (Base)의 관계 (4.10).
"""
from fractions import Fraction as Fr
from math import comb, factorial

NMAX = 16


def cumulative(nmax):
    """A[n][k] = #{alpha in PF_n : M(alpha) <= k}, 0 <= k <= nmax (A[0][k] = 1)."""
    A = [[0] * (nmax + 2) for _ in range(nmax + 1)]
    for k in range(nmax + 2):
        A[0][k] = 1
    for n in range(1, nmax + 1):
        for k in range(nmax + 2):
            A[n][k] = sum(comb(n - 1, j) * min(j + 1, k + 1) * A[j][k] * A[n - 1 - j][k]
                          for j in range(n))
    return A


A = cumulative(NMAX)


def Acum(n, k):
    if n == 0:
        return 1
    if k < 0:
        return 0
    return A[n][min(k, NMAX + 1)]


def b(n, l):
    return Acum(n, l) - Acum(n, l - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


# 뿌리 파일의 확인용 값
assert [b(4, l) for l in range(4)] == [24, 51, 34, 16]
assert [b(7, l) for l in range(7)] == [5040, 42253, 62145, 57398, 46142, 32359, 16807]
for n in range(1, NMAX + 1):
    assert sum(b(n, l) for l in range(n)) == (n + 1) ** (n - 1)

# (1) 나무 행 -----------------------------------------------------------------

def tau(t, k):
    return 0 if k < 0 else min(t, k + 1) * Acum(t - 1, k)


def y(t, l):
    return tau(t, l) - tau(t, l - 1)


for t in range(1, NMAX + 1):
    assert sum(y(t, l) for l in range(t)) == t ** (t - 1)
    for l in range(0, NMAX + 1):
        bT = min(t, l + 1) * Acum(t - 1, l) - min(t, l) * Acum(t - 1, l - 1)   # re61cc9dab…
        assert y(t, l) == bT
        if l <= t - 1:
            beta = (l + 1) * Acum(t - 1, l) - l * Acum(t - 1, l - 1)           # r43fbfedf…
            assert y(t, l) == beta
        cell = 0 if t <= l else (l + 1) * b(t - 1, l) + Acum(t - 1, l - 1)     # r535d20f…
        assert y(t, l) == cell
        if l >= t:
            assert y(t, l) == 0
print("(1) 나무 행: 네 정의가 t <=", NMAX, "에서 같은 수")

# (2) 표준 수열과 정준 핵 ---------------------------------------------------------

def canonical_kernel(p):
    """d*p_d = sum_{gamma=1}^{d} g(gamma) p_{d-gamma}, 1 <= d <= D."""
    g = [None]
    for dd in range(1, len(p)):
        s = sum(g[c] * p[dd - c] for c in range(1, dd))
        g.append((Fr(dd) * p[dd] - s) / p[0])
    return g


def standard_sequence(s):
    """(j+1) s_{j+1} = sum_{i=0}^{j} rho_i s_{j-i}, j >= 0."""
    rho = []
    for j in range(len(s) - 1):
        acc = sum(rho[i] * s[j - i] for i in range(j))
        rho.append((Fr(j + 1) * s[j + 1] - acc) / s[0])
    return rho


for n in range(4, NMAX + 1):
    D = n // 2
    p = [Fr(b(n, n - 1 - dd)) for dd in range(D + 1)]
    g = canonical_kernel(p)
    rho = standard_sequence(p)
    assert all(g[c] == rho[c - 1] for c in range(1, D + 1))
    if n >= 3:
        assert g[1] == 1 + 2 * Fr(n - 1, n) ** (n - 2)
print("(2) 정준 핵 g(gamma) = 표준 수열 rho_{gamma-1}, 행 n <=", NMAX)

# (3) 얼린 다항식 ---------------------------------------------------------------
# 다항식은 계수 목록(낮은 차수부터)으로 적는다.

def padd(a, c):
    m = max(len(a), len(c))
    return [(a[i] if i < len(a) else 0) + (c[i] if i < len(c) else 0) for i in range(m)]


def pmul(a, c):
    r = [Fr(0)] * (len(a) + len(c) - 1)
    for i, x in enumerate(a):
        if x:
            for j, z in enumerate(c):
                r[i + j] += x * z
    return r


def pscale(a, s):
    return [x * s for x in a]


def peval(a, x):
    r = Fr(0)
    for c in reversed(a):
        r = r * x + c
    return r


def pder(a):
    return [a[i] * i for i in range(1, len(a))] or [Fr(0)]


def frozen(nmax, k):
    """K_{n,k}(y) = sum_F prod_{t_v>k} y/t_v, n <= nmax, 가중 재귀로."""
    Z = [[Fr(1)]]
    for n in range(1, nmax + 1):
        acc = [Fr(0)]
        for j in range(n):
            t = j + 1
            w = [Fr(1)] if t <= k else [Fr(0), Fr(1, t)]
            term = pscale(pmul(pmul(w, Z[j]), Z[n - 1 - j]), comb(n - 1, j) * t)
            acc = padd(acc, term)
        Z.append(acc)
    return Z


def Zthr(n, j):
    """Z_n(j) = A_{n,j-1}: 모든 변위가 j보다 작은 길이 n의 주차함수의 수."""
    return Acum(n, j - 1) if j >= 1 else (1 if n == 0 else 0)


NK = 12
Kpoly = {k: frozen(NK, k) for k in range(0, NK + 1)}
count = 0
for n in range(3, NK + 1):
    for k in range(1, n - 1):
        K = Kpoly[k][n]
        assert all(c >= 0 for c in K)
        assert peval(K, k) == Zthr(n, k) and peval(K, k + 1) == Zthr(n, k + 1)
        Cm = peval(K, k + 1) - 2 * peval(K, k) + peval(K, k - 1)
        Cp = peval(K, k + 2) - 2 * peval(K, k + 1) + peval(K, k)
        Bm = peval(K, k - 1) - Zthr(n, k - 1)
        Bp = peval(K, k + 2) - Zthr(n, k + 2)
        assert d(n, k) == Cm - Bm and d(n, k + 1) == Cp - Bp
        assert Bm > 0 and Bp > 0 and Cp >= Cm >= 0
        S = Bp * Cm - Bm * Cp
        assert S == Bp * d(n, k) - Bm * d(n, k + 1) == Cp * d(n, k) - Cm * d(n, k + 1)
        assert S > 0
        # (4) 손실과 매듭 다항식: K_{n,k-1}(y) - K_{n,k}(y) = (y-k) G_k(y), L = G_k(k)
        Kprev = Kpoly[k - 1][n]
        L = peval(pder(Kprev), k) - peval(pder(K), k)       # Z_n'(k-) - Z_n'(k+)
        diff = padd(Kprev, pscale(K, -1))
        assert peval(diff, k) == 0
        assert L > 0 and Bm <= L
        V = d(n, k) + L
        assert V >= Cm
        count += 1
assert (peval(Kpoly[3][5], 4) - 2 * peval(Kpoly[3][5], 3) + peval(Kpoly[3][5], 2)) == 32
print("(3)(4) 얼린 다항식의 분해, 교차곱의 두 꼴과 양성, B_- <= L, V >= C_-:", count, "자리 (n <=", NK, ")")

# (5) 교차 행 -----------------------------------------------------------------
zeros = [(n, k) for n in range(2, NMAX + 1) for k in range(1, n) if d(n, k) == 0]
assert not zeros
for k in range(1, 8):
    q0 = next(n for n in range(k + 1, NMAX + 1) if d(n, k) > 0)
    nstar = next(n for n in range(k + 1, NMAX + 1) if d(n, k) >= 0)
    assert q0 == nstar
assert [next(n for n in range(k + 1, NMAX + 1) if d(n, k) > 0) for k in range(1, 8)] == [3, 6, 8, 10, 12, 13, 15]
print("(5) 영인 차분 없음(n <=", NMAX, "), q_0(k) = n*(k) = 3,6,8,10,12,13,15 (k=1..7)")

# (6) 두 괄호와 (4.10) --------------------------------------------------------
for k in range(2, 8):
    r = Fr(k + 1, k) ** (k - 1)          # 임계 성장비 = lambda_k = 1/x_k
    x = 1 / r
    for n in range(k + 1, NMAX + 1):
        DB = b(n, k) - r * n * b(n - 1, k - 1)
        CB = r * n * b(n - 1, k - 1) - b(n, k - 1)
        assert DB + CB == d(n, k)
        cr = Fr(k + 1, k) ** (k - 2)
        assert b(n, k) >= cr * n * b(n - 1, k - 1)      # 대각 아래 한계
    for n0 in range(k + 1, NMAX + 1):
        for i in range(k, n0 + 1):
            xi = sum(Fr(y(t, k) - y(t, k - 1), factorial(t)) * x ** t for t in range(i, n0 + 1))
            tausum = sum(Fr(1, factorial(m)) * (y(m, k) - r * m * y(m - 1, k - 1)) * x ** m
                         for m in range(i, n0 + 1))
            bT = lambda m: Fr(y(m, k - 1), factorial(m)) * x ** m
            assert xi == tausum + bT(i - 1) - bT(n0)
print("(6) d = 대각 괄호 + 열 괄호, 항등식 (4.10): k <= 7, n <=", NMAX)
print("모든 대조가 맞았다.")
