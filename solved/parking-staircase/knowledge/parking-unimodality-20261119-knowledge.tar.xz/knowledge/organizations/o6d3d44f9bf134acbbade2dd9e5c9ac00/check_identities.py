# -*- coding: utf-8 -*-
"""check_identities.py -- 조직화 세션 s4fb086456194433599697569c7a9a5b4의 대조 스크립트.

무엇을 하는가. 이 조직화가 용어 항목에 옮겨 적은 식과 범위를 작은 예에서 대조한다.
어느 정리의 근거도 아니다. 기록의 주장은 기록과 그 검토의 것이고, 여기서는 옮겨 적는
과정에서 정규화, 부호, 범위가 틀리지 않았는지만 본다. 주차함수의 수는 n<=30만 쓴다
(첫째 규칙의 기저).

  0번  도구의 자기 점검: 마지막 차 점화식으로 셈한 수를 n<=6에서 주차함수와 숲의
       전수 나열과 견준다.
  1번  「임계 창의 극한 함수들」 항목의 대수 관계(기호 계산).
  2번  「대각선 위의 닻과 윤곽, 넓이 법칙」 항목의 여섯 양과 세 부등식(정확한 유리수;
       2<=q<=8, n<=30).
  3번  전역으로 올린 항목 「성질 K의 기울임 꼴, 옮긴 판정, 여유」의 대조(그 항목이
       가리키는 스크립트가 그 조직화의 폴더에 없어 같은 대조를 여기 싣는다).

실행:  python check_identities.py   (Python 3.12, sympy 1.14, mpmath 1.3; 한 분 안팎)
출력은 check_identities.out.txt에 그대로 실었다.
"""
import itertools
import random
import sys
from fractions import Fraction
from functools import lru_cache
from math import comb, factorial

import mpmath as mp
import sympy as sp

FAIL = []


def report(label, ok, detail=''):
    print(('  [맞음] ' if ok else '  [어긋남] ') + label + (' -- ' + detail if detail else ''))
    if not ok:
        FAIL.append(label)


# ---------------------------------------------------------------------------
# 공통: 마지막 차 점화식
#   G_n = sum_{t=1..n} C(n-1,t-1) * w(t) * G_{t-1} * G_{n-t},  G_0 = 1
# 은 [n] 위의 뿌리 숲 F에 대한 합 sum_F prod_v (w(t_v)/t_v) * (정규화 없음)을 준다
# (t_v는 v의 부분나무 크기). w(t)=min(t,y)이면 Z_n(y), w(t)=t (t<=k), y (t>k)이면
# 얼린 다항식 K_{n,k}(y)다(전역 용어 「얼린 다항식, 곡률항, 경계항, 교차곱」).
# ---------------------------------------------------------------------------
def weighted_count(n, w):
    G = [Fraction(1)]
    for m in range(1, n + 1):
        G.append(sum(comb(m - 1, t - 1) * w(t) * G[t - 1] * G[m - t] for t in range(1, m + 1)))
    return G


@lru_cache(maxsize=None)
def Z_table(y, nmax=30):
    """Z_n(y) (n=0..nmax): 모든 변위가 y보다 작은 주차함수의 수 (정수 y>=0)."""
    return tuple(weighted_count(nmax, lambda t: Fraction(min(t, y))))


@lru_cache(maxsize=None)
def K_table(k, y, nmax=30):
    """K_{n,k}(y) (n=0..nmax)."""
    return tuple(weighted_count(nmax, lambda t: Fraction(t) if t <= k else Fraction(y)))


def Z(n, y):
    return Z_table(y)[n]


def K(n, k, y):
    return K_table(k, y)[n]


def cell(n, j):
    """b_{n,j}: 최대 변위가 꼭 j인 길이 n의 주차함수의 수."""
    return Z(n, j + 1) - Z(n, j)


def diff(n, k):
    """d_{n,k} = b_{n,k} - b_{n,k-1}."""
    return cell(n, k) - cell(n, k - 1)


def B_minus(n, k):
    return K(n, k, k - 1) - Z(n, k - 1)


def C_minus(n, k):
    return K(n, k, k + 1) - 2 * K(n, k, k) + K(n, k, k - 1)


def borel(m):
    """Borel 수 beta_m = m^(m-1)/m!."""
    return Fraction(m ** (m - 1), factorial(m))


# ---------------------------------------------------------------------------
print('0번. 도구의 자기 점검 (n<=6의 전수 나열)')
# ---------------------------------------------------------------------------
def park_max_disp(pref):
    n = len(pref)
    occ = [False] * n
    worst = 0
    for p in pref:
        q = p
        while q < n and occ[q]:
            q += 1
        if q == n:
            return None
        occ[q] = True
        worst = max(worst, q - p)
    return worst


ok = True
for n in range(1, 7):
    cnt = [0] * n
    for pref in itertools.product(range(n), repeat=n):
        m = park_max_disp(pref)
        if m is not None:
            cnt[m] += 1
    if sum(cnt) != (n + 1) ** (n - 1):
        ok = False
    for y in range(0, n + 2):
        if Z(n, y) != sum(cnt[:y]):
            ok = False
report('주차 과정의 전수 나열과 점화식: Z_n(y) = #{모든 변위 < y} (1<=n<=6, 0<=y<=n+1)', ok)


def forests(n):
    """[n] 위의 뿌리 숲 전부: 부모 함수 p: [n] -> {0..n} (0은 가상의 뿌리) 가운데 순환이 없는 것."""
    for par in itertools.product(range(n + 1), repeat=n):
        good = True
        for v in range(1, n + 1):
            seen = 0
            u = v
            while u != 0:
                u = par[u - 1]
                seen += 1
                if seen > n:
                    good = False
                    break
            if not good:
                break
        if good:
            yield par


def subtree_sizes(par):
    n = len(par)
    size = [1] * (n + 1)
    for v in range(1, n + 1):
        u = par[v - 1]
        while u != 0:
            size[u] += 1
            u = par[u - 1]
    return size[1:]


ok_Z = ok_K = ok_d = True
for n in range(1, 6):
    sizes = [subtree_sizes(par) for par in forests(n)]
    if len(sizes) != (n + 1) ** (n - 1):
        ok_Z = False
    for y in range(1, n + 2):
        tot = sum((sp.prod([min(Fraction(1), Fraction(y, t)) for t in ts]) for ts in sizes), Fraction(0))
        if tot != Z(n, y):
            ok_Z = False
    for k in range(1, n):
        for y in (k - 1, k, k + 1, k + 2):
            tot = Fraction(0)
            for ts in sizes:
                term = Fraction(1)
                for t in ts:
                    if t > k:
                        term *= Fraction(y, t)
                tot += term
            if tot != K(n, k, y):
                ok_K = False
        if diff(n, k) != C_minus(n, k) - B_minus(n, k):
            ok_d = False
report('숲의 전수 나열과 점화식: Z_n(y) = sum_F prod_v min(1, y/t_v) (1<=n<=5)', ok_Z)
report('숲의 전수 나열과 점화식: K_{n,k}(y) = sum_F prod_{t_v>k} y/t_v (1<=k<n<=5, y=k-1..k+2)', ok_K)
ok = all(diff(n, k) == C_minus(n, k) - B_minus(n, k) for n in range(2, 31) for k in range(1, n))
report('d_{n,k} = C_-(n,k) - B_-(n,k) (1<=k<n<=30)', ok and ok_d)
ok = all(Z(n, n) == (n + 1) ** (n - 1) for n in range(1, 31))
report('Z_n(n) = (n+1)^(n-1) (n<=30)', ok)

# ---------------------------------------------------------------------------
print()
print('1번. 「임계 창의 극한 함수들」의 대수 관계 (기호 계산; S, beta_0, beta_1은 임의의 매끄러운 함수)')
# ---------------------------------------------------------------------------
z = sp.symbols('z', positive=True)
S = sp.Function('S')(z)
b0 = sp.Function('beta0')(z)
b1 = sp.Function('beta1')(z)
f = -sp.diff(S, z)
f1 = sp.diff(f, z)
f2 = sp.diff(f, z, 2)
# 사다리 m_j' = j*beta_{j-1} - m_{j+1} 에서
m1 = f
m2 = b0 - sp.diff(m1, z)
m3 = 2 * b1 - sp.diff(m2, z)


def is_zero(e):
    return sp.simplify(sp.expand(e)) == 0


report('m_2 = beta_0 - f\'', is_zero(m2 - (b0 - f1)))
report('m_3 = 2*beta_1 - beta_0\' + f\'\'', is_zero(m3 - (2 * b1 - sp.diff(b0, z) + f2)))
Sig1 = f1 ** 2 - f * f2 - b0 * f1
Sig2 = -(f2 * m1 + f1 * m2)
report('Sigma^SP: f\'^2 - f*f\'\' - beta_0*f\' = -(f\'\'*m_1 + f\'*m_2)', is_zero(Sig1 - Sig2))
W = f2 * m2 + f1 * m3
lamB = 2 * b1 / b0 - sp.diff(b0, z) / b0
report('W = f\'\'*m_2 + f\'*m_3 = beta_0*(f\'\' + lambda_B*f\'), lambda_B = 2*beta_1/beta_0 - beta_0\'/beta_0',
       is_zero(W - b0 * (f2 + lamB * f1)))
Yq = m3 * b0 - 2 * b1 * m2          # (Y):  Yq <= 0
Ypq = f2 * b0 + 2 * f1 * b1         # (Y'): f'<0 인 z에서 Ypq <= 0  (|f'| = -f')
report('(Y)의 양 m_3*beta_0 - 2*beta_1*m_2 = [f\'\'*beta_0 + 2*f\'*beta_1] - beta_0*beta_0\'',
       is_zero(Yq - (Ypq - b0 * sp.diff(b0, z))))
report('W = [f\'\'*beta_0 + 2*f\'*beta_1] - beta_0\'*f\'', is_zero(W - (Ypq - sp.diff(b0, z) * f1)))
print('       읽기: f\'<0, beta_0>0이고 beta_0\'<=0인 z에서, (Y)이면 대괄호 <= beta_0*beta_0\' <= 0, 곧 (Y\')이고,')
print('             (Y\')이면 W = 대괄호 - beta_0\'*f\' <= 0이다(beta_0\'*f\' >= 0). 두 함의 모두 beta_0\'<=0을 쓴다.')
nu = sp.Function('nu')(z)
h_dip = b1 + sp.diff(b0, z)
S_local = 4 * (sp.diff(b0, z) + b1) + 2 * nu      # 국소 항등식 S = 4(beta_0' + beta_1) + 2 nu
report('국소 항등식 아래 쌍극 응답 beta_1 + beta_0\' = S/4 - nu/2', is_zero(h_dip - (S_local / 4 - nu / 2)))
# 전역 항목 「극한 함수 theta와 Theta」와의 대응: S(z) = L(z^{3/2})
u = sp.symbols('u', positive=True)
Lf = sp.Function('L')
Su = Lf(z ** sp.Rational(3, 2))
fu = -sp.diff(Su, z)
theta = lambda uu: -uu * sp.diff(Lf(u), u).subs(u, uu) / Lf(uu)
Theta = lambda uu: -uu * sp.diff(Lf(u), u, 2).subs(u, uu) / sp.diff(Lf(u), u).subs(u, uu)
uu = z ** sp.Rational(3, 2)
e1 = sp.simplify((z * fu / Su - sp.Rational(3, 2) * theta(uu)).doit())
e2 = sp.simplify((z * sp.diff(fu, z) / fu - (1 - 3 * Theta(uu)) / 2).doit())
report('z*f/S = (3/2)*theta(z^{3/2})', e1 == 0)
report('z*f\'/f = (1 - 3*Theta(z^{3/2}))/2', e2 == 0)
# 눈금 방정식 S'' = (z^2/2) S' + (5z/4) S - (2 pi z)^{-1/2} 의 z->0 선두 차수:
# S = 1 - E[A] z^{3/2} + ... 이므로 -(3/4) E[A] = -(2 pi)^{-1/2}, 곧 E[A] = (4/3)(2 pi)^{-1/2}.
# 한편 E[A] = int_0^1 E[max_{s<=t} B_s] dt = int_0^1 sqrt(2t/pi) dt.
t = sp.symbols('t', positive=True)
EA = sp.integrate(sp.sqrt(2 * t / sp.pi), (t, 0, 1))
report('눈금 방정식의 z^{-1/2} 차수: E[A] = (4/3)(2 pi)^{-1/2} = int_0^1 sqrt(2t/pi) dt',
       sp.simplify(EA - sp.Rational(4, 3) / sp.sqrt(2 * sp.pi)) == 0, 'E[A] = %s' % sp.nsimplify(EA))

# ---------------------------------------------------------------------------
print()
print('2번. 대각선 위의 여섯 양과 세 부등식 (정확한 유리수; 2<=q<=8, n=k+q-1<=30)')
# ---------------------------------------------------------------------------
# F가 닻 s에서 음이 아닌 측도의 변환, 곧 F(k) = int e^{-b/(k-s)} mu(db) 이면 w=k-s로
#   (i)   F(w+1) >= F(w)
#   (ii)  2w F(w) <= (w+1) F(w+1) + (w-1) F(w-1)
#   (iii) F(w)^{2w} <= F(w+1)^{w+1} F(w-1)^{w-1}
# 이다. k에 달리지 않는 양의 상수(e^q 따위)는 세 부등식에서 지워진다.
NMAX = 30


def quantity(name, q, k, s):
    n = k + q - 1
    if name == 'surv':      # (beta_{k+q}/beta_k) Pr(M_n<k)
        return borel(k + q) / borel(k) * Z(n, k) / Fraction((n + 1) ** (n - 1))
    if name == 'viol':      # (k-s)(beta_{k+q}/beta_k) Pr(M_n>=k)
        return (k - s) * borel(k + q) / borel(k) * (1 - Z(n, k) / Fraction((n + 1) ** (n - 1)))
    if name == 'cell_k':    # (k-s) b_{n,k}/(n! beta_k)
        return (k - s) * cell(n, k) / (factorial(n) * borel(k))
    if name == 'cell_k-1':  # (k-s) b_{n,k-1}/(n! beta_k)
        return (k - s) * cell(n, k - 1) / (factorial(n) * borel(k))
    if name == 'block':     # (k-s) B_-(n,k)/(n! beta_k)
        return (k - s) * B_minus(n, k) / (factorial(n) * borel(k))
    if name == 'tie':       # (k-s)^2 C_-(n,k)/(n! beta_k)
        return (k - s) ** 2 * C_minus(n, k) / (factorial(n) * borel(k))
    raise ValueError(name)


def ratpow_le(a, ea, b, eb, c, ec):
    """a^ea <= b^eb * c^ec  (a,b,c 양의 유리수; 지수는 음이 아닌 유리수)."""
    den = 1
    for e in (ea, eb, ec):
        den = den * Fraction(e).denominator // sp.igcd(den, Fraction(e).denominator)
    ea, eb, ec = int(ea * den), int(eb * den), int(ec * den)
    return a ** ea <= b ** eb * c ** ec


def test(name, q, s, kmin):
    """정수 k>=kmin, k>s, n<=30에서 세 부등식을 본다. (본 부등식의 수, 어긋난 자리의 목록)을 돌려준다."""
    s = Fraction(s)
    ks = [k for k in range(max(kmin, 1), NMAX - q + 2) if k > s]
    Fv = {k: quantity(name, q, k, s) for k in ks}
    bad = []
    count = 0
    for k in ks:
        w = k - s
        if k + 1 in Fv:
            count += 1
            if not Fv[k + 1] >= Fv[k]:
                bad.append(('i', k))
        if k + 1 in Fv and k - 1 in Fv and Fv[k - 1] > 0 and Fv[k] > 0:
            count += 2
            if not 2 * w * Fv[k] <= (w + 1) * Fv[k + 1] + (w - 1) * Fv[k - 1]:
                bad.append(('ii', k))
            if not ratpow_le(Fv[k], 2 * w, Fv[k + 1], w + 1, Fv[k - 1], w - 1):
                bad.append(('iii', k))
    return count, bad


# 항목이 적은 닻의 범위와 k의 범위. 생존, 위반, 앞의 셀은 k>=max(1,q-2), 나머지는 k>=q (첫 층의 자리).
LOW = lambda q: max(1, q - 2)
FIRST = lambda q: q
SPEC = [
    ('surv',     '생존   (beta_{k+q}/beta_k)*Pr(M_n<k)',       lambda q: max(1, q - 2), 'max(1,q-2)', 'int',  LOW,   'k>=max(1,q-2)', 2),
    ('viol',     '위반   (k-s)*(beta_{k+q}/beta_k)*Pr(M_n>=k)', lambda q: 0,              '0',          'real', LOW,   'k>=max(1,q-2)', 2),
    ('cell_k',   '셀     (k-s)*b_{n,k}/(n!*beta_k)',           lambda q: max(1, q - 3), 'max(1,q-3)', 'int',  LOW,   'k>=max(1,q-2)', 2),
    ('cell_k-1', '셀     (k-s)*b_{n,k-1}/(n!*beta_k)',         lambda q: max(1, q - 3), 'max(1,q-3)', 'int',  FIRST, 'k>=q',          2),
    ('block',    '막힘   (k-s)*B_-(n,k)/(n!*beta_k)',          lambda q: 1,              '1',          'real', FIRST, 'k>=q',          2),
    ('tie',      '동률   (k-s)^2*C_-(n,k)/(n!*beta_k)',        lambda q: max(1, q - 4), 'max(1,q-4)', 'int',  FIRST, 'k>=q',          3),
]
for name, label, smin, smin_txt, kind, kmin, kmin_txt, qmin in SPEC:
    total = 0
    bad_all = []
    for q in range(qmin, 9):
        s0 = smin(q)
        anchors = [Fraction(s0), Fraction(s0 + 1), Fraction(s0 + 3)]
        if kind == 'real':
            anchors += [Fraction(2 * s0 + 1, 2), Fraction(2 * s0 + 5, 2)]
        for s in anchors:
            c, bad = test(name, q, s, kmin(q))
            total += c
            bad_all += [(q, str(s)) + b for b in bad]
    report('%s: 닻 s>=%s (%s), %s, q=%d..8' % (label, smin_txt, '정수' if kind == 'int' else '실수; 반정수도 봄', kmin_txt, qmin),
           not bad_all, '부등식 %d개' % total + ('' if not bad_all else '; 어긋난 곳 %s' % bad_all[:6]))

print('  참고(조건 밖의 닻; 항목의 범위가 필요한지 보는 것이고, 어긋남이 없어도 변환이라는 뜻은 아니다):')
for name, label, smin, smin_txt, kind, kmin, kmin_txt, qmin in SPEC:
    notes = []
    for q in range(qmin, 9):
        s0 = smin(q)
        lows = [s for s in ([Fraction(s0 - 1)] if kind == 'int' else [Fraction(2 * s0 - 1, 2)]) if s >= 0]
        if kind == 'int' and s0 - 1 > 1:
            lows.append(Fraction(1))
        for s in lows:
            c, bad = test(name, q, s, kmin(q))
            if bad:
                notes.append('q=%d, s=%s: %d곳' % (q, s, len(bad)))
    print('    %s: %s' % (label.split('  ')[0] + ' ' + name,
                          '; '.join(notes) if notes else '조건 밖의 닻에서도 이 범위에서는 어긋남이 없다'))
print('  참고(적힌 k의 범위 밖, 곧 모든 정수 k>s까지 넣으면):')
for name, label, smin, smin_txt, kind, kmin, kmin_txt, qmin in SPEC:
    notes = []
    for q in range(qmin, 9):
        c, bad = test(name, q, Fraction(smin(q)), 1)
        c0, bad0 = test(name, q, Fraction(smin(q)), kmin(q))
        if len(bad) > len(bad0):
            notes.append('q=%d: %d곳' % (q, len(bad) - len(bad0)))
    print('    %s: %s' % (label.split('  ')[0] + ' ' + name, '; '.join(notes) if notes else '어긋남이 없다'))

# 넓이 법칙의 전체 질량과 원자: F_surv(k)*e^{-q} -> 1 (k -> oo) 이어야 한다. n<=30 안에서는
# q=2에서 k=29까지의 값이 1 아래에서 늘어 가는지만 본다.
vals = [float(quantity('surv', 2, k, Fraction(1))) * float(mp.e ** -2) for k in (2, 5, 10, 20, 29)]
report('넓이 법칙의 정규화: e^{-q}*(beta_{k+q}/beta_k)*Pr(M_{k+q-1}<k) 가 1 아래에서 는다 (q=2; k=2,5,10,20,29)',
       all(0 < a < b < 1 for a, b in zip(vals, vals[1:])), ', '.join('%.4f' % v for v in vals))

# ---------------------------------------------------------------------------
print()
print('3번. 「성질 K의 기울임 꼴, 옮긴 판정, 여유」의 대조 (무작위의 양의 세 점 수열; 수치)')
# ---------------------------------------------------------------------------
mp.mp.dps = 30
rnd = random.Random(20261122)


def Lam(Wm, W0, Wp, y, beta):
    yb = mp.mpf(y) - beta
    return (yb + 1) * mp.log(Wp / (yb + 1)) + (yb - 1) * mp.log(Wm / (yb - 1)) - 2 * yb * mp.log(W0 / yb)


ok_form = ok_impl = ok_margin = True
n_pos = 0
worst = mp.mpf(1)
for trial in range(800):
    y = rnd.randint(2, 40)
    W0 = mp.mpf(rnd.uniform(0.5, 2.0))
    # 세 점이 거의 등비여야 판정이 설 때가 생긴다
    r = mp.mpf(rnd.uniform(0.8, 1.25))
    Wp = W0 * r * mp.mpf(1 + rnd.uniform(-0.02, 0.06))
    Wm = W0 / r * mp.mpf(1 + rnd.uniform(-0.02, 0.06))
    # (1) theta 꼴과 lambda 꼴: theta = (y^2-1) lambda, e^{y lambda}를 곱한다
    lam = mp.mpf(rnd.uniform(0, 3))
    th = (y * y - 1) * lam
    lhs_theta = Wp * mp.e ** (-th / (y + 1)) + Wm * mp.e ** (-th / (y - 1)) - 2 * W0 * mp.e ** (-th / y)
    lhs_lam = mp.e ** lam * Wp + mp.e ** (-lam) * Wm - 2 * mp.e ** (lam / y) * W0
    if abs(lhs_theta * mp.e ** (y * lam) - lhs_lam) > mp.mpf(10) ** (-25) * (1 + abs(lhs_lam)):
        ok_form = False
    # (2), (3): 옮긴 판정과 여유
    beta = mp.mpf(rnd.uniform(0, y - 1.001)) if rnd.random() < 0.7 else mp.mpf(0)
    mu = Lam(Wm, W0, Wp, y, beta)
    if mu >= 0:
        n_pos += 1
        eps = 2 * (mp.e ** (mu / (2 * (y - beta))) - 1)
        for i in range(0, 101):
            lam = mp.mpf(i) / 10      # lambda in [0, 10]
            g = mp.e ** lam * Wp + mp.e ** (-lam) * Wm
            base = mp.e ** (lam / y) * W0
            ratio = g / ((2 + eps) * base)
            worst = min(worst, ratio)
            if g < 2 * base * (1 - mp.mpf(10) ** (-30)):
                ok_impl = False
            if ratio < 1 - mp.mpf(10) ** (-30):
                ok_margin = False
report('(1) theta 꼴과 lambda 꼴이 같은 부등식이다 (theta=(y^2-1)*lambda; 800개의 점)', ok_form)
report('(2) 옮긴 판정 (K*_beta)가 서는 세 점에서 성질 K (lambda 격자 [0,10])', ok_impl, '판정이 선 표본 %d개' % n_pos)
report('(3) Lambda_{y-beta}[W] >= mu 이면 여유 2*(e^{mu/(2(y-beta))}-1)의 성질 K', ok_margin,
       '좌변/우변의 최솟값 %s' % mp.nstr(worst, 12))
# beta=0: 모든 실수 lambda에서 e^lam W(y+1) + e^{-lam} W(y-1) >= 2 e^{lam/y} W(y) e^{Xi/(2y)}, Xi = Lambda_y[W]
ok_xi = True
for trial in range(300):
    y = rnd.randint(2, 40)
    Wm, W0, Wp = (mp.mpf(rnd.uniform(0.2, 3.0)) for _ in range(3))
    xi = Lam(Wm, W0, Wp, y, mp.mpf(0))
    for i in range(-50, 51):
        lam = mp.mpf(i) / 5
        if mp.e ** lam * Wp + mp.e ** (-lam) * Wm < 2 * mp.e ** (lam / y) * W0 * mp.e ** (xi / (2 * y)) * (1 - mp.mpf(10) ** (-30)):
            ok_xi = False
report('beta=0: 모든 실수 lambda에서 e^lam*W(y+1)+e^{-lam}*W(y-1) >= 2*e^{lam/y}*W(y)*e^{Lambda_y[W]/(2y)} (부호 제한 없는 세 점)', ok_xi)

print()
if FAIL:
    print('어긋난 대조: %d개' % len(FAIL))
    for x in FAIL:
        print('  -', x)
    sys.exit(1)
print('모든 대조가 맞았다.')
