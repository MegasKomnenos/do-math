# -*- coding: utf-8 -*-
"""조직화 세션 s020525a0eef24f5e8aec94cf627eec09의 대조 스크립트.

이 스크립트는 이 조직화의 용어 항목과 영역 설명에 옮겨 적은 식이 기록의 정의와 같은 수를
주는지를 작은 예에서 확인한다. 주차함수의 수는 길이 n<=30만 쓴다(인수인계 문서의 규칙 1의 기저).
옮겨 적은 식의 대조이고, 어느 정리의 근거도 아니다.

  0. 도구의 자기 점검: 마지막 차 점화식으로 셈한 b_{n,l}을 뿌리 명제의 확인용 값(n<=7)과 견준다.
  1. 「셀의 대각 감소」(기록 r88013dc3...): 정의, r213dbe8...의 생존 질량과의 관계, 행 사이의 몫 Psi를
     대각 감소의 증분으로 적은 등식, 첫 층의 닫힌 식과 T_1, T_2의 꼴, 대각 감소의 열 방정식(명제 6.4),
     검토가 rb9e33ce7...에서 옮긴 상계. 그리고 조직화가 정의를 대입해 적은 대응: 전역 용어의 대각 비와
     대각 초과로 적은 꼴, 정리 Dg를 옮긴 위쪽 한계, r6af349eb...의 부등식 (G)와의 관계.
  2. 「생존 윤곽의 꼴과 k만의 가상의 열」(기록 r418c4ecc...): (S1)-(S3), 걸음의 식 (2.6),
     다섯 윤곽(입력이 0인 것, 흐름, Euler, 위쪽, 위험률)의 정의로 셈한 결손이 기록의 표와 같은지,
     비교 정리의 부등식, 교차 행의 끼움.
  3. 정리 QD(기록 r418c4ecc...)의 (가)와 따름 QD3, 행 k+2의 닫힌 식.
  4. 쌍-충격 판정(기록 reea223c..., rdc057f21...)의 두 쪽과 전역 용어 「첫 층의 응답 꼴」의 대응,
     보조정리 M의 정수 걸음, 둘째 적률의 등식.
  5. 무거운 사슬의 창의 법칙과 끝 조건 (E_L)(기록 ra9096d37...): 작은 N에서 법칙을 숲의 전수 나열과
     견주고, 격자 조건과 끝 조건이 같은 답을 주는지 본다.
  6. 어림 없는 교차곱 부등식 G*(기록 ra9096d37...)의 문턱 kappa*(r).

실행: python check_identities.py  (표준 라이브러리와 mpmath만 쓴다)
"""
import sys
from fractions import Fraction as Fr
from functools import lru_cache
from math import comb, factorial
from itertools import product

import mpmath as mp

mp.mp.dps = 60
NMAX = 30
OK = True


def report(label, cond, extra=''):
    global OK
    OK = OK and bool(cond)
    print(('  [맞음] ' if cond else '  [어긋남] ') + label + ((' — ' + extra) if extra else ''))


# ---------------------------------------------------------------------------
# 주차함수의 수: 마지막 차 점화식 A_{n,k} = sum_j C(n-1,j) min(j+1,k+1) A_{j,k} A_{n-1-j,k}
# ---------------------------------------------------------------------------
@lru_cache(maxsize=None)
def A(n, k):
    """최대 변위가 k 이하인 길이 n의 주차함수의 수 (A_{0,k}=1; n>=1, k<0이면 0)."""
    if n == 0:
        return 1
    if k < 0:
        return 0
    if k >= n - 1:
        return (n + 1) ** (n - 1)
    return sum(comb(n - 1, j) * min(j + 1, k + 1) * A(j, k) * A(n - 1 - j, k) for j in range(n))


def b(n, l):
    if l < 0 or l > n - 1:
        return 0
    return A(n, l) - A(n, l - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


def q0(k, nmax=NMAX):
    for n in range(k + 1, nmax + 1):
        if d(n, k) > 0:
            return n
    return None


def qcirc(k, nmax=NMAX):
    """d_{n,k}>=0인 가장 작은 n>=k+1."""
    for n in range(k + 1, nmax + 1):
        if d(n, k) >= 0:
            return n
    return None


# ---------------------------------------------------------------------------
# 0. 자기 점검
# ---------------------------------------------------------------------------
def check0():
    print('0. 도구의 자기 점검')
    rows = {1: [1], 2: [2, 1], 3: [6, 7, 3], 4: [24, 51, 34, 16], 5: [120, 421, 377, 253, 125],
            6: [720, 3963, 4594, 3688, 2546, 1296], 7: [5040, 42253, 62145, 57398, 46142, 32359, 16807]}
    report('n<=7의 행이 뿌리 명제의 확인용 값과 같다',
           all([b(n, l) for l in range(n)] == rows[n] for n in rows))
    report('n<=30에서 행의 합이 (n+1)^(n-1)',
           all(sum(b(n, l) for l in range(n)) == (n + 1) ** (n - 1) for n in range(1, NMAX + 1)))


# ---------------------------------------------------------------------------
# Borel 질량과 생존 질량 (mpmath)
# ---------------------------------------------------------------------------
@lru_cache(maxsize=None)
def Bor(m):
    if m <= 0:
        return mp.mpf(0)
    return mp.e ** (-m) * mp.mpf(m) ** (m - 1) / mp.factorial(m)


@lru_cache(maxsize=None)
def Ren(m):
    return mp.e ** (-m) * mp.mpf(m) ** m / mp.factorial(m)


def a_mass(N, s):
    """생존 질량 a(N,s) = e^{-N} A(N-1,s-1)/N!  (전역 용어 「생존 질량, 질량 셀, 셀의 열」)."""
    return mp.e ** (-N) * mp.mpf(A(N - 1, s - 1)) / mp.factorial(N)


def beta_cell(N, s):
    """질량 셀 beta(N,s) = e^{-N} b_{N-1,s}/N!."""
    return mp.e ** (-N) * mp.mpf(b(N - 1, s)) / mp.factorial(N)


def u_cell(M, j):
    """r88013dc3의 셀 u_M(j) = beta(M, M-j) (j<=1에서 0)."""
    if j <= 1 or j > M:
        return mp.mpf(0)
    return beta_cell(M, M - j)


def kappa_src(s, N):
    """전역 용어의 kappa_s(N) = Bor(N) - sum_{i=s+1}^{N-1} Bor(i)Bor(N-i)."""
    return Bor(N) - sum(Bor(i) * Bor(N - i) for i in range(s + 1, N))


# ---------------------------------------------------------------------------
# 1. 셀의 대각 감소
# ---------------------------------------------------------------------------
def check1():
    print('1. 셀의 대각 감소 e_M(j) = u_M(j) - u_{M+1}(j)  (행 M+1<=31, 곧 주차함수의 길이 <=30)')
    MM = NMAX  # 행 M+1 = 31은 길이 30의 주차함수를 쓴다

    def e(M, j):
        return u_cell(M, j) - u_cell(M + 1, j) if j >= 2 else mp.mpf(0)

    def x(M, j):
        return u_cell(M, j - 1) - u_cell(M, j)

    def De(M, j):
        return e(M, j) - e(M, j - 1)

    # (a) De_M(j) = x_{M+1}(j) - x_M(j)
    ok = all(abs(De(M, j) - (x(M + 1, j) - x(M, j))) < mp.mpf(10) ** (-50)
             for M in range(4, MM + 1) for j in range(2, M + 1))
    report('De_M(j) = x_{M+1}(j) - x_M(j)', ok)

    # (b) e = 생존 질량의 대각 감소분의 수준 방향 차분
    def Am(M, j):  # A_M(j) = a(M, M-j) (j>=0; A_M(0)=A_M(1)=Bor(M)/M)
        return a_mass(M, M - j)
    ok = all(abs(u_cell(M, j) - (Am(M, j - 1) - Am(M, j))) < mp.mpf(10) ** (-50)
             for M in range(4, MM + 2) for j in range(2, M))
    report('u_M(j) = A_M(j-1) - A_M(j),  A_M(j) = a(M, M-j)', ok)

    # (c) Psi_N(r) = sum_gamma Bor(gamma)[x_N(r-gamma) - x_{N-gamma}(r-gamma)]
    #             = sum_{t=1}^{r-2} sum_{j=2}^{r-t} Bor(r-j) De_{N-t}(j)
    def Psi(N, r):
        return sum(Bor(g) * (x(N, r - g) - x(N - g, r - g)) for g in range(1, r - 1))

    def Psi_by_e(N, r):
        return sum(Bor(r - j) * De(N - t, j) for t in range(1, r - 1) for j in range(2, r - t + 1))
    worst = mp.mpf(0)
    cnt = 0
    for N in range(6, MM + 2):
        for r in range(3, N):
            worst = max(worst, abs(Psi(N, r) - Psi_by_e(N, r)))
            cnt += 1
    report('행 사이의 몫 Psi_N(r)를 대각 감소의 증분의 Borel 합으로 적은 등식 (%d자리)' % cnt,
           worst < mp.mpf(10) ** (-45), '가장 큰 차 %s' % mp.nstr(worst, 3))

    # (d) 첫 층에서 E/mu = G - T_3, G = 2 - T_1 - T_2  (3<=r<=(N+2)/2)
    def frac_sigma(N, r):
        # sigma_N(r) = (N/(N-r)) x_N(r) - sum_gamma Bor(gamma) x_{N-gamma}(r-gamma)
        return (mp.mpf(N) / (N - r)) * x(N, r) - sum(Bor(g) * x(N - g, r - g) for g in range(1, r - 1))

    def s_src(s, N):  # 𝔰_s(N) = sum_{S=s+1}^{N-1} Bor(N-S) a(S,s+1)
        return sum(Bor(N - S) * a_mass(S, s + 1) for S in range(s + 1, N))
    worst = mp.mpf(0)
    cnt = 0
    for N in range(8, MM + 2):
        for r in range(3, (N + 2) // 2 + 1):
            s = N - r
            mu = mp.mpf(N) / (s * (s + 1))
            T1 = 2 * s_src(s + 1, N) / (N * u_cell(N, r - 1))
            T2 = Bor(r - 1) * Bor(s + 1) / (N * u_cell(N, r - 1))
            closed = mu * u_cell(N, r - 1) * (2 - T1 - T2)
            worst = max(worst, abs(frac_sigma(N, r) - closed) / abs(closed))
            cnt += 1
    report('첫 층에서 sigma_N(r) = mu u(r-1)(2 - T_1 - T_2), mu = N/(s(s+1)) (%d자리)' % cnt,
           worst < mp.mpf(10) ** (-40), '가장 큰 상대 차 %s' % mp.nstr(worst, 3))

    # (d') T_1, T_2의 확률 꼴: T_1 = 2[psi_N(r-2) - R_N(r-1)]/((s+2)P_N(r-1)), T_2 = beta_N(r-1)/P_N(r-1)
    def P_N(N, j):   # Pr(N - M_{N-1} = j)
        return mp.mpf(b(N - 1, N - j)) / mp.mpf(N) ** (N - 2)

    def psi_N(N, j):  # Pr(N - M_{N-1} > j) = Pr(M_{N-1} <= N-j-1)
        return mp.mpf(A(N - 1, N - j - 1)) / mp.mpf(N) ** (N - 2)

    def beta_first(N, g):
        return Bor(g) * Bor(N - g) / Bor(N)

    def R_first(N, bb):
        return 1 - sum(beta_first(N, g) for g in range(1, bb))
    worst = mp.mpf(0)
    for N in range(8, MM + 2):
        for r in range(3, (N + 2) // 2 + 1):
            s = N - r
            T1m = 2 * s_src(s + 1, N) / (N * u_cell(N, r - 1))
            T2m = Bor(r - 1) * Bor(s + 1) / (N * u_cell(N, r - 1))
            T1p = 2 * (psi_N(N, r - 2) - R_first(N, r - 1)) / ((s + 2) * P_N(N, r - 1))
            T2p = beta_first(N, r - 1) / P_N(N, r - 1)
            worst = max(worst, abs(T1m - T1p), abs(T2m - T2p))
    report('T_1, T_2를 확률, 첫 간격 무게, 첫 간격의 생존으로 적은 꼴이 질량의 꼴과 같다',
           worst < mp.mpf(10) ** (-45), '가장 큰 차 %s' % mp.nstr(worst, 3))

    # (d'') e_M(j)>=0  <=>  b_{M,M+1-j} <= e (M+1) b_{M-1,M-j}  <=>  theta(M,k) <= (e/gamma_k)(1+1/M), k=M+1-j
    same = True
    for M in range(4, MM + 1):
        for j in range(2, M):
            k = M + 1 - j
            lhs = e(M, j) >= 0
            mid = mp.mpf(b(M, M + 1 - j)) <= mp.e * (M + 1) * b(M - 1, M - j)
            gk = (mp.mpf(k + 1) / k) ** (k - 2)
            theta = mp.mpf(b(M, k)) / (gk * M * b(M - 1, k - 1))
            rhs = theta <= (mp.e / gk) * (1 + mp.mpf(1) / M)
            same = same and (lhs == mid == rhs)
    report('e_M(j)>=0 <=> b_{M,M+1-j} <= e(M+1) b_{M-1,M-j} <=> 대각 비 theta(M,k) <= (e/gamma_k)(1+1/M)', same)

    # (d3) 대각 초과와의 정확한 대응: e_M(j)/u_M(j) = 1 - (gamma_k M/(e(M+1))) (1 + exc(M,k)/k), exc = k(theta-1), k=M+1-j>=2
    #      정리 Dg(theta>=1)를 옮긴 위쪽 한계 e_M(j) <= u_M(j)[1 - gamma_k M/(e(M+1))]
    #      e_M(j)>=0 <=> exc(M,k) <= k[(e/gamma_k)(1+1/M)-1]; 그 우변과 5/2+k/M의 차
    worst = mp.mpf(0)
    dg_ok = True
    gap = mp.mpf(0)
    cnt = 0
    for M in range(4, MM + 1):
        for j in range(2, M):
            k = M + 1 - j
            if k < 2:
                continue
            gk = (mp.mpf(k + 1) / k) ** (k - 2)
            theta = mp.mpf(b(M, k)) / (gk * M * b(M - 1, k - 1))
            exc = k * (theta - 1)
            lhs = e(M, j) / u_cell(M, j)
            rhs = 1 - (gk * M / (mp.e * (M + 1))) * (1 + exc / k)
            worst = max(worst, abs(lhs - rhs))
            dg_ok = dg_ok and (e(M, j) <= u_cell(M, j) * (1 - gk * M / (mp.e * (M + 1))) + mp.mpf(10) ** (-50))
            bound = k * ((mp.e / gk) * (1 + mp.mpf(1) / M) - 1)
            gap = max(gap, k * abs(bound - (mp.mpf(5) / 2 + mp.mpf(k) / M)))
            cnt += 1
    report('e_M(j)/u_M(j) = 1 - (gamma_k M/(e(M+1)))(1 + e(M,k)/k), e(M,k)=k(theta(M,k)-1)는 전역 용어의 대각 초과 (%d자리)' % cnt,
           worst < mp.mpf(10) ** (-45), '가장 큰 차 %s' % mp.nstr(worst, 3))
    report('정리 Dg(theta>=1)를 옮긴 위쪽 한계 e_M(j) <= u_M(j)[1 - gamma_k M/(e(M+1))]', dg_ok)
    report('e_M(j)>=0 <=> e(M,k) <= k[(e/gamma_k)(1+1/M)-1]; 우변과 5/2+k/M의 차는 5/k 이하', gap < 5,
           'k x 차의 최댓값 %s' % mp.nstr(gap, 3))

    # (d4) r6af349eb의 부등식 (G): b_{n,k} <= gamma_k (n+1) b_{n-1,k-1}, 곧 theta(n,k) <= 1+1/n.
    #      (G)이면 e_M(j)>=0 (M=n, j=M+1-k). 행 M<=30에서 (G)가 깨지는 자리와 e<0인 자리를 센다.
    impl = True
    nG = nE = nboth = 0
    worstG = None
    for M in range(4, MM + 1):
        for j in range(2, M):
            k = M + 1 - j
            if k < 2:
                continue
            gk = (mp.mpf(k + 1) / k) ** (k - 2)
            G_ok = mp.mpf(b(M, k)) <= gk * (M + 1) * b(M - 1, k - 1)
            e_ok = e(M, j) >= 0
            impl = impl and ((not G_ok) or e_ok)
            if not G_ok:
                nG += 1
                if worstG is None or k > worstG[1]:
                    worstG = (M, k)
            if not e_ok:
                nE += 1
    report('(G): theta(n,k) <= 1+1/n 이면 e_M(j) >= 0 (M=n, j=M+1-k)', impl,
           '행 M<=%d에서 (G)가 깨지는 자리 %d곳(가장 큰 열의 자리 %s), e<0인 자리 %d곳' % (MM, nG, worstG, nE))

    # (e) 대각 감소의 열 방정식 (명제 6.4): j>=2, M<=2 sigma+2
    def V(M, j):
        sg = M - j
        return a_mass(M, sg + 1) - kappa_src(sg, M) / M
    worst = mp.mpf(0)
    cnt = 0
    for M in range(6, MM + 1):
        for j in range(2, M):
            sg = M - j
            if M > 2 * sg + 2:
                continue
            Se = (M * V(M, j) - (mp.mpf(sg) * (M + 1) / (sg + 2)) * V(M + 1, j) - j * u_cell(M + 1, j)) / (M * (sg + 1))
            rhs = (mp.mpf(sg) / M) * sum(Bor(t) * e(M - t, j - t) for t in range(1, j - 1)) + Se
            worst = max(worst, abs(e(M, j) - rhs))
            cnt += 1
    report('대각 감소의 열 방정식 e_M(j) = (sigma/M) sum_t Bor(t) e_{M-t}(j-t) + S^e_M(j) (%d자리)' % cnt,
           worst < mp.mpf(10) ** (-45), '가장 큰 차 %s' % mp.nstr(worst, 3))

    # (f) 첫 층에서 e>=0 (기록의 관찰은 8<=M<=639; 여기서는 M<=30)
    neg = [(M, j) for M in range(8, MM + 1) for j in range(2, (M + 2) // 2 + 1) if e(M, j) < 0]
    report('8<=M<=30의 첫 층(2<=j<=(M+2)/2)에서 e_M(j)>=0', not neg, str(neg[:5]))

    # (g) 검토가 rb9e33ce7/p-second-order-inequalities (3)(i)에서 옮긴 상계
    bad = []
    cnt = 0
    for M in range(8, MM + 1):
        n = M - 1
        for j in range(2, (M + 2) // 2 + 1):
            k = M - j
            w = k - max(1, j - 3)
            if w < 1:
                continue
            bound = u_cell(M, j) * (1 - mp.e ** (-1) * (1 + mp.mpf(1) / k) ** (k - 1)
                                    * (mp.mpf(w) / (w + 1)) * (mp.mpf(n + 1) / (n + 2)))
            cnt += 1
            if e(M, j) > bound:
                bad.append((M, j))
    report('e_M(j) <= u_M(j)[1 - e^{-1}(1+1/k)^{k-1} (w/(w+1)) ((n+1)/(n+2))] (%d자리)' % cnt, not bad, str(bad[:5]))


# ---------------------------------------------------------------------------
# 소인 주차함수의 수 C_{m,k}: 1/A_{k-1}(x) = 1 - sum_{m>=1} C_{m,k} x^m/m!
# ---------------------------------------------------------------------------
@lru_cache(maxsize=None)
def Cprime(m, k):
    """모든 변위가 k보다 작은 길이 m의 소인 주차함수의 수."""
    # z_N = A_{N,k-1}/N!,  (sum z_N x^N)(1 - sum c_m x^m) = 1,  c_m = C_{m,k}/m!
    c = cfrac(m, k)
    val = c * factorial(m)
    assert val.denominator == 1
    return int(val)


@lru_cache(maxsize=None)
def cfrac(m, k):
    z = lambda N: Fr(A(N, k - 1), factorial(N))
    # z_m = sum_{i=1}^{m} c_i z_{m-i}  =>  c_m = z_m - sum_{i=1}^{m-1} c_i z_{m-i}
    return z(m) - sum(cfrac(i, k) * z(m - i) for i in range(1, m))


# ---------------------------------------------------------------------------
# 2. 생존 윤곽의 꼴과 k만의 가상의 열
# ---------------------------------------------------------------------------
def gamma(m):
    return Fr(m + 1, m) ** (m - 2)


class Column:
    """열 k의 대각 기울임 x=(k/(k+1))^{k-2}에서의 양들 (정확한 유리수)."""

    def __init__(self, k, nmax):
        self.k = k
        self.nmax = nmax
        self.x = Fr(k, k + 1) ** (k - 2)
        x = self.x
        self.kap = {m: x ** m * Fr(Cprime(m, k), factorial(m)) for m in range(1, nmax - k + 2)}
        self.phi = lambda n: (k + 1) * x / n
        self.alp = lambda n: (k - 1) * x / n

    # Green 함수
    @lru_cache(maxsize=None)
    def ga(self, n, l):
        if n == l:
            return Fr(1)
        return self.alp(n) * self.ga(n - 1, l) + sum(self.kap[m] * self.ga(n - m, l) for m in range(1, n - l + 1))

    @lru_cache(maxsize=None)
    def gb(self, n, l):
        if n == l:
            return Fr(1)
        return self.phi(n) * self.gb(n - 1, l) + sum(self.kap[m] * self.gb(n - m, l) for m in range(1, n - l + 1))

    def w(self, n, l):
        return self.gb(n, l) - self.ga(n, l)

    def solve_VU(self, psi):
        """원천 psi(l)(l>=k)로 (S1), (S2)를 다른 입력 없이 푼 V, U와 걸음 eta=V-U."""
        k = self.k
        V = {n: sum(self.gb(n, l) * psi[l] for l in range(k + 1, n + 1)) for n in range(k, self.nmax + 1)}
        U = {n: sum(self.ga(n, l) * psi[l] for l in range(k, n + 1)) for n in range(k, self.nmax + 1)}
        return V, U, {n: V[n] - U[n] for n in V}


def worlds(col):
    """흐름의 세계(a=0), Euler의 세계(a=a'), 위쪽 세계(a=2a')의 기준 풀이.
    psi는 행 2k+2까지, V는 행 2k+1까지 (기록의 보조정리 L', L''의 N=2k+1)."""
    k, x = col.k, col.x
    out = {}
    for name, mult in (('J', 0), ('E', 1), ('U', 2)):
        psi = {k: Fr(1), k + 1: Fr(1)}
        V = {k: Fr(0), k + 1: Fr(1)}
        for n in range(k + 2, 2 * k + 3):
            c = gamma(n - 1) / gamma(k)
            aprime = x * x * gamma(n - 1) * (n - 1 - k) / (2 * (n - 1) ** 2)
            psi[n] = c * psi[n - 1] - (x / n) * V[n - 1] + mult * aprime * V[n - 2]
            if n <= 2 * k + 1:
                V[n] = psi[n] + col.phi(n) * V[n - 1] + sum(col.kap[m] * V[n - m] for m in range(1, n - k))
        out[name] = (psi, V)
    return out


def check2():
    print('2. 생존 윤곽의 꼴 (S1)-(S3), 걸음의 식 (2.6), 세 세계와 교차 행의 끼움')
    # --- 실제 열에서의 (S1)-(S3)과 (2.6) (첫 층 n<=2k-1에서 X~', Y~ = 0) ---
    worst_ok = True
    cnt = 0
    for k in range(2, 16):
        nmax = min(NMAX, 2 * k + 1)
        col = Column(k, nmax)
        x = col.x
        psi = {n: x ** n * Fr(A(n - 1, k - 1), factorial(n)) for n in range(k, nmax + 1)}
        V = {n: x ** n * Fr(b(n, k), factorial(n)) for n in range(k, nmax + 1)}
        U = {n: x ** n * Fr(b(n, k - 1), factorial(n)) for n in range(k, nmax + 1)}
        gk = gamma(k)
        for n in range(k + 1, nmax + 1):
            # (S1): n<=2k+1에서 X~'_n=0
            s1 = psi[n] + col.phi(n) * V[n - 1] + sum(col.kap[m] * V[n - m] for m in range(1, n - k))
            # (S2): n<2k에서 Y~_n=0, n>=2k에서 U_n <= 우변
            s2 = psi[n] + col.alp(n) * U[n - 1] + sum(col.kap[m] * U[n - m] for m in range(1, n - k + 1))
            # (S3)
            sn = x ** n * Fr(A(n - 1, k) - gk * n * A(n - 2, k - 1), factorial(n)) if n >= k + 2 else Fr(0)
            s3 = psi[n - 1] - (x / n) * V[n - 1] + sn
            c1 = (V[n] == s1)
            c2 = (U[n] == s2) if n < 2 * k else (U[n] <= s2)
            c3 = (psi[n] == s3) and sn >= 0
            cnt += 1
            if not (c1 and c2 and c3):
                worst_ok = False
                print('    어긋남:', k, n, c1, c2, c3)
        # (2.6): 첫 층에서 eta_n = sum_l w_n(l) psi_l - g^a(n,k) U_k
        for n in range(k + 1, min(nmax, 2 * k - 1) + 1):
            eta = V[n] - U[n]
            rhs = sum(col.w(n, l) * psi[l] for l in range(k + 1, n + 1)) - col.ga(n, k) * U[k]
            if eta != rhs:
                worst_ok = False
                print('    (2.6) 어긋남:', k, n)
        if k >= 2:
            assert psi[k] == U[k] and psi[k + 1] == U[k]
    report('2<=k<=15, k+1<=n<=min(30,2k+1)에서 (S1), (S2)(n>=2k에서는 부등식), (S3)과 s_n>=0, 첫 층의 (2.6) (%d행)' % cnt, worst_ok)

    # --- 생존 윤곽과 전역 용어의 생존 질량: psi_n = (e x)^n a(n,k) ---
    ok = True
    for k in range(2, 12):
        x = mp.mpf(k) / (k + 1)
        x = x ** (k - 2)
        for n in range(k, 25):
            psi = x ** n * mp.mpf(A(n - 1, k - 1)) / mp.factorial(n)
            ok = ok and abs(psi - (mp.e * x) ** n * a_mass(n, k)) < mp.mpf(10) ** (-45)
    report('생존 윤곽 psi_n = (e x)^n a(n,k) (전역 용어의 생존 질량)', ok)

    # --- 세 세계와 끼움 ---
    table_rE = {}
    table_rU = {}
    for k in range(11, 15):
        table_rE[k] = 9
    for k in range(15, 20):
        table_rE[k] = 10
    for k in range(20, 26):
        table_rE[k] = 11
    for k in range(11, 16):
        table_rU[k] = 9
    for k in range(16, 21):
        table_rU[k] = 10
    for k in range(21, 26):
        table_rU[k] = 11
    table_rJ = {}
    for k in range(11, 15):
        table_rJ[k] = 9
    for k in range(15, 20):
        table_rJ[k] = 10
    for k in range(20, 26):
        table_rJ[k] = 11
    all_ok = True
    cmp_ok = True
    sandwich_ok = True
    lines = []
    for k in range(2, 26):
        nmax = max(2 * k + 2, min(k + 27, NMAX))
        col = Column(k, nmax)
        W = worlds(col)
        res = {}
        for name in ('J', 'E', 'U'):
            psi, Vw = W[name]
            if name == 'U':
                # 위쪽 세계: 첫 층에서 쓴다. U^U_n = sum_l g^a(n,l) psi^U_l, eta^U = V^U - U^U
                Uw = {n: sum(col.ga(n, l) * psi[l] for l in range(k, n + 1)) for n in range(k, 2 * k + 2)}
                eta = {n: Vw[n] - Uw[n] for n in range(k, 2 * k + 2)}
                rU = next((r for r in range(1, k) if k + r <= 2 * k - 1 and eta[k + r] >= 0), k)
                res['U'] = (eta, rU)
            else:
                # 다하는 행(2k+2 이하) 뒤에서 0으로 자른 윤곽을 원천으로 (S1), (S2)를 모든 행에서 푼다
                lstar = k + 1
                while lstar + 1 <= 2 * k + 2 and psi[lstar + 1] > 0:
                    lstar += 1
                flat = {l: (psi[l] if l <= lstar else Fr(0)) for l in range(k, nmax + 1)}
                Vf, Uf, eta = col.solve_VU(flat)
                r = next((rr for rr in range(1, nmax - k + 1) if eta[k + rr] > 0), None)
                res[name] = (eta, r)
        rJ, rE, rU = res['J'][1], res['E'][1], res['U'][1]
        if k >= 11:
            if (table_rE.get(k), table_rU.get(k), table_rJ.get(k)) != (rE, rU, rJ):
                all_ok = False
                print('    표와 다름: k=%d  r^E=%s r^U=%s r^J=%s (표: %s %s %s)' %
                      (k, rE, rU, rJ, table_rE.get(k), table_rU.get(k), table_rJ.get(k)))
        # 실제 열과의 비교 (행 n<=30까지)
        x = col.x
        Uk = x ** k * Fr(b(k, k - 1), factorial(k))
        for n in range(k + 1, min(NMAX, nmax) + 1):
            eta_true = x ** n * Fr(d(n, k), factorial(n))
            if not (eta_true >= Uk * res['E'][0][n] >= Uk * res['J'][0][n]):
                cmp_ok = False
                print('    아래쪽 비교 어긋남', k, n)
            if n <= 2 * k - 1 and not (eta_true <= Uk * res['U'][0][n]):
                cmp_ok = False
                print('    위쪽 비교 어긋남', k, n)
        qq = q0(k)
        qc = qcirc(k)
        if qq is not None and rE is not None:
            if not (k + rU <= qc <= qq <= k + rE):
                sandwich_ok = False
                print('    끼움 어긋남', k, rU, qc, qq, rE)
            lines.append('k=%d: r^U=%d, q_0-k=%d, r^E=%d, r^J=%s' % (k, rU, qq - k, rE, rJ))
    report('11<=k<=25에서 r^E, r^U, r^J가 기록의 표(p-cert-euler, p-cert-flow)와 같다', all_ok)

    # --- 나머지가 0인 궤적(잘린 세계)과 위험률의 세계: l_1, r^1, r^N을 기록의 표와 견준다 ---
    def tab(spec):
        t = {}
        for (lo, hi), v in spec:
            for kk in range(lo, hi + 1):
                t[kk] = v
        return t
    t_r1 = tab([((11, 15), 10), ((16, 22), 11), ((23, 25), 12)])
    t_rN = tab([((11, 13), 9), ((14, 18), 10), ((19, 24), 11), ((25, 25), 12)])
    ok1 = True
    okN = True
    okl = True
    okcmp = True
    for k in range(11, 26):
        nmax = 2 * k + 2
        col = Column(k, nmax)
        x = col.x
        # 나머지가 0인 생존 윤곽: psi^1_n = psi^1_{n-1} - (x/n) V^1_{n-1}
        psi = {k: Fr(1), k + 1: Fr(1)}
        V = {k: Fr(0), k + 1: Fr(1)}
        for n in range(k + 2, nmax + 1):
            psi[n] = psi[n - 1] - (x / n) * V[n - 1]
            V[n] = psi[n] + col.phi(n) * V[n - 1] + sum(col.kap[m] * V[n - m] for m in range(1, n - k))
        l1 = k + 1
        while l1 + 1 <= nmax and psi[l1 + 1] > 0:
            l1 += 1
        if k <= 20:
            okl = okl and (l1 == (2 * k if k <= 15 else 2 * k - 1))
        _, _, eta1 = col.solve_VU(psi)
        r1 = next((rr for rr in range(1, nmax - k + 1) if eta1[k + rr] > 0), None)
        ok1 = ok1 and (r1 == t_r1[k]) and (k + r1 <= l1)
        # 위험률의 세계: psi^N_n = rho_n psi^N_{n-1}, rho_n = (gamma_{n-1}/gamma_k) max(0, 1-h_n)
        def chibar(m):
            return sum(Fr(comb(m + 1, g) * g ** g * (m + 1 - g) ** (m - g), (m + 1) ** m) for g in range(1, m - k + 1))
        psiN = {k: Fr(1), k + 1: Fr(1)}
        for n in range(k + 2, nmax + 1):
            h = chibar(n - 1) / (k + 1)
            psiN[n] = (gamma(n - 1) / gamma(k)) * max(Fr(0), 1 - h) * psiN[n - 1]
        _, _, etaN = col.solve_VU(psiN)
        rN = next((rr for rr in range(1, nmax - k + 1) if etaN[k + rr] > 0), None)
        okN = okN and (rN == t_rN[k])
        # 실제 열과의 비교 (행 n<=30): psi_l >= U_k psi^N_l, eta_n >= U_k eta^N_n; l<=l_1에서 psi_l >= U_k psi^1_l
        Uk = x ** k * Fr(b(k, k - 1), factorial(k))
        for n in range(k + 1, min(NMAX, nmax) + 1):
            psi_true = x ** n * Fr(A(n - 1, k - 1), factorial(n))
            eta_true = x ** n * Fr(d(n, k), factorial(n))
            okcmp = okcmp and psi_true >= Uk * psiN[n] and eta_true >= Uk * etaN[n]
            if n <= l1:
                okcmp = okcmp and psi_true >= Uk * psi[n]
    report('11<=k<=20에서 다하는 행 l_1(k)가 기록의 값(2k, 2k-1)과 같다', okl)
    report('11<=k<=25에서 r^1(k)가 기록의 표(p-cert-level1)와 같고 k+r^1<=l_1', ok1)
    report('11<=k<=25에서 r^N(k)가 기록의 표(p-cert-hazard)와 같다', okN)
    report('11<=k<=25, 행 n<=30에서 psi >= U_k psi^N, eta >= U_k eta^N, l<=l_1에서 psi >= U_k psi^1', okcmp)
    report('2<=k<=25, 행 n<=30에서 eta >= U_k eta^{E♭} >= U_k eta^{J♭}, 첫 층에서 eta <= U_k eta^U', cmp_ok)
    report('교차 행이 30 이하인 열에서 k+r^U <= q° <= q_0 <= k+r^E', sandwich_ok)
    print('     ' + '; '.join(lines))


# ---------------------------------------------------------------------------
# 3. 정리 QD
# ---------------------------------------------------------------------------
def check3():
    print('3. 정리 QD (가), 따름 QD3, 행 k+2의 닫힌 식')
    cnt = 0
    worst = None
    ok = True
    ok3 = True
    for n in range(4, NMAX + 1):
        for k in range(2, n - 1):  # r=n-k>=2
            lhs = b(n, k)
            rhs = n * Fr(1, 2) * (gamma(k) + gamma(n - 1)) * b(n - 1, k - 1)
            cnt += 1
            ratio = Fr(lhs) / rhs
            if worst is None or ratio < worst[0]:
                worst = (ratio, n, k)
            ok = ok and lhs >= rhs
            # 따름 QD3: 늦춘 부등식
            ok3 = ok3 and lhs >= Fr(k + 1, k) ** (k - 1) * (n - 1) * b(n - 1, k - 1)
    report('n<=30, k>=2, r>=2의 %d자리에서 b_{n,k} >= n (gamma_k+gamma_{n-1})/2 b_{n-1,k-1}' % cnt, ok,
           '가장 작은 비 %.4f, (n,k)=(%d,%d)' % (float(worst[0]), worst[1], worst[2]))
    report('같은 자리에서 늦춘 부등식 b_{n,k} >= (1+1/k)^{k-1}(n-1) b_{n-1,k-1}', ok3)
    # (theta-1)/tau의 최솟값과 c*(k)
    best = None
    okc = True
    for k in range(2, NMAX - 1):
        n = k + 2
        theta = Fr(b(n, k)) / (gamma(k) * n * b(n - 1, k - 1))
        tau = gamma(n - 1) / gamma(k) - 1
        c = (theta - 1) / tau
        chibar = Fr(k, k + 1) ** (k - 1)
        P = tau * k / ((k + 1) * chibar)
        Q = Fr(2, (k + 1) * (k + 2))
        S = 2 * (k + 1) * tau / (k + 2)
        cstar = (P + Q) / (P - tau * Q + S)
        okc = okc and (c == cstar)
        if best is None or c < best[0]:
            best = (c, k)
    report('행 k+2에서 (theta-1)/tau가 닫힌 식 c*(k)와 같다 (2<=k<=28)', okc)
    report('c*(2) = 9/14이고 2<=k<=28에서 가장 작다', best[0] == Fr(9, 14) and best[1] == 2)


# ---------------------------------------------------------------------------
# 4. 쌍-충격 판정, 응답 꼴, 보조정리 M, 둘째 적률
# ---------------------------------------------------------------------------
def a_cay(j):
    return Fr(j ** (j - 1), factorial(j))


@lru_cache(maxsize=None)
def Lam(m, y, N):
    """전역 용어의 사슬 합 Lambda_m(y;N): 토막마다 a_gamma, 자르는 점 s마다 y/(N-s). (정확한 유리수)"""
    if m == 0:
        return Fr(1)
    return a_cay(m) + sum(a_cay(g) * Fr(y) / (N - g) * Lam(m - g, y, N - g) for g in range(1, m))


def check4():
    print('4. 쌍-충격 판정의 두 쪽, 첫 층의 응답 꼴과의 대응, 보조정리 M의 정수 걸음, 둘째 적률의 등식')
    # 첫 층의 응답 꼴: d_{n,k}/n! = X_k(n) - iota_k(n), iota_k(n) = lambda_k Lambda_{n-k+1}(k+1;N)
    ok = True
    okM = True
    okcrit = True
    cnt = 0
    eq = 0
    for k in range(2, 16):
        lam_k = Fr(k ** (k - 2), factorial(k))
        for n in range(k + 1, min(2 * k - 1, NMAX) + 1):
            N = n + 1
            R = N - k
            iota = lam_k * Lam(R, k + 1, N)
            X = 2 * sum(Lam(n - j, k + 1, N) * Fr(b(j, k - 1), factorial(j + 1)) for j in range(k, n))
            ok = ok and (Fr(d(n, k), factorial(n)) == X - iota)
            # 쌍 쪽: 정규화한 사슬 합 Lambda~_m(y;Q) = e^{-m} Lambda_m(y;Q); e의 거듭제곱을 걷어 내고 유리수로 견준다.
            # (3.4)의 좌변 P_R(k) = 2 sum_{a<b} L~_a(k;N)(k/(N-a)) L~_{b-a}(k;N-a)(k/(N-b)) (Bor(N-b)/Bor(k)) Pr(M_{N-b-1}<k)
            # 우변 k L~_R(k+1;N).  양변에 e^{R}을 곱하면 유리수가 된다:
            #   e^{R} L~_a L~_{b-a} Bor(N-b)/Bor(k) = Lam_a Lam_{b-a} a_{N-b}/a_k
            lhs = Fr(0)
            for bb in range(2, R + 1):
                surv = Fr(A(N - bb - 1, k - 1), (N - bb) ** (N - bb - 2)) if N - bb - 1 >= 1 else Fr(1)
                for aa in range(1, bb):
                    lhs += (Lam(aa, k, N) * Fr(k, N - aa) * Lam(bb - aa, k, N - aa) * Fr(k, N - bb)
                            * a_cay(N - bb) / a_cay(k) * surv)
            lhs *= 2
            rhs = k * Lam(R, k + 1, N)
            # 판정이 딛는 부등식: d_{n,k}/p_n >= (Bor(k)/(k^2 Bor(N))) [P_R(k) - k L~_R(k+1;N)]
            #   Bor(k)/Bor(N) e^{-R}[..e^{R}] = (a_k/a_N) [lhs - rhs]
            lower = a_cay(k) / a_cay(N) / (k * k) * (lhs - rhs)
            val = Fr(d(n, k), (n + 1) ** (n - 1))
            cnt += 1
            if val == lower:
                eq += 1
            okcrit = okcrit and (val >= lower)
            # 보조정리 M의 정수 걸음: I^(k) = k e^R L~_R(k+1;k+R) 에 대해 I^(k+1)/I^(k) >= (k+1)/k
            I0 = k * Lam(R, k + 1, k + R)
            I1 = (k + 1) * Lam(R, k + 2, k + 1 + R)
            okM = okM and (I1 * k >= I0 * (k + 1))
    report('첫 층의 응답 꼴 d_{n,k}/n! = X_k(n) - iota_k(n) (열 k<=15, n<=min(2k-1,30))', ok)
    report('쌍-충격 판정이 딛는 부등식 d_{n,k}/p_n >= (Bor(k)/(k^2 Bor(N)))[(3.4)의 좌변 - 우변] (%d자리, 등호 %d자리)' % (cnt, eq), okcrit)
    report('보조정리 M의 정수 걸음: 결손을 고정하면 k Lambda~_R(k+1;k+R)의 걸음의 비가 (k+1)/k 이상', okM)
    # 둘째 적률: sum_s s(m-s)Ren(s)Ren(m-s) = (m^2/8 - m/12) kappa_2(m) + (m(m-1)/6) Ren(m)
    worst = mp.mpf(0)
    for m in range(2, 61):
        k2 = sum(Ren(g) * Ren(m - g) for g in range(1, m))
        lhs = sum(s * (m - s) * Ren(s) * Ren(m - s) for s in range(1, m))
        rhs = (mp.mpf(m) ** 2 / 8 - mp.mpf(m) / 12) * k2 + (mp.mpf(m) * (m - 1) / 6) * Ren(m)
        worst = max(worst, abs(lhs - rhs))
    report('자르는 점의 둘째 적률의 등식 (2<=m<=60)', worst < mp.mpf(10) ** (-50), '가장 큰 차 %s' % mp.nstr(worst, 3))


# ---------------------------------------------------------------------------
# 5. 무거운 사슬의 창의 법칙과 끝 조건 (E_L)
# ---------------------------------------------------------------------------
def rooted_forests(n):
    """[n] 위의 뿌리 숲을 부모 함수(0은 가상 뿌리)로 모두 낸다."""
    for par in product(range(n + 1), repeat=n):
        # par[v-1]은 v의 부모; 순환이 없어야 한다
        ok = True
        for v in range(1, n + 1):
            seen = set()
            u = v
            while u != 0:
                if u in seen:
                    ok = False
                    break
                seen.add(u)
                u = par[u - 1]
            if not ok:
                break
        if ok:
            yield par


def check5():
    print('5. 무거운 사슬의 창의 법칙과 끝 조건 (E_L)')
    # 창 [1,L] 안의 점이 꼭 g_1<...<g_j일 확률 = (H_L(g_j)/Bor(N)) prod Bor(g_i - g_{i-1})
    def H(L, N, g):
        return Bor(N - g) - sum(Bor(m) * Bor(N - g - m) for m in range(1, L - g + 1))
    ok = True
    for N in (6, 7):
        n = N - 1
        for L in range(2, (N - 1) // 2 + 1):
            if not (2 * L < N):
                continue
            counts = {}
            total = 0
            for par in rooted_forests(n):
                total += 1
                size = [0] * (n + 1)
                for v in range(1, n + 1):
                    u = v
                    while u != 0:
                        size[u] += 1
                        u = par[u - 1]
                conf = tuple(sorted(set(N - size[v] for v in range(1, n + 1) if N - size[v] <= L)))
                counts[conf] = counts.get(conf, 0) + 1
            assert total == (n + 1) ** (n - 1)
            for conf, c in counts.items():
                pr = H(L, N, conf[-1] if conf else 0) / Bor(N)
                prev = 0
                for g in conf:
                    pr *= Bor(g - prev)
                    prev = g
                ok = ok and abs(pr - mp.mpf(c) / total) < mp.mpf(10) ** (-40)
    report('N=6,7에서 창의 법칙이 숲의 전수 나열과 같다', ok)

    # 격자 조건(정의대로) <=> 끝 조건 (E_L): Phi_L(g)=H_L(g)/Bor(L-g)가 0<=g<=L-1에서 늘지 않는다
    def law(N, L):
        P = {}
        for bits in product((0, 1), repeat=L):
            conf = [g + 1 for g in range(L) if bits[g]]
            pr = H(L, N, conf[-1] if conf else 0) / Bor(N)
            prev = 0
            for g in conf:
                pr *= Bor(g - prev)
                prev = g
            P[bits] = pr
        return P

    def lattice(N, L):
        P = law(N, L)
        for x1 in P:
            for x2 in P:
                jo = tuple(max(a, b_) for a, b_ in zip(x1, x2))
                me = tuple(min(a, b_) for a, b_ in zip(x1, x2))
                if P[jo] * P[me] < P[x1] * P[x2] * (1 - mp.mpf(10) ** (-40)):
                    return False
        return True

    def end_condition(N, L):
        Phi = [H(L, N, g) / Bor(L - g) for g in range(0, L)]
        return all(Phi[g + 1] <= Phi[g] * (1 + mp.mpf(10) ** (-40)) for g in range(L - 1))
    same = True
    cases = 0
    L1 = {}
    for N in range(5, 27):
        for L in range(2, (N - 1) // 2 + 1):
            if 2 * L >= N:
                continue
            ec = end_condition(N, L)
            if L <= 7:
                cases += 1
                same = same and (lattice(N, L) == ec)
            if not ec and N not in L1:
                L1[N] = L
    report('5<=N<=26, L<=7의 %d가지에서 격자 조건(정의대로)과 끝 조건이 같은 답을 준다' % cases, same)
    # N>=12L이면 끝 조건이 선다; L<=N/4에서도 선다(기록의 관찰 5<=N<=200)
    ok12 = all(end_condition(N, L) for N in range(24, 121) for L in range(2, N // 12 + 1))
    ok4 = all(end_condition(N, L) for N in range(8, 121) for L in range(2, N // 4 + 1) if 2 * L < N)
    report('24<=N<=120에서 N>=12L이면 끝 조건이 선다(보조정리 G2의 범위)', ok12)
    report('8<=N<=120에서 L<=N/4이면 끝 조건이 선다(기록의 관찰의 범위 안)', ok4)
    # 처음 깨지는 L_1(N): N/4+0.75 <= L_1 <= N/4+3.5
    okL1 = True
    for N in range(7, 121):
        first = None
        for L in range(2, (N - 1) // 2 + 1):
            if 2 * L >= N:
                continue
            if not end_condition(N, L):
                first = L
                break
        if first is not None:
            okL1 = okL1 and (N / 4 + 0.75 <= first <= N / 4 + 3.5)
    report('7<=N<=120에서 끝 조건이 처음 깨지는 L_1(N)이 N/4+0.75와 N/4+3.5 사이', okL1)


# ---------------------------------------------------------------------------
# 6. 어림 없는 교차곱 부등식 G*(r,k)와 문턱 kappa*(r)
# ---------------------------------------------------------------------------
def check6():
    print('6. 어림 없는 교차곱 부등식 G*(r,k)의 문턱 kappa*(r)와 첫 부등식')

    def EJ(h, r):
        ws = []
        for j in range(0, r):
            w = h ** j * (j + 1)
            for i in range(1, j + 1):
                w *= Fr(r - i, r)
            ws.append(w)
        tot = sum(ws)
        return sum(j * w for j, w in enumerate(ws)) / tot

    def Dr(r):
        s = Fr(0)
        for j in range(1, r + 1):
            t = Fr(1)
            for i in range(0, j):
                t *= Fr(r - i, r)
            s += t
        return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))

    def Gstar(r, k):
        hmid = Fr(k) / (k + 1 + Fr(r, 2))
        hminus = Fr(k - 1, k + r)
        return (k * (Fr(1, 2 * r) - Fr(1, 3 * r * r)) - Fr(5, 2) + 2 * (1 - Fr(1, k)) * EJ(hmid, r)
                + Fr(k, 2 * (k - 1)) * EJ(hminus, r) - Fr(k, k - 1) * Dr(r) + Fr(1, k))
    table = [9, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 31, 33, 35, 37, 40, 42, 45, 47, 50, 53, 55, 58, 61, 64,
             67, 70, 73, 76, 79, 82, 85, 88, 91, 94, 98, 101, 104, 108, 111, 114, 118, 121, 125]
    got = []
    for r in range(2, 46):
        k = 2 * r + 1
        while Gstar(r, k) <= 0:
            k += 1
        got.append(k)
    report('2<=r<=45의 kappa*(r)가 기록의 목록(c-kappa-star)과 같다', got == table)

    # 첫 부등식 k log(B_+ C_- /(B_- C_+)) >= G*(r,k)를 작은 첫 층의 자리에서 본다 (얼린 다항식을 숲의 무게로 셈)
    # K_{n,k}(y) = sum_F prod_{t_v>k} y/t_v 는 수준 k의 열 방정식 없이, 문턱 무게의 재귀로 셈한다:
    # Z_n[g] = sum_j C(n-1,j) (j+1) g(j+1) Z_j[g] Z_{n-1-j}[g]  (마지막 차 재귀의 일반 무게 꼴; g(t)=1 (t<=k), y/t (t>k))
    def Kpoly(n, k, y):
        @lru_cache(maxsize=None)
        def Z(m):
            if m == 0:
                return Fr(1)
            tot = Fr(0)
            for j in range(m):
                t = j + 1
                g = Fr(1) if t <= k else Fr(y, t)
                tot += comb(m - 1, j) * t * g * Z(j) * Z(m - 1 - j)
            return tot
        return Z(n)
    okK = all(Kpoly(n, k, k) == A(n, k - 1) and Kpoly(n, k, k + 1) == A(n, k)
              for n in range(3, 15) for k in range(1, n))
    report('얼린 다항식의 셈: K_{n,k}(k)=A_{n,k-1}, K_{n,k}(k+1)=A_{n,k} (n<=14)', okK)
    bad = []
    cnt = 0
    for k in range(3, 14):
        for n in range(k + 2, min(2 * k - 1, 26) + 1):
            r = n - k
            Km1, K0, K1, K2 = (Kpoly(n, k, y) for y in (k - 1, k, k + 1, k + 2))
            Cm = K1 - 2 * K0 + Km1
            Cp = K2 - 2 * K1 + K0
            Bm = Km1 - A(n, k - 2)
            Bp = K2 - A(n, k + 1)
            # d = C_- - B_-,  d_{n,k+1} = C_+ - B_+
            assert d(n, k) == Cm - Bm and d(n, k + 1) == Cp - Bp
            num, den = Fr(Bp * Cm), Fr(Bm * Cp)
            val = k * mp.log((mp.mpf(num.numerator) / num.denominator) / (mp.mpf(den.numerator) / den.denominator))
            cnt += 1
            g = Gstar(r, k)
            if val < mp.mpf(g.numerator) / g.denominator:
                bad.append((n, k))
    report('첫 층의 %d자리(열 3<=k<=13)에서 k log(B_+C_-/(B_-C_+)) >= G*(r,k)' % cnt, not bad, str(bad[:5]))


if __name__ == '__main__':
    which = sys.argv[1:] or ['0', '1', '2', '3', '4', '5', '6']
    for wname in which:
        globals()['check' + wname]()
    print('모든 대조가 맞았다.' if OK else '어긋난 대조가 있다.')
    sys.exit(0 if OK else 1)
