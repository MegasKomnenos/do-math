# -*- coding: utf-8 -*-
"""넷째 조직화가 용어를 묶거나 대응을 적기 전에 확인한 등식들.

연구의 증거로 쓰려는 계산이 아니다. 용어집의 병합·등록과 모듈 설명의 사전이
가리키는 「같은 수」가, 정의를 맞대었을 때 실제로 같은 수인지를 작은 크기에서
정확한 정수와 유리수로 대조한다. 누적 개수 A_{n,k}는 마지막 차 재귀로 구하고,
뿌리 파일의 표(n=4, 7)와 대조한 뒤에 쓴다. 범위는 모두 n <= 31이다.

확인하는 것
 (1) 대각 증분: r21b6d042…의 kappa_N(l) = F_{N+1}(l) - F_N(l-1)이 전역 용어
     「전이 비」의 분자 eps_{N+1}(N-l)이고 r6af349eb…의 흐름 J_{N+1}(l)이라는 것,
     그리고 m_N(l) = lambda_N(l) + kappa_N(l), m_{N+1}(l) = kappa_N(l) + lambda_N(l-1).
 (2) 거꾸로 가는 전이 비(rb9ca4897…)와 전이 비의 관계
     phat_{n+1}(k) Pr(M_{n+1}=k) = q_N(r) Pr(M_n=k) (N=n+1, r=n-k),
     열 감소분 c_n(k) = (1-phat_n(k)) Pr(M_n=k), 0 <= phat <= 1,
     그리고 정의를 바르게 옮겼는지 보려고 관찰 R의 세 부등식을 작은 범위에서.
 (3) Euler 결함(rbc6a3c2f…): U_y(N) = ((r+1)/N - q_N(r)) m_N(r), r = N-1-y.
 (4) 대각 교차곱(rbc6a3c2f…): 얻음·잃음과 얼린 다항식의 경계항·곡률항의 사전
     p_n Gain_N(y) = B_-(n,y), p_n Loss_N(y) = C_-(n,y) (N=n+1, y+1 <= n <= 2y-1),
     n = 2y에서 사전이 어긋난다는 것, 그리고 추측 (GL)이 (n,k)=(29,15)에서 깨진다는 것.
 (5) 뼈대의 계수(r790d81e5…) kappa_k(j) = [z^j] z exp(S_k(z))와 전역 용어
     「생존 질량, 질량 셀, 셀의 열」의 kappa_s(N): k+1 <= j <= 2k+2에서
     e^{-j} kappa_k(j) = kappa_k^{전역}(j)이고 j = 2k+3에서 갈린다는 것.
 (6) 노드 (D), (E)의 개수 꼴이 DC^T(t)와 sigma_t에 (t+1)!/x_k^{t-1}을 곱한 것이라는 것
     (전역 용어 「대각 둘째 차분, 대각 볼록성」의 나무 질량 판).
"""
from fractions import Fraction as Fr
from math import comb, factorial

NMAX = 31


def cumulative(nmax):
    """A[n][k] = #{alpha in PF_n : M(alpha) <= k}, 0 <= k <= nmax+1 (A[0][k] = 1)."""
    A = [[0] * (nmax + 2) for _ in range(nmax + 1)]
    for k in range(nmax + 2):
        A[0][k] = 1
    for n in range(1, nmax + 1):
        for k in range(nmax + 2):
            A[n][k] = sum(comb(n - 1, j) * min(j + 1, k + 1) * A[j][k] * A[n - 1 - j][k]
                          for j in range(n))
    return A


A = cumulative(NMAX)


def Acum(n, k):
    if n == 0:
        return 1
    if k < 0:
        return 0
    return A[n][min(k, NMAX + 1)]


def p(n):
    return (n + 1) ** (n - 1) if n >= 1 else 1


def b(n, l):
    return Acum(n, l) - Acum(n, l - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


assert [b(4, l) for l in range(4)] == [24, 51, 34, 16]
assert [b(7, l) for l in range(7)] == [5040, 42253, 62145, 57398, 46142, 32359, 16807]
for n in range(1, NMAX + 1):
    assert sum(b(n, l) for l in range(n)) == p(n)


def F(n, l):
    """Pr(M_n <= l); F(n, -1) = 0 (n >= 1), F(0, l) = 1."""
    return Fr(Acum(n, l), p(n))


def cell(n, l):
    """Pr(M_n = l)."""
    return F(n, l) - F(n, l - 1)


# (1) 대각 증분 -----------------------------------------------------------------

def phi(N, r):          # r535d20f…: phi_N(r) = Pr(M_{N-1} <= N-1-r)
    return F(N - 1, N - 1 - r)


def m_def(N, r):        # r535d20f…: m_N(r) = Pr(M_{N-1} = N-1-r)
    return cell(N - 1, N - 1 - r)


def eps(N, r):          # 전이 비의 분자 (생존의 대각 증분)
    return phi(N + 1, r + 1) - phi(N, r + 1)


def q_tr(N, r):         # 전이 비 q_N(r), N >= 2, 1 <= r <= N-1
    return eps(N, r) / m_def(N, r)


def flow(n, k):         # r6af349eb…: J_n(k) = Pr(M_n <= k) - Pr(M_{n-1} <= k-1)
    return F(n, k) - F(n - 1, k - 1)


def kappa(N, l):        # r21b6d042…: kappa_N(l) = F_{N+1}(l) - F_N(l-1)
    return F(N + 1, l) - F(N, l - 1)


def lam(N, l):          # r21b6d042…: 첫 통과 질량 lambda_N(l) = F_N(l) - F_{N+1}(l)
    return F(N, l) - F(N + 1, l)


cnt = 0
for N in range(1, 16):
    for l in range(0, N):
        assert kappa(N, l) == flow(N + 1, l)
        assert kappa(N, l) == eps(N + 1, N - l)
        assert kappa(N, l) >= 0 and lam(N, l) >= 0
        assert cell(N, l) == lam(N, l) + kappa(N, l)
        assert cell(N + 1, l) == kappa(N, l) + (lam(N, l - 1) if l >= 1 else 0)
        # 「전이 비」 항목의 좌표로: 셀 m_{N+1}(N-l), 열 감소분 c_{N+1}(N-l)
        assert cell(N, l) == m_def(N + 1, N - l)
        assert lam(N, l) == phi(N + 1, N - l) - phi(N + 2, N - l + 1)
        cnt += 1
print("(1) kappa_N(l) = eps_{N+1}(N-l) = J_{N+1}(l), m = lambda + kappa,",
      "m_N(l) = m_{N+1}(N-l), lambda_N(l) = c_{N+1}(N-l):", cnt, "칸 (N <= 15)")

# (2) 거꾸로 가는 전이 비 ---------------------------------------------------------

def phat(n, k):         # rb9ca4897…: n >= 2, 0 <= k <= n-1
    return flow(n, k) / cell(n, k)


cnt = 0
for n in range(1, 16):
    N = n + 1
    for k in range(0, n):
        r = n - k
        # 같은 분자: phat_{n+1}(k) Pr(M_{n+1}=k) = q_N(r) Pr(M_n=k)
        assert phat(n + 1, k) * cell(n + 1, k) == q_tr(N, r) * cell(n, k) == eps(N, r)
        cnt += 1
for n in range(2, 17):
    for k in range(0, n):
        ph = phat(n, k)
        assert 0 <= ph <= 1
        # r535d20f… 8.3절의 거꾸로 가는 비 p_N(r) = eps_N(r)/m_{N+1}(r+1), N = n, r = n-1-k
        assert ph == eps(n, n - 1 - k) / m_def(n + 1, n - k)
        # 열 감소분
        assert (1 - ph) * cell(n, k) == F(n - 1, k - 1) - F(n, k - 1)
# 관찰 R의 세 부등식 (정의를 옮긴 것이 맞는지 보는 작은 범위의 대조; 관찰 자체는 그 기록의 계산)
for n in range(2, 16):
    for k in range(0, n):
        assert phat(n + 1, k + 1) <= phat(n, k) <= phat(n + 1, k)      # (R1), (R3)
        if k + 1 <= n - 1:
            assert phat(n, k + 1) <= phat(n, k)                          # (R4)
print("(2) 거꾸로 가는 전이 비와 전이 비는 분자가 같다:", cnt, "칸; 0<=phat<=1, 열 감소분, (R1)(R3)(R4) (n <= 15)")

# (3) Euler 결함 ----------------------------------------------------------------

def P(y, N):            # rbc6a3c2f…: P_y(N) = Pr(M_{N-1} < y)
    return F(N - 1, y - 1)


cnt = 0
for N in range(2, 17):
    for y in range(1, N):
        U = Fr(N - y, N) * P(y + 1, N) + Fr(y, N) * P(y, N) - P(y + 1, N + 1)
        r = N - 1 - y
        if r >= 1:
            assert U == (Fr(r + 1, N) - q_tr(N, r)) * m_def(N, r)
            cnt += 1
print("(3) U_y(N) = ((r+1)/N - q_N(r)) m_N(r):", cnt, "칸 (N <= 16)")

# (4) 얻음·잃음과 얼린 다항식, 추측 (GL)의 반례 -----------------------------------

def padd(a, c):
    m = max(len(a), len(c))
    return [(a[i] if i < len(a) else 0) + (c[i] if i < len(c) else 0) for i in range(m)]


def pmul(a, c):
    r = [Fr(0)] * (len(a) + len(c) - 1)
    for i, x in enumerate(a):
        if x:
            for j, z in enumerate(c):
                r[i + j] += x * z
    return r


def pscale(a, s):
    return [x * s for x in a]


def peval(a, x):
    r = Fr(0)
    for c in reversed(a):
        r = r * x + c
    return r


def frozen(nmax, k):
    """K_{n,k}(y) = sum_F prod_{t_v>k} y/t_v, n <= nmax (가중한 마지막 차 재귀)."""
    Z = [[Fr(1)]]
    for n in range(1, nmax + 1):
        acc = [Fr(0)]
        for j in range(n):
            t = j + 1
            w = [Fr(1)] if t <= k else [Fr(0), Fr(1, t)]
            term = pscale(pmul(pmul(w, Z[j]), Z[n - 1 - j]), comb(n - 1, j) * t)
            acc = padd(acc, term)
        Z.append(acc)
    return Z


def Zthr(n, j):
    return Acum(n, j - 1) if j >= 1 else (1 if n == 0 else 0)


_frozen_cache = {}


def CB_minus(n, k):
    """(C_-(n,k), B_-(n,k))."""
    if k not in _frozen_cache or len(_frozen_cache[k]) <= n:
        _frozen_cache[k] = frozen(max(n, 2 * k + 2 if 2 * k + 2 <= NMAX else n), k)
    K = _frozen_cache[k][n]
    Cm = peval(K, k + 1) - 2 * peval(K, k) + peval(K, k - 1)
    Bm = peval(K, k - 1) - Zthr(n, k - 1)
    assert d(n, k) == Cm - Bm
    return Cm, Bm


def w_weight(N, j):     # rbc6a3c2f…: w_N(j) = C(N,j) j^{j-1} (N-j)^{N-j-1} / N^{N-1}
    return Fr(comb(N, j) * j ** (j - 1) * (N - j) ** (N - j - 1), N ** (N - 1))


_g_cache = {}


def g_fun(N, y):
    if N <= y:
        return Fr(0)
    key = (N, y)
    if key not in _g_cache:
        _g_cache[key] = w_weight(N, y) + sum(w_weight(N, j) * Fr(y - 1, j) * g_fun(j, y)
                                             for j in range(y + 1, N))
    return _g_cache[key]


def gain(N, y):
    return g_fun(N, y) / y


def loss(N, y):         # Loss = Gain - x_y(N), x_y(N) = -d_{N-1,y}/N^{N-2}
    return gain(N, y) + Fr(d(N - 1, y), N ** (N - 2))


cnt = 0
mismatch_at_2y = 0
for y in range(2, 9):
    for n in range(y + 1, 2 * y + 1):
        N = n + 1
        Cm, Bm = CB_minus(n, y)
        if n <= 2 * y - 1:
            assert p(n) * gain(N, y) == Bm and p(n) * loss(N, y) == Cm
            cnt += 1
        else:
            if p(n) * gain(N, y) != Bm:
                mismatch_at_2y += 1
assert mismatch_at_2y > 0
print("(4a) p_n Gain = B_-, p_n Loss = C_- (y+1 <= n <= 2y-1):", cnt, "자리; n = 2y에서는 어긋나는 열", mismatch_at_2y, "개 (y <= 8)")

C1, B1 = CB_minus(29, 15)
C2, B2 = CB_minus(30, 16)
assert d(29, 15) > 0                      # 행이 오르는 칸
assert C2 * B1 > C1 * B2                  # 대각 교차곱 C_-(n+1,k+1) B_-(n,k) <= C_-(n,k) B_-(n+1,k+1) 이 깨진다
# 한 행 앞의 같은 자리에서는 선다
C1a, B1a = CB_minus(28, 15)
C2a, B2a = CB_minus(29, 16)
assert C2a * B1a <= C1a * B2a
print("(4b) 대각 교차곱은 (n,k)=(29,15)에서 깨지고 (d_{29,15} > 0인 칸), (28,15)에서는 선다")

# (5) 뼈대의 계수와 전역 kappa_s(N) ------------------------------------------------

def a_coef(t):          # a_t = t^{t-1}/t!
    return Fr(t ** (t - 1), factorial(t))


def series_exp(S, deg):
    """exp(S(z)) mod z^{deg+1}; S[0] = 0."""
    E = [Fr(0)] * (deg + 1)
    E[0] = Fr(1)
    for n in range(1, deg + 1):
        E[n] = sum(Fr(i) * S[i] * E[n - i] for i in range(1, n + 1) if i < len(S)) / n
    return E


def kappa_skeleton(k, j):
    S = [Fr(0)] + [a_coef(t) for t in range(1, k + 1)]
    E = series_exp(S, j)
    return E[j - 1]      # [z^j] z e^{S_k(z)}


def kappa_global_times_exp(s, N):
    """e^{N} kappa_s(N) = a_N - sum_{i=s+1}^{N-1} a_i a_{N-i} (Bor(m) = e^{-m} a_m)."""
    return a_coef(N) - sum(a_coef(i) * a_coef(N - i) for i in range(s + 1, N))


cnt = 0
for k in range(1, 8):
    for j in range(1, k + 2):
        assert kappa_skeleton(k, j) == a_coef(j)
    for j in range(k + 1, 2 * k + 3):
        assert kappa_skeleton(k, j) == kappa_global_times_exp(k, j)
        cnt += 1
    assert kappa_skeleton(k, 2 * k + 3) != kappa_global_times_exp(k, 2 * k + 3)
assert kappa_skeleton(1, 5) == Fr(1, 24) and kappa_global_times_exp(1, 5) == Fr(-11, 24)
print("(5) 뼈대의 kappa_k(j) = e^j * 전역 kappa_k(j) (k+1 <= j <= 2k+2):", cnt, "칸; j = 2k+3에서 갈린다 (k <= 7)")

# (6) 노드 (D), (E)의 개수 꼴 ------------------------------------------------------

def rc(k):
    r = 1
    while r ** 3 <= k * k:
        r += 1
    return r


cnt = 0
for k in range(2, 15):
    x = Fr(k, k + 1) ** (k - 1)

    def n_mass(c, t):   # 기울인 나무 질량 n_c(t) = min(t,c) A_{t-1,c-1} x^t / t!
        return Fr(min(t, c) * Acum(t - 1, c - 1), factorial(t)) * x ** t

    for t in range(k + 1, 2 * k):
        DCT = n_mass(k + 1, t + 1) - 2 * n_mass(k, t) + n_mass(k - 1, t - 1)
        sigma = Fr(b(t - 1, k) + b(t - 1, k - 1), factorial(t)) * x ** t
        scale = Fr(factorial(t + 1)) / x ** (t - 1)
        lhs = (k + 1) * x * x * Acum(t, k) - 2 * k * (t + 1) * x * Acum(t - 1, k - 1) \
            + (k - 1) * t * (t + 1) * Acum(t - 2, k - 2)
        rhs = (t + 1) * x * (Acum(t - 1, k) - Acum(t - 1, k - 2))
        assert lhs == DCT * scale and rhs == sigma * scale
        assert lhs >= 0                                   # (D)의 꼴: 이 범위에서 선다
        if t >= k + rc(k) + 1:
            assert lhs <= rhs                             # (E)의 꼴: 곡선 앞의 첫 자리 다음부터
        cnt += 1
print("(6) (D), (E)의 개수 꼴 = DC^T(t), sigma_t 에 (t+1)!/x_k^{t-1}:", cnt, "칸 (2 <= k <= 14, k+1 <= t <= 2k-1)")
print("모든 대조가 맞았다.")
