# -*- coding: utf-8 -*-
"""조직화(묶음: 연구 개정 110-113)가 영역 설명과 용어 항목에 옮겨 적은 식과 수의 대조.

n <= 30의 정확한 유리수(와 tail이 드는 곳에서는 60자리 십진)로, 옮겨 적은 정의와 등식이
맞는지를 본다. 정리의 증명이 아니고, 기록의 계산을 다시 돌린 것도 아니다.
누적 개수 A_{n,k}는 마지막 차 재귀  n f_n = sum_{t=1}^{n} min(t,k+1) f_{t-1} f_{n-t}
(f_n = A_{n,k}/n!, f_0 = 1) 로 셈한다.

실행: python check_identities.py   (출력은 check_identities.out.txt 에 둔 것과 같아야 한다)
"""
from fractions import Fraction as Fr
from math import comb, factorial
from decimal import Decimal, getcontext
import io
import sys

getcontext().prec = 60
NMAX = 31
out = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
ok_all = True


def report(name, ok, extra=''):
    global ok_all
    ok_all = ok_all and bool(ok)
    out.write('%-4s %s %s\n' % ('OK' if ok else 'FAIL', name, extra))


# ---------- 누적 개수 A_{n,k} (0 <= n <= NMAX, 0 <= k) ----------
_f = {}


def fcol(k):
    if k not in _f:
        f = [Fr(1)]
        for n in range(1, NMAX + 1):
            f.append(sum(min(t, k + 1) * f[t - 1] * f[n - t] for t in range(1, n + 1)) / n)
        _f[k] = f
    return _f[k]


def A(n, k):
    if n == 0:
        return 1
    if k < 0:
        return 0
    k = min(k, n)            # 변위는 n-1 이하
    v = fcol(k)[n] * factorial(n)
    assert v.denominator == 1
    return v.numerator


def b(n, k):
    return A(n, k) - A(n, k - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


def p(n):
    return (n + 1) ** (n - 1) if n >= 1 else 1


# 0. 뿌리 파일의 확인용 값
rows = {1: [1], 2: [2, 1], 3: [6, 7, 3], 4: [24, 51, 34, 16], 5: [120, 421, 377, 253, 125],
        6: [720, 3963, 4594, 3688, 2546, 1296], 7: [5040, 42253, 62145, 57398, 46142, 32359, 16807]}
report('0. 뿌리 파일의 행 n<=7과 A_{n,n-1}=p_n (n<=31)',
       all([b(n, l) for l in range(n)] == r for n, r in rows.items()) and all(A(n, n - 1) == p(n) for n in range(1, NMAX + 1)))

# ---------- 1. 꼬리 곱수와 판정 (Z_t)  (rd60e0831/c-tail-criterion) ----------
E = Decimal(1).exp()


def Bor(m):
    return (Decimal(-m).exp()) * Decimal(m) ** (m - 1) / Decimal(factorial(m))


_tail = {1: Decimal(1)}
for m in range(2, 2 * NMAX + 5):
    _tail[m] = _tail[m - 1] - Bor(m - 1)


def tail(m):
    return _tail[m]


def zt_row(N):
    """행 N (N = n+1) 에서 판정 (Z_{t,N}) 과 단봉성을 본다. 돌려주는 것: (판정이 서는가, 단봉인가, r_1, 최소 비)."""
    n = N - 1
    u = {j: b(n, N - j) for j in range(2, N + 1)}
    u[N + 1] = 0
    r1 = min(r for r in range(2, N + 1) if u[r + 1] <= u[r])
    c = {2: Decimal(0)}
    for r in range(3, N + 1):
        c[r] = sum(tail(g) * Decimal(u[r - g]) for g in range(1, r - 1)) / Decimal(u[r])
    mu = {r: c[r] - c[r - 1] for r in range(3, N + 1)}
    good = True
    worst = None
    for r2 in range(r1 + 2, N + 1):
        lam = max(tail(l + r2 - r1 - 1) / tail(l) for l in range(1, r1))
        rhs = min(tail(r2 - r1 - 1), lam * mu[r1 + 1])
        ratio = mu[r2] / rhs
        worst = ratio if worst is None else min(worst, ratio)
        good = good and mu[r2] >= rhs
    row = [b(n, l) for l in range(n)]
    pk = row.index(max(row))
    unimodal = all(row[i] <= row[i + 1] for i in range(pk)) and all(row[i] >= row[i + 1] for i in range(pk, n - 1))
    return good, unimodal, r1, worst


res = {N: zt_row(N) for N in range(5, NMAX + 1)}
report('1a. (Z_{t,N})이 5<=N<=31의 모든 행에서 선다 (60자리 십진; 관찰)', all(v[0] for v in res.values()))
report('1b. 그 행들이 단봉이다 (명제 G의 결론과 맞는다)', all(v[1] for v in res.values()))
report('1c. N=31에서 좌변/우변의 최솟값이 1.0935 (기록의 값)', abs(res[31][3] - Decimal('1.0935')) < Decimal('0.00006'),
       '값 %.5f' % res[31][3])
# Lambda 의 닫힌 값: tail 이 로그볼록이어서 최댓값은 l = r_1 - 1 에서 난다
okL = True
for N in range(6, NMAX + 1):
    r1 = res[N][2]
    for r2 in range(r1 + 2, N + 1):
        lam = max(tail(l + r2 - r1 - 1) / tail(l) for l in range(1, r1))
        okL = okL and lam == tail(r2 - 2) / tail(r1 - 1)
report('1d. Λ(r_1,r_2)=tail(r_2−2)/tail(r_1−1) (6<=N<=31)', okL)
report('1e. tail이 로그볼록: tail(m)^2 <= tail(m−1)·tail(m+1) (2<=m<=60)',
       all(tail(m) ** 2 <= tail(m - 1) * tail(m + 1) for m in range(2, 61)))

# ---------- 2. 넘김 개수의 단일 사슬 식, 첫 어긋남, 한가운데 칸 (r5a5749f3) ----------


def U(n, y):
    return p(n) - A(n, y - 1)


def W(y, t):
    return t ** (t - 1) - min(t, y) * A(t - 1, y - 1)


def S(n, y):
    return sum(comb(n, t) * p(n - t) * W(y, t) for t in range(y + 1, n + 1))


ok2a = all(U(n, y) == S(n, y) for y in range(1, 15) for n in range(1, min(2 * y + 1, NMAX) + 1))
report('2a. U(n,y)=Σ_{t=y+1}^{n} C(n,t)·p_{n−t}·W_y(t) (n<=2y+1, y<=14, n<=31)', ok2a)
ok2b = all(S(2 * y + 2, y) - U(2 * y + 2, y) == comb(2 * y + 2, y + 1) * (y + 1) ** (2 * y - 2) // 2
           and comb(2 * y + 2, y + 1) % 2 == 0 for y in range(1, 15))
report('2b. n=2y+2에서의 어긋남이 (1/2)·C(2y+2,y+1)·(y+1)^{2y−2} (y<=14)', ok2b)
ok2c = all(d(n, c) == 2 * U(n, c) - U(n, c + 1) - U(n, c - 1) for c in range(2, 15) for n in range(c + 1, NMAX + 1))
report('2c. d_{n,c}=2U(n,c)−U(n,c+1)−U(n,c−1) (c>=2)', ok2c)
ok2d = all(d(2 * k, k) == 2 * S(2 * k, k) - S(2 * k, k + 1) - S(2 * k, k - 1) + comb(2 * k, k) * k ** (2 * k - 4) // 2
           for k in range(2, 16))
report('2d. d_{2k,k} = (단일 사슬 식을 한 행 더 읽은 값) + (1/2)·C(2k,k)·k^{2k−4} (2<=k<=15)', ok2d)
signs = [(k, d(2 * k, k)) for k in range(1, 16)]
report('2e. d_{2k,k}: k<=7에서 음, 8<=k<=15에서 양 (표의 값과 맞는다)',
       all(v < 0 for k, v in signs if k <= 7) and all(v > 0 for k, v in signs if k >= 8))
share10 = Fr(comb(20, 10) * 10 ** 16, 2) / d(20, 10)
report('2f. k=10에서 보정의 몫이 3.7%쯤', abs(float(share10) - 0.037) < 0.0006, '값 %.4f' % float(share10))

# 홀수 n의 (S_R)과 짝수 n에서 한가운데 걸음: n<=30에서 (S_R)의 쌍이 없다는 것과 d_{2k,k}의 부호의 관계


def sr_pair(n):
    lo = (n + 1) // 2
    return any(d(n, i) < 0 < d(n, j) for i in range(lo, n) for j in range(i + 1, n))


report('2g. n<=30에서 (S_R)의 쌍이 없다; 짝수 n=2k (k>=10)에서 d_{2k,k}>=0',
       not any(sr_pair(n) for n in range(1, 31)) and all(d(2 * k, k) >= 0 for k in range(10, 16)))

# ---------- 3. 교차 행 (r5a5749f3의 표의 처음과 기저 안의 열) ----------


def q0(k):
    for n in range(k + 1, NMAX + 1):
        if d(n, k) > 0:
            return n
    return None


z = [q0(k) - k - 1 for k in range(1, 9)]
report('3a. z(k)=q_0(k)−k−1 = 1,3,4,5,6,6,7,7 (k=1..8)', z == [1, 3, 4, 5, 6, 6, 7, 7], str(z))
qs = [q0(k) for k in range(1, 21)]
report('3b. 열 1..20의 교차 행이 기저 안에 있고 엄격히 증가하며 걸음이 1, 2, 3',
       all(v is not None for v in qs) and all(1 <= qs[i + 1] - qs[i] <= 3 for i in range(19)), str(qs))
report('3c. 열 8의 교차는 한가운데 칸 n=16이고 열 9부터는 n<=2k−1', q0(8) == 16 and all(q0(k) <= 2 * k - 1 for k in range(9, 21)))

# ---------- 4. (S_R)의 조립의 정수 부등식 (rebe4c3c5의 동료) ----------
ok4 = True
tight = None
for k in range(82, 125):
    r = 1
    while r ** 3 <= k * k:     # (r−1)^3 <= k^2 인 가장 큰 r
        r += 1
    ok4 = ok4 and 4 * r < k
    m = k - 4 * r
    if tight is None or m < tight[1]:
        tight = (k, m)
report('4. 82<=k<=124, (r−1)^3<=k^2 이면 4r<k; 가장 빠듯한 열은 83', ok4 and tight[0] == 83, '여유 최소 (k, k−4r)=%s' % (tight,))

# ---------- 5. (Base)_k 의 부호 (rb567ea70의 바로잡음) ----------


def bT(m, l):
    if l < 0:
        return 0
    return min(m, l + 1) * A(m - 1, l) - min(m, l) * A(m - 1, l - 1)


def base_min(k):
    rk = Fr(k + 1, k) ** (k - 1)
    xk = 1 / rk
    terms = {m: (bT(m, k) - rk * m * bT(m - 1, k - 1)) * xk ** m / factorial(m) for m in range(k + 1, 2 * k + 2)}
    suf = Fr(0)
    best = None
    longest = None
    for i in range(2 * k + 1, k, -1):
        suf += terms[i]
        best = suf if best is None else min(best, suf)
        longest = suf
    iota = Fr(p(k - 1)) * xk ** k / factorial(k)
    return best, longest / iota


vals = {k: base_min(k) for k in range(3, 15)}
report('5a. (Base)_k (n_0=2k+1): 3<=k<=11에서 서지 않고 12<=k<=14에서 선다 (2k+1<=29)',
       all(vals[k][0] < 0 for k in range(3, 12)) and all(vals[k][0] >= 0 for k in range(12, 15)))
report('5b. 가장 긴 접미합/ι: k=11에서 −0.0111, k=12에서 +0.0035',
       abs(float(vals[11][1]) + 0.0111) < 0.00006 and abs(float(vals[12][1]) - 0.0035) < 0.00006,
       '값 %.4f, %.4f' % (float(vals[11][1]), float(vals[12][1])))

# ---------- 6. 첫 층의 생존 확률의 닫힌 하계 (rd60e0831의 명제 J) ----------


def beta(N, g):
    return Fr(comb(N, g) * g ** (g - 1) * (N - g) ** (N - g - 1), N ** (N - 1))


def R(N, bb):
    return 1 - sum(beta(N, g) for g in range(1, bb))


ok6 = True
worst6 = None
for s in range(1, 31):
    for N in range(s + 1, min(2 * s + 2, NMAX) + 1):
        r = N - s
        lhs = Fr(A(N - 1, s - 1), p(N - 1))
        RN = R(N, r)
        rhs = Decimal(N) * (Decimal(RN.numerator) / Decimal(RN.denominator)) / (Decimal(r) + Decimal(s) * tail(r))
        l = Decimal(lhs.numerator) / Decimal(lhs.denominator)
        ok6 = ok6 and l >= rhs
        ratio = rhs / l
        worst6 = ratio if worst6 is None else min(worst6, ratio)
report('6. Pr(M_{N−1}<s) >= N·R_N(r)/(r+s·tail(r)) (s+1<=N<=2s+2, N<=31)', ok6, '하계/참값의 최솟값 %.3f' % worst6)

out.write('전체: %s\n' % ('모두 맞음' if ok_all else '어긋난 항목이 있음'))
out.flush()
sys.exit(0 if ok_all else 1)
