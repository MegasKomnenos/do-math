# -*- coding: utf-8 -*-
"""조직화의 대조 계산 (연구의 증거가 아니다).

용어를 묶거나 모듈 설명에 「같은 수」, 「같은 진술」이라고 적기 전에, 정의와 산술을 작은 크기에서
맞대어 본 것이다. 주차함수의 수가 드는 것은 모두 n ≤ 30의 정확한 표(인수인계 문서의 첫째 규칙의
기저) 안이고, 모든 산술은 정확한 유리수다. 실행:  python check_identities.py
"""
from fractions import Fraction as Fr
from math import comb, factorial
from itertools import product

NMAX = 30

# ---------------------------------------------------------------- 표: 마지막 차 재귀
# A[n][l] = #{길이 n의 주차함수: 최대 변위 <= l},  A_{0,l} = 1.
A = [[0] * (NMAX + 2) for _ in range(NMAX + 1)]
for l in range(NMAX + 2):
    A[0][l] = 1
for n in range(1, NMAX + 1):
    for l in range(NMAX + 2):
        A[n][l] = sum(comb(n - 1, j) * min(j + 1, l + 1) * A[j][l] * A[n - 1 - j][l] for j in range(n))


def Acum(n, l):
    if l < 0:
        return 1 if n == 0 else 0
    return A[n][min(l, NMAX + 1)]


def b(n, l):
    return Acum(n, l) - Acum(n, l - 1)


def p(n):
    return (n + 1) ** (n - 1) if n >= 1 else 1


def a(j):  # a_j = j^{j-1}/j!  (Borel 질량 항목의 tau_j, Cayley 계수 c_{j-1})
    return Fr(j ** (j - 1), factorial(j))


def PrLe(n, l):  # Pr(M_n <= l)
    return Fr(Acum(n, l), p(n))


def PrEq(n, l):
    return Fr(b(n, l), p(n))


results = []


def check(name, ok, detail=''):
    results.append((name, bool(ok), detail))
    print(('OK   ' if ok else 'FAIL ') + name + (' : ' + detail if detail else ''))


# 0. 표가 뿌리 명제의 확인용 값과 맞는가
root_rows = {1: [1], 2: [2, 1], 3: [6, 7, 3], 4: [24, 51, 34, 16], 5: [120, 421, 377, 253, 125],
             6: [720, 3963, 4594, 3688, 2546, 1296], 7: [5040, 42253, 62145, 57398, 46142, 32359, 16807]}
check('0. 뿌리 명제의 확인용 값', all([b(n, l) for l in range(n)] == row for n, row in root_rows.items())
      and all(Acum(n, n - 1) == p(n) for n in range(1, NMAX + 1)))


# ---------------------------------------------------------------- 1. 첫 간격 무게의 이름들
def beta(N, g):  # r535d20f: beta_N(g) = Bor(g)Bor(N-g)/Bor(N)   (지수 인자는 약분된다)
    return a(g) * a(N - g) / a(N)


ok = True
for N in range(2, 31):
    for g in range(1, N):
        v = beta(N, g)
        ok &= v == Fr(comb(N, g) * g ** (g - 1) * (N - g) ** (N - g - 1), N ** (N - 1))        # r535d20f의 둘째 꼴
        ok &= v == beta(N, N - g)                                                              # 대칭
        n, t = N - 1, g                                                                        # [n] 위의 균등한 숲에서 크기 t인 나무의 기대 개수
        ok &= v == Fr(comb(n, t) * t ** (t - 1) * p(n - t), p(n))                              # r6c69820c, r425e458e, r7514f8ae의 pi
    ok &= sum(beta(N, g) for g in range(1, N)) == Fr(2 * (N - 1), N)
check('1. beta_N(g) = q_L(i) = w^N_D = q_N(g) = C(n,t)t^{t-1}p_{n-t}/p_n (N=n+1), 합 2(N-1)/N', ok)


# ---------------------------------------------------------------- 2. 첫 간격의 생존과 그 이름들
def R(N, bb):  # r5050c217: R_N(b) = 1 - sum_{g<b} beta_N(g)
    return 1 - sum(beta(N, g) for g in range(1, bb))


def kappa_skeleton(k, jmax):  # 전역 「뼈대, 덤불, 계수 kappa_k」: kappa_k(j) = [z^j] z e^{S_k(z)}
    S = [Fr(0)] + [a(t) if t <= k else Fr(0) for t in range(1, jmax + 1)]
    E = [Fr(0)] * (jmax + 1)
    E[0] = Fr(1)
    for m in range(1, jmax + 1):  # E' = S' E
        E[m] = sum(i * S[i] * E[m - i] for i in range(1, m + 1)) / m
    return [Fr(0)] + [E[j - 1] for j in range(1, jmax + 1)]


ok_in, bad_out, prob_ok = True, 0, True
for k in range(1, 30):
    ks = kappa_skeleton(k, 31)
    for N in range(2, 31):
        bb = N - k
        if bb < 1:
            continue
        lhs, rhs = R(N, bb), ks[N] / a(N)
        if 2 * bb <= N + 2:
            ok_in &= lhs == rhs
        elif lhs != rhs:
            bad_out += 1
        prob_ok &= 0 < rhs <= 1
check('2a. R_N(b) = kappa_{N-b}(N)/a_N  (b <= (N+2)/2)', ok_in, '범위 밖에서 다른 칸 %d개' % bad_out)
check('2b. kappa_k(j)/a_j 는 언제나 (0,1] 안', prob_ok)
check('2c. R_5(4) = -11/125 (b >= (N+3)/2 에서는 확률이 아니다), R_N(N) = (2-N)/N',
      R(5, 4) == Fr(-11, 125) and all(R(N, N) == Fr(2 - N, N) for N in range(2, 20)))
ok = True
for N in range(2, 31):
    for s in range(1, N):  # 전역 「생존 질량, 질량 셀, 셀의 열」: kappa_s(N) e^N = a_N - sum_{i=s+1}^{N-1} a_i a_{N-i}
        ok &= a(N) - sum(a(i) * a(N - i) for i in range(s + 1, N)) == a(N) * R(N, N - s)
    for bb in range(1, (N + 1) // 2 + 1):  # 꼬리 합
        ok &= R(N, bb) == Fr(1, N) + sum((beta(N, g) for g in range(bb, N - bb + 1)), Fr(0)) / 2
check('2d. kappa_s(N) = Bor(N) R_N(N-s) (모든 s),  R_N(b) = 1/N + (1/2) sum_{g=b}^{N-b} beta_N(g) (b <= (N+1)/2)', ok)
ok = True
for y in range(1, 13):
    for bb in range(1, y + 3):  # rc31497의 바닥 인자, r425e458e의 omega_z(b), r535d20f의 R_N(r)
        lam = a(y + bb) - sum(a(g) * a(y + bb - g) for g in range(1, bb))
        ok &= lam == a(y + bb) * R(y + bb, bb)
check('2e. lambda_b(y) = a_{y+b} R_{y+b}(b)  (1 <= b <= y+2)', ok)


# ---------------------------------------------------------------- 3. 나무의 넘김 확률과 (DI)
def v(j, s):  # re8460c2: v_j(s) = 1 - (j/s) Pr(M_{s-1} < j)  (s >= j), 0 (s <= j)
    if s <= j:
        return Fr(0)
    return 1 - Fr(j, s) * PrLe(s - 1, j - 1)


def alpha(j, s):  # 넘김 증분
    return v(j, s) - v(j, s - 1)


ok_di, eq_only_first, top_ok, ok_cum = True, True, True, True
for k in range(3, 15):
    for s in range(k + 1, 2 * k + 3):
        if s - 1 > NMAX:
            continue
        lhs, rhs = alpha(k - 1, s - 1), Fr(k + 1, k) * alpha(k, s)
        ok_di &= lhs <= rhs
        eq_only_first &= (lhs == rhs) == (s == k + 1)
        if s == 2 * k + 2:
            top_ok &= lhs < rhs
        x = s - k  # r5050c217의 결손 좌표: e_k(x) = v_k(k+x), 𝔡_k(x) = (k+1)alpha_k(x) - k alpha_{k-1}(x)
        ok_di &= ((k + 1) * alpha(k, k + x) - k * alpha(k - 1, k - 1 + x) >= 0) == (lhs <= rhs)
    for Rr in range(1, k + 2):  # rb631a853 정리 9.5 (누적 꼴), j = k
        if k + Rr - 1 > NMAX:
            continue
        ok_cum &= (k + 1) * v(k, k + Rr) - k * v(k - 1, k - 1 + Rr) >= Fr(Rr * (Rr - 1), (k + Rr) * (k + Rr - 1))
check('3a. (DI): alpha^{(k-1)}_{s-1} <= (1+1/k) alpha^{(k)}_s, 3<=k<=14, k+1<=s<=2k+2; 세 좌표의 진술이 같다', ok_di)
check('3b. (DI)의 등호는 s = k+1 뿐, 꼭대기 칸 s = 2k+2 에서 엄격', eq_only_first and top_ok)
check('3c. 누적 꼴 (rb631a853 정리 9.5), 3<=j<=14, 1<=R<=j+1', ok_cum)

# ---------------------------------------------------------------- 4. Euler 결함, 전이 비, 준승법성
ok_u, ok_q, ok_first = True, True, True
for y in range(1, 29):
    for N in range(y + 1, 30):
        P = lambda yy, NN: PrLe(NN - 1, yy - 1)
        U = Fr(N - y, N) * P(y + 1, N) + Fr(y, N) * P(y, N) - P(y + 1, N + 1)
        ok_u &= U >= 0
        n, r = N - 1, N - 1 - y
        if r >= 1:  # 전이 비 q_N(r)은 1 <= r <= N-1 에서 정의된다
            kk = n - r
            m = PrEq(n, kk)
            q = (PrLe(n + 1, kk) - PrLe(n, kk - 1)) / m
            ok_q &= U == (Fr(r + 1, N) - q) * m and 0 <= q <= Fr(r + 1, N)
        if N <= 2 * y + 2:  # r5050c217 정리 A의 여유
            ok_first &= U >= v(y + 1, N) / (N * (N + 1))
check('4a. U_y(N) >= 0 (y+1 <= N <= 29), U_y(N) = ((r+1)/N - q_N(r)) m_N(r)', ok_u and ok_q)
check('4b. 첫 층 y+1 <= N <= 2y+2 에서 U_y(N) >= v_{y+1}(N)/(N(N+1))', ok_first)
ok = all(PrLe(x + z, y) <= PrLe(x, y) * PrLe(z, y) for y in range(0, 30) for x in range(0, 31) for z in range(0, 31 - x))
check('4c. Pr(M_{a+b} <= y) <= Pr(M_a <= y) Pr(M_b <= y)  (a+b <= 30)', ok)


# ---------------------------------------------------------------- 5. 가장 낮은 달성 꼭짓점으로 가른 셀, 섞은 짝
def Lam(m, y, Q, memo={}):  # r7514f8ae: 사슬 합 Lambda_m(y;Q), Lambda_0 = 1
    if m == 0:
        return Fr(1)
    key = (m, y, Q)
    if key not in memo:
        tot = a(m)
        for g in range(1, m):
            tot += a(g) * Fr(y, Q - g) * Lam(m - g, y, Q - g)
        memo[key] = tot
    return memo[key]


def cal_L(n, sig, y):  # 달성 밀도 L_n(sigma;y) = (a_sigma/sigma) Lambda_{N-sigma}(y;N)
    return a(sig) / sig * Lam(n + 1 - sig, y, n + 1)


def Asplit(n, k, s):  # A_s(n,k) = (n!/p_n) L_n(s;k+1) Pr(M_{s-1} < k)
    return Fr(factorial(n), p(n)) * cal_L(n, s, k + 1) * PrLe(s - 1, k - 1)


ok_A, sharp, ok_mix, ok_E2 = True, True, True, True
for k in range(1, 12):
    for n in range(k + 1, min(2 * k + 2, 24) + 1):
        tot = sum(Asplit(n, k, s) for s in range(k + 1, n + 1))
        if n <= 2 * k + 1:
            ok_A &= tot == PrEq(n, k)
        else:
            sharp &= tot > PrEq(n, k)
    for n in range(k + 1, min(2 * k, 22) + 1):
        if k < 2:
            continue
        d = PrEq(n, k) - PrEq(n, k - 1)
        As = {s: Asplit(n, k, s) for s in range(k + 1, n + 1)}
        Bs = {s: Asplit(n, k - 1, s) for s in range(k, n + 1)}
        E2 = Fr(comb(2 * k, k) * k ** (2 * k - 2), 2 * p(2 * k) * k * k) if n == 2 * k else 0
        for s0 in range(k, n + 1):
            rhs = sum(As[s] - Bs[s] for s in range(s0 + 1, n + 1)) + sum(As[s] - Bs[s - 1] for s in range(k + 1, s0 + 1)) - Bs[s0] + E2
            ok_mix &= rhs == d
        if n == 2 * k:
            ok_E2 &= sum(Bs.values()) - E2 == PrEq(n, k - 1)
check('5a. 보조정리 A: Pr(M_n=k) = sum_s A_s  (n <= 2k+1), n = 2k+2 에서는 합이 더 크다', ok_A and sharp)
check('5b. 섞은 짝의 항등식 (모든 전환점 s_0; n <= 2k-1, n = 2k 에서는 E_2 를 더한다)', ok_mix and ok_E2)


# ---------------------------------------------------------------- 6. 손실, 경계항, (LD)와 (Z_d)
def Zpoly(n, k):  # K_{n,k}(y): 무게 g(t) = 1 (t <= k), y/t (t > k) 의 Z_n[g]  (y의 다항식, 계수 리스트)
    Z = [[Fr(1)]]
    for m in range(1, n + 1):
        acc = [Fr(0)] * (m + 1)
        for j in range(m):
            t = j + 1
            c = comb(m - 1, j)
            w = [Fr(c * t)] if t <= k else [Fr(0), Fr(c)]  # (j+1) g(j+1)
            for i1, c1 in enumerate(Z[j]):
                for i2, c2 in enumerate(Z[m - 1 - j]):
                    for i3, c3 in enumerate(w):
                        acc[i1 + i2 + i3] += c1 * c2 * c3
        while len(acc) > 1 and acc[-1] == 0:
            acc.pop()
        Z.append(acc)
    return Z[n]


def ev(poly, y):
    return sum(c * Fr(y) ** i for i, c in enumerate(poly))


ok_piece, ok_V, ok_L, ok_B, ok_Zd, viol = True, True, True, True, True, []
for n in range(3, 17):
    for k in range(1, n):
        K = Zpoly(n, k)
        ok_piece &= ev(K, k) == Acum(n, k - 1) and ev(K, k + 1) == Acum(n, k)   # 조각이 Z_n 과 [k,k+1] 의 두 끝에서 맞는다
        Cm = ev(K, k + 1) - 2 * ev(K, k) + ev(K, k - 1)
        Bm = ev(K, k - 1) - Acum(n, k - 2)
        ok_piece &= Cm - Bm == b(n, k) - b(n, k - 1)                              # d = C_- - B_-
        if k + 1 <= n <= 2 * k:                                                   # 손실 L_{n,k} = Z'(k-) - Z'(k+) = n! L_n(k;k)
            Kprev = Zpoly(n, k - 1)
            dK = lambda P_, y: sum(i * c * Fr(y) ** (i - 1) for i, c in enumerate(P_) if i)
            loss = dK(Kprev, k) - dK(K, k)
            ok_L &= loss == factorial(n) * cal_L(n, k, k)
            if n <= 2 * k - 1 and k >= 2:                                          # s_0 = k 의 섞은 짝 = V - L
                ok_V &= Fr(loss, p(n)) == Asplit(n, k - 1, k)
        if k >= 3 and k + 2 <= n <= 2 * k - 1:                                    # 첫 층: B_-(n,k) = n! L_n(k;k-1)
            ok_B &= Bm == factorial(n) * cal_L(n, k, k - 1)
for n in range(5, 17):
    for kp in range(3, n - 1):  # (Z_d)_{n,k'}: B_-(n,k'+1) > B_-(n,k')
        if not (kp + 2 <= n <= 2 * kp - 2):
            continue
        Bm0 = ev(Zpoly(n, kp), kp - 1) - Acum(n, kp - 2)
        Bm1 = ev(Zpoly(n, kp + 1), kp) - Acum(n, kp - 1)
        zd = Bm1 > Bm0
        k_, s_ = kp - 1, kp + 1  # (LD)_{n,k,s} 의 엄격한 꼴, 여유 s-k = 2
        ld = cal_L(n, s_, k_ + 1) > cal_L(n, s_ - 1, k_)
        ok_Zd &= zd == ld
        if not zd:
            viol.append((n, kp))
check('6a. 얼린 다항식 조각과 d = C_- - B_-  (n <= 16)', ok_piece)
check('6b. 손실 L_{n,k} = n! L_n(k;k) (k+1 <= n <= 2k),  p_n B_k = L_{n,k} (n <= 2k-1)', ok_L and ok_V)
check('6c. 첫 층에서 B_-(n,k) = n! L_n(k;k-1)', ok_B)
check('6d. (Z_d)_{n,k\'} <=> (LD)_{n,k\'-1,k\'+1} 의 엄격한 꼴  (k\'+2 <= n <= 2k\'-2, n <= 16)', ok_Zd,
      '그 범위에서 (Z_d)가 깨지는 (n,k\'): ' + str(viol))

# ---------------------------------------------------------------- 7. (L)에 남은 자리의 산술
k0, k1 = 160, 10 ** 8 - 1
check('7. 남은 자리 160 <= k <= 10^8-1, 2k+3 <= n <= 2k(k+1)-1: 가장 큰 행은 N_* - 1 보다 작다',
      2 * k1 * (k1 + 1) - 1 < 2 * 10 ** 8 * (10 ** 8 + 1) and 2 * k0 + 3 == 323)

# ---------------------------------------------------------------- 8. 첫 간격의 전이 구조 (r5050c217)
# Pi_N(m) = sum_{g<=m} beta_N(g),  Gamma_N(m) = (N-1)[Pi_{N-1}(m) - Pi_N(m)],
# 머무는 몫 k_N(m) = Pi_N(m) - Pi_{N-1}(m-1),  G_N(m) = m beta_{N-1}(m) - Gamma_N(m).
def Pi(N, m):
    return sum((beta(N, g) for g in range(1, m + 1)), Fr(0))


ok_split = ok_sign = ok_mono = ok_euler = ok_eq = True
for N in range(3, 41):
    for m in range(1, N - 1):
        Gam = (N - 1) * (Pi(N - 1, m) - Pi(N, m))
        Gam_prev = (N - 1) * (Pi(N - 1, m - 1) - Pi(N, m - 1))
        stay = Pi(N, m) - Pi(N - 1, m - 1)
        ok_split &= beta(N - 1, m) == stay + Gam / (N - 1) and beta(N, m) == stay + Gam_prev / (N - 1)
        ok_sign &= Gam >= 0 and stay > 0
        if m <= N - 3:
            ok_mono &= stay >= Pi(N, m + 1) - Pi(N - 1, m)
        if 2 * m <= N - 1:
            G = m * beta(N - 1, m) - Gam
            ok_euler &= G >= Fr(1, N)
            ok_eq &= (G == Fr(1, N)) == (N % 2 == 1 and 2 * m == N - 1)
check('8. 첫 간격의 전이 구조 (3 <= N <= 40): beta_{N-1}(m) = 머무는 몫 + 옮겨 가는 몫, beta_N(m) = 머무는 몫 + 옮겨 온 몫; '
      '두 몫의 부호, 머무는 몫의 단조성, G_N(m) >= 1/N (등호는 N 홀수, m = (N-1)/2 뿐)',
      ok_split and ok_sign and ok_mono and ok_euler and ok_eq)

# ---------------------------------------------------------------- 9. (LD)가 작은 n에서 깨지는 자리
# (LD)_{n,k,s}: L_n(s;k+1) >= L_n(s-1;k).  사슬 합만 드는 계산이고 주차함수의 표를 쓰지 않는다.
# r7514f8ae 4.7절의 보고와 맞대어 정의를 옮겨 적은 것을 확인한다:
#   3 <= n <= 40 의 모든 행에 위반이 있고 위반은 모두 여유 s-k <= 2,
#   n <= 2k-1 로 제한하면 2660칸 가운데 124칸.
cells = viol_cells = 0
rows_with_viol = set()
margin_ok = True
for n in range(3, 41):
    for k in range(1, n):
        if n > 2 * k:
            continue
        for s in range(k + 1, n + 1):
            bad_cell = cal_L(n, s, k + 1) < cal_L(n, s - 1, k)
            if bad_cell:
                rows_with_viol.add(n)
                margin_ok &= s - k <= 2
            if n <= 2 * k - 1:
                cells += 1
                viol_cells += bad_cell
check('9. (LD)_{n,k,s} (3 <= n <= 40, n <= 2k): 모든 행에 위반, 위반은 모두 여유 s-k <= 2',
      rows_with_viol == set(range(3, 41)) and margin_ok,
      'n <= 2k-1 의 %d칸 가운데 위반 %d칸 (기록의 보고: 2660칸 가운데 124칸)' % (cells, viol_cells))

print()
bad = [r for r in results if not r[1]]
print('%d개 가운데 %d개 맞음' % (len(results), len(results) - len(bad)))
if bad:
    raise SystemExit(1)
