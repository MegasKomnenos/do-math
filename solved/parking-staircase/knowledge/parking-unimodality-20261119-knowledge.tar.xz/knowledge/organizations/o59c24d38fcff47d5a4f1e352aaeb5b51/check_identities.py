# -*- coding: utf-8 -*-
"""
이 조직화(areas-r76)의 용어 항목과 자세한 서술이 옮겨 적은 대응을 작은 정확한 경우에서 대조한다.

무엇을 위한 것인가. 조직화는 새 수학을 내놓지 않는다. 다만 기록마다 다른 이름과 좌표로 적힌
같은 대상을 한 항목에 모아 적을 때, 첨자 하나가 어긋나면 그 항목이 거짓이 된다. 이 스크립트는
내가 옮겨 적은 등식과 범위가 n<=30의 정확한 수에서 실제로 맞는지를 본다. 어느 정리의 근거도
아니고, 범위를 넓히는 계산도 아니다(행 n<=30, 다항식은 n<=16).

쓰는 것: 유리수 산술만. 마지막 차 재귀로 누적 개수 A_{n,k}를 만들고, 숲의 무게 재귀로
실수 문턱의 Z_n(y)와 얼린 다항식 K_{n,j}(y)를 만든다. 두 재귀가 정수 문턱에서 같은 수를 주는지부터 본다.
"""
from fractions import Fraction as Fr
from math import comb, factorial
import itertools
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

NMAX = 31      # 표의 행 (n<=30과 대각 걸음용 한 행)
NPOLY = 16     # 얼린 다항식을 만드는 행의 끝
results = []


def report(tag, ok, detail=""):
    results.append((tag, ok))
    print(("[맞음] " if ok else "[어긋남] ") + tag + ((" — " + detail) if detail else ""))


# ---------------------------------------------------------------- 표
def cumulative_table(nmax):
    """A[k][n] = 최대 변위가 k 이하인 길이 n의 주차함수의 수 (마지막 차 재귀)."""
    A = {}
    for k in range(0, nmax + 1):
        row = [1]
        for n in range(1, nmax + 1):
            s = 0
            for j in range(1, n + 1):
                s += comb(n - 1, j - 1) * min(j, k + 1) * row[j - 1] * row[n - j]
            row.append(s)
        A[k] = row
    return A


A = cumulative_table(NMAX)


def Acum(n, k):
    if k < 0:
        return 0
    if k >= n:
        k = max(n - 1, 0)
    return A[k][n]


def p(n):
    return (n + 1) ** (n - 1) if n >= 1 else 1


def b(n, k):
    return Acum(n, k) - Acum(n, k - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


report("p_n=(n+1)^(n-1)=A_{n,n-1} (1<=n<=31)", all(Acum(n, n - 1) == p(n) for n in range(1, NMAX + 1)))


# ---------------------------------------------------------------- 숲의 재귀
def Z_values(y, nmax):
    """Z_n(y)=sum_F prod_v min(1,y/t_v), n=0..nmax (y>0 유리수)."""
    Z = [Fr(1)]
    tau = [None]
    for n in range(1, nmax + 1):
        tau.append(n * min(Fr(1), Fr(y) / n) * Z[n - 1])
        Z.append(sum(comb(n - 1, t - 1) * tau[t] * Z[n - t] for t in range(1, n + 1)))
    return Z


ok = True
for k in range(1, 31):
    Zk = Z_values(k, 30)
    for n in range(1, 31):
        if Zk[n] != Acum(n, k - 1):
            ok = False
report("Z_n(k)=A_{n,k-1} (정수 문턱; 1<=n,k<=30) — 숲의 재귀와 마지막 차 재귀가 같은 수를 준다", ok)


def brute_Z(n, y):
    """[n] 위의 뿌리 숲을 모두 세어 Z_n(y)를 직접 더한다 (n<=5)."""
    total = Fr(0)
    for par in itertools.product(range(0, n + 1), repeat=n):
        good = True
        for v in range(1, n + 1):
            if par[v - 1] == v:
                good = False
                break
        if not good:
            continue
        # 순환이 없는지
        depth_ok = True
        for v in range(1, n + 1):
            u, steps = v, 0
            while u != 0 and steps <= n:
                u = par[u - 1]
                steps += 1
            if u != 0:
                depth_ok = False
                break
        if not depth_ok:
            continue
        size = [0] * (n + 1)
        for v in range(1, n + 1):
            u = v
            while u != 0:
                size[u] += 1
                u = par[u - 1]
        w = Fr(1)
        for v in range(1, n + 1):
            w *= min(Fr(1), Fr(y) / size[v])
        total += w
    return total


ok = True
for n in range(1, 6):
    for y in (Fr(1, 2), Fr(3, 2), Fr(7, 3), Fr(5, 2), Fr(19, 5)):
        if brute_Z(n, y) != Z_values(y, n)[n]:
            ok = False
report("실수 문턱의 Z_n(y): 숲을 모두 센 값과 재귀의 값 (n<=5, 정수가 아닌 문턱 다섯)", ok)


# ---------------------------------------------------------------- (1) 흐름과 전이 비
def s_surv(n, c):
    """s_n(c)=Pr(M_n<c)."""
    if n == 0:
        return Fr(1) if c >= 1 else Fr(0)
    return Fr(Acum(n, c - 1), p(n))


def stay(n, k):      # 머무는 흐름  ς_n(k)
    return s_surv(n + 1, k + 1) - s_surv(n, k)


def up(n, c):        # 올라가는 흐름 λ_n(c)
    return s_surv(n, c) - s_surv(n + 1, c)


def cell(n, k):
    return Fr(b(n, k), p(n))


ok_eps = ok_c = ok_cells = ok_q = ok_wave = ok_sum = True
for N in range(2, 31):
    n = N - 1
    for r in range(1, N):
        k = n - r
        if k < 0:
            continue
        eps = Fr(Acum(n + 1, k), p(n + 1)) - (Fr(Acum(n, k - 1), p(n)))      # 전역 항목의 분자
        cN = cell(n, k) - eps                                                  # 열 감소분
        if stay(n, k) != eps:
            ok_eps = False
        if up(n, k + 1) != cN:
            ok_c = False
        if cell(n, k) != stay(n, k) + up(n, k + 1) or cell(n + 1, k) != stay(n, k) + up(n, k):
            ok_cells = False
        if not (0 <= eps <= cell(n, k)):
            ok_q = False
for n in range(2, 30):
    for k in range(1, n):
        C_br = s_surv(n - 1, k) - 2 * s_surv(n, k) + s_surv(n + 1, k)
        W_br = s_surv(n, k + 1) + s_surv(n, k - 1) - s_surv(n - 1, k) - s_surv(n + 1, k)
        if W_br != stay(n - 1, k) - stay(n, k - 1):
            ok_wave = False
        if Fr(d(n, k), p(n)) != C_br + W_br:
            ok_sum = False
report("머무는 흐름 ς_n(k)=ε_N(r) (N=n+1, r=n-k; 전역 「전이 비」의 대각 증분), 2<=N<=30", ok_eps)
report("올라가는 흐름 λ_n(k+1)=c_N(r) (열 감소분), 2<=N<=30", ok_c)
report("셀의 두 가름 π_n(k)=ς_n(k)+λ_n(k+1), π_{n+1}(k)=ς_n(k)+λ_n(k)", ok_cells)
report("0<=ε_N(r)<=m_N(r) (전이 비가 0과 1 사이; 표의 범위)", ok_q)
report("파동 괄호 W_{n,k}=ς_{n-1}(k)-ς_n(k-1), 2<=n<=29", ok_wave)
report("d_{n,k}/p_n = 크기 괄호 + 파동 괄호, 2<=n<=29", ok_sum)

# (L1°), (L2°)가 표에서 어떻게 보이는지 (정보)
neg_W = [(n, k) for n in range(3, 30) for k in range(1, n)
         if n >= 2 * k + 1 and (s_surv(n, k + 1) + s_surv(n, k - 1) - s_surv(n - 1, k) - s_surv(n + 1, k)) < 0]
print("   [정보] n>=2k+1, n<=29에서 파동 괄호가 음인 자리의 수:", len(neg_W),
      "| 그 가운데 k>=12인 것:", len([1 for (n, k) in neg_W if k >= 12]),
      "(노드 (L2°)의 범위는 k>=12, n>=max(2k+1,41)이어서 이 표의 행은 모두 그 범위 밖이다)")


# ---------------------------------------------------------------- (2) 사슬 합과 첫 층의 응답 꼴
def a_(j):
    return Fr(j ** (j - 1), factorial(j))


def chain_sum(m, y, N):
    """Λ_m(y;N): m의 합성에 걸친 합, 토막마다 a_γ, 자르는 점 s마다 y/(N-s)."""
    u = [Fr(1)]
    L = None
    for i in range(1, m + 1):
        L = sum(u[s] * a_(i - s) for s in range(0, i))
        if i < m:
            u.append(Fr(y) / (N - i) * L)
    return L


def impulse(k, n, y=None):
    """충격 응답 ι_k(n)=λ_k Λ_{n-k+1}(k+1;n+1); y를 주면 충격의 족 ι^{(y)}."""
    if y is None:
        y = k + 1
    return a_(k) / k * chain_sum(n - k + 1, y, n + 1)


def source(k, n):
    """원천 응답 X_k(n)=2 sum_{j=k}^{n-1} Λ_{n-j}(k+1;n+1) b_{j,k-1}/(j+1)!."""
    return 2 * sum(chain_sum(n - j, k + 1, n + 1) * Fr(b(j, k - 1), factorial(j + 1)) for j in range(k, n))


holds, fails = [], []
for k in range(2, 13):
    for n in range(k, min(2 * k + 3, 31)):
        lhs = Fr(d(n, k)) if n > k else Fr(-p(k - 1))
        rhs = factorial(n) * (source(k, n) - impulse(k, n))
        (holds if lhs == rhs else fails).append((n, k))
in_layer = all(((n, k) in holds) for k in range(2, 13) for n in range(k, 2 * k) if n <= 30)
outside = sorted(set(n - 2 * k for (n, k) in fails))
report("첫 층의 응답 꼴 d_{n,k}=n!(X_k(n)-ι_k(n)), k<=n<=2k-1 (2<=k<=12; n=k에서는 d_{k,k}:=-p_{k-1})",
       in_layer and all(n >= 2 * k for (n, k) in fails),
       "어긋나는 자리의 n-2k: %s (n>=2k에서만 어긋난다)" % outside)

# 생존 꼴 (r42f1242 명제 4): X_k(n)=2 sum_l V_l A_{n+1-l}
ok = True
for k in range(2, 12):
    for n in range(k + 1, 2 * k):
        N = n + 1
        val = 2 * sum(Fr(Acum(l - 1, k - 2), factorial(l)) *
                      (chain_sum(N - l, k + 1, N) - chain_sum(N - l, k, N)) for l in range(k, n))
        if val != source(k, n):
            ok = False
report("생존 꼴의 원천 X_k(n)=2 Σ_{l=k}^{n-1} V_l·𝒜_{n+1-l}, V_l=A_{l-1,k-2}/l! (k+1<=n<=2k-1, 2<=k<=11)", ok)

# r9faef2b6의 충격의 응답 J_n = x_k^n ι_k(n)
ok = True
for k in range(3, 12):
    x = Fr(k, k + 1) ** (k - 1)

    def tau(g):
        return x ** g * Fr(g ** (g - 1), factorial(g))

    def omega(s):
        return x ** s * Fr((s + 1) ** (s - 1), factorial(s))

    J = {}
    for n in range(k, 2 * k):
        J[n] = tau(n - k + 1) * omega(k - 1) / k + (k + 1) * sum(tau(n - s) * J[s] / (s + 1) for s in range(k, n))
        if J[n] != x ** n * impulse(k, n):
            ok = False
report("r9faef2b6의 「충격의 응답」 𝖩_n = x_k^n·ι_k(n) (k<=n<=2k-1, 3<=k<=11)", ok)


# ---------------------------------------------------------------- (3) 얼린 다항식과 세 분해의 빼는 항
def poly_mul(P, Q):
    R = [0] * (len(P) + len(Q) - 1)
    for i, x in enumerate(P):
        if x == 0:
            continue
        for j, y in enumerate(Q):
            R[i + j] += x * y
    return R


def poly_add(P, Q):
    n = max(len(P), len(Q))
    return [(P[i] if i < len(P) else 0) + (Q[i] if i < len(Q) else 0) for i in range(n)]


def poly_eval(P, y):
    v = Fr(0)
    for c in reversed(P):
        v = v * y + c
    return v


def poly_der(P):
    return [i * c for i, c in enumerate(P)][1:] or [0]


def frozen_polys(j, nmax):
    """K_{n,j}(y)=sum_F prod_{t_v>j} y/t_v 의 계수 (n=0..nmax). 계수는 정수다."""
    Z = [[1]]
    tau = [None]
    for n in range(1, nmax + 1):
        tau.append([n * c for c in Z[n - 1]] if n <= j else [0] + Z[n - 1])
        acc = [0]
        for t in range(1, n + 1):
            acc = poly_add(acc, [comb(n - 1, t - 1) * c for c in poly_mul(tau[t], Z[n - t])])
        Z.append(acc)
    return Z


K = {j: frozen_polys(j, NPOLY) for j in range(0, NPOLY + 1)}


def Zn(n, y):
    if y <= 0:
        return Fr(0)
    if y >= n:
        return Fr(p(n))
    return Z_values(y, n)[n]


ok_dec = True
rng = {"B+": [], "C+": [], "B-": [], "L": []}
bad = {"B+": [], "C+": [], "B-": [], "L": []}
ok_pair = True
for n in range(3, NPOLY + 1):
    for k in range(2, n):
        Kk, Km = K[k][n], K[k - 1][n]
        C_minus = poly_eval(Kk, k + 1) - 2 * poly_eval(Kk, k) + poly_eval(Kk, k - 1)
        B_minus = poly_eval(Kk, k - 1) - Acum(n, k - 2)
        C_plus = poly_eval(Km, k + 1) - 2 * poly_eval(Km, k) + poly_eval(Km, k - 1)      # C_+(n,k-1)
        B_plus = poly_eval(Km, k + 1) - Acum(n, k)                                       # B_+(n,k-1)
        L = poly_eval(poly_der(Km), k) - poly_eval(poly_der(Kk), k)
        if not (C_minus - B_minus == d(n, k) == C_plus - B_plus):
            ok_dec = False
        if C_plus < poly_eval(poly_der(poly_der(Km)), k):
            ok_pair = False
        G = lambda y: factorial(n) * impulse(k, n, y)
        for name, lhs, rhs in (("B+", B_plus, G(k + 1)), ("C+", C_plus, factorial(n) * source(k, n)),
                               ("B-", B_minus, G(k - 1)), ("L", L, G(k))):
            (rng if lhs == rhs else bad)[name].append((n, k))
report("d_{n,k}=C_-(n,k)-B_-(n,k)=C_+(n,k-1)-B_+(n,k-1) (모든 자리 2<=k<=n-1, n<=16)", ok_dec)
report("쌍–충격 판정의 첫 걸음 C_+(n,k-1)>=K''_{n,k-1}(k) (2<=k<=n-1, n<=16)", ok_pair)


def describe(name):
    good, wrong = rng[name], bad[name]
    lo = min((n - 2 * k for (n, k) in wrong), default=None)
    hi_good = max((n - 2 * k for (n, k) in good), default=None)
    return "맞는 자리의 n-2k의 최댓값 %s, 어긋나는 자리의 n-2k의 최솟값 %s" % (hi_good, lo)


report("B_+(n,k-1)=n!·ι_k(n)=n!λ_kΛ_{n-k+1}(k+1;n+1): n<=2k-1에서 모두 맞는다",
       all(n >= 2 * k for (n, k) in bad["B+"]), describe("B+"))
report("C_+(n,k-1)=n!·X_k(n): n<=2k-1에서 모두 맞는다",
       all(n >= 2 * k for (n, k) in bad["C+"]), describe("C+"))
report("B_-(n,k)=n!λ_kΛ_{n-k+1}(k-1;n+1): n<=2k-1에서 모두 맞는다",
       all(n >= 2 * k for (n, k) in bad["B-"]), describe("B-"))
report("손실 L_{n,k}=n!λ_kΛ_{n-k+1}(k;n+1): n<=2k에서 모두 맞는다",
       all(n >= 2 * k + 1 for (n, k) in bad["L"]), describe("L"))

# reea223c의 정규화: B_+/p_n=(1/k)(Bor(k)/Bor(N))Λ~_R(k+1;N) 은 p_n/a_N=n! 과 같은 말
report("p_n/a_N=n! (N=n+1) — reea223c의 정규화 B_+/p_n=(1/k)(Bor(k)/Bor(N))·Λ~_R(k+1;N)이 위의 식과 같은 말",
       all(Fr(p(n)) / a_(n + 1) == factorial(n) for n in range(1, 31)))


# ---------------------------------------------------------------- (4) 단위 둘째 차분
def Dn(n, y):
    return Zn(n, y + 1) - 2 * Zn(n, y) + Zn(n, y - 1)


report("D_n(k)=d_{n,k} (정수 1<=k<=n-1, n<=30)",
       all(Dn(n, k) == d(n, k) for n in range(2, 31) for k in range(1, n)))

roots = {}
ok_one = True
for n in range(1, 15):
    grid = [Fr(i, 16) for i in range(1, 16 * n)]
    signs = [(y, Dn(n, y)) for y in grid]
    changes = [(signs[i][0], signs[i + 1][0]) for i in range(len(signs) - 1)
               if (signs[i][1] > 0) != (signs[i + 1][1] > 0)]
    if len(changes) != 1 or not signs[0][1] > 0:
        ok_one = False
        continue
    lo, hi = changes[0]
    for _ in range(40):
        mid = (lo + hi) / 2
        if Dn(n, mid) > 0:
            lo = mid
        else:
            hi = mid
    roots[n] = float(lo)
report("D_n의 부호가 격자 (1/16)Z 위에서 양에서 음으로 꼭 한 번 바뀐다 (1<=n<=14; 격자 위의 대조)", ok_one)
steps = [roots[n + 1] - roots[n] for n in range(1, 14) if n in roots and n + 1 in roots]
report("실수 교차점의 걸음 0<y*(n+1)-y*(n)<1 (1<=n<=13; 이분법의 근삿값)", all(0 < s < 1 for s in steps),
       "걸음의 범위 %.3f–%.3f" % (min(steps), max(steps)))


def interp_peak(n):
    for k in range(1, n - 1):
        if d(n, k) >= 0 > d(n, k + 1):
            return k + Fr(d(n, k), d(n, k) - d(n, k + 1))
    return None


pk = {n: interp_peak(n) for n in range(3, 31)}
st = [pk[n + 1] - pk[n] for n in range(3, 30)]
report("보간한 봉우리(가장 작은 k로 정한 것)의 걸음이 0과 1 사이 (3<=n<=29)", all(0 < s < 1 for s in st),
       "걸음의 범위 %.3f–%.3f" % (float(min(st)), float(max(st))))
zero_diffs = [(n, k) for n in range(2, 31) for k in range(1, n) if d(n, k) == 0]
print("   [정보] n<=30에서 d_{n,k}=0인 자리:", zero_diffs)


# ---------------------------------------------------------------- (5) 대각 방향의 우도비 조건
viol = {}
total = 0
for n in range(3, 30):
    for k in range(1, n):
        total += 1
        if b(n + 1, k + 1) * b(n, k - 1) > b(n + 1, k) * b(n, k):
            viol.setdefault(n - k, []).append(n)
print("   [정보] 대각 방향의 우도비 조건 b_{n+1,k+1}·b_{n,k-1}<=b_{n+1,k}·b_{n,k}이 깨지는 자리 (3<=n<=29):")
for r in sorted(viol):
    rows = viol[r]
    print("      결손 n-k=%d: 행 %s" % (r, (str(rows[0]) + "–" + str(rows[-1]) if rows == list(range(rows[0], rows[-1] + 1)) else rows)))
neg_viol = [(n, n - r) for r in viol for n in viol[r] if d(n, n - r) <= 0 and r >= 3]
report("대각 방향의 우도비 조건: 결손 1, 2의 자리는 4<=n<=29에서 모두 깨지고, 결손 3 이상에서 깨지는 자리는 n<=15에 있다",
       all(set(viol.get(r, [])) >= set(range(4, 30)) for r in (1, 2))
       and all(n <= 15 for r in viol if r >= 3 for n in viol[r]),
       "결손 3 이상에서 깨지는 자리 %d곳 (모두 d_{n,k}<=0인 자리인가: %s)" %
       (sum(len(viol[r]) for r in viol if r >= 3), len(neg_viol) == sum(len(viol[r]) for r in viol if r >= 3)))
ok = True
for n in range(3, 30):
    for k in range(1, n):
        if b(n + 1, k + 1) * b(n, k - 1) <= b(n + 1, k) * b(n, k) and d(n, k) <= 0 and d(n + 1, k + 1) > 0:
            ok = False
report("조건이 서는 자리에서 d_{n,k}<=0이면 d_{n+1,k+1}<=0 (그 자리의 (Diag))", ok)

# ---------------------------------------------------------------- 맺음
print()
print("대조 %d개 가운데 맞음 %d개." % (len(results), sum(1 for _, okk in results if okk)))
if not all(okk for _, okk in results):
    print("어긋난 대조:", [t for t, okk in results if not okk])
