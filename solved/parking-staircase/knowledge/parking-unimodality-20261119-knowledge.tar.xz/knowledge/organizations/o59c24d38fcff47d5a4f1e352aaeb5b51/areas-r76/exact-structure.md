# 정확한 구조: 숲 표현, 마지막 차 재귀, 단일 사슬 범위의 식, 걸음의 분해, 열 방정식의 꼴, 합성의 법칙, 소인 주차함수 수준의 식

자세한 서술의 덧붙임 (연구 개정 71–76). 조직화 세션 sfcc8a7bebdbe4d0c9e3f4be71f29811f의 출력이다.

이 글은 이 조직화가 개정 71–76의 다섯 기록(rbd60d0c, r7c05856b, r467bd858, r42f1242, reea223c)의 주장의 문면 전부와 주장마다의 검토의 판정과 사유, 검토문 전문, 지역 용어집을 읽고 적은 것이다. 해설(exposition.md)은 읽지 않았고, 어느 증명도 다시 따라가지 않았다. 「증명되었다」, 「지지되었다」는 검토의 판정을 옮긴 것이다. 수학적 주장은 기록과 그 검토의 것이고, 이 글은 그것을 찾아가게 하는 글이다. 다섯 기록에 대한 문단은 기록마다 하나씩의 하위 점검이 주장의 문면과 검토에 맞대었고, 지적된 곳을 고쳤다. 「이 조직화의 읽기」라고 적은 문장은 어느 기록의 주장도 아니고 검토를 거치지 않았다. 이 조직화가 일하는 동안 게시된 두 기록(개정 77의 r44512889, 개정 78의 r26911cae)은 묶음 밖이어서 주장과 검토문을 읽지 않았고, 닿는 자리에는 그 서술과 검토의 판정문에서 옮긴 문장만 적었다. 읽은 것과 읽지 않은 것, 하위 점검이 낸 것은 이 폴더의 위 폴더에 있는 `organization-notes.md`에 적었다.

이 파일은 앞선 네 조직화의 자세한 서술(`areas-r54`, `areas-r59`, `areas-r64`, `areas-r70`의 `exact-structure.md`)에 덧붙는 글이다. 개정 71–76의 다섯 기록이 더한 정확한 식을 기록과 주장 ID로 적는다. 어떤 식이 이미 있는지를 찾을 때 여는 문서다. 식의 정확한 꼴은 주장의 문면에 있고 여기에는 무엇에 대한 식인지와 먼저 게시된 같은 식을 적는다.

## 문단 차례

줄 번호는 이 파일의 줄이다. 문단 하나가 한 줄이어서, 그 줄만 읽으면 그 문단을 읽는다.

- 25행, 절: 첫 층의 응답 꼴: 네 이름의 한 등식
  - 27행: 등식. k≤n≤2k−1에서 d_{n,k}=n!·(X_k(n)− …
  - 29행: 세 분해의 빼는 항. 동률 빼기 막힘의 B_−(n,k), 곡률 …
- 31행, 절: 기록마다 더한 식
  - 33행: rbd60d0c. c-flow-identities(명제 1: …
  - 35행: r7c05856b. c-interpolation(조각 y=k+ …
  - 37행: r467bd858. p-profile(명제 A: 정규화한 음의 …
  - 39행: r42f1242. p-survival-form(위의 절), p …
  - 41행: reea223c. c-pair-impulse(따름 A′: 곡률 …
- 43행, 절: 이 조직화의 대조
  - 45행: check_identities.py(이 폴더의 위 폴더)는 위 …

## 첫 층의 응답 꼴: 네 이름의 한 등식

등식. k≤n≤2k−1에서 d_{n,k}=n!·(X_k(n)−ι_k(n)). X_k(n)은 원천 응답, ι_k(n)=λ_k·Λ_{n−k+1}(k+1;n+1)은 충격 응답이다. 네 기록의 이름: rb3d5f15의 수준 재귀 (R1′)(c-level-recursion), r9faef2b6의 핵 꼴(p-kernel-form), r42f1242의 생존 꼴(p-survival-form), reea223c의 첫 층의 꼴(c-first-layer-forms). 얼린 다항식의 말로 n!·X_k(n)=C_+(n,k−1), n!·ι_k(n)=B_+(n,k−1)이다. 정의와 대응, 범위는 이 조직화의 용어 항목 「첫 층의 응답 꼴: 원천 응답, 충격 응답, 충격의 족」에 모았고 check_identities.py가 작은 경우에서 대조했다.

세 분해의 빼는 항. 동률 빼기 막힘의 B_−(n,k), 곡률 빼기 손실의 L_{n,k}, 위의 B_+(n,k−1)이 사슬 합 λ_k·Λ_{n−k+1}(y;n+1)의 y=k−1, k, k+1에서의 값에 n!을 곱한 것이다(rb3d5f15의 해설 2.5절; r42f1242의 p-impulse-family). 범위는 차례로 k+1≤n≤2k−1, k+1≤n≤2k, k+1≤n≤2k−1이다(대조에서 그 밖의 자리는 어긋났다).

## 기록마다 더한 식

rbd60d0c. c-flow-identities(명제 1: 차분과 두 괄호를 흐름으로 적은 등식), c-three-brackets(정리 2: 세 괄호의 한 방정식), c-prob-wave-equation(정리 3: 확률로 정규화한 파동 방정식과 원천의 식), c-propagation (가)(나)(핵을 부분합으로 적은 등식, 파동의 빚과 차분의 부분합을 잇는 등식), c-flow-equations(식 (3.5): 두 흐름의 양의 핵의 방정식), c-hazard-averaging(명제 7: 위험률의 평균 방정식), c-threshold-spot(명제 8: 문턱 자리의 확률), c-debt-free(식 (3.7): W^x=DC+E+E′와 그 방정식), p-exit-times(명제 11: 파동 괄호가 떠나는 시각 둘의 확률의 차), p-kernel-second-difference(보조정리 Q1: 급수의 핵의 크기 방향 둘째 차분). 먼저 게시된 같은 식: 흐름의 읽기는 rf9e63ea의 해설 7.1절, 크기 괄호의 식은 r0bffe377의 (2.4), 흐름의 첫 방정식은 rf0331155의 대각 재귀.

r7c05856b. c-interpolation(조각 y=k+θ 위에서 D_n=𝖢−𝖡↓−𝖡↑; θ=0에서 C_−, B_−이고 θ=1에서 C_+, B_+), c-achiever-count(달성하는 차의 수의 생성함수와 「동률의 혹」), c-real-sandwich(끼임의 실수 문턱 꼴), c-transfer-identity(실수 문턱의 전이 항등식), c-real-column(실수 문턱의 열 방정식과 열 연산자), p-end-pieces(끝 조각; (I)의 두 꼴이 n≥3에서 같다), p-minor-form(소행렬식 꼴), p-bernstein-form(조각 위의 값이 한 이산 분포의 둘째 차분의 Bernstein 다항식), p-shifted-series(실수 문턱의 포함–배제 급수), p-pointwise-cross의 등식 부분(교차곱이 점별 식의 적분). 먼저 게시된 같은 식: 연속 최대 변위의 식별은 re6ac5d71의 2.2절, c-achiever-count (1)은 rbbb706e의 (2.3)의 특수화.

r467bd858. p-profile(명제 A: 정규화한 음의 윤곽과 (β)), p-discrete-averaging-identities(보조정리 V1: 게시된 수준 방정식을 비로 나눈 두 평균 항등식), p-weighted-column-equation(보조정리 DW1), p-weight-family-finite(명제 DW4), p-source-dg(명제 DW5: 결손을 곱한 원천 = 열 k−1의 칸만의 식 + 정리 Dg의 여분), p-spare-spot(명제 B: 여분 자리 족의 무게 r의 열 방정식), p-cross-product-reading(교차곱의 양성을 한 부등식으로). 먼저 게시된 같은 식: 윤곽의 식은 r692807de, 명제 B는 r6473edca의 c-family-structure를 수준에 대해 뺀 것, 교차곱의 등식은 r496399b6의 p-level-form.

r42f1242. p-survival-form(위의 절), p-slack-kernel-identity(대각 걸음의 차를 여분의 몫과 핵의 몫으로 가른 등식), p-increment-ratio-bound(문턱 증분의 비의 한계), p-impulse-family(충격의 족), p-kernel-split(명제 P6: 대각 결손의 정확한 가름), p-rho-order-reduction (i)(충격 비의 로그를 대각 흐름의 적분으로 적은 식과 공분산의 식), p-frozen-forest(명제 P2: 얼린 숲의 둘째 차분), p-factor-free-moments(인자 없는 법칙의 이차 적률; 생일 법칙의 귀결), p-comparison-tools(쓰는 게시된 비교). p-frozen-forest의 (i), (ii)는 r496399b6의 숲 공식과 같은 내용을 결손의 말로 적은 것이라고 그 주장이 적었다.

reea223c. c-pair-impulse(따름 A′: 곡률항이 순서쌍의 수 이상이라는 것과 쌍–충격 판정), c-first-layer-forms(사슬 합으로 적은 꼴), c-prop-C의 등식(Ren(m)−Λ~_m(y;Q)=Σ_s(1−y/(Q−s))·Λ~_s(y;Q)·Ren(m−s); 「처음 어기는 점」으로 가른 것이고 인자가 무엇이든 선다), p-count-sandwich(명제 S와 균질 사슬의 합의 닫힌 꼴 (4.4)), p-count-blocks(자른 자리를 가로지르는 간격으로 가른 사슬 합의 분해). 그 기록이 쓰는 게시된 식: 얼린 다항식의 분해(r496399b6의 p-general-identities), 사슬의 법칙(r7514f8ae의 p-lemma-A), 식 (9.15)(rbbb706e의 p-last-violation), Borel–Tanner 공식(rbbb706e의 c-lemma-1-1).

## 이 조직화의 대조

check_identities.py(이 폴더의 위 폴더)는 위의 대응 가운데 용어 항목에 옮겨 적은 것을 작은 정확한 경우에서 본다. 마지막 차 재귀와 숲의 재귀가 정수 문턱에서 같은 수를 준다는 것, 두 흐름과 전이 비의 대응, 파동 괄호의 두 식, 첫 층의 응답 꼴과 세 빼는 항의 범위, r9faef2b6의 충격의 응답과의 대응, 쌍–충격 판정의 첫 걸음, 단위 둘째 차분의 정수에서의 값과 격자 위의 부호 변화, 대각 방향의 우도비 조건이 깨지는 자리다. 스물다섯 대조가 모두 맞았다(출력은 check_identities.out.txt). n≤30의 대조이고 어느 정리의 근거도 아니다.
