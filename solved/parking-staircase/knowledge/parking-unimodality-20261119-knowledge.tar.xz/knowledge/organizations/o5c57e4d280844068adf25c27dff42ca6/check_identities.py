# -*- coding: utf-8 -*-
"""조직화 세션 s22fb873d23064302863ef6fb265194f2의 대조 스크립트.

이 조직화가 색인의 설명, areas-r70의 글, 지역 용어 항목에 옮겨 적은 정의와 대응을 작은 경우에서 대조한다.
표의 크기는 모두 30 이하이고(둘째 상시 조건: 논증의 특정한 걸음을 작은 예에서 확인하는 계산), 어느 정리의
근거도 아니다. 하는 일은 옮겨 적은 식이 원문의 식과 같은 식인지를 보는 것이다.

 1. 노드 (L1°)의 양 𝖢_{n,c}=φ_{n−1}−2φ_n+φ_{n+1} (φ_N=Pr(M_N<c))과 전역 용어 「넘김 확률, 나무의 넘김 확률,
    넘김 증분」의 χ(n+2)가 같은 수라는 것 (areas-r70/notation-and-corrections.md의 「이 조직화의 읽기」).
 2. rfaf06c62의 주장 c-three-directions의 등식 (1), (2), (5)를 areas-r70/critical-tilt-first-layer.md에
    옮겨 적은 꼴 그대로.
 3. 지역 용어 「교차곱의 판정 함수 𝖦(r,k)」에 옮겨 적은 정의가 원문의 것과 같은 함수인지: 기록이 적은 참값
    (r670ca907의 p-G-small-deficit의 𝖦(r,82), r04646f8의 p-criterion-no-computation의 곡선 위의 값)과 견준다.
 4. 지역 용어 「창의 연장과 ϖ(k)」에 적은 정수 부등식 둘과, r670ca907의 가름에서 표로 읽는 자리의 수 둘.

실행: python check_identities.py  (몇 초; 실패가 있으면 종료 코드 1)
"""
import io
import sys
from fractions import Fraction as Fr
from math import comb, factorial, sqrt

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
NMAX = 30
FAILS = []


def report(tag, ok, scope):
    print(('PASS ' if ok else 'FAIL ') + tag + ' | ' + scope)
    if not ok:
        FAILS.append(tag)


# ---------------------------------------------------------------- tables
def table_A(nmax):
    """A[k][n] = 최대 변위가 k 이하인 길이 n의 주차함수의 수 (마지막 차 재귀)."""
    A = {}
    for k in range(0, nmax + 2):
        col = [1]
        for n in range(nmax):
            col.append(sum(min(j + 1, k + 1) * comb(n, j) * col[j] * col[n - j] for j in range(n + 1)))
        A[k] = col
    return A


A = table_A(NMAX)


def Acnt(n, k):
    if k < 0:
        return 0
    return A[min(k, NMAX + 1)][n]


def p(n):
    return Fr(n + 1) ** (n - 1) if n >= 1 else Fr(1)


def b(n, l):
    return Acnt(n, l) - Acnt(n, l - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


# sanity of the table: row sums are (n+1)^(n-1), and a hand value
ok = all(sum(b(n, l) for l in range(0, n)) == (n + 1) ** (n - 1) for n in range(1, NMAX + 1))
ok = ok and [b(3, l) for l in range(3)] == [6, 7, 3]
report('0 table', ok, '행의 합 (n+1)^(n-1), n<=30; b_{3,.}=(6,7,3) (손으로 센 값)')


# ---------------------------------------------------------------- 1. 𝖢_{n,c} = χ(n+2)
def phi(N, c):
    """φ_N = Pr(M_N < c)."""
    return Fr(Acnt(N, c - 1)) / p(N)


def chi(N, k):
    """전역 용어의 정의를 그대로: 𝗌(N)=Pr(M_{N−1}<k), 𝗎=1−𝗌, 𝖿(N)=𝗎(N)−𝗎(N−1), χ(N)=𝖿(N−1)−𝖿(N)."""
    s = lambda m: Fr(Acnt(m - 1, k - 1)) / p(m - 1)
    u = lambda m: 1 - s(m)
    f = lambda m: u(m) - u(m - 1)
    return f(N - 1) - f(N)


ok = True
cnt = 0
for c in range(2, 13):
    for n in range(1, NMAX):
        lhs = phi(n - 1, c) - 2 * phi(n, c) + phi(n + 1, c)
        ok = ok and (lhs == chi(n + 2, c))
        cnt += 1
report('1 C_{n,c} = chi(n+2)', ok, f'2<=c<=12, 1<=n<=29, {cnt}자리, 정확한 유리수')

# ---------------------------------------------------------------- 2. three directions
ok1 = ok2 = ok5 = True
cnt = 0
for c in range(2, 13):
    for x in (Fr(1, 3), Fr(c, c + 1) ** (c - 1), Fr(3 * c, 3 * c + 1) ** (3 * c - 1), Fr(7, 10)):
        z = lambda N, cc: x ** N * Fr(Acnt(N, cc - 1), factorial(N))
        U = lambda N, l: x ** N * Fr(b(N, l), factorial(N))
        for N in range(1, NMAX - 1):
            C = z(N + 1, c) - 2 * z(N, c) + z(N - 1, c)
            DC = z(N + 1, c + 1) - 2 * z(N, c) + z(N - 1, c - 1)
            W = z(N, c + 1) + z(N, c - 1) - z(N + 1, c) - z(N - 1, c)
            nab = lambda M: U(M - 1, c - 1) - U(M, c - 1)
            ok1 = ok1 and (C == DC + U(N - 1, c - 1) - U(N + 1, c))
            ok2 = ok2 and (x ** N * Fr(d(N, c), factorial(N)) == C + W)
            ok5 = ok5 and (C + x ** (N + 1) * Fr(d(N + 1, c), factorial(N + 1)) == DC + nab(N) + nab(N + 1))
            cnt += 1
report('2 (1) C = DC + U_{N-1}(c-1) - U_{N+1}(c)', ok1, f'2<=c<=12, 기울임 넷, 1<=N<=28, {cnt}자리')
report('2 (2) x^N d_{N,c}/N! = C + W', ok2, '같은 범위')
report('2 (5) C + x^{N+1} d_{N+1,c}/(N+1)! = DC + nabla_N + nabla_{N+1}', ok5, '같은 범위')


# ---------------------------------------------------------------- 3. criterion function G(r,k)
def s_r(r):
    out = Fr(0)
    term = Fr(1)
    for j in range(1, r + 1):
        term *= Fr(r - j + 1, r)
        out += term
    return out


def D_r(r):
    s = s_r(r)
    return 3 * ((r + 2) * s - 3 * r) / (2 * (r - s))


def mu0(X, r):
    return (sqrt((4 + X) ** 2 + 12 * (r - 1)) - (4 + X)) / 3


def G(r, k):
    Xm = r * (r + 1) / (k - 1)
    Xmid = r * (r + 2) / (2 * k)
    return (k * (1 / (2 * r) - 1 / (3 * r * r)) - 2.5 + 0.5 * mu0(Xm, r)
            + 2 * (1 - 1 / k) * mu0(Xmid, r) - (k / (k - 1)) * float(D_r(r)))


ok = (s_r(5) == Fr(1569, 625)) and (s_r(9) == Fr(16541017, 4782969)) and (s_r(13) == Fr(98139640241473, 23298085122481))
report('3 s_r', ok, 's_5, s_9, s_13이 r670ca907, r7ce45a38의 주장에 적힌 분수와 같다')
quoted82 = [12.22, 9.41, 7.51, 6.24, 5.34, 4.69, 4.18, 3.78]
vals = [G(r, 82) for r in range(2, 10)]
ok = all(abs(v - q) < 0.006 for v, q in zip(vals, quoted82))
report('3 G(r,82), r=2..9', ok, '옮겨 적은 정의의 값 ' + ', '.join(f'{v:.2f}' for v in vals) + ' / 기록의 값 ' + ', '.join(f'{q:.2f}' for q in quoted82))
c10, c9 = G(10, 10 ** 1.5), G(9, 27.0)
ok = abs(c10 - 0.3606) < 0.0006 and abs(c9 - 0.170) < 0.0006 and all(G(r, r ** 1.5) < 0 for r in range(2, 9))
report('3 G(r,r^{3/2})', ok, f'r=10에서 {c10:.4f}, r=9에서 {c9:.4f} (기록: 0.3606, 0.170), r=2..8에서 음')
ok = all(G(r, k + 1) > G(r, k) for r in range(2, 70) for k in range(max(3, r + 1), 400))
report('3 G increasing in k', ok, '2<=r<=69, 정수 k<=400의 표본에서 (기록의 문장은 실수 k>1에서의 단조성이고 이 표본은 그 증명이 아니다)')
gmin = min((G(r, k), r, k) for k in range(125, 265) for r in range(2, -(-k // 4) - 1))
ncell = sum(1 for k in range(125, 265) for r in range(2, -(-k // 4) - 1))
ok = (ncell == 6440) and abs(gmin[0] - 1.3278) < 0.0006 and gmin[1:] == (64, 261)
report('3 G on 125<=k<=264, 2<=r<=ceil(k/4)-2', ok, f'{ncell}칸, 최솟값 {gmin[0]:.4f} (r={gmin[1]}, k={gmin[2]}); 기록: 6440칸, 1.3278 (r=64, k=261)')


# ---------------------------------------------------------------- 4. window extension, counts
def ceil_08_k23(k):
    """⌈0.8·k^{2/3}⌉: 125·m³ ≥ 64·k²인 가장 작은 정수 m."""
    m = 0
    while 125 * m ** 3 < 64 * k * k:
        m += 1
    return m


def varpi(k):
    return (2 * k) // 5 + 3 - ceil_08_k23(k)


def r_c(k):
    r = 1
    while r ** 3 <= k * k:
        r += 1
    return r


KTOP = 20000
bad27 = [k for k in range(64, KTOP + 1) if (27 * k) // 100 > varpi(k)]
ok = (max(bad27) == 167) and all((27 * k) // 100 <= varpi(k) for k in range(168, KTOP + 1))
b125 = [k for k in bad27 if k >= 125]
report('4 floor(27k/100) <= varpi(k)', ok, f'168<=k<={KTOP}에서 서고(k>=234에서는 r670ca907의 p-columns-ge-125의 증명에 닫힌 부등식이 있다), 서지 않는 마지막 k는 {max(bad27)}; 125<=k<=167에서 서지 않는 열 {len(b125)}개: ' + ', '.join(map(str, b125)))
b148 = [k for k in bad27 if k >= 148]
ok = (b148 == [149, 152, 156, 157, 167])
report('4 columns 148..167', ok, '열 148 이상에서 floor(27k/100) > varpi(k)인 열: ' + ', '.join(map(str, b148)) + ' (r670ca907의 검토가 적은 다섯 열 149, 152, 156, 157, 167)')
badrc = [k for k in range(64, KTOP + 1) if r_c(k) > varpi(k)]
ok = (max(badrc) == 77)
report('4 r_c(k) <= varpi(k)', ok, f'78<=k<={KTOP}에서 서고, 서지 않는 마지막 k는 {max(badrc)}')
ok = all(r_c(k) <= min((27 * k) // 100, varpi(k)) for k in range(82, 125))
report('4 r_c(k) <= min(floor(27k/100), varpi(k))', ok, '82<=k<=124 (r670ca907의 p-columns-82-124가 쓰는 정수 부등식)')
def pairs(lo, hi):
    """조건 ⌈n/2⌉ ≤ l ≤ n−2, lo ≤ l ≤ hi를 만족하는 쌍 (n,l)과 그 행의 최댓값."""
    P = [(n, l) for l in range(lo, hi + 1) for n in range(1, 2 * hi + 3) if -(-n // 2) <= l <= n - 2]
    return len(P), max(n for n, _ in P)


ok = (pairs(1, 81) == (3240, 162)) and (pairs(82, 124)[0] == 4386) and (124 - 82 + 1 == 43)
ok = ok and (min(k + r_c(k) for k in range(82, 125)) == 101) and (max(k + r_c(k) for k in range(82, 125)) == 149)
report('4 counts', ok, '⌈n/2⌉≤l≤n−2인 쌍 (n,l): l≤81에서 3240곳(행 n≤162), 82≤l≤124에서 4386곳; 열 82..124는 43개이고 자리 (k+r_c(k),k)는 행 101..149')

print()
print('FAILS:', FAILS if FAILS else 'none')
sys.exit(1 if FAILS else 0)
