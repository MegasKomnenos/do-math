# -*- coding: utf-8 -*-
"""조직화 세션 s846e100925954d3ca24057bb1e0fe64d의 대조 스크립트.

이 스크립트는 이 조직화의 지역 용어 항목 셋과 영역 설명에 옮겨 적은 식이 기록의 정의와 같은 수를
주는지를 작은 예에서 확인한다. 주차함수의 수는 길이 n<=30만 쓴다(인수인계 문서의 규칙 1의 기저).
옮겨 적은 식의 대조이고, 어느 정리의 근거도 아니다. 모든 셈은 정확한 유리수다.

  0. 도구의 자기 점검: 마지막 차 점화식으로 셈한 b_{n,l}을 뿌리 명제의 확인용 값(n<=7)과 견준다.
  1. 용어 「한 수준의 핵과 첫 층의 가름의 족」(기록 r698c42fa..., r33aa2fb2..., r9faef2b6..., r3bd6df85...,
     r418c4ecc..., r04a6299b...): 한 수준의 핵 G^{[c]}의 점화와 사슬 합 꼴, 연산자의 등식, 첫 층의 차분을
     「원천의 응답 빼기 충격의 응답」으로 적는 네 등식과 그 범위, 세 수준 핵의 곱 꼴, 동률과 막힘의 식,
     임계 기울임의 핵 꼴의 수와의 대응, 죽임 있는 갱신 사슬 Gamma(r,l)과의 대응.
  2. 용어 「두 열의 차의 풀린 꼴」(기록 rdf5f9d9d...): 두 열의 재귀 (2.1), 처음 세 행의 닫힌 꼴,
     풀린 꼴 (2.3), 잘린 해의 풀린 꼴 (3.1), 정리 1과 정리 8의 부등식(기저 안의 열), 판정 수 N_k(r)의
     부호가 처음 바뀌는 결손 r_N(k), 정리 10의 범위, 명제 7의 사슬 꼴.
  3. 용어 「두 수준의 괄호」(기록 r0f0ade87...): 두 항등식, 전역 용어의 두 둘째 차분과의 인자,
     기울인 꼴의 동치, 두 아래 한계.
  4. 영역 설명에 조직화가 수를 대입해 적은 대응: rdf5f9d9d...의 명제 14의 (가)가 주는 교차 행의 상계
     108과 117이 열 82-96에서 k+ceil(k/3)-1 이하라는 산수, 그리고 설명에 옮긴 문턱의 산수 몇 개.

실행: python check_identities.py  (표준 라이브러리만 쓴다)
"""
import sys
from fractions import Fraction as Fr
from functools import lru_cache
from math import comb, factorial
from itertools import product

NMAX = 30
OK = True


def report(label, cond, extra=''):
    global OK
    OK = OK and bool(cond)
    print(('  [맞음] ' if cond else '  [어긋남] ') + label + ((' — ' + extra) if extra else ''))


# ---------------------------------------------------------------------------
# 주차함수의 수: 마지막 차 점화식 A_{n,k} = sum_j C(n-1,j) min(j+1,k+1) A_{j,k} A_{n-1-j,k}
# ---------------------------------------------------------------------------
@lru_cache(maxsize=None)
def A(n, k):
    """최대 변위가 k 이하인 길이 n의 주차함수의 수 (A_{0,k}=1; n>=1, k<0이면 0)."""
    if n == 0:
        return 1
    if k < 0:
        return 0
    if k >= n - 1:
        return (n + 1) ** (n - 1)
    return sum(comb(n - 1, j) * min(j + 1, k + 1) * A(j, k) * A(n - 1 - j, k) for j in range(n))


def b(n, l):
    if l < 0 or l > n - 1:
        return 0
    return A(n, l) - A(n, l - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


def q0(k, nmax=NMAX):
    for n in range(k + 1, nmax + 1):
        if d(n, k) > 0:
            return n
    return None


def a(g):
    """a_g = g^{g-1}/g!  (g>=1)."""
    return Fr(g ** (g - 1), factorial(g))


def c(i):
    """c_i = (i+1)^{i-1}/i! = a_{i+1}  (i>=0)."""
    return a(i + 1)


def check0():
    print('0. 도구의 자기 점검')
    rows = {1: [1], 2: [2, 1], 3: [6, 7, 3], 4: [24, 51, 34, 16], 5: [120, 421, 377, 253, 125],
            6: [720, 3963, 4594, 3688, 2546, 1296], 7: [5040, 42253, 62145, 57398, 46142, 32359, 16807]}
    report('n<=7의 행이 뿌리 명제의 확인용 값과 같다',
           all([b(n, l) for l in range(n)] == rows[n] for n in rows))
    report('n<=30에서 행의 합이 (n+1)^(n-1)',
           all(sum(b(n, l) for l in range(n)) == (n + 1) ** (n - 1) for n in range(1, NMAX + 1)))


# ---------------------------------------------------------------------------
# 1. 한 수준의 핵과 첫 층의 가름의 족
# ---------------------------------------------------------------------------
@lru_cache(maxsize=None)
def G(cc, n, m):
    """한 수준의 핵 G^{[c]}(n,m), 0<=m<n. 점화 G(n,m)=a_{n-m}/(m+1)+c*sum_{m<s<n} a_{n-s} G(s,m)/(s+1)."""
    return a(n - m) / (m + 1) + cc * sum(a(n - s) * G(cc, s, m) / (s + 1) for s in range(m + 1, n))


def Lam(m, y, N):
    """전역 용어 「절단 인자를 가진 Cayley 합성의 법칙」의 사슬 합 Lambda_m(y;N):
    m의 모든 합성에 걸친 합, 토막마다 a_gamma, 자르는 점 s(부분합, 1<=s<=m-1)마다 y/(N-s)."""
    @lru_cache(maxsize=None)
    def rest(s):
        if s == m:
            return Fr(1)
        tot = Fr(0)
        for g in range(1, m - s + 1):
            t = s + g
            f = a(g) * (Fr(y) / (N - t) if t < m else 1)
            tot += f * rest(t)
        return tot
    return rest(0)


def Lam_brute(m, y, N):
    """같은 합을 합성을 하나씩 늘어놓아 셈한다(m<=9)."""
    tot = Fr(0)
    for mask in range(1 << (m - 1)):
        cuts = [s for s in range(1, m) if (mask >> (s - 1)) & 1]
        pts = [0] + cuts + [m]
        w = Fr(1)
        for i in range(len(pts) - 1):
            w *= a(pts[i + 1] - pts[i])
        for s in cuts:
            w *= Fr(y) / (N - s)
        tot += w
    return tot


@lru_cache(maxsize=None)
def kappa(k, j):
    """전역 용어 「뼈대, 덤불, 계수 kappa_k」: kappa_k(j)=[z^j] z*exp(S_k(z)), S_k(z)=sum_{t<=k} a_t z^t."""
    # e^{S_k}의 계수 E_i: i*E_i = sum_{t=1}^{min(i,k)} t*a_t*E_{i-t}
    E = [Fr(1)]
    for i in range(1, j):
        E.append(sum(t * a(t) * E[i - t] for t in range(1, min(i, k) + 1)) / i)
    return E[j - 1]


def frozen_K(nmax, k, y):
    """얼린 다항식 K_{n,k}(y)=sum_F prod_{v: t_v>k} y/t_v (n=0..nmax). 뿌리 있는 표지 숲의 지수 생성함수로 셈한다.
    돌려주는 값은 K_{n,k}(y)의 목록."""
    y = Fr(y)
    # f[m] = 숲의 무게 합/m!, t[m] = 나무의 무게 합/m!;  t[m] = phi(m) * f[m-1],  F = exp(T)
    f = [Fr(1)]
    t = [Fr(0)]
    for m in range(1, nmax + 1):
        phi = (y / m) if m > k else Fr(1)
        t.append(phi * f[m - 1])
        # m*f[m] = sum_{i=1}^{m} i*t[i]*f[m-i]
        f.append(sum(i * t[i] * f[m - i] for i in range(1, m + 1)) / m)
    return [f[m] * factorial(m) for m in range(nmax + 1)]


def check1():
    print('1. 한 수준의 핵 G^{[c]}와 첫 층의 가름의 족 (기호는 r698c42fa의 주장 p-chain-kernel-form의 것)')
    # (1a) 점화와 사슬 합 꼴
    ok = True
    cnt = 0
    for cc in (0, 1, 2, 3, 5, 7, Fr(5, 2)):
        for n in range(1, 15):
            for m in range(0, n):
                cnt += 1
                if G(cc, n, m) * (m + 1) != Lam(n - m, cc, n + 1):
                    ok = False
    report('G^{[c]}(n,m)=Lambda_{n-m}(c;n+1)/(m+1)  (c=0,1,2,3,5,7,5/2; 0<=m<n<=14)', ok, '%d자리' % cnt)
    ok = all(Lam(m, y, N) == Lam_brute(m, y, N) for m in range(1, 10) for y in (2, 5) for N in (m + 1, m + 4))
    report('사슬 합 Lambda_m(y;N)의 재귀 셈이 합성을 하나씩 늘어놓은 합과 같다 (m<=9)', ok)
    # (1c) 연산자의 등식 K_b-K_a=(b-a)K_b K_a
    ok = True
    for (aa, bb) in ((2, 3), (3, 4), (4, 6), (1, 5)):
        for n in range(1, 13):
            for m in range(0, n):
                lhs = G(bb, n, m) - G(aa, n, m)
                rhs = (bb - aa) * sum(G(bb, n, s) * G(aa, s, m) for s in range(m + 1, n))
                ok = ok and lhs == rhs
    report('G^{[b]}(n,m)-G^{[a]}(n,m)=(b-a)*sum_{m<s<n} G^{[b]}(n,s)G^{[a]}(s,m)', ok)

    # (1d) 네 등식: 첫 층 k<=n<=2k-1
    def lhs(n, k):
        return Fr(d(n, k), factorial(n))

    def form_i(n, k):
        return 2 * sum(Fr(b(j, k - 1), factorial(j)) * G(k + 1, n, j) for j in range(k, n)) \
            - a(k) * G(k + 1, n, k - 1)

    def form_ii(n, k):
        return 2 * sum(Fr(A(m, k - 2), factorial(m)) * (G(k + 1, n, m) - G(k, n, m)) for m in range(k - 1, n - 1)) \
            - a(k) * G(k + 1, n, k - 1)

    def form_iii(n, k):
        return sum(Fr(A(m, k - 1), factorial(m)) * (G(k + 1, n, m) - G(k - 1, n, m)) for m in range(k, n)) \
            - a(k) * G(k - 1, n, k - 1)

    def M3(n, m, k):
        return (k + 1) * G(k + 1, n, m) - 2 * k * G(k, n, m) + (k - 1) * G(k - 1, n, m)

    def form_iv(n, k):
        return sum(kappa(k, m + 1) * M3(n, m, k) for m in range(k, n - 1)) - a(k) * G(k - 1, n, k - 1)

    forms = (('(i) 원천 2b_{j,k-1}/j!, 핵 G^{[k+1]}, 충격 a_k G^{[k+1]}(n,k-1)', form_i),
             ('(ii) 원천 2A_{m,k-2}/m!, 핵 G^{[k+1]}-G^{[k]}, 충격 a_k G^{[k+1]}(n,k-1)', form_ii),
             ('(iii) 원천 A_{m,k-1}/m!, 핵 G^{[k+1]}-G^{[k-1]}, 충격 a_k G^{[k-1]}(n,k-1)', form_iii),
             ('(iv) 원천 kappa_k(m+1), 세 수준 핵, 충격 a_k G^{[k-1]}(n,k-1)', form_iv))
    for name, fn in forms:
        ok = True
        cnt = 0
        for k in range(2, 16):
            for n in range(k, 2 * k):
                if n > NMAX:
                    continue
                cnt += 1
                ok = ok and (lhs(n, k) == fn(n, k))
        # n=2k에서의 어긋남
        fails = [k for k in range(2, 16) if 2 * k <= NMAX and lhs(2 * k, k) != fn(2 * k, k)]
        allk = [k for k in range(2, 16) if 2 * k <= NMAX]
        report('d_{n,k}/n! = ' + name + '  (2<=k<=15, k<=n<=2k-1)', ok, '%d자리' % cnt)
        report('    같은 식이 n=2k에서는 서지 않는다 (2<=k<=15)', fails == allk,
               '서는 k: %s' % [k for k in allk if k not in fails])

    # (1e) 동률과 막힘, 충격의 족
    ok_d = ok_C = ok_B = ok_Bp = True
    cnt = 0
    for k in range(2, 11):
        nmax = 2 * k - 1
        Km1 = frozen_K(nmax, k, k - 1)
        K0 = frozen_K(nmax, k, k)
        Kp1 = frozen_K(nmax, k, k + 1)
        # 문턱 k-1의 얼린 다항식 (C_+(n,k-1), B_+(n,k-1))
        Kq1 = frozen_K(nmax, k - 1, k + 1)
        for n in range(k + 1, 2 * k):
            cnt += 1
            Cm = Kp1[n] - 2 * K0[n] + Km1[n]
            Bm = Km1[n] - A(n, k - 2)
            ok_d = ok_d and (Cm - Bm == d(n, k))
            ok_C = ok_C and (Cm / factorial(n) == sum(kappa(k, m + 1) * M3(n, m, k) for m in range(k, n - 1)))
            ok_B = ok_B and (Bm / factorial(n) == a(k) * G(k - 1, n, k - 1))
            Bp = Kq1[n] - A(n, k)          # B_+(n,k-1)=K_{n,k-1}(k+1)-Z_n(k+1)
            ok_Bp = ok_Bp and (Bp / factorial(n) == a(k) * G(k + 1, n, k - 1))
    report('d_{n,k}=C_-(n,k)-B_-(n,k)  (얼린 다항식을 숲의 생성함수로 셈; 2<=k<=10, k+1<=n<=2k-1)', ok_d, '%d자리' % cnt)
    report('C_-(n,k)/n! = sum_{m=k}^{n-2} kappa_k(m+1)*M(n,m)  (세 수준 핵)', ok_C)
    report('B_-(n,k)/n! = a_k*G^{[k-1]}(n,k-1)  (= 전역 용어의 iota^{(k-1)}_k(n))', ok_B)
    report('B_+(n,k-1)/n! = a_k*G^{[k+1]}(n,k-1)  (= 전역 용어의 충격 응답 iota_k(n))', ok_Bp)

    # (1f) 세 수준 핵의 곱 꼴과 부호
    ok = True
    okpos = True
    for k in range(2, 9):
        for n in range(k + 1, 2 * k + 3):
            for m in range(k, n):
                rhs = 2 * sum(G(k + 1, n, s) * G(k, s, sp) * ((1 if sp == m else 0) + ((k - 1) * G(k - 1, sp, m) if sp > m else 0))
                              for s in range(m + 1, n) for sp in range(m, s))
                ok = ok and (M3(n, m, k) == rhs)
                if n == m + 1:
                    okpos = okpos and M3(n, m, k) == 0
                else:
                    okpos = okpos and M3(n, m, k) > 0
    report('M=2*K_{k+1}*K_k*(1+(k-1)*K_{k-1})  (핵으로 적은 꼴; 2<=k<=8)', ok)
    report('M(m+1,m)=0이고 n>=m+2에서 M(n,m)>0', okpos)

    # (1i) 임계 기울임의 핵 꼴의 수(r9faef2b6의 정리 15)와의 대응
    ok_e = ok_J = ok_u = ok_eta = True
    for k in range(3, 13):
        x = Fr(k, k + 1) ** (k - 1)
        tau = lambda g: x ** g * a(g)
        om = lambda s: x ** s * c(s)

        @lru_cache(maxsize=None)
        def uu(n, s):
            return tau(n - s) * om(s) / (s + 1) + k * sum(tau(n - sp) * uu(sp, s) / (sp + 1) for sp in range(s + 1, n))

        @lru_cache(maxsize=None)
        def ee(n, s):
            return sum(tau(n - sp) * ((k + 1) * ee(sp, s) + 2 * uu(sp, s)) / (sp + 1) for sp in range(max(s + 1, k), n))

        @lru_cache(maxsize=None)
        def JJ(n):
            return tau(n - k + 1) * om(k - 1) / k + (k + 1) * sum(tau(n - sp) * JJ(sp) / (sp + 1) for sp in range(k, n))

        for n in range(k, 2 * k):
            ok_J = ok_J and (JJ(n) == x ** n * a(k) * G(k + 1, n, k - 1))
            tot = -JJ(n)
            for s in range(k - 1, n):
                ok_u = ok_u and (uu(n, s) == x ** n * c(s) * G(k, n, s))
            for s in range(k - 1, n - 1):
                ok_e = ok_e and (ee(n, s) == 2 * x ** n * c(s) * (G(k + 1, n, s) - G(k, n, s)))
                tot += ee(n, s) * Fr(A(s, k - 2), (s + 1) ** (s - 1))
            ok_eta = ok_eta and (tot == x ** n * Fr(d(n, k), factorial(n)))
    report('핵 꼴의 수: J_n = x^n*a_k*G^{[k+1]}(n,k-1)  (3<=k<=12, 첫 층)', ok_J)
    report('핵 꼴의 수: e_n(s) = 2*x^n*c_s*(G^{[k+1]}-G^{[k]})(n,s),  u_n(s) = x^n*c_s*G^{[k]}(n,s)', ok_e and ok_u)
    report('x^n*d_{n,k}/n! = -J_n + sum_s e_n(s)*Psi_s  (Psi_s=A_{s,k-2}/(s+1)^{s-1})', ok_eta)

    # (1j) 죽임 있는 갱신 사슬 Gamma(r,l) (rdf5f9d9d의 명제 7)
    ok = True
    cnt = 0
    for k in range(3, 12):
        def ghat(j):
            return Fr(j - 1, k + j + 1) if j >= 2 else Fr(0)

        @lru_cache(maxsize=None)
        def Gam(r, l):
            # e^{r-l}*Gamma(r,l): l에서 떠나 r을 밟는 사슬, 사이에 밟는 자리 j마다 1-ghat_j
            tot = a(r - l)
            for j in range(l + 1, r):
                tot += Gam(j, l) * (1 - ghat(j)) * a(r - j)
            return tot
        for r in range(1, k):
            for l in range(0, r):
                cnt += 1
                ok = ok and (Gam(r, l) == (k + l + 1) * G(k + 2, k + r, k + l))
    report('e^{r-l}*Gamma(r,l) = (k+l+1)*G^{[k+2]}(k+r,k+l) = Lambda_{r-l}(k+2;k+r+1)  (0<=l<r<=k-1, 3<=k<=11)', ok, '%d자리' % cnt)


# ---------------------------------------------------------------------------
# 2. 두 열의 차의 풀린 꼴 (rdf5f9d9d)
#    e^r을 곱한 양으로 셈한다: Bor(m)e^m=a_m, Ren(m)e^m=m^m/m!, e^r*D_r, e^r*w_r, e^r*W_r 는 유리수다.
# ---------------------------------------------------------------------------
def Rh(m):
    """e^m*Ren(m) = m^m/m!  (Ren(0)=1)."""
    return Fr(m ** m, factorial(m)) if m > 0 else Fr(1)


def col_consts(k):
    gam = Fr(k + 1, k) ** (k - 2)
    alpha = gam + Fr(2, k + 1)
    xi = Fr(9, 2) - Fr(4, k + 1) - (2 * gam + Fr(6 * k, k + 1)) / (k + 2)
    q1 = Fr(6 * k, (k + 1) * (k + 2))
    q2 = 3 * xi / (k + 3)
    return gam, alpha, xi, q1, q2


def E_(r):
    return Fr(r + 1, r) ** r


def A_(r):
    return Fr(r - 1, r) ** (r - 1)


def B_(r):
    return Fr((r - 1) * (r - 2) ** (r - 2), r ** (r - 1)) if r >= 3 else Fr(0)


def g_(k, j):
    return Fr(j - 1, k + j + 1)


def mu_(k, r):
    """mu_k(r) = eps_r - delta_k + q1*A_r + q2*B_r = alpha_k - E_r + q1*A_r + q2*B_r (유리수)."""
    gam, alpha, xi, q1, q2 = col_consts(k)
    return alpha - E_(r) + q1 * A_(r) + q2 * B_(r)


def pi_(r, j):
    return Fr(comb(r, j) * j ** j * (r - j) ** (r - j), r ** r)


def N_(k, r):
    return mu_(k, r) - sum(g_(k, j) * pi_(r, j) * mu_(k, j) for j in range(2, r))


def check2():
    print('2. 두 열의 차의 풀린 꼴 (기호는 rdf5f9d9d의 것; e^r을 곱한 유리수로 셈한다)')
    ok21 = ok23 = ok31 = okT1 = okT8 = okP7 = True
    okrow1 = okrow2 = okrow3 = okb = True
    cnt = 0
    for k in range(2, 16):
        gam, alpha, xi, q1, q2 = col_consts(k)
        sig = lambda r: Fr(factorial(k), factorial(k + r) * k ** (k - 2))   # e^r*sigma_r
        Dh = lambda r: -sig(r) * d(k + r, k)                                 # e^r*D_r
        wh = lambda r: sig(r) * (d(k + r, k) - d(k + r, k + 1))              # e^r*w_r
        Phi = lambda r: (alpha - 1) * a(r) - a(r + 1)                        # e^r*Phi_r
        rmax = min(k - 1, NMAX - k)
        # 닫힌 꼴
        okrow1 = okrow1 and d(k + 1, k) == -2 * k ** (k - 1) and Dh(1) == Fr(2 * k, k + 1)
        if k >= 3:
            okrow2 = okrow2 and Fr(d(k + 2, k)) == -(Fr(9 * k * k + 7 * k + 2, 2) * k ** (k - 2) - 2 * (k + 1) ** (k - 1)) \
                and Dh(2) == xi and xi > 0
        if k >= 4 and k + 3 <= NMAX:
            okrow3 = okrow3 and Fr(d(k + 3, k)) == -Fr(32 * k ** 3 + 75 * k ** 2 + 67 * k + 18, 3) * k ** (k - 2) \
                + 8 * (k + 1) ** k + 2 * (k + 2) ** k
        if k + 2 <= NMAX:
            okb = okb and b(k + 2, k) == (k + 2) ** k + 2 * (k + 1) ** k
        # (2.1)
        for r in range(1, rmax + 1):
            cnt += 1
            rhs = Phi(r) + sum(a(r - j) * ((1 - g_(k, j)) * wh(j) + 3 * Dh(j) / (k + j + 1)) for j in range(1, r))
            ok21 = ok21 and (wh(r) == rhs)
            # (2.3)
            lhs = wh(r) + sum(Rh(r - j) * g_(k, j) * wh(j) for j in range(2, r))
            rhs = Rh(r) * (alpha - E_(r)) + sum(Rh(r - j) * 3 * Dh(j) / (k + j + 1) for j in range(1, r))
            ok23 = ok23 and (lhs == rhs)
        if k >= 3:
            # 잘린 해 W
            Wh = {}
            for r in range(1, k):
                Wh[r] = Phi(r) + sum(a(r - j) * ((1 - g_(k, j)) * Wh[j] + (3 * (Fr(2 * k, k + 1) if j == 1 else xi) / (k + j + 1) if j <= 2 else 0))
                                     for j in range(1, r))
            for r in range(2, k):
                lhs = Wh[r] + sum(Rh(r - j) * g_(k, j) * Wh[j] for j in range(2, r))
                ok31 = ok31 and (lhs == Rh(r) * mu_(k, r))
            # 정리 1: 3<=l<=r-1에서 d_{k+l,k}<=0이면 w_r>=W_r
            for r in range(2, rmax + 1):
                if all(d(k + l, k) <= 0 for l in range(3, r)):
                    okT1 = okT1 and (wh(r) >= Wh[r])
            # 정리 8: 2<=j<=R에서 N_k(j)>=0이면 0<=Ren(j)N_k(j)<=W_j<=Ren(j)mu_k(j)
            R = 1
            while R + 1 <= k - 1 and N_(k, R + 1) >= 0:
                R += 1
            for j in range(2, R + 1):
                okT8 = okT8 and (0 <= Rh(j) * N_(k, j) <= Wh[j] <= Rh(j) * mu_(k, j))
            # 명제 7 (가): W_r = alpha*Gam(r,0)+theta1*Gam(r,1)+theta2*Gam(r,2)-e*Gam(r,-1)
            def ghat(j):
                return Fr(j - 1, k + j + 1) if j >= 2 else Fr(0)

            @lru_cache(maxsize=None)
            def Gam(r, l):
                tot = a(r - l)
                for j in range(l + 1, r):
                    tot += Gam(j, l) * (1 - ghat(j)) * a(r - j)
                return tot
            for r in range(3, k):
                rhs = alpha * Gam(r, 0) + 3 * Fr(2 * k, k + 1) / (k + 2) * Gam(r, 1) + 3 * xi / (k + 3) * Gam(r, 2) - Gam(r, -1)
                okP7 = okP7 and (Wh[r] == rhs)
    report('처음 행의 닫힌 꼴 d_{k+1,k}=-2k^{k-1}  (2<=k<=15)', okrow1)
    report('둘째 행의 닫힌 꼴과 e^2*D_2=xi_k>0  (3<=k<=15)', okrow2)
    report('셋째 행의 닫힌 꼴 (2.2′)  (4<=k<=15)', okrow3)
    report('b_{k+2,k}=(k+2)^k+2(k+1)^k  (2<=k<=15)', okb)
    report('두 열의 재귀 (2.1)  (2<=k<=15, 1<=r<=k-1, n=k+r<=30)', ok21, '%d자리' % cnt)
    report('풀린 꼴 (2.3): 완충, 정규화의 빚, 열 k의 앞선 행의 양의 결합, 되먹임', ok23)
    report('잘린 해의 풀린 꼴 (3.1): W_r+sum Ren(r-j)g_j W_j = Ren(r)*mu_k(r)  (3<=k<=15)', ok31)
    report('정리 1의 부등식 w_r>=W_r (가정이 서는 자리; 기저 안의 열)', okT1)
    report('정리 8의 부등식 0<=Ren(j)N_k(j)<=W_j<=Ren(j)mu_k(j) (N이 음이 아닌 범위)', okT8)
    report('명제 7 (가)의 사슬 꼴', okP7)

    # 판정 수의 부호가 처음 바뀌는 결손 r_N(k) (주차함수의 수를 쓰지 않는다)
    def rN(k):
        for r in range(2, k):
            if N_(k, r) < 0:
                return r
        return None
    want = {14: 10, 21: 12, 30: 15, 45: 18, 60: 21, 81: 24, 96: 27}
    got = {k: rN(k) for k in want}
    report('N_k(r)<0인 가장 작은 r: k=14,21,30,45,60,81,96에서 10,12,15,18,21,24,27', got == want, str(got))
    # 정리 10의 범위: 2<=r<=18, k>=kappa(r)에서 N_k(r)>=0 (k<=160에서 본다)
    kap = {r: 21 for r in range(2, 11)}
    kap.update({11: 26, 12: 32, 13: 38, 14: 45, 15: 52, 16: 59, 17: 67, 18: 75})
    ok = all(N_(k, r) >= 0 for r in kap for k in range(kap[r], 161))
    report('정리 10의 범위에서 N_k(r)>=0  (2<=r<=18, kappa(r)<=k<=160; 손 증명의 대조이고 증명이 아니다)', ok)
    # 기저 안의 교차 결손: r_N(k)와 tau(k) (k<=15; 2k-1<=30)
    rows = []
    for k in range(8, 16):
        t = q0(k)
        rows.append((k, (t - k) if t else None, rN(k)))
    print('     기저 안의 열 (k, 교차 결손 tau(k), r_N(k)):', rows)


# ---------------------------------------------------------------------------
# 3. 두 수준의 괄호 (r0f0ade87)
# ---------------------------------------------------------------------------
def check3():
    print('3. 두 수준의 괄호 T(n,k), T°(n,k)  (x=x_k=(k/(k+1))^{k-1})')
    ok1 = ok2 = okf1 = okf2 = okeq = oklb1 = oklb2 = okD = okDC = True
    cnt = 0
    for k in range(2, 16):
        x = Fr(k, k + 1) ** (k - 1)
        zp = lambda i: x ** i * Fr(A(i, k), factorial(i))        # z^+_i
        z = lambda i: x ** i * Fr(A(i, k - 1), factorial(i))     # z_i
        zq = lambda i: x ** i * Fr(A(i, k - 2), factorial(i))    # z'_i
        U = lambda i: x ** i * Fr(b(i, k - 1), factorial(i))
        for n in range(2, NMAX + 1):
            N = n - 1
            Dt = x * x * A(N + 1, k) - 2 * N * x * A(N, k - 1) + N * (N - 1) * A(N - 1, k - 2)
            T = x * x * (A(n, k - 2) - 2 * A(n, k - 1)) + 2 * x * (n - 1) * A(n - 1, k - 1) - (n - 1) * (n - 2) * A(n - 2, k - 2) if n >= 2 else None
            DCt = x * x * A(N + 1, k) - 2 * (N + 1) * x * A(N, k - 1) + N * (N + 1) * A(N - 1, k - 2)
            To = x * x * (A(n, k - 2) - 2 * A(n, k - 1)) + 2 * x * n * A(n - 1, k - 1) - n * (n - 1) * A(n - 2, k - 2)
            cnt += 1
            ok1 = ok1 and (x * x * d(n, k) == Dt + T)
            ok2 = ok2 and (x * x * d(n, k) == DCt + To)
            # 전역 용어의 둘째 차분과의 인자
            if N >= 1:
                Dpsi = (N + 1) * zp(N + 1) - 2 * N * z(N) + (N - 1) * zq(N - 1)     # 무게 psi(N)=N
                DC = zp(N + 1) - 2 * z(N) + zq(N - 1)
                okf1 = okf1 and (Dt == Fr(factorial(N)) / x ** (N - 1) * Dpsi)
                okf2 = okf2 and (DCt == Fr(factorial(N + 1)) / x ** (N - 1) * DC)
            # 기울인 꼴: T*x^{n-2}/(n-1)! = 2U_{n-1}(sigma_n-1)-SC'(n-1)
            if n - 1 >= k and n >= 3:
                SC = (N - 1) * zq(N - 1) - 2 * N * zq(N) + (N + 1) * zq(N + 1)
                vs = n * (1 - U(n) / U(n - 1))
                okeq = okeq and (T * x ** (n - 2) / factorial(n - 1) == 2 * U(n - 1) * (vs - 1) - SC)
                okeq = okeq and (vs == n - x * Fr(b(n, k - 1), b(n - 1, k - 1)))
            # 아래 한계
            if k >= 3 and n >= k + 1:
                okD = okD and (Dt >= 0)
                oklb1 = oklb1 and (x * x * d(n, k) >= T)
            if k >= 2 and k + 1 <= n <= 2 * k + 1:
                okDC = okDC and (DCt >= 0)
                oklb2 = oklb2 and (x * x * d(n, k) >= To)
    report('x^2*d_{n,k} = Dtilde(n-1)+T(n,k)  (2<=k<=15, 2<=n<=30)', ok1, '%d자리' % cnt)
    report('x^2*d_{n,k} = DCtilde(n-1)+T°(n,k)', ok2)
    report('Dtilde(N) = (N!/x^{N-1})*Delta_psi(N), psi(N)=N  (전역 용어 「무게 달린 대각 둘째 차분」; N=n-1이면 인자 (n-1)!/x^{n-2})', okf1)
    report('DCtilde(N) = ((N+1)!/x^{N-1})*DC(N)  (전역 용어 「대각 둘째 차분」의 핵 질량 꼴; N=n-1이면 인자 n!/x^{n-2})', okf2)
    report('T(n,k)*x^{n-2}/(n-1)! = 2U_{n-1}(varsigma_n-1)-SC′(n-1),  varsigma_n=n-x*b_{n,k-1}/b_{n-1,k-1}  (n-1>=k)', okeq)
    report('기저 안에서 Dtilde(N)>=0 (k>=3, N>=k)이고 d_{n,k}>=T(n,k)/x^2 (k>=3, n>=k+1)', okD and oklb1)
    report('기저 안에서 DCtilde(N)>=0 (k>=2, k<=N<=2k)이고 d_{n,k}>=T°(n,k)/x^2 (k+1<=n<=2k+1)', okDC and oklb2)


# ---------------------------------------------------------------------------
# 4. 영역 설명에 조직화가 수를 대입해 적은 대응과 문턱의 산수
# ---------------------------------------------------------------------------
def check4():
    print('4. 영역 설명에 적은 산수')
    from math import ceil
    # 명제 14 (가): 82<=k<=88에서 d_{108,k}>0, 89<=k<=96에서 d_{117,k}>0. 곧 q_0(k)<=108, 117.
    ok = all(108 <= k + ceil(k / 3) - 1 for k in range(82, 89)) and all(117 <= k + ceil(k / 3) - 1 for k in range(89, 97))
    need = [ceil(k / 3) - 1 for k in range(82, 97)]
    report('108<=k+ceil(k/3)-1 (82<=k<=88)이고 117<=k+ceil(k/3)-1 (89<=k<=96)', ok,
           '필요한 상계의 결손 ceil(k/3)-1은 %d에서 %d' % (min(need), max(need)))
    # 정리 S+의 가정 q_0(k)<=k+k/3도 같은 수에서 선다
    ok = all(3 * (108 - k) <= k for k in range(82, 89)) and all(3 * (117 - k) <= k for k in range(89, 97))
    report('같은 수에서 q_0(k)<=k+k/3 (82<=k<=96)', ok)
    # r0f0ade87: 63은 가정 q_0(k)<=k+27k/100이 표의 교차 행에서 참이 되는 끝 (q_0(62)-62=17, q_0(63)-63=17)
    report('17>27*62/100이고 17<=27*63/100', 17 * 100 > 27 * 62 and 17 * 100 <= 27 * 63)
    # 갈아타는 행의 뒤처짐: 3k/5-27k/100=0.33k
    report('3/5-27/100=33/100', Fr(3, 5) - Fr(27, 100) == Fr(33, 100))
    # 기저 안에서 볼 수 있는 닫힌 꼴의 값: d_{4,3}=-18, d_{5,3}=-124, d_{7,4}=-11256
    report('d_{4,3}=-18, d_{5,3}=-124, d_{7,4}=-11256', d(4, 3) == -18 and d(5, 3) == -124 and d(7, 4) == -11256)
    # 기저 안의 교차 행 (rdf5f9d9d의 주장 p-mono-structural이 적은 값): q_0(k), k=1..20
    want = [3, 6, 8, 10, 12, 13, 15, 16, 17, 19, 20, 21, 22, 23, 25, 26, 27, 28, 29, 30]
    report('q_0(k)=3,6,8,10,12,13,15,16,17,19,20,21,22,23,25,26,27,28,29,30 (k=1..20)', [q0(k) for k in range(1, 21)] == want)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    check0()
    check1()
    check2()
    check3()
    check4()
    print('모든 대조가 맞았다.' if OK else '어긋난 대조가 있다.')
    sys.exit(0 if OK else 1)
