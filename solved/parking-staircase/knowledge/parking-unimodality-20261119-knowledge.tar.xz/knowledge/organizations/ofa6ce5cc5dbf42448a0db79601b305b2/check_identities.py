"""조직화 판단에 쓴 표기 대응의 작은 범위 대조 (정확한 정수와 유리수).

이 계산은 용어를 묶거나 모듈 설명에 대응을 적어도 되는지를 확인하려는 것이고,
연구의 증거로 쓰려는 것이 아니다. 범위는 n <= NMAX 이다.
"""
from fractions import Fraction as Fr
from math import comb, factorial
import sys

NMAX = 14

# --- 누적 개수 A_{n,k}: 마지막 차 재귀 A_{m+1,k} = sum_j C(m,j) min(j+1,k+1) A_{j,k} A_{m-j,k}
A = {}
for k in range(-2, NMAX + 3):
    A[0, k] = 1
for k in range(-2, 0):
    for n in range(1, NMAX + 2):
        A[n, k] = 0
for k in range(0, NMAX + 3):
    for m in range(0, NMAX + 1):
        A[m + 1, k] = sum(comb(m, j) * min(j + 1, k + 1) * A[j, k] * A[m - j, k] for j in range(m + 1))

def b(n, k):
    if k < 0 or k > n - 1:
        return 0
    return A[n, k] - A[n, k - 1]

def d(n, k):
    return b(n, k) - b(n, k - 1)

def p(n):
    return (n + 1) ** (n - 1) if n >= 1 else 1

ok = True
def need(cond, msg):
    global ok
    if not cond:
        ok = False
        print('FAIL', msg)

# 뿌리 파일의 표와 대조
need([b(4, l) for l in range(4)] == [24, 51, 34, 16], 'row 4')
need([b(7, l) for l in range(7)] == [5040, 42253, 62145, 57398, 46142, 32359, 16807], 'row 7')
for n in range(1, NMAX + 1):
    need(A[n, n - 1] == p(n), 'total')

# (1) 문턱 누적 개수 Z_n(k) = A_{n,k-1} 의 약속: Z_0(k)=1, Z_n(0)=0 (n>=1), k>=n 이면 p_n
for n in range(0, NMAX + 1):
    for k in range(0, NMAX + 2):
        Z = A[n, k - 1]
        if n == 0:
            need(Z == 1, 'Z_0')
        elif k == 0:
            need(Z == 0, 'Z_n(0)')
        elif k >= n:
            need(Z == p(n), 'Z_n(k>=n)')
# 한 칸 차분 d_{n,k} = Z_n(k+1) - 2 Z_n(k) + Z_n(k-1)
for n in range(1, NMAX + 1):
    for k in range(1, n):
        need(d(n, k) == A[n, k] - 2 * A[n, k - 1] + A[n, k - 2], 'step')

# (2) 전이 비 q_N(r) (r535d20f) 와 머무를 확률 stay_{n+1}(k) (r6af349eb): N = n+1, r = n-k
def F(n, l):  # Pr(M_n <= l)
    if l < 0:
        return Fr(0) if n >= 1 else Fr(1)
    return Fr(A[n, min(l, n)], p(n)) if n >= 1 else Fr(1)

def P(n, l):
    return Fr(b(n, l), p(n))

def J(n, k):  # 흐름 J_n(k) = F_n(k) - F_{n-1}(k-1)
    return F(n, k) - (F(n - 1, k - 1) if k >= 1 else Fr(0))

def stay(n, k):
    return J(n, k) / P(n - 1, k)

def q(N, r):  # [phi_{N+1}(r+1) - phi_N(r+1)] / m_N(r),  phi_N(r) = A_{n,n-r}/p_n, m_N(r) = b_{n,n-r}/p_n, n = N-1
    n = N - 1
    phi = lambda NN, rr: F(NN - 1, NN - 1 - rr)
    return (phi(N + 1, r + 1) - phi(N, r + 1)) / P(n, n - r)

for n in range(1, NMAX):
    for k in range(0, n):
        N, r = n + 1, n - k
        need(stay(n + 1, k) == q(N, r), 'stay = q')
        need(0 <= q(N, r) <= 1, '0<=q<=1')
    # 전이 항등식 m_{N+1}(r) = (1-q_N(r)) m_N(r) + q_N(r-1) m_N(r-1)
    for k in range(0, n + 1):
        lhs = P(n + 1, k)
        rhs = (stay(n + 1, k) * P(n, k) if k <= n - 1 else 0) + ((1 - stay(n + 1, k - 1)) * P(n, k - 1) if 1 <= k else 0)
        need(lhs == rhs, 'transfer identity')
# 대각 증분의 여러 이름: re8460c2 의 Delta_j(N) = Pr(M_{N-1}<j) - Pr(M_{N-2}<j-1) = J_{N-1}(j-1);
# rf9e63ea 의 varsigma_n(k) = s_{n+1}(k+1) - s_n(k) = J_{n+1}(k), s_n(k) = Pr(M_n<k)
for N in range(3, NMAX + 1):
    for j in range(1, N):
        need(F(N - 1, j - 1) - F(N - 2, j - 2) == J(N - 1, j - 1), 'Delta = J')
for n in range(1, NMAX):
    for k in range(1, n + 1):
        need(F(n + 1, k) - F(n, k - 1) == J(n + 1, k), 'varsigma = J')

# (3) 나무 행: beta^{(t)}_l = (l+1)A_{t-1,l} - l A_{t-1,l-1} = tau_{t,l} - tau_{t,l-1}, 합 t^{t-1}; 나무 곡률
def tau(t, k):
    return min(t, k + 1) * A[t - 1, k] if k >= 0 else 0

for t in range(1, NMAX + 1):
    row = [(l + 1) * A[t - 1, l] - l * A[t - 1, l - 1] for l in range(t)]
    need(row == [tau(t, l) - tau(t, l - 1) for l in range(t)], 'tree row')
    need(row == [(l + 1) * b(t - 1, l) + A[t - 1, l - 1] for l in range(t)], 'tree row 2')
    need(sum(row) == t ** (t - 1), 'tree row sum')
    for k in range(2, t):  # t >= k+1
        delta = tau(t, k) - 2 * tau(t, k - 1) + tau(t, k - 2)
        need(delta == row[k] - row[k - 1], 'curvature from tree row')
        need(delta == (k + 1) * b(t - 1, k) - (k - 1) * b(t - 1, k - 1), 'curvature formula')
for k in range(2, NMAX):
    need(tau(k, k) - 2 * tau(k, k - 1) + tau(k, k - 2) == -k ** (k - 2), 'delta_k')

# (4) 대각 아래 한계 (r6af349eb 정리 Dg): b_{n,k} >= (1+1/k)^{k-2} n b_{n-1,k-1}  (k>=2, n>=k+1), 등호는 n=k+1
for k in range(2, NMAX):
    for n in range(k + 1, NMAX + 1):
        lhs = Fr(b(n, k))
        rhs = Fr(k + 1, k) ** (k - 2) * n * b(n - 1, k - 1)
        need(lhs >= rhs, 'Dg')
        need((lhs == rhs) == (n == k + 1), 'Dg equality only at n=k+1')

# (5) r6473edca 명제 6.6 의 귀결: A_{m,k} >= (k+1)(1+1/m)^{m-1} A_{m-1,k}  (0<=k<=m-1 에서 시험; k=m-1 에서 등호)
bad = []
for m in range(1, NMAX + 1):
    for k in range(0, m):
        lhs = Fr(A[m, k])
        rhs = (k + 1) * Fr(m + 1, m) ** (m - 1) * A[m - 1, k]
        if lhs < rhs:
            bad.append((m, k))
need(not bad, 'tree dominates forest bound fails at %s' % bad[:5])

# (6) 노드 (C) 와 (Col_1) 의 정의역: (Col_1) 은 k+1<=n<=2k-1, (C) 는 k+1<=n<=2k-2. 작은 범위에서 0 인 차분이 없음을 본다.
zeros = [(n, k) for n in range(2, NMAX + 1) for k in range(1, n) if d(n, k) == 0]
print('zero steps for n <=', NMAX, ':', zeros)

# (7) 여분 자리 족 (r,m) 의 행: 길이 m+r-1 의 주차함수에서 처음 m 대의 최대 변위 (전수 열거, 작은 크기)
from itertools import product
def prefix_rows(n, m):
    cnt = {}
    for alpha in product(range(1, n + 1), repeat=n):
        occ = [False] * (n + 2)
        mx = 0
        good = True
        for i, a in enumerate(alpha):
            s = a
            while s <= n and occ[s]:
                s += 1
            if s > n:
                good = False
                break
            occ[s] = True
            if i < m:
                mx = max(mx, s - a)
        if good:
            cnt[mx] = cnt.get(mx, 0) + 1
    return cnt
def allowed_rows(m, r):
    cnt = {}
    L = m + r - 1
    for alpha in product(range(1, L + 1), repeat=m):
        occ = [False] * (L + 2)
        mx = 0
        good = True
        for a in alpha:
            s = a
            while s <= L and occ[s]:
                s += 1
            if s > L:
                good = False
                break
            occ[s] = True
            mx = max(mx, s - a)
        if good:
            cnt[mx] = cnt.get(mx, 0) + 1
    return cnt
for (m, r) in [(2, 2), (3, 2), (3, 3), (4, 2), (2, 4)]:
    n = m + r - 1
    ar = allowed_rows(m, r)
    need(sum(ar.values()) == r * (m + r) ** (m - 1), 'allowed count')
    pr = prefix_rows(n, m)
    tot_a, tot_p = sum(ar.values()), sum(pr.values())
    need(all(Fr(ar.get(l, 0), tot_a) == Fr(pr.get(l, 0), tot_p) for l in range(m)), 'spare-spot = prefix law (m=%d,r=%d)' % (m, r))


# ---------------------------------------------------------------------------
# 덧붙임 (용어 승격의 확인)
# (8) r43fbfedf 의 Borel 무게의 모멘트 측도: c_m = int_0^e s^m nu(ds), nu(ds) = v(s)/pi ds,
#     s(v) = (sin v / v) e^{v cot v} (0<v<pi). 부분적분으로 c_m = (1/(pi (m+1))) int_0^pi s(v)^{m+1} dv.
import math
def sv(v):
    if v < 1e-9:
        return math.e
    if math.pi - v < 1e-9:
        return 0.0
    return math.sin(v) / v * math.exp(v * math.cos(v) / math.sin(v))
def simpson(f, a, b2, n=200000):
    h = (b2 - a) / n
    s = f(a) + f(b2)
    for i in range(1, n):
        s += (4 if i % 2 else 2) * f(a + i * h)
    return s * h / 3
num_ok = True
for m in range(0, 7):
    val = simpson(lambda v: sv(v) ** (m + 1), 0.0, math.pi) / (math.pi * (m + 1))
    cm = (m + 1) ** (m - 1) / math.factorial(m)
    if abs(val - cm) > 1e-7 * max(1, cm):
        num_ok = False
        print('FAIL moment', m, val, cm)
print('Borel moment measure moments c_0..c_6:', 'ok' if num_ok else 'FAILED')

# (9) rf9e63ea 의 라벨 모형: b_{n,l} = #{[n] 위의 뿌리 숲 F : max_v I_v(F) = l}, I_v = #{u in sub(v): u < v}
#     (n <= 6 전수 열거; 숲은 {0..n} 위의 뿌리 0 인 나무의 부모 함수)
from itertools import product as _prod
def forests(n):
    for par in _prod(range(0, n + 1), repeat=n):
        ok2 = True
        for v in range(1, n + 1):
            if par[v - 1] == v:
                ok2 = False; break
        if not ok2:
            continue
        # acyclic: every vertex reaches 0
        good = True
        for v in range(1, n + 1):
            seen = 0; u = v
            while u != 0 and seen <= n:
                u = par[u - 1]; seen += 1
            if u != 0:
                good = False; break
        if good:
            yield par
lab_ok = True
for n in range(1, 7):
    cnt = {}
    tot = 0
    for par in forests(n):
        tot += 1
        # ancestors
        I = [0] * (n + 1); J = [0] * (n + 1)
        for u in range(1, n + 1):
            w = par[u - 1]
            while w != 0:
                if u < w: I[w] += 1
                else: J[w] += 1
                w = par[w - 1]
        mI = max(I[1:]); mJ = max(J[1:])
        cnt[mI] = cnt.get(mI, 0) + 1
        cnt[('J', mJ)] = cnt.get(('J', mJ), 0) + 1
    if tot != (n + 1) ** (n - 1):
        lab_ok = False; print('FAIL forest count', n, tot)
    for l in range(n):
        if cnt.get(l, 0) != b(n, l) or cnt.get(('J', l), 0) != b(n, l):
            lab_ok = False; print('FAIL label model', n, l, cnt.get(l, 0), cnt.get(('J', l), 0), b(n, l))
print('label model (both orientations) n<=6:', 'ok' if lab_ok else 'FAILED')

# (10) 교차 행 q_0(k) = min{n>=k+1 : d_{n,k}>0} 의 비감소와 노드 (Mono) 의 문면이 같은 진술인지 (n <= NMAX 범위에서 대조)
def q0(k):
    for n in range(k + 1, NMAX + 1):
        if d(n, k) > 0:
            return n
    return None
mono_stmt = all((not all(d(j, k) <= 0 for j in range(k + 1, n + 1))) or d(n, k + 1) <= 0
                for n in range(3, NMAX + 1) for k in range(1, n - 1))
q = [q0(k) for k in range(1, NMAX)]
print('q_0(k), k=1..:', q, '| (Mono) literal on n<=%d:' % NMAX, mono_stmt)

ok = ok and num_ok and lab_ok and mono_stmt and all(q[i] <= q[i+1] for i in range(len(q)-1) if q[i] is not None and q[i+1] is not None)
print('ALL OK' if ok else 'SOME FAILED')
sys.exit(0 if ok else 1)
