# Exact check of the identities used in the organizer's term-merge reasons.
# A[n][k] = #{parking functions of length n with max displacement <= k}, via the last-car recursion.
from fractions import Fraction as Fr
from math import comb, factorial
NMAX = 16
def A(n, k, memo={}):
    if n == 0: return 1
    if k < 0: return 0
    if (n, k) in memo: return memo[(n, k)]
    v = sum(comb(n-1, j) * min(j+1, k+1) * A(j, k) * A(n-1-j, k) for j in range(n))
    memo[(n, k)] = v
    return v
# sanity against the root table
assert [A(4,l)-A(4,l-1) for l in range(4)] == [24, 51, 34, 16]
assert [A(7,l)-A(7,l-1) for l in range(7)] == [5040, 42253, 62145, 57398, 46142, 32359, 16807]
def tau(t, k):            # rc31497: tree number
    return 0 if k < 0 else min(t, k+1) * A(t-1, k)
def Ncap(c, t):           # r3e8ad56e: N_c(t)
    return min(t, c) * A(t-1, c-1) if c >= 1 else 0
def Theta(N, s):          # r213dbe8: closed parking functions with M < s
    return min(N, s) * A(N-1, s-1)
ok = True
for t in range(1, NMAX):
    for k in range(0, NMAX):
        ok &= tau(t, k) == Ncap(k+1, t) == Theta(t, k+1)
print('tau_{t,k} = N_{k+1}(t) = Theta(t,k+1):', ok)
bad = 0
for x in (Fr(1,3), Fr(2,5), Fr(7,10)):
    def n_(c, t): return Fr(Ncap(c, t)) * x**t / factorial(t) if t >= 1 else Fr(0)
    def w(t): return x**t / factorial(t)
    for k in range(2, 7):
        def delta(t): return tau(t, k) - 2*tau(t, k-1) + tau(t, k-2)
        def DCT(t): return n_(k+1, t+1) - 2*n_(k, t) + n_(k-1, t-1)
        def J(t): return n_(k+1, t) - n_(k-1, t-1)
        def beta(t): return Fr(t**(t-1)) * x**t / factorial(t)
        for n0 in range(k+2, NMAX-1):
            lhs = sum(w(t)*delta(t) for t in range(k, n0+1))
            Lo = w(k+1)*(k+1)**k - w(k)*k**(k-1)
            D = {a: w(k+1+a)*tau(k+1+a, k) - 2*w(k+a)*tau(k+a, k-1) + w(k-1+a)*tau(k-1+a, k-2) for a in range(1, n0-k)}
            In = sum(D.values())
            Tp = w(n0-1)*tau(n0-1, k-2) - 2*w(n0)*tau(n0, k-1) + w(n0)*tau(n0, k-2)
            if lhs != Lo + In + Tp: bad += 1
            if any(D[a] != DCT(k+a) for a in D): bad += 1
            if Tp != DCT(n0) - J(n0+1): bad += 1
            if Lo != beta(k+1) - beta(k): bad += 1
            if lhs != (beta(k+1)-beta(k)) + sum(DCT(t) for t in range(k+1, n0+1)) - J(n0+1): bad += 1
print('excess-orbit vs diagonal regrouping mismatches:', bad)
# transfer ratio identity m_{N+1}(r) = (1-q_N(r)) m_N(r) + q_N(r-1) m_N(r-1) in root coordinates
bad = 0
def p(n): return (n+1)**(n-1) if n >= 1 else 1
def P(n, k): return Fr(A(n, k), p(n)) if k >= 0 else Fr(0)   # Pr(M_n <= k)
for n in range(2, 11):
    N = n + 1
    def m(NN, r): nn = NN-1; return P(nn, nn-r) - P(nn, nn-r-1)
    def q(r): k = n - r; return (P(n+1, k) - P(n, k-1)) / m(N, r)
    for r in range(1, n+1):
        rhs = (1 - q(r)) * m(N, r) + (q(r-1) * m(N, r-1) if r >= 2 else 0)
        if m(N+1, r) != rhs: bad += 1
        if not (0 <= q(r) <= 1): bad += 1
print('transfer-ratio identity / range mismatches:', bad)
