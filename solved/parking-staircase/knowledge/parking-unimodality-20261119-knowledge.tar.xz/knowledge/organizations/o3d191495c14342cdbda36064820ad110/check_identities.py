# -*- coding: utf-8 -*-
"""조직화 세션 s68c4ca4b02d24bf6a4a63c120d557f49의 대조 스크립트 (묶음: 연구 개정 99-108).

이 스크립트는 이 조직화가 영역 설명, 용어의 병합 사유, 조직화의 기록에 옮겨 적은 식과 대응이
기록의 정의와 같은 수를 주는지를 작은 예에서 확인한다. 주차함수의 수는 길이 n<=30만 쓴다
(인수인계 문서의 규칙 1의 기저). 옮겨 적은 식의 대조이고, 어느 정리의 근거도 아니다.
주차함수의 수가 드는 셈은 모두 정확한 유리수다.

  0. 도구의 자기 점검: 마지막 차 점화식으로 셈한 b_{n,l}을 뿌리 명제의 확인용 값(n<=7)과 견준다.
  1. 용어의 병합 (rc4c34a92...의 「열 초과와 분리 수준, 분리 수준의 창」을 전역 용어
     「대각 비와 대각 초과(세 가지 쓰임), 평균 대각 초과, 필요 초과」에 합친다):
     분리 수준 lambda와 필요 초과 n_k(z)가 같은 좌표라는 것, 두 표시된 값, 기울임 지수 eta와의 관계,
     d_{n,k}=(gamma_k n b_{n-1,k-1}/k)(e-c), (DB)와 (CB)의 꼴.
  2. r88d1de99...의 유출과 전역 용어 「전이 비」: 유출이 올라가는 흐름(열 감소분)에 p_{n+1}을 곱한
     것이라는 것, 전이 비로 적은 꼴, 게시된 강한 꼴 (Q') (기저 안의 자리).
  3. r8a9fd8d8...의 나무 정규화한 질량과 노드 (D): v_rho(c)=n_c(c+rho+1)/x, 노드 (D)의 식이
     나무 질량 꼴의 대각 둘째 차분에 (t+1)!/x^{t-1}을 곱한 것이라는 것, 무게 달린 대각 볼록성의 식.
  4. r78a97aa6...의 율-2 감소: 소인 핵의 정의(급수 1-1/F의 계수), m<=k의 닫힌 꼴, 율-2의 두 꼴이
     같은 부등식이라는 것(기저 안의 열에서의 관찰).
  5. r538f630c...: (J)의 꼴 4(j-k)<k와 정리 J의 꼴 j-k<=ceil(k/4)-1이 같다는 산수, (J)에서 (E)가
     따른다는 산수, 창의 길이 R_s(k)의 양쪽 한계(명제 W)와 위 한계(따름 W'')를 전역 용어의 정의로
     셈한 값과 견준 것.
  6. r1c0e811e...의 보조정리 H의 꼴(기저 안의 자리), rcca316c6...의 보조정리 A의 꼴.
  7. 설명에 적은 산수 몇 개.

실행: python check_identities.py  (표준 라이브러리만 쓴다)
"""
import sys
from fractions import Fraction as Fr
from functools import lru_cache
from math import comb, factorial, isqrt

NMAX = 30
OK = True


def report(label, cond, extra=''):
    global OK
    OK = OK and bool(cond)
    print(('  [맞음] ' if cond else '  [어긋남] ') + label + ((' — ' + extra) if extra else ''))


@lru_cache(maxsize=None)
def A(n, k):
    """최대 변위가 k 이하인 길이 n의 주차함수의 수 (A_{0,k}=1; n>=1, k<0이면 0)."""
    if n == 0:
        return 1
    if k < 0:
        return 0
    if k >= n - 1:
        return (n + 1) ** (n - 1)
    return sum(comb(n - 1, j) * min(j + 1, k + 1) * A(j, k) * A(n - 1 - j, k) for j in range(n))


def b(n, l):
    if l < 0 or l > n - 1:
        return 0
    return A(n, l) - A(n, l - 1)


def d(n, k):
    return b(n, k) - b(n, k - 1)


def p(n):
    return 1 if n == 0 else (n + 1) ** (n - 1)


def gam(k):
    return Fr(k + 1, k) ** (k - 2)


def rr(k):
    """임계 성장비 (1+1/k)^{k-1}."""
    return Fr(k + 1, k) ** (k - 1)


def xcrit(k):
    return Fr(k, k + 1) ** (k - 1)


def xdiag(k):
    return Fr(k, k + 1) ** (k - 2)


# ---------------------------------------------------------------------------
print('0. 도구의 자기 점검')
ROOT = {1: [1], 2: [2, 1], 3: [6, 7, 3], 4: [24, 51, 34, 16], 5: [120, 421, 377, 253, 125],
        6: [720, 3963, 4594, 3688, 2546, 1296], 7: [5040, 42253, 62145, 57398, 46142, 32359, 16807]}
report('n<=7의 행이 뿌리 명제의 확인용 값과 같다', all([b(n, l) for l in range(n)] == ROOT[n] for n in ROOT))
report('n<=30에서 행의 합이 (n+1)^(n-1)', all(sum(b(n, l) for l in range(n)) == p(n) for n in range(1, NMAX + 1)))

# ---------------------------------------------------------------------------
print('1. 열 초과와 분리 수준 (rc4c34a92) 과 전역 용어의 필요 초과')


def e_exc(n, k):
    return k * (Fr(b(n, k)) / (gam(k) * n * b(n - 1, k - 1)) - 1)


def c_exc(n, k):
    return k * (Fr(b(n, k - 1)) / (gam(k) * n * b(n - 1, k - 1)) - 1)


def need(k, z):
    """전역 용어의 필요 초과 n_k(z)=k(1/(z gamma_k)-1)."""
    return k * (1 / (z * gam(k)) - 1)


ok = True
cnt = 0
for k in range(2, 15):
    for lam in [Fr(0), Fr(1), Fr(1, 2), Fr(-1, 3), Fr(5, 4), Fr(7, 3)]:
        g = gam(k) * (1 + lam / k)
        ok &= (need(k, 1 / g) == lam)
        cnt += 1
report('성장비 gamma=gamma_k(1+lambda/k)의 분리 수준 lambda는 필요 초과 n_k(1/gamma)와 같다 (2<=k<=14)', ok, f'{cnt}자리')
report('lambda=0은 대각 기울임 1/gamma_k=(k/(k+1))^{k-2}에서, lambda=1은 임계 기울임 x_k에서의 값이다',
       all(need(k, xdiag(k)) == 0 and need(k, xcrit(k)) == 1 for k in range(2, 30)))
ok = True
for k in range(2, 15):
    for eta in [Fr(0), Fr(1), Fr(1, 2), Fr(-1, 2), Fr(7, 10), Fr(2)]:
        x = xcrit(k) * (1 + eta / k)
        ok &= (need(k, x) == k * (1 - eta) / (k + eta))
report('기울임 x=x_k(1+eta/k)에서 n_k(x)=k(1-eta)/(k+eta)', ok)
ok = True
cnt = 0
okdb = True
okcb = True
for k in range(2, 16):
    for n in range(k + 1, NMAX + 1):
        ee, cc = e_exc(n, k), c_exc(n, k)
        ok &= (d(n, k) == gam(k) * n * b(n - 1, k - 1) / k * (ee - cc))
        okdb &= ((b(n, k) >= rr(k) * n * b(n - 1, k - 1)) == (ee >= 1))
        okcb &= ((b(n, k - 1) <= rr(k) * n * b(n - 1, k - 1)) == (cc <= 1))
        cnt += 1
report('d_{n,k}=(gamma_k n b_{n-1,k-1}/k)(e(n,k)-c(n,k))  (2<=k<=15, k+1<=n<=30)', ok, f'{cnt}자리')
report('(DB_{n,k})는 e(n,k)>=1과, (CB_{n,k})는 c(n,k)<=1과 같은 말이다 (같은 자리)', okdb and okcb)
report('대각 아래 한계(정리 Dg)는 e(n,k)>=0이고 등호는 n=k+1에서만 (같은 자리)',
       all((e_exc(n, k) >= 0) and ((e_exc(n, k) == 0) == (n == k + 1)) for k in range(2, 16) for n in range(k + 1, NMAX + 1)))

# ---------------------------------------------------------------------------
print('2. 유출 (r88d1de99) 과 전역 용어의 전이 비')


def outflow(n, k):
    return Fr(p(n + 1), p(n)) * A(n, k - 1) - A(n + 1, k - 1)


def PrLe(n, l):
    return Fr(A(n, l), p(n)) if l >= 0 else Fr(0)


ok1 = True
ok2 = True
ok3 = True
cnt = 0
for n in range(1, NMAX):
    for k in range(1, n + 2):
        o = outflow(n, k)
        ok1 &= (o == p(n + 1) * (PrLe(n, k - 1) - PrLe(n + 1, k - 1)))
        ok3 &= (o >= 0)
        cnt += 1
    for l in range(0, n):
        q = (PrLe(n + 1, l) - PrLe(n, l - 1)) / Fr(b(n, l), p(n))
        ok2 &= (outflow(n, l + 1) == Fr(p(n + 1), p(n)) * (1 - q) * b(n, l))
report('유출 O_n(k)=r^_n A_{n,k-1}-A_{n+1,k-1}은 p_{n+1}·[Pr(M_n<k)-Pr(M_{n+1}<k)]다 (n<=29)', ok1, f'{cnt}자리')
report('O_n(l+1)=r^_n·(1-q)·b_{n,l}, q는 자리 (n,l)의 전이 비 q_{n+1}(n-l) (n<=29, 0<=l<=n-1)', ok2)
report('유출은 음이 아니다 (같은 자리; 누적의 끼임의 한쪽)', ok3)
ok = True
cnt = 0
for l in range(0, NMAX):
    for N in range(l + 1, NMAX):
        lhs = A(N + 1, l)
        rhs = Fr(p(N + 1), p(N)) * A(N, l) - Fr(p(l + 1), p(l)) * b(N, l)
        ok &= (lhs <= rhs)
        cnt += 1
report("강한 꼴 (Q'): A_{N+1,l} <= (p_{N+1}/p_N)A_{N,l} - (p_{l+1}/p_l)b_{N,l}  (0<=l<N<=29)", ok, f'{cnt}자리')

# ---------------------------------------------------------------------------
print('3. 나무 정규화한 질량 (r8a9fd8d8), 노드 (D), 무게 달린 대각 볼록성')


def u_mass(N, c, x):
    return x ** N * Fr(A(N, c - 1), factorial(N))


def n_tree(c, t, x):
    return min(t, c) * A(t - 1, c - 1) * x ** t / factorial(t)


ok = True
okD = True
okpos = True
cnt = 0
for k in range(3, 15):
    x = xcrit(k)
    for c in (k - 1, k, k + 1):
        for rho in range(0, 8):
            if c + rho + 1 <= NMAX:
                ok &= (Fr(c, c + rho + 1) * u_mass(c + rho, c, x) == n_tree(c, c + rho + 1, x) / x)
    for t in range(k + 1, min(2 * k + 1, NMAX) + 1):
        dct = n_tree(k + 1, t + 1, x) - 2 * n_tree(k, t, x) + n_tree(k - 1, t - 1, x) if t + 1 <= NMAX + 1 and t <= NMAX - 0 else None
        if t > NMAX - 1:
            continue
        nodeD = (k + 1) * x ** 2 * A(t, k) - 2 * k * (t + 1) * x * A(t - 1, k - 1) + (k - 1) * t * (t + 1) * A(t - 2, k - 2)
        okD &= (nodeD == dct * factorial(t + 1) / x ** (t - 1))
        okpos &= (nodeD >= 0)
        cnt += 1
report('v_rho(c)=(c/(c+rho+1))u_{c+rho}(c)=n_c(c+rho+1)/x  (3<=k<=14, c=k-1,k,k+1)', ok)
report('노드 (D)의 식 = DC^T(t)·(t+1)!/x_k^{t-1}  (3<=k<=14, k+1<=t<=min(2k+1,29))', okD, f'{cnt}자리')
report('그 식이 그 자리(첫 층과 접합부의 두 크기; 기저 안)에서 음이 아니다', okpos)
ok = True
cnt = 0
for k in range(3, 15):
    x = xcrit(k)
    for N in range(k, NMAX):
        v = x ** 2 * A(N + 1, k) - 2 * N * x * A(N, k - 1) + N * (N - 1) * A(N - 1, k - 2)
        ok &= (v >= 0)
        cnt += 1
report('무게 달린 대각 볼록성 x_k^2 A_{N+1,k}-2N x_k A_{N,k-1}+N(N-1)A_{N-1,k-2}>=0  (3<=k<=14, k<=N<=29)', ok, f'{cnt}자리')

# ---------------------------------------------------------------------------
print('4. 소인 핵과 율-2 감소 (r78a97aa6)')


@lru_cache(maxsize=None)
def Cprime(m, k):
    """모든 변위가 k보다 작은 길이 m의 소인 주차함수의 수: 1/F=1-sum C_{m,k}x^m/m!, F=sum A_{N,k-1}x^N/N!."""
    # F*(1-P)=1  =>  sum_{j} binom(m,j) A_{m-j,k-1} C_j = A_{m,k-1}  (m>=1), C_0 := 0
    if m == 0:
        return 0
    s = A(m, k - 1)
    for j in range(1, m):
        s -= comb(m, j) * A(m - j, k - 1) * Cprime(j, k)
    return s


ok = True
for k in range(2, 13):
    for m in range(1, k + 1):
        ok &= (Cprime(m, k) == (m - 1) ** (m - 1))
report('m<=k에서 C_{m,k}=(m-1)^{m-1} (0^0=1)  (2<=k<=12)', ok)
ok = True
okrate = True
cnt = 0
worst = None
for k in range(3, 13):
    x = xcrit(k)
    for M in range(k, NMAX):
        kM = x ** M * Fr(Cprime(M, k), factorial(M))
        kM1 = x ** (M + 1) * Fr(Cprime(M + 1, k), factorial(M + 1))
        f1 = ((M + 1) * kM1 <= (M - 1) * kM)
        f2 = (Cprime(M + 1, k) <= rr(k) * (M - 1) * Cprime(M, k))
        ok &= (f1 == f2)
        okrate &= f1
        cnt += 1
report('율-2의 두 꼴 (M+1)kappa_{M+1}<=(M-1)kappa_M 과 C_{M+1,k}<=(1+1/k)^{k-1}(M-1)C_{M,k}는 같은 부등식이다', ok, f'{cnt}자리')
report('그 부등식이 3<=k<=12, k<=M<=29의 모든 걸음에서 선다 (기저 안의 관찰; 정리의 범위 k>=148 밖)', okrate)

# ---------------------------------------------------------------------------
print('5. 들머리의 진술 (J), (E)와 창의 길이 (r538f630c)')


def ceil_div(a, bb):
    return -((-a) // bb)


ok = True
okE = True
for k in range(1, 2001):
    for m in range(1, k + 2):
        ok &= ((m <= ceil_div(k, 4) - 1) == (4 * m < k))
        if 4 * m < k:
            okE &= (3 * m <= k)
report('정수 m>=1에서 m<=ceil(k/4)-1 과 4m<k 는 같다 (k<=2000)', ok)
report('4m<k이면 3m<=k다, 곧 (J)의 꼴에서 (E)의 꼴이 따른다 (k<=2000)', okE)


def eps(m):
    return Fr((m - 1) ** (m - 1) if m > 1 else 1, factorial(m))


def Rs(k):
    xd = xdiag(k)
    R = 0
    for r in range(1, k - 1):
        g = eps(r + 1) / eps(r)
        if (k + r + 1) * xd * g <= k + r:
            R = r
        else:
            break
    return R


def floor_theta(k):
    """floor(theta_* k), theta_*=(sqrt(19)-2)/5: 가장 큰 정수 m with (5m+2k)^2<=19k^2."""
    m = (isqrt(19 * k * k) - 2 * k) // 5
    while (5 * (m + 1) + 2 * k) ** 2 <= 19 * k * k:
        m += 1
    while (5 * m + 2 * k) ** 2 > 19 * k * k:
        m -= 1
    return m


KW = 260
vals = {k: Rs(k) for k in range(3, KW + 1)}
report(f'k>=3에서 R_s(k)>=floor(2k/5) (전역 용어의 문장; 3<=k<={KW})', all(vals[k] >= (2 * k) // 5 for k in vals))
report(f'명제 W: 16<=k<={KW}에서 floor(theta_* k)<=R_s(k)<=floor(theta_* k)+1, theta_*=(sqrt(19)-2)/5',
       all(floor_theta(k) <= vals[k] <= floor_theta(k) + 1 for k in vals if k >= 16),
       'R_s=floor+1인 k: ' + str([k for k in vals if k >= 16 and vals[k] == floor_theta(k) + 1]))
report(f"따름 W'': 3<=k<={KW}에서 R_s(k)<=floor(3k/5)", all(vals[k] <= (3 * k) // 5 for k in vals))
low = [k for k in range(3, 16) if not (floor_theta(k) <= vals[k] <= floor_theta(k) + 1)]
print('     (참고) 3<=k<=15에서 양쪽 한계가 서지 않는 k:', low)

# ---------------------------------------------------------------------------
print('6. 보조정리 H의 꼴 (r1c0e811e) 과 보조정리 A의 꼴 (rcca316c6)')
ok = True
cnt = 0
for k in range(2, 16):
    for m in range(k, NMAX + 1):
        ok &= (Fr(b(m, k - 1)) >= (1 - rr(k) / rr(m + 1)) * A(m, k - 1))
        cnt += 1
report('b_{m,k-1} >= (1-r_k/r_{m+1})·A_{m,k-1}, r_j=(1+1/j)^{j-1}  (2<=k<=15, k<=m<=30)', ok, f'{cnt}자리')


def s_birth(m):
    s = Fr(0)
    t = Fr(1)
    for j in range(1, m + 1):
        t *= Fr(m - j + 1, m)
        s += t
    return s


def D_birth(m):
    s = s_birth(m)
    return 3 * ((m + 2) * s - 3 * m) / (2 * (m - s))


PI_LO = Fr(314159265358979, 10 ** 14)
ok = True
for m in range(2, 401):
    lhs = D_birth(m) + 1 + Fr(8, 5)
    ok &= (lhs > 0 and lhs * lhs <= Fr(9, 4) * PI_LO * m / 2)
report('보조정리 A: D_m+1 <= (3/2)sqrt(pi m/2)-8/5  (2<=m<=400; pi의 아래 어림으로 견줌)', ok)

# ---------------------------------------------------------------------------
print('7. 설명에 적은 산수')
report('floor((11k/5)^{2/3})+1 <= floor(27k/100)  (265<=k<=5000; 띠의 끝과 들머리의 견줌)',
       all((lambda k: (max(t for t in range(1, k) if t ** 3 * 25 <= 121 * k * k) + 1) <= (27 * k) // 100)(k) for k in range(265, 5001, 1) if k < 400 or k % 97 == 0))
report('열 82<=k<=264에서 ceil(k/4)-1<k/3 이고 열 45<=k<=96에서 k+floor(k/3)<=2k-1', all(ceil_div(k, 4) - 1 < Fr(k, 3) for k in range(82, 265)) and all(k + k // 3 <= 2 * k - 1 for k in range(45, 97)))
report('3160=sum_{k=2}^{81}(k-2): 열 k<=81의 사슬 영역 k+1<=n<=2k-2의 자리 수', sum(k - 2 for k in range(2, 82)) == 3160)
report('183=264-82+1: 열 82-264의 열마다 부호 하나', 264 - 82 + 1 == 183)
report('43=124-82+1, 140=264-125+1, 48=96-49+1', (124 - 82 + 1, 264 - 125 + 1, 96 - 49 + 1) == (43, 140, 48))

print()
print('모든 항목이 맞았다' if OK else '어긋난 항목이 있다')
sys.exit(0 if OK else 1)
