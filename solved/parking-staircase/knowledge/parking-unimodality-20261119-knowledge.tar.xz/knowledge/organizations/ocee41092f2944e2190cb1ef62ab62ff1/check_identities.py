# -*- coding: utf-8 -*-
"""조직화 scc172ad… 의 지역 용어 항목이 옮겨 적은 식의 대조.

계산의 자리: 용어 항목에 옮긴 정의와 대응이 대상과 맞는지를 작은 크기에서 정확한
유리수로 확인한다. 어떤 진술의 근거도 아니고, 표의 범위를 넓히는 계산도 아니다(n<=40).

대조하는 것
 1. 소인 주차함수의 넘김 비율: 네 기록의 정의가 같은 수라는 것, Δ_0=0, Δ_1의 닫힌 꼴,
    r5050c217 명제 L11의 재귀와 rc28b265의 잘림의 점화식, 단조성과 준승법성.
 2. 무게 달린 대각 둘째 차분: ψ≡1, ψ=N의 관계식, 보조정리 B의 등식(무게 셋),
    나무 질량 꼴과 무게 (1+1/k)^N/(N+1)의 관계식, 작은 열에서 정리 F와 M의 결론.
"""
from fractions import Fraction as Fr
from math import comb, factorial
import sys

NMAX = 40
fails = 0


def check(name, cond):
    global fails
    if not cond:
        fails += 1
        print('FAIL', name)


# 누적 개수 A_{n,l}: 마지막 차 재귀. A[l][n], l = -1..NMAX
def cumulative(level, nmax):
    if level < 0:
        return [1] + [0] * nmax
    a = [1]
    for n in range(1, nmax + 1):
        a.append(sum(comb(n - 1, j) * min(j + 1, level + 1) * a[j] * a[n - 1 - j] for j in range(n)))
    return a


A = {l: cumulative(l, NMAX) for l in range(-1, NMAX + 1)}

# 대조 0: 확인용 값과 총수
check('row 5', [A[l][5] - A[l - 1][5] for l in range(5)] == [120, 421, 377, 253, 125])
check('total', all(A[n][n] == (n + 1) ** (n - 1) for n in range(1, 15)))


def prime_counts(c, mmax):
    """C_{m,c}: 모든 변위가 c보다 작은 길이 m의 소인 주차함수의 수 (1/F_{c-1} = 1 - sum C x^m/m!)."""
    f = [Fr(A[c - 1][n], factorial(n)) for n in range(mmax + 1)]
    inv = [Fr(1)]
    for m in range(1, mmax + 1):
        inv.append(-sum(f[i] * inv[m - i] for i in range(1, m + 1)))
    return [None] + [int(-inv[m] * factorial(m)) for m in range(1, mmax + 1)]


def pw(b, e):
    return 1 if e == 0 else b ** e


# ---------------- 1. 넘김 비율 ----------------
for k in range(2, 12):
    M = min(NMAX, 3 * k + 3)
    C = prime_counts(k, M)
    total = [None] + [pw(m - 1, m - 1) for m in range(1, M + 1)]
    check('C=total for m<=k', all(C[m] == total[m] for m in range(1, k + 1)))
    delta = lambda s: 1 - Fr(C[k + s], total[k + s])       # rc28b265 Δ_s = r43a26ea3 r_s
    theta = lambda K: Fr(C[K], total[K])                    # r5050c217 θ_K (Y = k)
    check('Delta_0', delta(0) == 0)
    check('Delta_1 closed form', delta(1) == Fr((k + 1) ** k, k ** k) / (k + 1))
    check('theta', all(theta(k + s) == 1 - delta(s) for s in range(0, M - k + 1)))
    # rdd38d98: P_N = kappa_free_N - kappa_N = x^N eps_N Delta_{N-k} (기울임과 무관한 꼴로 대조)
    check('P_N', all(Fr(total[N] - C[N], factorial(N)) == Fr(total[N], factorial(N)) * delta(N - k)
                     for N in range(k, M + 1)))
    # r5050c217 명제 L11의 재귀: K f_K = sum_u beta_u (min(K,Y)-u)^+ f_{K-u}
    f = lambda K: Fr(C[K], factorial(K))
    beta = lambda u: Fr(pw(u, u - 2), factorial(u - 1)) if u >= 2 else Fr(1)
    check('L11 recursion', all(K * f(K) == sum(beta(u) * max(min(K, k) - u, 0) * f(K - u) for u in range(1, K))
                               for K in range(2, M + 1)))
    check('theta nonincreasing', all(theta(K + 1) <= theta(K) for K in range(1, M)))
    check('theta submultiplicative', all(theta(a + b) <= theta(a) * theta(b)
                                         for a in range(1, M) for b in range(1, M - a + 1)))
    # rc28b265 잘림의 점화식 (0 <= s <= k-1)
    cay = lambda j: Fr(pw(j + 1, j - 1), factorial(j)) if j >= 1 else Fr(1)
    eps = lambda m: Fr(pw(m - 1, m - 1), factorial(m))
    for s in range(0, k):
        Mm = k + s
        if Mm + 1 > M:
            break
        om = lambda i: cay(Mm - i) * eps(i) / ((Mm + 1) * eps(Mm + 1))
        rhs = sum(min(i, s + 1) * om(i) for i in range(1, Mm + 1)) + \
            sum((k - 1 - j) * om(Mm - j) * delta(s - j) for j in range(0, s))
        check('truncation recurrence k=%d s=%d' % (k, s), delta(s + 1) == rhs)
    # r43a26ea3 보조정리 KL (가): 0 = r_0 <= r_1 <= ... <= r_{k-1} <= 1
    top = min(k - 1, M - k)
    check('monotone in s', all(0 <= delta(s) <= delta(s + 1) <= 1 for s in range(0, top)))

# ---------------- 2. 무게 달린 대각 둘째 차분 ----------------
for k in range(3, 13):
    x = Fr(k, k + 1) ** (k - 1)
    zp = lambda i: x ** i * Fr(A[k][i], factorial(i))        # ẑ⁺
    z = lambda i: x ** i * Fr(A[k - 1][i], factorial(i))      # ẑ
    zq = lambda i: x ** i * Fr(A[k - 2][i], factorial(i))     # ẑ′
    U = lambda i: z(i) - zq(i)
    eta = lambda i: (zp(i) - z(i)) - U(i)                      # x^i d_{i,k}/i!
    Dpsi = lambda psi, N: psi(N + 1) * zp(N + 1) - 2 * psi(N) * z(N) + psi(N - 1) * zq(N - 1)
    one = lambda N: Fr(1)
    ident = lambda N: Fr(max(N, k))        # ψ(k-1)=ψ(k)가 되도록 k 아래에서 얼린 무게 N
    Psi = lambda N: Fr(max(N, 2 * k + 1))
    DC = lambda N: Dpsi(one, N)
    e = lambda N: zp(N + 1) - zq(N - 1)
    top = NMAX - 1
    # 전역 용어의 핵 질량 꼴과 같은 식인지: DC(N) = u_{N+1}(k+1) - 2u_N(k) + u_{N-1}(k-1)
    check('eta is tilted step', all(eta(i) == x ** i * Fr(A[k][i] - 2 * A[k - 1][i] + A[k - 2][i], factorial(i))
                                    for i in range(k, top)))
    # ψ(N)=N: Δ = N·DC + e
    check('weight N', all(Dpsi(lambda N: Fr(N), N) == N * DC(N) + e(N) for N in range(k, top)))
    # 보조정리 B의 등식 (ψ(k-1)=ψ(k))
    for name, psi in (('1', one), ('N frozen', ident), ('Psi', Psi)):
        for J in range(k, top):
            lhs = sum(psi(n) * eta(n) for n in range(k, J + 1))
            rhs = sum(Dpsi(psi, N) for N in range(k, J)) - psi(J) * U(J) - psi(J - 1) * U(J - 1) \
                + (psi(J - 1) * z(J - 1) - psi(J) * z(J))
            check('lemma B k=%d psi=%s J=%d' % (k, name, J), lhs == rhs)
    # 나무 질량 꼴과 무게 ψ_T(N)=(1+1/k)^N/(N+1)
    psiT = lambda N: Fr(k + 1, k) ** N / (N + 1)
    nT = lambda c, t: min(t, c) * x ** t * Fr(A[c - 1][t - 1], factorial(t))
    DCT = lambda t: nT(k + 1, t + 1) - 2 * nT(k, t) + nT(k - 1, t - 1)
    check('tree form', all(x * k / ((N + 1) * psiT(N)) * Dpsi(psiT, N)
                           == DCT(N + 1) + x * zq(N - 1) / ((k + 1) * N) for N in range(k, top)))
    # 작은 열에서: 첫 층의 DC>=0이 서면(가정) 정리 F와 M의 결론이 서는지
    hyp = all(DC(M) >= 0 for M in range(k, 2 * k + 1) if M < top)
    if hyp and 2 * k + 1 < top:
        check('theorem F conclusion k=%d' % k, all(Dpsi(lambda N: Fr(N), N) >= 0 for N in range(k, top)))
        check('theorem M conclusion k=%d' % k, all(Dpsi(Psi, N) >= 0 for N in range(k, top)))
    print('k=%d first-layer DC>=0: %s; min DC(N), 2k<N<%d: %s' % (
        k, hyp, top, min([float(DC(N) / z(N)) for N in range(2 * k + 1, top)], default=None)))

print('failures:', fails)
sys.exit(1 if fails else 0)
