from __future__ import annotations
import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from do_math.academic import *
class Tests(unittest.TestCase):
 def setUp(self):
  self.i={'goal_status':'mathematically_solved'};self.i=set_requirements(self.i,[{'id':'paper','scope':'solution','criteria':['draft'],'assessor':'research_plan'}]);self.b=solution_basis('goal',[{'id':'K','v':1}]);self.r={'tasks':{},'academic_assessments':[],'external_rejections':[]}
 def test_pending_completed_and_requirement_change(self):
  self.assertEqual(academic_status(self.i,self.r,self.b)['status'],'pending');self.r['academic_assessments']=[assess('paper',self.b,self.i['academic_requirements'],'satisfied',[{'criterion':'draft','satisfied':True,'evidence':'e'}])];self.assertEqual(academic_status(self.i,self.r,self.b)['status'],'completed')
  changed=set_requirements(self.i,[{'id':'paper','scope':'solution','criteria':['publish'],'assessor':'research_plan'}]);self.assertTrue(requirements_changed(self.i,changed));self.assertEqual(academic_status(changed,self.r,self.b)['status'],'pending')
 def test_rejection_and_resolution(self):
  self.r['external_rejections']=[{'solution_basis':self.b,'resolved':False,'source_ref':'planner-evidence'}];self.assertEqual(academic_status(self.i,self.r,self.b)['status'],'externally_rejected');self.r['external_rejections'][0]['resolved']=True;self.assertEqual(academic_status(self.i,self.r,self.b)['status'],'externally_rejected');self.r['external_rejections'][0]['resolution_evidence']=['planner-assessment'];self.assertEqual(academic_status(self.i,self.r,self.b)['status'],'pending')
 def test_invalid_requirement_shape_is_rejected(self):
  with self.assertRaises(ValueError):set_requirements({},[{'id':'x'}])
  with self.assertRaises(ValueError):set_requirements({},[{'id':'x','scope':'s','criteria':[],'assessor':'other'}])
 def test_unsolved_not_applicable(self):
  self.i['goal_status']='unresolved';self.assertEqual(academic_status(self.i,self.r,self.b)['status'],'not_applicable')
if __name__=='__main__':unittest.main()
