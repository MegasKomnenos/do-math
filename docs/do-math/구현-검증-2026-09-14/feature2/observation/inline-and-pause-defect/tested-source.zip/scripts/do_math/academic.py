"""Versioned postsolution academic requirements, separate from formal proof status."""
from __future__ import annotations
from copy import deepcopy
import hashlib,json
from typing import Any

def _hash(x:Any)->str:return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def set_requirements(instance:dict,requirements:list[dict])->dict:
    if not isinstance(requirements,list) or any(not isinstance(r,dict) for r in requirements):raise ValueError('requirements must be objects')
    if any(not isinstance(r.get('id'),str) or not r['id'].strip() for r in requirements) or len({r['id'] for r in requirements})!=len(requirements):raise ValueError('requirements need distinct IDs')
    for r in requirements:
        if not all(isinstance(r.get(k),str) and r[k].strip() for k in ('id','scope')) or r.get('assessor')!='research_plan' or not isinstance(r.get('criteria'),list) or not r['criteria'] or any(not isinstance(x,str) or not x.strip() for x in r['criteria']) or len(r['criteria'])!=len(set(r['criteria'])):raise ValueError('invalid academic requirement')
    out=deepcopy(instance);history=out.setdefault('academic_requirements_history',[]);old=out.get('academic_requirements');
    if old:history.append(deepcopy(old))
    record={'revision':out.get('academic_requirements',{}).get('revision',0)+1,'items':deepcopy(requirements)};record['sha256']=_hash(record);out['academic_requirements']=record;return out

def solution_basis(goal_ref:str,records:list[dict])->dict:
    if not isinstance(goal_ref,str) or not goal_ref or not records:raise ValueError('solution basis needs goal and records')
    return {'goal_ref':goal_ref,'records':[{'id':r['id'],'sha256':_hash(r)} for r in records]}

def assess(requirement_id:str,basis:dict,requirements:dict,decision:str,evidence:list[dict])->dict:
    if decision not in {'satisfied','not_satisfied','unresolved'} or not isinstance(evidence,list) or not evidence:raise ValueError('assessment needs decision and evidence')
    req=next((x for x in requirements.get('items',[]) if x['id']==requirement_id),None)
    if req is None:raise ValueError('unknown requirement')
    if any(not isinstance(x,dict) or not isinstance(x.get('criterion'),str) or not isinstance(x.get('satisfied'),bool) or not isinstance(x.get('evidence'),str) for x in evidence):raise ValueError('invalid criteria evidence')
    criteria={x['criterion']:x for x in evidence}
    if len(criteria)!=len(evidence) or set(criteria)!=set(req['criteria']):raise ValueError('assessment must cover each exact criterion once')
    if decision=='satisfied' and any(not x['satisfied'] or not x['evidence'].strip() for x in evidence):raise ValueError('satisfied assessment lacks exact criteria evidence')
    return {'requirement_id':requirement_id,'solution_basis':deepcopy(basis),'requirements_sha256':requirements['sha256'],'decision':decision,'evidence':deepcopy(evidence),'assessor':'research_plan'}

def academic_status(instance:dict,runtime:dict,current_basis:dict|None)->dict:
    if instance.get('goal_status')!='mathematically_solved' or not instance.get('academic_requirements',{}).get('items'):return {'status':'not_applicable','reason':'unsolved or no requirements'}
    if current_basis is None:return {'status':'incomplete','reason':'solution basis unreadable'}
    reqs=instance['academic_requirements']; assessments=runtime.get('academic_assessments',[]); rejects=runtime.get('external_rejections',[])
    if any(x.get('solution_basis')==current_basis and (not x.get('resolved') or not x.get('resolution_evidence')) for x in rejects):return {'status':'externally_rejected','reason':'unresolved external rejection'}
    matching=[a for a in assessments if a.get('solution_basis')==current_basis and a.get('requirements_sha256')==reqs.get('sha256') and a.get('assessor')=='research_plan']
    if all(any(a.get('requirement_id')==r['id'] and a.get('decision')=='satisfied' for a in matching) for r in reqs['items']):return {'status':'completed','reason':'all current requirements satisfied'}
    tasks=[t for t in runtime.get('tasks',{}).values() if t.get('academic_requirement_id') in {r['id'] for r in reqs['items']} and t.get('solution_basis')==current_basis]
    return {'status':'active' if tasks else 'pending','reason':'requirements remain'}

def requirements_changed(old:dict,new:dict)->bool:return old.get('academic_requirements')!=new.get('academic_requirements')
