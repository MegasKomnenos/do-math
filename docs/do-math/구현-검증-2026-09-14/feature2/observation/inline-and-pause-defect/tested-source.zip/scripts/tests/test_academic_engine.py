"""Integration checks for postsolution academic requirements.

These tests use the in-memory CAS repository and scripted runner from the
purpose-engine suite.  They verify engine orchestration, not a model judgment
or a Lean invocation.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from do_math.engine import control
from do_math.repository import canonical_json
from test_purpose_engine import PurposeHarness, PurposeRunner


def requirement(criteria: list[str]) -> dict:
    return {
        "id": "writeup",
        "scope": "A reader-facing account of the solved natural-number theorem.",
        "criteria": criteria,
        "assessor": "research_plan",
    }


class AcademicRunner(PurposeRunner):
    """Purpose fixture that supplies an explicit planner resolution when asked."""

    def answer(self, role, context, workspace):
        action = context["action"]
        if role == "research_plan" and action.get("rejection_id"):
            (workspace / "activity-extensions.json").write_bytes(canonical_json({
                "academic_resolutions": [{
                    "id": action["rejection_id"], "decision": "resolved",
                    "evidence": "The planner compared the preserved objection with the completed reviewed task report.",
                }],
            }))
        if role == "research_work" and context["task"].get("academic_requirement_id"):
            task = context["task"]
            self.work_order.append(task["title"])
            return {
                "summary": "The academic criterion is addressed by the submitted reader-facing account.",
                "used_sources": task.get("reuse", []), "questions": [], "outcome": "submitted",
                "report": "The report explains the exact natural-number domain and the reviewed equality.",
                "knowledge": [], "relations": [], "remaining_work": [],
                "checkpoint": "The required account and its evidence are ready for independent assessment.",
            }
        return super().answer(role, context, workspace)


class AcademicEngineTests(PurposeHarness):
    def make(self, *args, **kwargs):
        engine, _ = super().make(*args, **kwargs)
        runner = AcademicRunner()
        engine.runner = runner
        self.runners[-1] = runner
        return engine, runner

    def _set_requirements(self, engine, criteria, decision_id):
        control(self.repo, engine.instance["id"], "decision", config={"change": {
            "kind": "academic_requirements", "decision_id": decision_id,
            "requirements": [requirement(criteria)],
        }})
        engine.process_controls()

    def _academic_tasks(self, engine):
        return [task for task in engine.runtime["tasks"].values() if task.get("academic_requirement_id") == "writeup"]

    def test_explicit_requirement_blocks_runtime_completion_until_independent_assessment(self):
        engine, runner = self.make()
        self._set_requirements(engine, ["draft account", "cite reviewed equality"], "academic-v1")

        self.drive(engine, predicate=lambda current: current.instance["goal_status"] == "mathematically_solved")
        tasks = self._academic_tasks(engine)
        self.assertEqual(len(tasks), 1)
        task = tasks[0]
        self.assertEqual(task["completion_criteria"], ["draft account", "cite reviewed equality"])
        self.assertNotEqual(engine.runtime["status"], "completed")
        self.assertNotEqual(task["status"], "completed")

        self.drive(engine, predicate=lambda current: current.runtime["status"] == "completed", limit=30)
        task = self._academic_tasks(engine)[0]
        self.assertEqual(task["status"], "completed")
        self.assertTrue(any(review["decision"] == "approved" for review in task["reviews"]))
        self.assertNotEqual(task["assessment"]["execution_id"], task["results"][0]["execution_id"])
        self.assertEqual([item["criterion"] for item in task["assessment"]["criteria_results"]], task["completion_criteria"])
        recorded = [entry for entry in engine.runtime["academic_assessments"] if entry["task_id"] == task["id"]]
        self.assertEqual(len(recorded), 1)
        self.assertEqual(recorded[0]["decision"], "satisfied")
        self.assertEqual(engine.status()["academic_validation"]["status"], "completed")
        self.assertIn(task["title"], runner.work_order)

    def test_changed_same_requirement_id_supersedes_old_contract_and_creates_new_criteria(self):
        engine, _ = self.make()
        self._set_requirements(engine, ["draft account"], "academic-v1")
        self.drive(engine, predicate=lambda current: current.instance["goal_status"] == "mathematically_solved")
        old = self._academic_tasks(engine)[0]
        old_basis = deepcopy(old["solution_basis"])
        old_hash = old["requirements_sha256"]

        self._set_requirements(engine, ["draft account", "archival supplement"], "academic-v2")
        engine.run(max_steps=1)
        tasks = self._academic_tasks(engine)
        self.assertEqual(len(tasks), 2)
        superseded = next(task for task in tasks if task["id"] == old["id"])
        current = next(task for task in tasks if task["id"] != old["id"])
        self.assertEqual(superseded["status"], "closed")
        self.assertEqual(superseded["scope_disposition"]["kind"], "superseded_requirements")
        self.assertEqual(current["academic_requirement_id"], "writeup")
        self.assertEqual(current["completion_criteria"], ["draft account", "archival supplement"])
        self.assertEqual(current["solution_basis"], old_basis)
        self.assertNotEqual(current["requirements_sha256"], old_hash)
        self.assertNotEqual(engine.runtime["status"], "completed")

    def test_external_rejection_keeps_formal_solution_and_requires_planner_evidence_to_clear(self):
        engine, _ = self.make()
        self.drive(engine)
        knowledge = next(iter(engine.instance["knowledge"].values()))
        formal_before = deepcopy(knowledge["formal"])
        self.assertEqual(engine.runtime["status"], "completed")

        control(self.repo, engine.instance["id"], "decision", config={"change": {
            "kind": "academic_rejection", "actor": "external referee",
            "text": "The reader-facing explanation needs a specific response.",
        }})
        engine.process_controls()
        rejection = engine.runtime["external_rejections"][-1]
        self.assertFalse(rejection["resolved"])
        self.assertEqual(engine.instance["goal_status"], "mathematically_solved")
        self.assertEqual(engine.instance["knowledge"][knowledge["id"]]["formal"], formal_before)
        self.assertNotEqual(engine.runtime["status"], "completed")

        self.drive(engine, predicate=lambda current: current.runtime["status"] == "completed", limit=12)
        rejection = next(item for item in engine.runtime["external_rejections"] if item["id"] == rejection["id"])
        self.assertTrue(rejection["resolved"])
        self.assertTrue(rejection["resolution_evidence"].strip())
        resolution_execution = engine.runtime["executions"][rejection["resolution_execution_id"]]
        self.assertEqual(resolution_execution["action"]["role"], "research_plan")
        self.assertEqual(engine.instance["goal_status"], "mathematically_solved")
        self.assertEqual(engine.instance["knowledge"][knowledge["id"]]["formal"], formal_before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
