import json
from pathlib import Path
import subprocess
from task_tools import ROOT, HERE, dump

verification=json.loads((HERE/'verification.json').read_text(encoding='utf-8-sig'))
prefix='run:phases/015/tasks/t4-adapter-report/evidence/'
def evidence(*paths): return [prefix+p for p in paths]
suites={s['label']:s for s in verification['suites']}
canonical=suites['canonical-t4-final']; mirror=suites['mirror-t4-full']
green=suites['canonical-related-04']; mirror_green=suites['mirror-related-final']
success=all(s['exit_code']==0 and s['counts']=={'passed':s['selected']} for s in (canonical,mirror))
related=all(s['exit_code']==0 and s['counts']=={'passed':s['selected']} for s in (green,mirror_green))
measurement=all(s['adapter']['complete'] and not s['adapter']['problems'] for s in (canonical,mirror))
scope={'canonical':canonical['counts'],'mirror':mirror['counts']}
findings=[
 {'id':'F1','kind':'fact','detail':f"T4 단독의 adapter 분기 보고를 실제 runner/worker에 연결했다. 현 LAYERS5개가 소스 SHA·실행/미실행·제외/합계와 함께 전건 보고되고 두 최종 T4의 측정 complete는 {measurement}이다. 도달률은 정보이며 임계 관문이 아니다. 시험 결과는 별도이며 {scope}를 측정 성공으로 바꾸지 않는다.",
  'evidence':evidence('verification.json','canonical-t4-final/adapter-coverage.json','mirror-t4-full/adapter-coverage.json'),
  'affects':['run:context.md#C11','run:context.md#G7','run:plan.md'],
  'next_action':'manager가 T4 측정 공백의 해소와 기능 시험 미충족을 분리해 검수한다. 최종 G7 합격은 남은 실패/skip 수리와 재검증 뒤에만 판단한다.'},
 {'id':'F2','kind':'issue','detail':'쓰기 범위 밖의 기존 경계 fixture들이 현 계약과 어긋난다. knowledge_roundtrip.installed_request는 실제 nonempty fingerprint와 empty content를 조합해 trust_inventory.record_errors에서6건이 반려된다. 보존된 실제 Lean identity로 공개 producer만 호출한 측정 없는 최소 재현도 동일 ValueError다. observation_real_job은 닫힌 빈 object schema에 선언하지 않은 ok를 반환한다. scheduling_host_processes의 WriterLock child는 ResearchRepository의 필수 backend 없이 생성해 LockError 대신 TypeError를 낸다. submission_lean_preview archive child는 ports/env를 정의하지 않아 ports NameError가 난다. 정확 ID·원오류·양쪽 결과는 verification.suites[].nonpassed에 있다. 해당 코드·시험은 시작 판본과 바이트가 같다. 이번에는 이 계약/기대값을 약화하거나 수리하지 않았다.',
  'evidence':evidence('verification.json','fixture-reproduction.json','fixture-reproduce.command.json','review.md','canonical-t4-final/report.json','mirror-t4-full/report.json'),
  'affects':['run:context.md#G1','run:context.md#G3','run:context.md#G7','run:plan.md',
    'repo:.claude/skills/do-math/scripts/tests/support/knowledge_roundtrip.py',
    'repo:.claude/skills/do-math/scripts/tests/boundary/test_observation_real_job.py',
    'repo:.claude/skills/do-math/scripts/tests/boundary/test_scheduling_host_processes.py',
    'repo:.claude/skills/do-math/scripts/tests/boundary/test_submission_lean_preview.py'],
  'next_action':'현 record/출력 schema·Codex 전송·필수 backend·standalone 포트/환경 정의를 쓰는 작은 fixture 수리 task를 배정한다. 공개 guard/실제 Job/실제 compiler를 유지하고 정확 실패 ID red/green 후 관련 회귀·양쪽 T4 전건을 확인한다.'},
 {'id':'F3','kind':'issue','detail':'공식 T4 선택의 SharedInputProvenanceTests 두 exact-baseline 항목은 SHARED_INPUT_BASELINE_SCRIPTS 부재로 skipped다. 사유는 P10/P11 pending: supply a separate pre-provenance-fix scripts tree이며 현재 root를 과거 정본으로 대입하거나 skip을 passed로 세지 않았다. 전체 모집단 선택은 완결됐지만 이 비교 성질은 미검사다.',
  'evidence':evidence('verification.json','canonical-t4-final/report.json','mirror-t4-full/report.json'),
  'affects':['run:context.md#G2','run:context.md#G3','run:context.md#G7','run:plan.md',
             'repo:.claude/skills/do-math/scripts/tests/boundary/test_shared_input_provenance.py'],
  'next_action':'manager가 관련 과거 diff/원보고에 결속한 별도 pre-provenance-fix scripts tree를 준비하는 범위와 SHARED_INPUT_BASELINE_SCRIPTS 입력을 배정해 두 비교를 실제 실행한다. 정당한 제외로 판정하려면 원문/위임 권한 근거가 필요하다.'},
 {'id':'F4','kind':'fact','detail':f"첫 전체 T4에서 발견한 병렬 T3 import 누락은 새 설정을 _read_json으로 측정 시작 전에 읽던 이번 변경의 문제였다. 표준 라이브러리 읽기로 start-before-product-import를 복원했다. 증분 T3의 자기 records.json import 의존은 repo 내부 owned scratch의 prime/repeat로 재현했고 _t3_plan bookkeeping을 unmeasured로 교정했다. 저장소/gate 조건을 낮추지 않았다. 두 정본 관련 실행의 최종 선택 {green['selected']}건과 미러 {mirror_green['selected']}건은 {related}로 통과했고 실제 기존 incremental/parallel 경계를 포함한다. 새 runner/branch_gate 판본은 RUNNER 무효화 대상이라 과거 증분 T3를 최종 증거로 재사용하지 못한다. 원래 G4/G5/G6는 여전히 후속 전체 관문이다.",
  'evidence':evidence('canonical-t4-full/report.json','t3-prime/report.json','t3-repeat/report.json','canonical-related-04/report.json','mirror-related-final/report.json','review.md'),
  'affects':['run:context.md#C9','run:context.md#C11','run:context.md#G3','run:context.md#G4','run:context.md#G5','run:context.md#G6','run:plan.md'],
  'next_action':'manager가 D5/D6/D9/D11 유지와 두 교정을 지정 runner slice로 검수한다. 일반/fresh 전체 T3/전체 변이의 새 동일 판본 실행과 최종 review를 후속에 유지한다.'},
 {'id':'F5','kind':'fact','detail':f"허용된 변경만 존재하며 runtime/공급자·host·Lean·예약 입력 {verification['runtime_and_inputs_preserved']}개, 기존 corpus {verification['corpus_paths_preserved']}경로와 host8원자료·도구 SHA가 보존됐다. 공식 미러 생성·마지막 비용 캐시 동기화·--check/skill-only와 원 raw coverage 재분석을 확인했다. 과거 실호출은 승인된 성질·불변 입력/도구 조건에서만 재사용한다. 새 유료 모델/실예약 등록·발화/학술 검색·연구 재개/graphify/Git stage·commit·reset·checkout·push는0이다. 역사 요약의 사라진 원보고와 초기 실패는 새 counts에 합산하지 않는다.",
  'evidence':evidence('verification.json','source-final.json','history-original-observation.json','history-pr01.json','review.md','mirror-final-check.command.json','skill-final.command.json'),
  'affects':['run:context.md#C9','run:context.md#C12','run:context.md#G7','run:context.md#G8','run:plan.md'],
  'next_action':'manager가 불변/미러/부분 검증의 재사용 범위를 유지해 인도한다. 기능 실패/skip과 최종 일반/T3/변이·문서/의미 질문·L01·최종 review를 종결로 표시하지 않는다.'},
 {'id':'F6','kind':'issue','detail':'별도 OS 오류도 원관측으로 보존한다. 첫 정본 전건의 BootstrapInfo.freeze staging.rename은 WinError5였고 최종 정본에서는 동일 ID가 통과했다. 최종 정본의 scheduling_background_processes.real_git_descendants는 Git 자식 실행 중 subprocess.DuplicateHandle WinError6 invalid handle로 실패했다. 원인은 미확인이다. 해당 실행에서는 시험 성공으로 인정하지 않으며 현재 runner 측정 여부만으로 OS 원인을 단정하지 않는다. 미러의 같은 ID 결과와 초기 native 임시 상세 부재 한계도 review/verification 원자료에 구분한다.',
  'evidence':evidence('canonical-t4-full/report.json','canonical-t4-final/report.json','mirror-t4-full/report.json','verification.json','review.md'),
  'affects':['run:context.md#G3','run:context.md#G7','run:plan.md',
    'repo:.claude/skills/do-math/scripts/tests/boundary/test_operator_bootstrap_info.py',
    'repo:.claude/skills/do-math/scripts/tests/boundary/test_scheduling_background_processes.py'],
  'next_action':'manager가 각 실제 판본/ID/원error/원child·OS handle 조건을 대조한다. 필요한 정확 ID 재현과 정상 대조를 별도 배정하고 transient 여부를 근거 없이 확정하거나 failed row를 소급 pass로 바꾸지 않는다.'}
]
checks=[]
expected_one={'red-adapter','t3-prime','t3-repeat'}
for path in sorted(HERE.glob('*.command.json')):
    label=path.name.removesuffix('.command.json')
    if label in ('verification','report-check'): continue
    meta=json.loads(path.read_text(encoding='utf-8-sig'))
    expected=1 if label in expected_one else 0
    detail=('기대 exit1: 보고 부재 red 또는 작은 부분 T3의 gate 미도달을 보존했다.' if label in expected_one
        else '실제 실행 원stdout/stderr·PID/시작/종료/exit와 전후 소스를 보존했다.')
    if label in ('canonical-t4-full','canonical-t4-final','mirror-t4-full'):
        detail+=' 전체 T4의 실제 기능 실패/skip은 합격으로 세지 않는다. 측정 완전성은 별도 보고다.'
    if label=='fixture-reproduce': detail+=' 설치/컴파일 없이 보존된 실제 identity로 공개 fixture producer의 동일 반려를 재현했다.'
    checks.append({'command':subprocess.list2cmdline(meta['command']),'cwd':'repo:.',
        'result':'pass' if meta['exit_code']==expected else 'fail','exit_code':meta['exit_code'],
        'evidence':evidence(path.name,label+'.stdout',label+'.stderr'), 'detail':detail})
meta=json.loads((HERE/'verification.command.json').read_text(encoding='utf-8-sig'))
checks.append({'command':subprocess.list2cmdline(meta['command']),'cwd':'repo:.','result':'pass',
    'exit_code':meta['exit_code'],'evidence':evidence('verification.command.json','verification.json','verification.stdout'),
    'detail':'현재 소스·writes, 선택/고유row/exit, worker 게시·source/요청/판본·실제 raw coverage 재분석, 미러/입력/녹화/도구 보존을 대조했다. 기능 실패가 없음이라는 검사는 아니다.'})
report={'status':'complete' if success and related and measurement else 'partial',
 'narrative':f"T4의 누락된 adapter 분기 보고를 실제 공식 runner와 owned worker/병합 경로에 구현했다. 수정 전 clock10passed와 보고 부재, 새 실제 소비자의 KeyError red를 보존했다. Measurement 생명주기/branch 분석·D5 pause와 현 LAYERS5개를 재사용하고, source에서 미도달/제외/분모를 얻는다. worker 요청/실행/판본/게시 SHA와 branch DB를 같은 생산/소비 검사로 대조한다. invalid 자료는 원경로와 불완전 사유로 남고 시험 성공과 별개로 exit1이다.\n\nT4는 T3 gate/index/store/변이와 분리했다. 실제 jobs1·jobs2, known worker 함수 body·미도달 파일·runner 거짓 도달·누락/파손/외부 run/요청/판본/SQLite·실패/skip/not_run을 검사했다. 첫 전건에서 발견한 새 T3 worker import 순서 문제와 repo 내부 store 자기 의존을 교정하고 정확 기존 실제 T3 경계를 추가해 정본/미러 각{green['selected']}/{mirror_green['selected']}건을 확인했다.\n\n최종 정본/미러 각295전체 T4 선택은 실제 종료했지만 결과는 {scope}라 A4는 미충족이다. 측정 complete={measurement}, 각 worker={canonical['adapter']['workers']}/{mirror['adapter']['workers']}이며 이 완전성으로 기능 실패/skip을 승인하지 않는다. 쓰기 범위 밖의 fixture/API 불일치, 별도 baseline 입력 부재와 OS 오류는 원자료/최소 재현·정확 다음 범위로 반환한다. 실제 raw parent union을 coverage로 다시 분석하고 보고·source 판본을 대조했다.\n\n공식 생성의 변화가 writes 이내임을 확인하고 마지막 비용 캐시만 동기화했다. --check/skill-only 및 원입력/녹화/도구 보존을 확인했다. 이전 approved live 성질만 재사용하고 새 유료/실예약/학술 호출은 없다. 관련 history actual diff·현재 소비·존재 요약과 사라진 raw를 구분했으며 과거 counts/초기 실패를 합산하지 않는다. 최종 전체 일반/fresh T3/전체 변이·문서/의미·L01·review는 후속 manager 책임이다.",
 'acceptance':[
  {'id':'A1','result':'pass','detail':'014 inspected2750파일 시작 일치, 설계/목록/현재 생명주기와 실제 clock10passed/보고 부재·consumer red를 확정했다. 관련 actual diff/현 소비/존재 역사 요약과 원raw 부재를 한정 검토했다.','evidence':evidence('input-source-comparison.json','before-clock/report.json','red-adapter/report.json','history-log.json','history-measurement.diff','history-runner.diff','history-timeout.diff','history-original-observation.json','review.md')},
  {'id':'A2','result':'pass' if measurement else 'fail','detail':'현재 adapter 전체의 source 판본/실행·미실행/제외/합계를 실제 측정/worker raw 합집합으로 보고했다. 누락/파손/다른 실행·판본은 incomplete/원사유와 exit1이며 성공/skip/error/not_run과 분리한다. T3 자료/색인/저장소와 T4가 섞이지 않는다.','evidence':evidence('verification.json','canonical-t4-final/adapter-coverage.json','mirror-t4-full/adapter-coverage.json','canonical-t4-final-raw-analysis.json','mirror-t4-full-raw-analysis.json')},
  {'id':'A3','result':'pass' if related else 'fail','detail':f'정본/미러 관련 {green["selected"]}/{mirror_green["selected"]} 선택/고유row 전건 대조했다. 실제 native/worker/merge와 유한 음성 행렬·jobs2·거짓 도달·결과/exit 보존, 기존 실제 T3 incremental/parallel·정상 기준 소비·정확 store invalidation을 검증했다. 초기 실패와 준비/단언 교정은 원보고로 유지한다.','evidence':evidence('verification.json','canonical-related-04/report.json','mirror-related-final/report.json','red-adapter/report.json','t3-prime/report.json','t3-repeat/report.json','review.md')},
  {'id':'A4','result':'pass' if success else 'fail','detail':f'양쪽 최종 --list 모집단과295선택/고유row/실제exit·전후source·worker/adapter 모집단을 대조했으나 기능 결과 {scope}로 합격 조건을 충족하지 못했다. 범위 밖 fixture 오류·OS 오류·SHARED_INPUT_BASELINE_SCRIPTS 부재 두 skip은 findings로 반환한다. 지침/공식 미러/최종 캐시/check/skill-only·기존 입력/녹화/도구 보존은 완료했다.','evidence':evidence('verification.json','canonical-t4-list-final.stdout','mirror-t4-list.stdout','canonical-t4-final/report.json','mirror-t4-full/report.json','mirror-final-check.stdout','skill-final.stdout','source-final.json','review.md')}],
 'changes':[{'path':p,'detail':'공식 생성한 대응 미러.' if p.startswith('.agents/') else
     '실행에서 생성된 fixture-inclusive 비용 캐시.' if '/.timings' in p else
     'T4 실제 측정/게시/병합/보고·T3 생명주기와 bookkeeping 보존 및 관련 검증/지침 변경.'}
     for p in verification['changes']],
 'seams':[],'findings':findings,'checks':checks}
dump(HERE.parent/'report.json',report)
print(report['status'])
