
param([string]$OperatorTask,[string]$EngineTask,[string]$WakeTask,[string]$Workspace)
$ErrorActionPreference = 'Stop'
$rows = [ordered]@{}
foreach ($pair in @(@('operator',$OperatorTask),@('engine',$EngineTask),@('wake',$WakeTask))) {
    $task = Get-ScheduledTask -TaskName $pair[1] -ErrorAction SilentlyContinue
    if ($null -eq $task) { $rows[$pair[0]] = $null; continue }
    $info = Get-ScheduledTaskInfo -TaskName $pair[1]
    $a = @($task.Actions)[0]
    $rows[$pair[0]] = [ordered]@{
        name=[string]$task.TaskName; state=[string]$task.State
        execute=[string]$a.Execute; arguments=[string]$a.Arguments; cwd=[string]$a.WorkingDirectory
        principal_run_level=[string]$task.Principal.RunLevel; principal_logon_type=[string]$task.Principal.LogonType
        last_run_utc=$info.LastRunTime.ToUniversalTime().ToString('o')
        last_run_ticks=[string]$info.LastRunTime.ToUniversalTime().Ticks
        last_result=$info.LastTaskResult
        xml=(Export-ScheduledTask -TaskName $pair[1] | Out-String)
    }
}
$processes = @(Get-CimInstance Win32_Process -Filter "Name = 'pythonw.exe'" |
    Where-Object { $_.CommandLine -and $_.CommandLine.Contains($Workspace) } |
    Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine,CreationDate)
[ordered]@{ tasks=$rows; processes=$processes; observed_at=(Get-Date).ToUniversalTime().ToString('o') } |
    ConvertTo-Json -Depth 7 -Compress
