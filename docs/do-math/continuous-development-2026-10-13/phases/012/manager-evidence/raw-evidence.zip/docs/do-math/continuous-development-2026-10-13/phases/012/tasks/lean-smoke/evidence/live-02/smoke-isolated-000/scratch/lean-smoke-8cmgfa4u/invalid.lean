import Mathlib
theorem lean_smoke_add_zero (n : Nat) : n + 0 = n := True.intro
theorem lean_smoke_true : True := True.intro
