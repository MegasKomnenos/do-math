import Mathlib
example (n : Nat) : n + 0 = n := by rfl
example : (2 : ℝ) + 2 = 4 := by norm_num
