import json
from pathlib import Path
import subprocess

REPO = Path('C:/math')
RUN = REPO / 'docs/do-math/continuous-development-2026-10-13'
TASK = RUN / 'phases/014/tasks/scholarly-smoke'
E = TASK / 'evidence'
PREFIX = 'run:phases/014/tasks/scholarly-smoke/evidence/'

def refs(*names):
    return [PREFIX + name for name in names]

v = json.loads((E/'verification-final.json').read_bytes())
smoke = next((E/'live-final').rglob('smoke.json'))
smoke_ref = 'run:' + smoke.relative_to(RUN).as_posix()
native_refs = refs('live-final/report.json','live-final.command.json','native-observation-current.json','verification-final.json') + [smoke_ref]
corpus_refs = refs('promotion.json','manifest-before.json','corpus-final.json','canonical-final/report.json','mirror-final/report.json')
delivery_refs = refs('verification-final.json','source-final.json','mirror-plan-initial.json','mirror-plan-observer.json',
                     'mirror-plan-final-cache.json','mirror-final-check.stdout','skill-final.stdout','review.md')

details = {
    'test_scholarly_live.py':'실제 기존 files/scholarly probe의 성공 완료·전체 registry 요약·파일·checkpoint·격리·Job 회수를 resource T5 discovery에 연결한다.',
    'scholarly_live.py':'live/replay 공통의 작은 시험 관찰자와 실제 호출 준비/원근거 저장을 추가한다. 기존 runtime/parser를 사용하며 Codex structured_content 본문을 content와 대조한다.',
    'test_corpus.py':'scholarly_stream의 registry/request/schema/worker 파일 선언·해시와 성공 verdict를 기존 전건 완비 검사에 연결한다.',
    'test_corpus_replay.py':'현재 제품 parser와 공유 관찰자로 새 원녹화를 재생하고, exact final/worker 결속 및 시작만 있음·오류·누락/불완전 목록 등15파생 반례를 검증한다.',
    'manifest.json':'기존21항목/verdict를 보존하고 실제 list_sources 성공 원녹화1항목과 원자료10파일의 경로/SHA·판본·명령·서버 계약 snapshot/한계를 추가한다.',
    '시험-지침.md':'학술 T5 입력/서버 조건·실호출 설정·실행별 격리·회수·시작/완료 구별·native structured_content 표기·초기 오류와 재사용/관측 한계를 설명한다.',
    '.timings.json':'공식 runner가 기록한 관련 시험 실행 비용 캐시다. 마지막 미러 비용 캐시만 공식 생성기로 동기화했다.'
}
changes = []
for p in v['changes']:
    detail = details.get(Path(p).name)
    if '/corpus/scholarly/' in p:
        detail = '최종 실제 Codex list_sources 호출의 native/stdout·stderr·final·prompt·schema·worker snapshot/status·registry/버전 중 해당 원파일을 재직렬화 없이 바이트 그대로 보존한다.'
    if p.startswith('.agents/'):
        detail = '공식 build_skill_mirrors.py 생성 사본. ' + detail
    changes.append({'path':p,'detail':detail})

descriptions = {
    'live-01':'1선택/error1/exit1. 실제 응답/파일/Job 뒤 checkpoint bytes의 보고 JSON 직렬화 오류. 당시 실패와 raw를 유지한다.',
    'live-02':'1선택/failed1/exit1. 실제 registry/파일/Job 판정은 참이나 lazy data 디렉터리의 존재를 잘못 요구한 시험 단언. 당시 실패를 유지한다.',
    'live-final':'1선택/1passed/exit0,16개 판정 참. Codex0.162.1/gpt-6-astra/low의 최소 실제 연결. structured native 표기 추가 대조는 같은 원녹화의 native-observation-current로 보완한다.',
    'canonical-related':'초기 corpus/반례 추가판46선택/46passed/exit0. 당시 structuredContent 표기 조회 공백은 후속 current observer/final 보고로 보완했고 원보고는 불변이다.',
    'mirror-related':'초기 공식 미러의 같은46선택/46passed/exit0. 실호출이 아니며 현재 강화한 structured body 검사 근거는 mirror-final이다.',
    'canonical-final':'현재 관찰자와 corpus의46고유선택/46passed/exit0. 양 본문/registry 일치,15파생 반례·exact final/worker와 관련 회귀. 소스873개가 현재와 일치하고 변경/skip/error/미실행0.',
    'mirror-final':'공식 미러의 현재 같은46고유선택/46passed/exit0. 녹화 재생·설정/검증/구조/대역 회귀와 현재873Python SHA. 유료 미러 호출0.',
    'history-input':'8ee07448의 기존 scholarly files probe 입력/시작 검사 actual diff와 현재 소비를 대조한 한정 검토.',
    'history-isolation':'fd15f69d의 closed scholarly command/args와 실행별 data-dir 전달 actual diff만 유지 판단. 다른 hunk/연구 운전은 미검토.',
    'history-worker':'0c839843의 worker_request/argv_inputs 공유 정본 이동 actual diff와 현재 worker를 대조했다.',
    't5-list':'새 scholarly 포함T5 8건 discovery만 확인했다. 선택된 나머지 공급자/host/Lean/예약 T5는 실행하지 않았다.',
    'mirror-build':'사전 계획17경로가 writes 안이며 공식12생성/5갱신/삭제0.',
    'mirror-observer-build':'native structured_content 관찰자/반례/지침과 새 manifest verdict 교정을 공식 대응 사본에 반영했다. 사전5경로 계획이 writes 안이다.',
    'mirror-final-cache-build':'미러 시험 이후 비용 캐시 한 파일만 공식 생성기로 동기화했다.',
    'mirror-final-check':'공식1334파일의 드리프트 없음/exit0. corpus의 별도 바이트/clean 검증과 구별한다.',
    'skill-final':'최종 공식 skill-only verified/exit0. 실제 도구 호출 성공과 구별한다.',
    'corpus-final-audit':'양쪽 각22항목/72파일/409886bytes와75개명시SHA,총144경로 Git raw/clean·미러 바이트를 전건 대조했다. 기존21항목·122비manifest경로는 불변이다.',
    'verification-final':'시작2726/종료2750 소스·34변경/writes·선택/고유row/실제exit·worker/request/stdio/schema/native를 대조했다. runtime124를 포함한 재사용139경로·host8원자료·Lean/host도구SHA 및129미러변환 입력도 실제 파일로 확인했다.'
}
checks = []
for name, detail in descriptions.items():
    record = json.loads((E/(name+'.command.json')).read_bytes())
    evidence = refs(name+'.command.json',name+'.stdout',name+'.stderr')
    if (E/name/'report.json').is_file():
        evidence += refs(name+'/report.json')
    if name == 'verification-final':
        evidence += refs('verification-final.json','native-observation-current.json')
    if name == 'corpus-final-audit':
        evidence += refs('corpus-final.json')
    checks.append({'command':subprocess.list2cmdline(record['command']),'cwd':'repo:.',
                   'result':'pass' if record['exit_code']==0 else 'fail','exit_code':record['exit_code'],
                   'evidence':evidence,'detail':detail})

report = {
 'status':'complete',
 'narrative': 'G7의 기존 Codex worker→실제 scholarly MCP list_sources 최소 경계를 새 T5와 실제 원녹화 재생으로 연결했다. phase013 검수본과 시작 소스가 전부 같았고 현재 프로젝트 scholarly 쌍·전용 서버 Python/패키지/registry와 Codex 판본/SHA를 비밀 없이 기록했다. 사용자 설정·서비스·인증·설치·제품 runtime/probe는 수정하지 않았다. resource 격리에서 기존 probe_cli.run_case(files,scholarly=True)와 실제 ModelRunner/real_ports/worker/adapter/collector를 그대로 사용했다.\n\n제품 호출은 gpt-6-astra/low로 세 번이며 각 한 ModelRunner/CLI와 한 list_sources였다. 첫 error는 checkpoint bytes의 보고 직렬화,둘째 failed는 lazy ArtifactStore 디렉터리 존재를 잘못 요구한 시험 오류다. 두 실패를 보존하고 json_safe·실제 서버 원문에 맞게 고쳐 마지막1선택/1passed/exit0·16판정을 얻었다. ID/server/tool이 같은 시작/성공 완료와 status=ok 전체49자료원 요약을 설치 Source.summary와 대조했다. 49는 관측값이며 시험에 고정하지 않는다. nonce·checkpoint의 정확 값·protocol_probe 구조화 final·worker request/argv/schema 해시·실행별 data-dir와 confirmed/root-signaled/빈 Job을 대조했다. list_sources는 artifact를 저장하지 않아 디렉터리를 실제 생성하지 않는 것이 정상이다. 연구 중앙 제출/전체 역할/자료원 search/fetch 성공으로 넓히지 않는다.\n\n원자료 추가 대조에서 Codex의 MCP structuredContent가 native structured_content라는 것을 확인했다. 최초 observer가 camelCase를 읽어 absent로 기록한 원smoke와 초기46건 보고는 그대로 보존한다. 현재 공통 시험 관찰자가 동일 성공 원바이트의 content와 structured 본문 전체의 일치·registry summary 일치를 확인했고 새 manifest verdict와 지침을 교정했다. 현재 정본/미러 각각46고유선택/46passed/exit0·소스 불변이며15음성 파생 반례가 정확히 거부된다. 호출 입력/worker/runtime는 불변이라 이 관찰자 보완만으로 성공 유료 호출을 반복하지 않았다. wire MCP initialize/protocolVersion/isError는 CLI가 별도 노출하지 않아 미관측으로 남기며 native completed/error-null 및 초기화 후 성공 payload가 직접 근거다. 실제 모델명·비용·내부 요청 수·원격 종료는 미보고 또는 unknown이다.\n\n기존21항목/verdict와122비manifest경로를 보존하며 최종 성공1항목·원바이트10파일만 승격했다. 양쪽 각22항목/72파일/409886bytes·75개명시SHA,144경로 Git raw/clean·미러 바이트가 일치하고5MiB 아래다. 과거fd15f69d/8ee07448/0c839843의 입력/격리/정본 이동 slice actual diff를 유지 판정하고 존재하는 서술 원보고와 사라진 native 좌표를 구분했다. 역사 counts는 합산하지 않았다. 공식 생성의 사전변경계획과 실제34제품변경이 전부writes 안이다. 마지막 비용 캐시만 동기화했고--check1334파일/skill-only가 통과했다.\n\n시작2726/종료2750소스를 대조했고 기존runtime124·공급자/host/Lean/예약입력139경로·host8원녹화·기존도구SHA가 유지됐다. 공식 변환129입력과 동일 미러 offline/replay로 정본 성공의 한정 재사용을 확인했다. 미러의 새 유료 실호출은0이며 실제 미러 호출 성공으로 보고하지 않는다. 전체 일반/T3/변이·T4별도adapter보고·나머지문서/의미질문·L01·G4~G6/G8와최종review는 후속manager책임이다. Git stage/commit/reset/checkout/push와 graphify 갱신은 수행하지 않았다.',
 'acceptance': [
  {'id':'A1','result':'pass','detail':'phase013 source 전부 일치, 현재 scholarly validator/선택 파일·CLI/서버 Python/패키지/Source.summary 원문 및 SHA를 확인했다. 실제 snapshot/argv/status 해시로 새 workspace 내부 scholarly-data 전달을 결속했다. service/config/auth/runtime는 불변이며 lazy 디렉터리의 실제 생성과 전달을 구별했다.',
   'evidence':refs('start-comparison.json','source-start.json','server-selection.json','verification-final.json','review.md')+[smoke_ref]},
  {'id':'A2','result':'pass','detail':'최종 정본T5 1passed/exit0·16판정, 실제 같은 요청의 시작/성공 완료·전체content/structured_content·status=ok와 registry 전summary·exactnonce/checkpoint/JSON·worker결속/emptyJob을 확인했다. 초기2공식실패와3CLI호출을 보존했다. handshake/negotiatedprotocolVersion 및wireisError 미관측을 SDK판본이나 모델의 성공 주장으로 대체하지 않는다.',
   'evidence':native_refs},
  {'id':'A3','result':'pass','detail':'최종성공의전체native/원final/stderr/prompt/schema/request/status/registry/version10원파일과안전한판본좌표를원바이트로추가했다. 현재제품parser/실수신정의를쓰고공유시험observer로양본문을검사했다. 기존21항목과122비manifest경로불변,15음성반례,양쪽전건SHA/선언/5MiB/Gitraw-clean/미러바이트·corpus3모듈을확인했다. scholarly_config는설정녹화로그대로다.',
   'evidence':corpus_refs+refs('native-observation-current.json','verification-final.json')},
  {'id':'A4','result':'pass','detail':'지정설계/9-C·지침과입력/격리도입3commit의actualdiff/현소비/존재원보고를대조했다. 정본새T5와최종관련offline각46고유선택/row/exit0,공식생성/현재PythonSHA·1334파일check/skill-only를완결했다. 실제worker배선변경없음·원자료/도구조건보존과129변환입력으로미러실호출을한정재사용하며다른G미완료를유지한다.',
   'evidence':delivery_refs+refs('canonical-final/report.json','mirror-final/report.json','history-input.stdout','history-isolation.stdout','history-worker.stdout','history-original-reports.json','t5-list.stdout')}
 ],
 'changes':changes,
 'seams':[],
 'findings':[
  {'id':'F1','kind':'fact','detail':'실제gpt-6-astra/low→Codex0.162.1→설정된서버에서list_sources한요청이nativeID결속성공완료를반환했다. 현재registry의49summary와양본문이일치하고파일/checkpoint/final·격리·로컬Job회수가성립한다. source49개표시나과거verification문자열은이번search/fetch/계정접근성공이아니다. native초기화handshake/protocolVersion/wireisError·actualmodel·비용·원격종료는별도미관측/unknown이다.',
   'evidence':native_refs,'affects':['run:context.md#C11','run:context.md#G7','run:plan.md'],
   'next_action':'manager가 이 범위의 학술 최소 연결을 검수하고 T4 보고·L01·다른 G의 남김과 분리해 현재 증거로 연결한다.'},
  {'id':'F2','kind':'fact','detail':'초기공식error1/failed1은시험보고bytes직렬화와lazy디렉터리존재단언오류였다. 각원실호출/원보고는유지했고수리뒤최종T5만전체passed다. 추가raw대조에서native structured_content키를놓친초기관측을교정했다. 원smoke/초기offline보고의absent표현은불변으로두고현재observer·새finaloffline·native-observation-current로보완한다. 총3ModelRunner/CLI/도구호출이며새미러유료호출0이다.',
   'evidence':refs('live-01/report.json','live-02/report.json','live-final/report.json','native-observation-current.json','verification-final.json'),
   'affects':['run:context.md#C12','run:context.md#G7','run:plan.md'],
   'next_action':'manager가 역사 실패/오관측과 최종 해소를 구분해 기록하고 기존 보고를 소급 수정하거나 성공 횟수로 합산하지 않는다.'},
  {'id':'F3','kind':'fact','detail':'fd15f69d/8ee07448/0c839843의학술입력·격리·worker정본이동slice를actualdiff/현소비와대조했다. 존재하는operator-probe.json은이전성공/Job/snapshot의서술보고지만그native stdout와original_result_path는현재없다. 역사counts를새성공으로더하지않고이번native·registry대조로현재목록경계를직접확인했다. 다른hunk/연구운전/전체PR은미종결이다.',
   'evidence':refs('history-input.stdout','history-isolation.stdout','history-worker.stdout','history-original-reports.json','review.md'),
   'affects':['run:context.md#C9','run:context.md#G2','run:context.md#G7'],
   'next_action':'manager가 이 한정 slice의 유지/검증 추가만 반영하고 사라진 역사 raw 및 무관 영역을 포괄 승인으로 바꾸지 않는다.'},
  {'id':'F4','kind':'fact','detail':'2726시작/2750종료소스에서34변경이전부writes안이다. 기존runtime124·재사용입력139경로·host8원자료/도구SHA·기존21corpus/verdict·122비manifest경로가보존됐다. 새원녹화1/10파일을포함해각22항목72파일409886bytes·75SHA와144Gitraw/clean·미러바이트가일치한다. 최종양쪽offline각46과공식1334파일check/skill-only가통과했다. 미러129변환입력/재생은정본실호출의한정재사용이며미러live를실행하지않았다.',
   'evidence':delivery_refs+corpus_refs,'affects':['run:context.md#C12','run:context.md#G7','run:context.md#G8','run:plan.md'],
   'next_action':'manager가 원바이트/변환/기존 실호출 재사용과 이번 제품 단위를 검수·관리 마감하고 나머지 관문과 review 책임을 보존한다.'}
 ],
 'checks':checks
}
# Keep the detailed handoff prose readable; these are editorial clarifications,
# not new claims or changes to immutable execution reports.
report['narrative'] = report['narrative'].replace('기존runtime124·공급자/host/Lean/예약입력139경로',
                                               'runtime124를 포함한 공급자/host/Lean/예약 재사용139경로')
report['acceptance'][2]['detail'] = ('최종 성공의 전체 native/원 final/stderr/prompt/schema/request/status/registry/version '
    '10원파일과 안전한 판본 좌표를 원바이트로 추가했다. 현재 제품 parser/실수신 정의를 쓰고 공유 시험 observer로 '
    '양 본문을 검사했다. 기존21항목과122비manifest경로 불변,15음성 반례,양쪽 전건 SHA/선언/5MiB/Git raw-clean/미러 바이트·'
    'corpus3모듈을 확인했다. scholarly_config는 설정 녹화로 그대로다.')
report['acceptance'][3]['detail'] = ('지정 설계/9-C·지침과 입력/격리 도입3commit의 actual diff/현 소비/존재 원보고를 대조했다. '
    '정본 새T5와 최종 관련 offline 각46고유선택/row/exit0,공식 생성/현재Python SHA·1334파일 check/skill-only를 완결했다. '
    '실제 worker 배선 변경 없음·원자료/도구 조건 보존과129변환 입력으로 미러 실호출 근거를 한정 재사용하며 다른 G 미완료를 유지한다.')
report['findings'][0]['detail'] = ('실제 gpt-6-astra/low→Codex0.162.1→설정된 서버에서 list_sources 한 요청이 native ID에 결속된 '
    '성공 완료를 반환했다. 현재 registry의49summary와 양 본문이 일치하고 파일/checkpoint/final·격리·로컬 Job 회수가 성립한다. '
    'source49개 표시나 과거 verification 문자열은 이번 search/fetch/계정 접근 성공이 아니다. native 초기화 handshake/protocolVersion/'
    'wire isError·actual model·비용·원격 종료는 별도 미관측/unknown이다.')
report['findings'][1]['detail'] = ('초기 공식 error1/failed1은 시험 보고 bytes 직렬화와 lazy 디렉터리 존재 단언 오류였다. 각 원실호출/'
    '원보고는 유지했고 수리 뒤 최종 T5만 전체 passed다. 추가 raw 대조에서 native structured_content 키를 놓친 초기 관측을 교정했다. '
    '원 smoke/초기 offline 보고의 absent 표현은 불변으로 두고 현재 observer·새 final offline·native-observation-current로 보완한다. '
    '총3ModelRunner/CLI/도구 호출이며 새 미러 유료 호출0이다.')
report['findings'][2]['detail'] = ('fd15f69d/8ee07448/0c839843의 학술 입력·격리·worker 정본 이동 slice를 actual diff/현 소비와 대조했다. '
    '존재하는 operator-probe.json은 이전 성공/Job/snapshot의 서술 보고지만 그 native stdout와 original_result_path는 현재 없다. '
    '역사 counts를 새 성공으로 더하지 않고 이번 native·registry 대조로 현재 목록 경계를 직접 확인했다. 다른 hunk/연구 운전/전체 PR은 미종결이다.')
report['findings'][3]['detail'] = ('시작2726/종료2750 소스에서34변경이 전부 writes 안이다. runtime124를 포함한 재사용139경로·'
    'host8원자료/도구SHA·기존21corpus/verdict·122비manifest경로가 보존됐다. 새 원녹화1/10파일을 포함해 각22항목72파일409886bytes·'
    '75SHA와144Git raw/clean·미러 바이트가 일치한다. 최종 양쪽 offline 각46과 공식1334파일 check/skill-only가 통과했다. '
    '미러129변환 입력/재생은 정본 실호출의 한정 재사용이며 미러 live를 실행하지 않았다.')
(TASK/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('report written; complete, A1-A4 pass;',len(changes),'changes')
