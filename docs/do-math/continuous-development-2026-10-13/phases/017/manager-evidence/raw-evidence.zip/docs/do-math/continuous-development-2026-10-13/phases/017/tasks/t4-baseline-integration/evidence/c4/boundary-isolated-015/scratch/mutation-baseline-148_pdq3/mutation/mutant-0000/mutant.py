def value():
    return None
