
from pathlib import Path
from support.branch_gate import shared_state, used_state, unmeasured

import os
INPUT = Path(__file__).resolve().parents[1] / os.environ['PROVENANCE_INPUT']
UNUSED = INPUT.with_name('unused.txt')
EVENTS = []
VALUES = {}
NESTED = True


def read_input():
    EVENTS.append('read')
    return INPUT.read_text(encoding='utf-8')


def leaf():
    if 'leaf' not in VALUES:
        with shared_state('leaf'):
            VALUES['leaf'] = read_input()
    used_state('leaf')
    return VALUES['leaf']


def warm():
    if 'outer' not in VALUES:
        with shared_state('outer'):
            VALUES['outer'] = leaf() if NESTED else read_input()
        # Building another, unconsumed template does not make its inputs outer's.
        with shared_state('unused-outer'):
            with shared_state('unused-leaf'):
                UNUSED.read_text(encoding='utf-8')
            used_state('unused-leaf')


def consume():
    warm()
    used_state('outer')
    return VALUES['outer']


def paused_consume():
    with unmeasured():
        consume()
