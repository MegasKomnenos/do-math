
from pathlib import Path
from support.branch_gate import shared_state, used_state, unmeasured

INPUT = Path(__file__).resolve().parents[1] / 'input.txt'
UNUSED = INPUT.with_name('unused.txt')
EVENTS = []
VALUES = {}
NESTED = True


def read_input():
    EVENTS.append('read')
    return INPUT.read_text(encoding='utf-8')


def leaf():
    if 'leaf' not in VALUES:
        with shared_state('leaf'):
            VALUES['leaf'] = read_input()
    used_state('leaf')
    return VALUES['leaf']


def warm():
    if 'outer' not in VALUES:
        with shared_state('outer'):
            VALUES['outer'] = leaf() if NESTED else read_input()
        # Building another, unconsumed template does not make its inputs outer's.
        with shared_state('unused-outer'):
            with shared_state('unused-leaf'):
                UNUSED.read_text(encoding='utf-8')
            used_state('unused-leaf')


def consume():
    warm()
    used_state('outer')
    return VALUES['outer']


def paused_consume():
    with unmeasured():
        consume()

EXTRA_READS = []


def read_named(name):
    value = INPUT.with_name(name).read_text(encoding='utf-8')
    EXTRA_READS.append([name, value])
    return value


def prime_import():
    with shared_state('import-leaf'):
        VALUES['import-leaf'] = read_named('import.txt')
    with shared_state('import-unused'):
        VALUES['import-unused'] = read_named('import-unused.txt')


def restore(key):
    used_state(key)
    return VALUES[key]


def prime_fixture():
    assert restore('import-leaf') == 'import value'
    # The child is already built; this is actual nested consumption of it.
    with shared_state('fixture-parent'):
        VALUES['fixture-parent'] = restore('import-leaf') + '/' + read_named('fixture.txt')
    with shared_state('fixture-unused'):
        VALUES['fixture-unused'] = read_named('fixture-unused.txt')
    with unmeasured():
        with shared_state('paused-build'):
            VALUES['paused-build'] = read_named('paused.txt')
        assert restore('import-leaf') == 'import value'


def touch():
    return 'no use'


def paused_restore():
    with unmeasured():
        assert restore('fixture-parent') == 'import value/fixture value'
