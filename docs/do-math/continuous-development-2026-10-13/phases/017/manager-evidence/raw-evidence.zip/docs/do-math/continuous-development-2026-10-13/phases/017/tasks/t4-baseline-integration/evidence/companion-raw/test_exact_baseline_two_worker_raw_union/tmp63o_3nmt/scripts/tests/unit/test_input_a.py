
import unittest
import producer

setUpModule = producer.warm


class Case(unittest.TestCase):
    def test_consume(self):
        self.assertEqual(producer.consume(), 'observed a')
        self.assertEqual(producer.EVENTS, ['read'])
