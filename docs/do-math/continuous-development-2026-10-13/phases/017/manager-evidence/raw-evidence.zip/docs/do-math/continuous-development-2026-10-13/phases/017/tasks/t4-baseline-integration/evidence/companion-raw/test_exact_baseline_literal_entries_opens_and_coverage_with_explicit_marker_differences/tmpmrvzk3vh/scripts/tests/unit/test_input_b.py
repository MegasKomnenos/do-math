
import unittest
import producer


class Case(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.value = producer.restore('fixture-parent')

    def test_first(self):
        self.assertEqual(self.value, 'import value/fixture value')

    def test_second(self):
        self.assertEqual(self.value, 'import value/fixture value')
