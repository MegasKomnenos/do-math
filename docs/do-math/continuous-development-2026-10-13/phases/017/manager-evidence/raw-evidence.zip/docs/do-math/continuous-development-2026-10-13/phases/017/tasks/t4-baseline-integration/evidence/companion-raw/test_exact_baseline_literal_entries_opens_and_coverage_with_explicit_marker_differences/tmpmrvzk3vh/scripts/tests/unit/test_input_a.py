
import unittest
import producer

producer.prime_import()
setUpModule = producer.prime_fixture


class Case(unittest.TestCase):
    def test_actual(self):
        self.assertEqual(producer.restore('import-leaf'), 'import value')

    def test_observer(self):
        self.assertEqual(producer.touch(), 'no use')

    def test_paused(self):
        producer.paused_restore()
        self.assertEqual(2 + 2, 4)
