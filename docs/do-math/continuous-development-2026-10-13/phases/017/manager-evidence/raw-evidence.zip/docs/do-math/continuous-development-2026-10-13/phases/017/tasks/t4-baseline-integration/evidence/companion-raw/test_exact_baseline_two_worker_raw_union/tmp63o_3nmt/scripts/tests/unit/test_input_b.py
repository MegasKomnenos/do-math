
import unittest
import producer

setUpModule = producer.warm


class Case(unittest.TestCase):
    def test_consume(self):
        self.assertEqual(producer.consume(), 'observed b')
        self.assertEqual(producer.EVENTS, ['read'])

    def test_passive(self):
        # Runner bookkeeping must not acquire a shared dependency while paused.
        producer.paused_consume()
        self.assertEqual(2 + 2, 4)
