"""Build the task submission from retained actual receipts and verification files."""
import json
from pathlib import Path
from task_driver import E, RUN, REPO, read, write

PREFIX='run:phases/017/tasks/t4-baseline-integration/evidence/'
def refs(*paths): return [PREFIX+p for p in paths]

exact=[read(E/(tree+'-exact-verification.json')) for tree in ('canonical','mirror')]
full=[read(E/(label+'-verification.json')) for label in ('canonical-t4-short','mirror-t4-short')]
raw=read(E/'raw-verification.json')
preserved=read(E/'preservation.json')
original=read(E/'canonical-t4-full-verification.json')
intermediate=read(E/'canonical-t4-full-final-verification.json')
assert all(d['counts']=={'passed':2} and d['exit_code']==0 for d in exact)
assert raw['successful'] and raw['child_invocations']==30
a3_pass=all(d['counts']=={'passed':d['selected']} and d['exit_code']==0 and d['complete'] and d['successful']
            and not d['fixture_counts'] and d['adapter']['complete'] and d['adapter']['tests_complete'] for d in full)
assert read(E/'mirror-check.command.json')['exit_code']==read(E/'skill.command.json')['exit_code']==0
changes=[{'path':p,'detail':'공식 정확 비교 실행과 공식 미러 생성의 비용 캐시 부산물. 제품·시험 소스와 기대값은 불변.'} for p in preserved['changes']]
summaries=[{k:d[k] for k in ('label','selected','counts','exit_code','seconds')} for d in full]
narrative=(
    '017 t4-baseline-integration의 입력·두 정확 비교·전체 실행 및 원측정 검산과 보존을 수행했다. A3의 기능 합격 판정은 아래 실제 결과를 따른다. 시작 2675경로는016 manager 검수본과 SHA가 전건 같았고, '
    '도입066f2b82의 첫 부모0b4a2ebc에서 추출한 과거910파일/901blob을 새 ls-tree/cat-file와 원바이트로 다시 확인했다. '
    '정본/미러 Python875파일 및 시험·문서, 실제 argv/cwd·비밀 없는 baseline/TEMP 환경·PID/시작/종료/exit와 소스 전후를 남겼다.\n\n'
    '승인된 SHARED_INPUT_BASELINE_SCRIPTS를 실제 소비한 양쪽 공식 두 exact 시험은 각2selected/2고유row/2passed/skip0/exit0이다. '
    '정본의 기존 TestCase와 WORKER/SNAPSHOT을 바꾸지 않고 정상 unittest lifecycle의 cleanup 전에6fixture를 복사했다. '
    '그30snapshot/16coverage DB와30actual child를 재대조했다. ordinary 결과와 읽기 기록·모든 literal label/pair(빈 label 포함), '
    'opens/import_opens·파일/context/lines/arcs, 명시 marker 차이·input-a/b의 각 판본 실제 merge와 raw union이 맞았다. '
    '미러 시험 정의는 공식 변환과 바이트가 같으며 미러 공식 실행은 별도다. 보존된 fixture raw는 정본 companion 것이고 미러 원fixture raw는 별도 보존하지 않았다.\n\n'
    '첫 정본 전체 실행은 작업자가 저장소 내부의 긴 TEMP를 선택하여 Git 계약6건이 실패/오류였다. '
    '이 원실행은 '+json.dumps(original['counts'],ensure_ascii=False)+' 및 exit1 그대로 보존했다. '
    'Git 없는 fixture가 상위C:\\math를 찾는4failure와 SHA-256 rev-list Filename too long2error를 코드/trace에서 확인했다. '
    '제품·기대값을 수정하거나 첫 실행을 소급 통과시키지 않고 저장소 밖 짧은 전용 TEMP에서 새 전체 실행으로 대조했다. '
    '그 외부TEMP 실행은294passed/1error였다. 설치probe의nativecwd가262자로WinError267을냈으며 같은기존TestCase의실제대조에서241자cwd는normalexit0/반려exit1로통과했다. 두번째실패도그대로보존하고resource worker경로까지짧아지는출력c4/m4에서새전체를수행했다. 최종 동일 제품 판본의 두 전체 결과는 '+json.dumps(summaries,ensure_ascii=False)+'. '
    '각 실제 선택/고유row와 --list를 전건 대조했다. 기능 오류는 각 counts/nonpassed에 그대로 남겼다. '
    '각 worker의 requested/run_id/875소스/게시 artifact SHA/branch DB와 부모 원DB 재분석·adapter5개 소스 분모가 맞고 측정complete이다. '
    '도달률은 정보이며 두 트리 동일률이나 임계값을 완료조건으로 만들지 않았다.015의10실패/오류·2skip은 새전체passed에 정확 연결된다.\n\n'
    '현재/과거 소스,139실호출 입력·144corpus 경로와150명시 SHA 참조/Git raw-clean·host8원자료/도구·01512/01610제품22경로·색인/pseudo/T3-store를 보존했다. '
    '공식 생성은 사전 예상 변경이 비용 캐시 범위뿐임을 확인한 뒤 수행했고 --check/skill-only가 통과했다. '
    '초기 raw 보조 집계의 Git -c 오분류 exit1도 관측 기록에 남기고 같은 raw로 교정된 검산exit0을 구별했다. '
    '네 역사Temp 원보고 부재·역사counts 한계와 과거 bootstrap WinError5 원인 미확인은 유지한다. '
    '새 유료 공급자/실예약/학술 호출이나 설치 신뢰 승인·연구 재개·Git마감은 수행하지 않았다. '
    'G4 일반/fresh G5/전수G6·남은 의미/문서/L01·최종review 및22제품 Git마감은 다음 manager 책임이다.'
)
acceptance=[
 {'id':'A1','result':'pass','detail':'시작2675경로/016판본과875Python을 결속했고 승인된 별도910파일을 전건 SHA/Git blob 및 fresh Git 원바이트로 확인했다. 실제 공통 API/fixture/merge·입력 namespace와 역사 원보고 한계를 유지했다.',
  'evidence':refs('environment.json','tool-versions.json','source-start.json','source-population-observation.json','start-baseline.json','baseline-git-verification.json','input-audit.json','administrative-observations.md')},
 {'id':'A2','result':'pass','detail':'정본/미러 공식각2선택·고유row·passed·skip0·exit0. 실제 TestCase companion의6fixture/30snapshot/16DB/30child에서 ordinary·literal(빈label포함)/opens/import/전체coverage와 marker·두worker actual raw union을 재대조했다. 정본 companion raw의 미러 재사용은 같은 공식 변환·바이트/시험 정의와 별도 미러 공식 통과 범위만이다.',
  'evidence':refs('canonical-exact/report.json','mirror-exact/report.json','canonical-exact-verification.json','mirror-exact-verification.json','companion-result.json','companion-manifest.json','companion-invocations.json','raw-verification.json')},
 {'id':'A3','result':'pass' if a3_pass else 'fail','detail':json.dumps(summaries,ensure_ascii=False)+' 각 전건 selected/list/고유 row·exit와 worker requested/run_id/source/게시 SHA·branch DB 및 부모 재분석을 확인했다. 두 실행 환경 오류는 원결과를 보존하고 실제 대조로 교정했다. 이후 c4의 WindowsJobsContract.test_a_job_resumes_only_once가 TemporaryDirectory cleanup의 WinError32/5로 error여서 기능 합격은 미충족이다. fixture/runtime 수리는 writes 밖이며 F4에 후속 범위를 지정한다. adapter5개 정보와 기능 결과를 구별하고015의12nonpassed·016수리와bootstrap을 새전체row에 연결했다.',
  'evidence':refs('canonical-t4-full/report.json','canonical-t4-full-verification.json','canonical-t4-full-final/report.json','canonical-t4-full-final-verification.json','probe-long-observation.json','probe-short-observation.json','c4/report.json','m4/report.json','canonical-t4-short-verification.json','mirror-t4-short-verification.json','canonical-t4-short-raw-analysis.json','mirror-t4-short-raw-analysis.json','administrative-observations.md')},
 {'id':'A4','result':'pass','detail':'전후 source와910baseline이 불변이고139입력·corpus144경로/150명시SHA/Gitclean·host8/도구 및22제품·index/pseudo/T3-store를 보존했다. 비용캐시뿐인사전계획후 공식생성/check/skill-only를통과했다. 승인된실호출성질만재사용하며후속관문/검토/문서/의미/L01/Git마감은유지한다.',
  'evidence':refs('preservation.json','corpus-raw-clean.json','source-final.json','final-baseline.json','mirror-plan.json','mirror-build.command.json','mirror-check.command.json','mirror-check.stdout','skill.command.json','skill.stdout')}
]
findings=[
 {'id':'F1','kind':'fact','detail':'두exact비교와최종양쪽전체T4를실제연결했다. '+json.dumps(summaries,ensure_ascii=False)+'. 정본companion6fixture/30snapshot/16DB와각판본workermerge/rawunion을검증했다.015의10error/failed·2skip이새전체passed로연결되며측정complete는기능합격과별도판정이다.',
  'evidence':refs('raw-verification.json','canonical-t4-short-verification.json','mirror-t4-short-verification.json'),
  'affects':['run:context.md#C11','run:context.md#G2','run:context.md#G3','run:context.md#G7','run:plan.md'],
  'next_action':'manager가 두 비교의 성공과 전체 T4의 기능 오류를 구별해 검수한다. F4의 Job cleanup/종료 동기화 문제를 수리·검증하는 후속 work를 배정하고22제품마감은그결과로판단한다. 전체일반/freshT3/전수변이/남은의미·문서/L01·review는별도배정한다.'},
 {'id':'F2','kind':'fact','detail':'첫정본전체의저장소내부긴TEMP는Git계약4failure/2error를만들었다. Git없는fixture의상위저장소발견과.git삭제후상위발견은코드/반환에직접연결되고, SHA256 rev-list는Filename too long이다. 코드불변·외부짧은TEMP의새전체에서6ID전부passed다. 외부TEMP 전체의설치probe1error는resource worker의cwd262자WinError267이었다. 현재TestCase의직접대조는존재하는cwd262자에서같은267/exit1,241자에서normal0·반려1/전체0이다. 최종짧은c4/m4 전체에서그ID도passed다. 두실패전체와직접진단은소급수정하지않았다. 과거bootstrapWinError5는현재재현되지않았지만원인미확인이다.',
  'evidence':refs('canonical-t4-full-verification.json','canonical-t4-full.command.json','canonical-t4-full-final-verification.json','probe-long-observation.json','probe-short-observation.json','canonical-t4-short.command.json','canonical-t4-short-verification.json','administrative-observations.md'),
  'affects':['run:context.md#C5','run:context.md#C11','run:plan.md','repo:.claude/skills/do-math/scripts/tests/support/port_contracts/git_backend.py','repo:.claude/skills/do-math/scripts/tests/boundary/test_operator_installation_probe.py'],
  'next_action':'후속실행에는저장소밖짧은parent TEMP와resource worker의짧은출력/scratch조건을함께명시한다. 원실패를소급성공이나제품수리로표시하지않고bootstrap원인한계를유지한다.'},
 {'id':'F3','kind':'fact','detail':'139기존실호출입력·corpus144/150명시SHA·host8/도구·22제품과910baseline·색인/pseudo/T3-store는불변이며변경은공식비용캐시뿐이다. 미러생성/--check/skill-only는통과했다. P10/P11은정확시험/역사표기이며없는requirement-stateID가아니다. 네역사Temp보고와옛counts는새성공에합산하지않았다.',
  'evidence':refs('preservation.json','final-baseline.json','corpus-raw-clean.json','mirror-check.command.json','skill.command.json'),
  'affects':['run:context.md#C9','run:context.md#C12','run:context.md#G7','run:context.md#G8','run:plan.md'],
  'next_action':'manager가기존승인성질의불변입력/도구조건재사용과새017증거를구별해인계한다. 코드수정없는최종review와G4~G6/L01/의미·문서및Git마감의후속책임을유지한다.'}
]
if not a3_pass:
    findings.append({'id':'F4','kind':'issue',
      'detail':'짧은 경로의 정본 c4는 295선택/고유row 중294passed·1error·exit1이었다. 정확 ID는 boundary.test_port_jobs.WindowsJobsContract.test_a_job_resumes_only_once다. 실제 Job을 resume하고 두번째 resume의 already been resumed 반려를 확인한 뒤, TemporaryDirectory cleanup에서 WinError32가 나고 Python cleanup의 추가 unlink/rmtree에서5/32가 이어졌다. 같은 ID는 앞선 두 전체에서 passed였으며 소스는 불변이다. JobsContract.launch는job.close를cleanup에등록하고해당메서드는종료를기다리지않는다. WindowsJob.close는핸들을닫으며잔여자손을종료시키지만root wait/빈Job 확인을수행하지않는다는코드사실이다. 종료/커널cwd해제와디렉터리삭제의경쟁은가설이며오류순간의childPID/FILETIME/handle 소유는미관측이다. Windows32원인을임의로transient/제품버그로확정하거나다시전체를돌려성공으로가리지않았다.',
      'evidence':refs('c4/report.json','c4/boundary-isolated-027/result.json','c4/boundary-isolated-027/stderr.txt','canonical-t4-short-verification.json','job-cleanup-review.md')+
                 ['repo:.claude/skills/do-math/scripts/tests/support/port_contracts/jobs.py','repo:.claude/skills/do-math/scripts/do_math/windows_job.py'],
      'affects':['run:context.md#C11','run:context.md#G3','run:context.md#G7','run:plan.md',
                 'repo:.claude/skills/do-math/scripts/tests/support/port_contracts/jobs.py',
                 'repo:.claude/skills/do-math/scripts/tests/boundary/test_port_jobs.py'],
      'next_action':'후속work가정확한이한메서드와공유Job cleanup을검토한다. 실제root/PID/FILETIME·종료/빈Job·cwd해제의상태를cleanup전관측해원인을구분하고현 close 계약/real-fake parity를보존하는종료동기화를수리한다. 제품runtime수정이필요하면WindowsJob.close계약과소비자를함께검토한다. 정확반례/관련회귀뒤최종동일판본의양쪽전체T4를새로확보하며skip·무조건retry·삭제오류무시는하지않는다.'})
    narrative += '\n\nA3는 fail이고 task 상태는 partial이다. canonical c4의 Job cleanup WinError32/5가 남았으며 같은 ID의 앞선 통과와 현재 오류를 구별했다. 오류 순간 프로세스/핸들 상태는 미관측이다. fixture와runtime 수리는 허용된 비용캐시4경로 밖이라 수정하지 않고 F4에 정확 한 메서드/공유cleanup/종료 계약 검토와 후속검증을 반환한다. 전체 측정의 완전성으로 이 기능 오류를 통과시키지 않는다.'
checks=[]
for path in sorted(E.glob('*.command.json')):
    receipt=read(path)
    if 'exit_code' not in receipt: continue
    label=path.name.removesuffix('.command.json')
    evidence=refs(path.name,label+'.stdout',label+'.stderr')
    if label in ('canonical-exact','mirror-exact','canonical-t4-full','canonical-t4-full-final','mirror-t4-full','canonical-t4-short','mirror-t4-short'):
        evidence += refs(Path(receipt['output']).relative_to(E).as_posix()+'/report.json')
    checks.append({'command':__import__('subprocess').list2cmdline(receipt['argv']), 'cwd':'repo:.',
                   'result':'pass' if receipt['exit_code']==0 else 'fail','exit_code':receipt['exit_code'],
                   'evidence':evidence,'detail':'실제 argv/cwd/환경·PID/시작/종료/exit 및 소스 전후와 원 stdout/stderr를 보존했다.'+
                    (' 첫 내부TEMP 조건의 전체 실패를 소급 성공으로 바꾸지 않는다.' if label=='canonical-t4-full' else '')})
checks.append({'command':__import__('subprocess').list2cmdline([__import__('sys').executable,'-u','-B',str(E/'verify_task.py'),'raw']), 'cwd':'repo:.',
               'result':'fail','exit_code':1,'evidence':refs('administrative-observations.md','companion-invocations.json'),
               'detail':'초기보조분류가Git -c를Pythonchild로세어AssertionError였다. 제품시험/원자료는불변이며후속동일raw교정검산의exit0을별도보존했다.'})
write(E.parent/'report.json',{'status':'complete' if a3_pass else 'partial','narrative':narrative,'acceptance':acceptance,'changes':changes,
      'seams':[],'findings':findings,'checks':checks})
print('complete' if a3_pass else 'partial',E.parent/'report.json')
