"""Evidence-only Python audit hook for the single resource cwd follow-up."""
import json,os,sys
from pathlib import Path
destination=Path(__file__).resolve().parent.parent
def launched(event,args):
    if event=='subprocess.Popen':
        executable,argv,cwd,_=args
        row={'pid':os.getpid(),'executable':str(executable),'argv':argv,
             'cwd':str(cwd) if cwd is not None else os.getcwd()}
        with (destination/f'cwd-audit-{os.getpid()}.jsonl').open('a',encoding='utf-8') as stream:
            stream.write(json.dumps(row,ensure_ascii=False)+'\n')
sys.addaudithook(launched)
