from pathlib import Path

BASE = Path('C:/math/.claude/skills/do-math/scripts/tests')

path = BASE / 'boundary/test_scheduling_windows_job.py'
text = path.read_text(encoding='utf-8')
begin = text.index('\ndef process_kernel():')
end = text.index("\n@test_group('resource')", begin)
text = text[:begin] + '\n' + text[end:]
text = text.replace('from test_categories import test_group\n',
                    'from test_categories import test_group\nfrom support.host_live import WAIT_TIMEOUT, process_kernel, release_process, reached\n')
text = text.replace('WAIT_TIMEOUT = 258  # WaitForSingleObject: the object is not signaled\n', '')
path.write_text(text, encoding='utf-8')

path = BASE / 'boundary/test_scheduling_owned_job_children.py'
text = path.read_text(encoding='utf-8')
begin = text.index('\ndef reached(')
end = text.index("\n@category('resource')", begin)
text = text[:begin] + '\n' + text[end:]
text = text.replace('from test_categories import test_group as category\n',
                    'from test_categories import test_group as category\nfrom support.host_live import reached\n')
text = text.replace('import threading\n', '')
path.write_text(text, encoding='utf-8')

path = BASE / 'boundary/test_role_input_snapshot_reach.py'
text = path.read_text(encoding='utf-8')
begin = text.index('\nWINDOWLESS_READ =')
end = text.index('\ndef envelope(', begin)
text = text[:begin] + '\n' + text[end:]
text = text.replace('from support.engine_context import prepare\n',
                    'from support.engine_context import prepare\nfrom support.host_live import snapshot_read_fixture, snapshot_read_context, run_windowless_read\n')
begin = text.index('        self.repository = self.root /')
end = text.index('\n    def read(', begin)
text = text[:begin] + '''        self.repository, self.decision, self.result, self.snapshot = snapshot_read_fixture(
            self.root, _entry.ports, INSTANCE)

    def workspace_context(self, ledger):
        return snapshot_read_context(self.root, self.repository, self.snapshot, INSTANCE, ledger)
''' + text[end:]
begin = text.index("            (workspace / 'read-request.json').write_bytes")
end = text.index("            self.assertEqual(Path(observed['parent_executable']), PYTHONW)", begin)
text = text[:begin] + '''            observed = run_windowless_read(workspace, context, arguments, SCRIPTS)
''' + text[end:]
path.write_text(text, encoding='utf-8')

path = BASE / '시험-지침.md'
text = path.read_text(encoding='utf-8')
mark = '## 3. 시험을 돌리는 동안의 규칙'
section = '''### T5 Windows 호스트 연쇄

`python -u -B scripts/run_tests.py --tier T5 --list`는 공급자 두 건과 `smoke.test_host_live` 세 건을 함께 선택한다. 호스트만 확인하려면 `python -u -B scripts/run_tests.py --tier T5 smoke.test_host_live --jobs 1 --output <새 출력 폴더>`를 사용한다. 실제 Windows·현재 Python의 `pythonw.exe`·PowerShell·Git이 필요하며, 환경 부재와 실경계 실패는 실패로 보고한다.

호스트 시험은 실제 `real_ports`·ModelRunner·Codex worker·수집기를 유지하고 외부 모델 CLI 자리에서만 결정적 로컬 프로그램을 실행한다. 시작 공개 전 CLI 미기동, PID/FILETIME·이름 있는 Job의 커널 소유, 정확한 정상 JSON 및 비정상 exit 7·stderr, 명시 취소 뒤 worker·CLI·자손의 held handle 신호와 빈 Job을 검사한다. 별도로 실제 pythonw가 설치한 읽기 명령을 PowerShell로 실행해 console_python 지급, 온전한 JSON·exit 0/1 및 읽기 기록의 성공/반려를 검사한다. 기존 boundary도 `support.host_live`의 동일 준비/관측 코드를 사용하며 기존 커널·읽기 단언을 유지한다.

원자료는 공식 출력의 `smoke-isolated-*/scratch/host-job-*/`와 `host-pythonw-*/`에 남는다. `smoke.json`은 실제 판정과 시각·Python 판본·PID/FILETIME·Job·정리 결과를 기록하고, `call/`은 prompt·schema·worker 요청/argv·stdout/stderr·종료 수집을 보존한다. pythonw 하위 폴더에는 부모 argv/cwd/console·PowerShell 판본/명령·원 출력 바이트·제품 지급 context·파싱 결과·읽기 기록과 시험 전용 Git snapshot이 남는다. 이 로컬 CLI 출력은 실제 공급자 녹화나 모델 호출 성공이 아니며 corpus에 넣지 않는다. 유료 호출·OS 예약 등록/변경은 수행하지 않고 자신이 생성한 Job과 자손만 정리한다. 실제 Lean/Mathlib·예약 발화/해제·학술 MCP 및 운전 문서 읽기 한도는 별도 후속 검증이다.

'''
assert mark in text
path.write_text(text.replace(mark, section+mark), encoding='utf-8')
