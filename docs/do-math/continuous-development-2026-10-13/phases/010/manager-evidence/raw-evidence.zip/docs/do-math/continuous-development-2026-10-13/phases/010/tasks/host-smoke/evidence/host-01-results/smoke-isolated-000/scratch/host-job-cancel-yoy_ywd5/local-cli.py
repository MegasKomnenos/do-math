import json, os, subprocess, sys, threading
from pathlib import Path
root = Path(__file__).resolve().parent
prompt = json.loads(sys.stdin.buffer.read())
def atomic(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value), encoding='utf-8')
    os.replace(temporary, path)
child = None
try:
    child = subprocess.Popen([sys.executable, '-B', str(root / 'local-child.py')],
                             creationflags=subprocess.CREATE_NO_WINDOW)
    while not (root / 'grandchild.json').is_file():
        if child.poll() is not None:
            raise RuntimeError('local child exited before readiness')
        threading.Event().wait(.02)
    atomic(root / 'cli.json', {'pid':os.getpid(), 'argv':sys.argv, 'cwd':str(Path.cwd()),
                               'executable':sys.executable, 'prompt':prompt})
    while not (root / 'release').is_file():
        threading.Event().wait(.02)
    child.wait()
    if prompt['mode'] == 'nonzero':
        sys.stderr.buffer.write(b'local host CLI exit 7\n')
        raise SystemExit(7)
    final = json.dumps({'output_json':json.dumps(prompt['expected'], ensure_ascii=False)}, ensure_ascii=False)
    final_path = Path(sys.argv[sys.argv.index('--output-last-message') + 1])
    final_path.write_text(final, encoding='utf-8')
    for event in [{'type':'thread.started', 'thread_id':'host-local'},
                  {'type':'item.completed', 'item':{'id':'host-final', 'type':'agent_message', 'text':final}},
                  {'type':'turn.completed', 'usage':{'input_tokens':0, 'output_tokens':0}}]:
        print(json.dumps(event, ensure_ascii=False), flush=True)
finally:
    if child is not None and child.poll() is None:
        child.terminate()
        child.wait()
