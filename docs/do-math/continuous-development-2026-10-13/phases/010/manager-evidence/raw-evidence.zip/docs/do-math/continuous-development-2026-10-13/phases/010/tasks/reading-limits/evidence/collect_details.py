import hashlib
import json
import mmap
import re
from pathlib import Path
from investigate import EVIDENCE, REPO, RUN, write, stamp

skill = REPO / '.claude/skills/do-math'
docs = ['SKILL.md', 'GLOSSARY.md', 'README.md', 'references/초기화-운전.md', '계약/독립-운영.md']
skill_text = (skill / 'SKILL.md').read_text(encoding='utf-8')
table = skill_text.split('<!-- role-reading-map:start -->')[1].split('<!-- role-reading-map:end -->')[0]
assignments = {}
for line in table.splitlines():
    columns = [c.strip() for c in line.strip().strip('|').split('|')]
    paths = re.findall(r'`([^`]+)`', columns[-1])
    if paths: assignments[columns[0]] = paths
roles = {role: assignments['common'] + paths for role, paths in assignments.items() if role != 'common'}
docs = sorted(set(docs + [p for paths in roles.values() for p in paths]))
start_rows = []
metadata = []
for rel in docs:
    raw = (skill / rel).read_bytes()
    ref = 'repo:.claude/skills/do-math/' + rel
    row = {'ref': ref, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    start_rows.append(row)
    lines = raw.decode('utf-8').splitlines(keepends=True)
    metadata.append({**row, 'lines': len(lines), 'read_scope': 'metadata and required entry/section declarations; role semantics reuse prior validation'})
sections = []
for rel, start_tag, next_tag in [('README.md', '<a id="operating-model"></a>', '<a id="start-guide"></a>'), ('README.md', '<a id="start-guide"></a>', '<a id="existing-control"></a>')]:
    raw = (skill / rel).read_bytes()
    lines = raw.decode('utf-8').splitlines(keepends=True)
    # Source anchor spelling is checked below; headings also locate the semantic section.
    headings = ('## 운전 책임과 실행 구조', '## 새 연구를 시작하고 인계하기', '## 기존 연구 조회·제어')
    index = 0 if 'operating' in start_tag else 1
    start = next(i for i,l in enumerate(lines) if l.strip() == headings[index])
    end = next(i for i,l in enumerate(lines) if l.strip() == headings[index+1])
    body = ''.join(lines[start:end]).encode('utf-8')
    sections.append({'ref': 'repo:.claude/skills/do-math/' + rel, 'section': headings[index], 'inclusive_lines': [start+1, end], 'bytes_including_original_line_endings': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
write('document-population.json', {'at_utc': stamp(), 'documents': metadata, 'operator_sections': sections, 'roles': [{'role': r, 'ordered_paths': p, 'document_bytes': sum((skill / rel).stat().st_size for rel in p), 'transport': 'prompt stdin, not operator tool result'} for r,p in roles.items()], 'single_atomic_operator_batch_declared': False, 'role_validation_reexecuted': False})
write('additional-source-start.json', {'at_utc': stamp(), 'files': start_rows})
write('additional-inputs.json', [row['ref'] for row in start_rows] + ['repo:docs/do-math/시험-재편-2026-09-29/단계-전환표-2026-10-03.json'])

old = json.loads((EVIDENCE / 'historical-reading-boundary.json').read_text(encoding='utf-8'))
kept = {k:v for k,v in old.items() if k not in ['reading_declarations']}
# Retain only the reading-path evidence and reuse markers, not the entire historical 10-role census.
kept['reading_declarations'] = {'operator': old['reading_declarations']['operator'], 'internal_roles': {'actor': old['reading_declarations']['internal_roles']['actor'], 'common_paths': old['reading_declarations']['internal_roles']['common_paths'], 'role_count': len(old['reading_declarations']['internal_roles']['role_bundles']), 'reuse_note': 'Historical validation retained; current path and size census is document-population.json. Historical CLI/version/size is not re-certified as current.'}}
write('historical-reading-boundary-selected.json', kept)

claude = Path('C:/Users/wogud/.local/bin/claude.exe')
snippets = []
with claude.open('rb') as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
    for label, start, length in [('token-limits', 207620850, 4000), ('Read-description-and-schema', 208145150, 7500), ('byte-limits', 210866400, 2500)]:
        raw = mm[start:start+length]
        snippets.append({'label': label, 'binary_offset': start, 'bytes': length, 'sha256': hashlib.sha256(raw).hexdigest(), 'text': raw.decode('utf-8', errors='replace'), 'interpretation_scope': 'installed static implementation excerpt; not executing its runtime/configuration'})
write('claude-installed-read-excerpts.json', {'at_utc': stamp(), 'binary': str(claude), 'excerpts': snippets})
print(json.dumps({'document_count': len(metadata), 'role_count': len(roles), 'operator_sections': sections}, ensure_ascii=False, indent=2))
