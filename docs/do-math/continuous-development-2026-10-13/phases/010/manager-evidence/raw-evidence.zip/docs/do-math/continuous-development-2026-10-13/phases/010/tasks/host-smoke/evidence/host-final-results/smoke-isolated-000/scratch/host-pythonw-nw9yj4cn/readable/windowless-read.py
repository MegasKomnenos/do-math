import ctypes, json, os, subprocess, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from do_math import contracts, submission
from do_math.system_clock import SystemClock
from do_math.windows_job import owner_identity

workspace = Path.cwd()
request = json.loads((workspace / 'read-request.json').read_bytes())
submission.install_tools(workspace, request['context'], contracts.schema_for('maintenance'),
                         None, clock=SystemClock())
shell = workspace / 'read-issued-command.ps1'
shell.write_text(r"""
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$context = Get-Content -LiteralPath 'input/submission/context.json' -Raw | ConvertFrom-Json
$request = Get-Content -LiteralPath 'read-request.json' -Raw | ConvertFrom-Json
$command = @($context.record_map.read_tool.command)
$commandArguments = @($command | Select-Object -Skip 1) + @($request.arguments)
@{version=$PSVersionTable.PSVersion.ToString(); pid=$PID; executable=(Get-Process -Id $PID).Path;
  command=@($command[0]) + $commandArguments; cwd=(Get-Location).Path} |
  ConvertTo-Json -Depth 8 | Set-Content -LiteralPath 'powershell-observed.json' -Encoding UTF8
& $command[0] @commandArguments
exit $LASTEXITCODE
""", encoding='utf-8')
command = [request['powershell'], '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(shell)]
result = subprocess.run(command, cwd=workspace, capture_output=True,
                        creationflags=subprocess.CREATE_NO_WINDOW)
(workspace / 'read.stdout.bin').write_bytes(result.stdout)
(workspace / 'read.stderr.bin').write_bytes(result.stderr)
(workspace / 'read-result.json').write_text(json.dumps({
    'parent_executable': sys.executable, 'parent_python_version': sys.version,
    'parent_argv': sys.argv, 'parent_cwd': str(workspace),
    'parent_identity': owner_identity(), 'parent_console': int(ctypes.windll.kernel32.GetConsoleWindow()),
    'powershell_argv': command, 'returncode': result.returncode,
    'stdout': result.stdout.decode('utf-8'), 'stderr': result.stderr.decode('utf-8'),
}), encoding='utf-8')
