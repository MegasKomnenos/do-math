import ast
from collections import Counter
import hashlib
import inspect
import json
from pathlib import Path
import subprocess
import sys

from audit import REPO, RUN, HERE, snapshot, write

start=json.loads((HERE/'source-start.json').read_bytes())
end=snapshot()
write(HERE/'source-end.json',end)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()
assert head==json.loads((HERE/'start.json').read_bytes())['head']
changed=[p for p in sorted(set(start)|set(end)) if start.get(p)!=end.get(p)]
phase=json.loads((RUN/'phases/010/phase.json').read_bytes())
allowed=next(t['writes'] for t in phase['tasks'] if t['id']=='host-smoke')
assert set(changed)==set(allowed),changed
runtime=json.loads((RUN/'phases/007/manager-evidence/verification.json').read_bytes())['runtime_unchanged_since_live']
smoke=json.loads((RUN/'phases/008/manager-evidence/verification.json').read_bytes())['smoke_inputs_unchanged']
assert len(runtime)==124 and all(start[p]==end[p] for p in runtime)
assert len(smoke)==3 and all(start[p]==end[p] for p in smoke)
corpus=json.loads((RUN/'phases/008/tasks/document-recovery/evidence/corpus-final.json').read_bytes())
corpus_summary={}
for tree,record in corpus['trees'].items():
    for item in record['files'].values():
        assert end[item['path']]==start[item['path']]==item['sha256']
        assert (REPO/item['path']).stat().st_size==item['bytes']
    corpus_summary[tree]={k:record[k] for k in ('entry_count','file_count','bytes')}
    corpus_summary[tree]['explicit_sha_bindings']=len(record['bindings'])

suites={}
for name,tree in (('host-01','.claude'),('host-02','.claude'),('host-final','.claude'),
                  ('related','.claude'),('mirror-host','.agents')):
    report=json.loads((HERE/(name+'-results/report.json')).read_bytes())
    command=json.loads((HERE/(name+'.command.json')).read_bytes())
    before=json.loads((HERE/(name+'.before.json')).read_bytes())
    after=json.loads((HERE/(name+'.after.json')).read_bytes())
    rows=[r for group in report['reports'] for r in group['rows']]
    ids=[r['id'] for r in rows]
    assert len(ids)==len(set(ids))==len(report['selected'])
    assert set(ids)==set(report['selected'])
    assert dict(Counter(r['outcome'] for r in rows))==report['counts']
    assert report['complete'] and not report['changed_during_run']
    prefix=tree+'/skills/do-math/scripts/'
    assert all(before[prefix+p]==h==after[prefix+p] for p,h in report['source_sha256'].items())
    mismatches=[p for p,h in report['source_sha256'].items() if end.get(prefix+p)!=h]
    if name in ('host-final','related','mirror-host'): assert not mismatches,mismatches
    suites[name]={'selected':report['selected'],'unique_rows':len(ids),'counts':report['counts'],
                  'complete':report['complete'],'successful':report['successful'],'exit_code':command['exit_code'],
                  'python_source_count':len(report['source_sha256']),'current_source_mismatches':mismatches,
                  'nonpassed':[r for r in rows if r['outcome']!='passed'],
                  'report_sha256':hashlib.sha256((HERE/(name+'-results/report.json')).read_bytes()).hexdigest()}
assert suites['host-final']['counts']==suites['mirror-host']['counts']=={'passed':3}
assert suites['related']['counts']=={'passed':59,'failed':1,'error':1}
baseline=json.loads((HERE/'baseline-repro-02-results/report.json').read_bytes())
baseline_rows=[r for g in baseline['reports'] for r in g['rows']]
assert baseline['counts']=={'failed':1,'error':1} and baseline['complete']
assert {r['id']:r['outcome'] for r in baseline_rows}=={r['id']:r['outcome'] for r in suites['related']['nonpassed']}
preserved={}
for rel in ('boundary/test_scheduling_windows_job.py','boundary/test_scheduling_owned_job_children.py',
            'boundary/test_role_input_snapshot_reach.py'):
    path='.claude/skills/do-math/scripts/tests/'+rel
    original=subprocess.check_output(['git','show','HEAD:'+path],cwd=REPO).decode('utf-8')
    current=(REPO/path).read_text(encoding='utf-8')
    def methods(source):
        return {c.name+'.'+n.name:ast.dump(n,include_attributes=False) for c in ast.parse(source).body
                if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
    assert methods(original)==methods(current),rel
    preserved[rel]=len(methods(current))
sys.path.insert(0,str(REPO/'.claude/skills/do-math/scripts'))
sys.path.insert(0,str(REPO/'.claude/skills/do-math/scripts/tests'))
from support.smell_rules import smell_issues, patch_issues
from do_math.formal import _job_run
local_smells={rel:smell_issues((REPO/'.claude/skills/do-math/scripts/tests'/rel).read_text(encoding='utf-8'),rel)
              for rel in (*preserved,'smoke/test_host_live.py')}
helper_patches=patch_issues((REPO/'.claude/skills/do-math/scripts/tests/support/host_live.py').read_text(encoding='utf-8'),'support/host_live.py')
assert not any(local_smells.values()) and not helper_patches
try:
    _job_run(command=[sys.executable,'-c','pass'],cwd=HERE,jobs=object())
except TypeError as error:
    missing_arguments=str(error)
else: raise AssertionError('expected missing call contract')
assert "'clock'" in missing_arguments and "'environment'" in missing_arguments
write(HERE/'call-jobs-diagnosis.json',{'signature':str(inspect.signature(_job_run)),
    'observed_direct_type_error':missing_arguments,'boundary_error':'KeyError: -1',
    'cause':'The unchanged test passes jobs but omits clock and environment. ModelCalls.collect converts TypeError to a failed-result dict; tuple indexing then hides the initial failure.',
    'source_unchanged':start['.claude/skills/do-math/scripts/tests/boundary/test_scheduling_call_jobs.py']==end['.claude/skills/do-math/scripts/tests/boundary/test_scheduling_call_jobs.py']})

host_reports={}
for label in ('host-final','mirror-host'):
    recordings=[]
    for path in (HERE/(label+'-results')).rglob('smoke.json'):
        observed=json.loads(path.read_bytes())
        assert observed['passed'] and all(observed['checks'].values()) and 'error' not in observed
        entry={'path':path.relative_to(RUN).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
               'checks':observed['checks'],'mode':observed.get('mode','pythonw')}
        if 'mode' in observed:
            assert observed['wait_after']=={'worker':0,'cli':0,'child':0,'grandchild':0}
            entry.update(started=observed['started'],children_kernel=observed['children_kernel'],
                         termination_barrier=observed['result']['execution']['collect']['termination_barrier'],
                         cleanup=observed['wait_after'],worker_argv=observed['worker_argv'])
        else:
            entry['powershell']=[json.loads((path.parent/ledger/'powershell-observed.json').read_text(encoding='utf-8-sig'))
                                  for ledger in ('readable','supplied_only')]
            entry['observations']=observed['observations']
        recordings.append(entry)
    assert len(recordings)==4
    host_reports[label]=recordings
for name,plan in (('mirror-build','mirror-plan'),('cache-sync','cache-plan')):
    command=json.loads((HERE/(name+'.command.json')).read_bytes())
    expected=json.loads((HERE/(plan+'.json')).read_bytes())
    assert command['exit_code']==0 and command['changed_sources']==expected['changes']
for name in ('mirror-check','skill-only'):
    command=json.loads((HERE/(name+'.command.json')).read_bytes())
    assert command['exit_code']==0 and not command['changed_sources']
assert (REPO/'.claude/skills/do-math/scripts/tests/.timings.json').read_bytes()==(REPO/'.agents/skills/do-math/scripts/tests/.timings.json').read_bytes()
assert all(r['hash_matches'] for r in json.loads((HERE/'history-existing-reports.json').read_bytes()))
verification={'head':head,'source_count':len(end),'changes':changed,'writes_exactly_match':True,
    'suites':suites,'baseline_reproduction':{'counts':baseline['counts'],'rows':baseline_rows},
    'unchanged_test_method_ast':preserved,'local_smell_issues':local_smells,'helper_product_patches':helper_patches,
    'runtime_unchanged':runtime,'provider_smoke_inputs_unchanged':smoke,'corpus':corpus_summary,
    'host_recordings':host_reports,'cache_synchronized':True,'limits':'G4-G6/G8 and other G7 chains were not run.'}
write(HERE/'verification.json',verification)
print(json.dumps({'head':head,'source_count':len(end),'changes':changed,'counts':{k:v['counts'] for k,v in suites.items()},
                  'preserved_test_methods':sum(preserved.values()),'runtime_preserved':len(runtime),'provider_inputs_preserved':len(smoke)},ensure_ascii=False))
