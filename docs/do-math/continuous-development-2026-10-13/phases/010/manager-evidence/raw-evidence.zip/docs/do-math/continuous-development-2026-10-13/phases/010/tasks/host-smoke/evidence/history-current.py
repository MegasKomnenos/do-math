import hashlib
import json
from pathlib import Path
import subprocess

REPO=Path('C:/math')
HERE=Path(__file__).resolve().parent
board=json.loads((REPO/'docs/do-math/시험-재편-2026-09-29/단계-전환표-2026-10-03.json').read_bytes())
reports=[]
for key in ('builder_population_and_windowless_boundary','console_sibling_refusal'):
    value=board['current_work'][key]
    relevant={k:value[k] for k in ('id','scope','state','reports','windowless_boundary','changes','remaining','base_head') if k in value}
    (HERE/('history-'+value['id']+'-slice.json')).write_text(json.dumps(relevant,ensure_ascii=False,indent=2),encoding='utf-8')
    for name,reference in value['reports'].items():
        path=REPO/reference['path']
        raw=path.read_bytes()
        d=json.loads(raw)
        rows=[r for report in d.get('reports',[]) for r in report.get('rows',[]) if any(s in r['id'].lower() for s in ('pythonw','snapshotread','console','sibling'))]
        reports.append({'history':value['id'],'name':name,'path':reference['path'],
                        'sha256':hashlib.sha256(raw).hexdigest(),'hash_matches':hashlib.sha256(raw).hexdigest()==reference['sha256'],
                        'counts':d.get('counts'),'relevant_rows':rows})
        print(value['id'],name,'keys',list(d),'relevant',[(r['id'],r['outcome']) for r in rows])
for commit in ('b484771e','3dfea909','1b2b9e83'):
    paths=['.claude/skills/do-math/scripts/do_math/file_io.py', '.claude/skills/do-math/scripts/do_math/submission.py',
           '.claude/skills/do-math/scripts/tests/boundary/test_scheduling_call_jobs.py',
           '.claude/skills/do-math/scripts/tests/boundary/test_scheduling_windows_job.py',
           '.claude/skills/do-math/scripts/tests/test_windows_job.py']
    output=subprocess.check_output(['git','show',commit,'--',*paths],cwd=REPO)
    (HERE/('history-'+commit+'.diff')).write_bytes(output)
    print(commit,len(output))
(HERE/'history-existing-reports.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
