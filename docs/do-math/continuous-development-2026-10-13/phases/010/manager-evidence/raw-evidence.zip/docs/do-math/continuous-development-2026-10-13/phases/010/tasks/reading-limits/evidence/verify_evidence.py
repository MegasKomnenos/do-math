import hashlib
import json
import re
import unicodedata
from pathlib import Path
from investigate import EVIDENCE, REPO, resolve, stamp, write

manifest = json.loads((EVIDENCE / 'fixture-manifest.json').read_text(encoding='utf-8'))
pages = json.loads((EVIDENCE / 'fixture-page-results.json').read_text(encoding='utf-8'))
capped = json.loads((EVIDENCE / 'fixture-capped-results.json').read_text(encoding='utf-8'))
rows = []
for fixture in manifest['fixtures']:
    label = fixture['name'].split('-')[1].split('.')[0]
    selected = sorted([p for p in pages if p['case'].startswith(label + '-')], key=lambda p:p['start'])
    full = []
    for p in selected:
        expected = fixture['expected_lines'][p['start']-1:p['end']]
        received = p['result']['output'].splitlines()
        assert received == expected, p['case']
        assert p['result']['exit_code'] == 0
        assert 'truncated' not in p['result']['output']
        full.extend(received)
    assert full == fixture['expected_lines']
    sample = next(c for c in capped if c['case'].startswith(label))
    received_full_lines = [line for line in sample['result']['output'].splitlines() if re.fullmatch(label + r':\d{3}\|.*\|END:\d{3}', line)]
    ids = [int(line.split(':')[1].split('|')[0]) for line in received_full_lines]
    missing = sorted(set(range(1,81)) - set(ids))
    assert missing and ids[-1] == 80 and sample['result']['exit_code'] == 0
    # These are evidence-verifier controls, not do-math product tests or host limit experiments.
    bad = {'missing_middle': full[:40]+full[41:], 'end_only': full[-1:], 'missing_first': full[1:], 'swapped_order': full[:10]+[full[11],full[10]]+full[12:], 'duplicate_boundary': full[:10]+[full[9]]+full[10:]}
    if label == 'unicode': bad['normalization_change'] = [unicodedata.normalize('NFC', line) for line in full]
    assert all(value != full for value in bad.values())
    rows.append({'fixture': fixture['name'], 'bytes': fixture['bytes'], 'expected_lines': 80, 'pages': len(selected), 'exact_received_lines': len(full), 'all_expected_lines_received': True, 'capped_complete_line_ids': ids, 'missing_line_ids': missing, 'end_marker_visible_despite_missing': True, 'verifier_controls_rejected': list(bad), 'limits': 'No token-to-byte conversion. Output CRLF is normalized only by splitlines; all text code points and line order are exact. Claims apply to the 16 untruncated tool deliveries in this task, not future history retention or comprehension.'})

aggregate = json.loads((EVIDENCE / 'fixture-aggregate-results.json').read_text(encoding='utf-8'))
assert all(len(p['result']['output'].splitlines()) == 10 for p in aggregate['before_outer_delivery'])
assert aggregate['model_observed']['omission_marker'] == '…178 tokens truncated…'
write('fixture-verification.json', {'at_utc': stamp(), 'result': 'pass', 'fixtures': rows, 'aggregate_truncation_detected': True, 'aggregate_limit_unit': 'tokens', 'observation_scope': 'Actual tool responses forwarded to this existing task session; no new model or operator session.'})

sources_start = json.loads((EVIDENCE / 'sources-start.json').read_text(encoding='utf-8'))['files']
extra_start = json.loads((EVIDENCE / 'additional-source-start.json').read_text(encoding='utf-8'))['files']
changes = []
for row in sources_start + extra_start:
    current = hashlib.sha256(resolve(row['ref']).read_bytes()).hexdigest()
    if current != row['sha256']: changes.append({'ref':row['ref'], 'before':row['sha256'], 'after': current})
assert not changes, changes

historical = json.loads((EVIDENCE / 'historical-reading-boundary.json').read_text(encoding='utf-8'))
reuse = []
for name, meta in historical['source_metadata']['product_code'].items():
    p = REPO / '.claude/skills/do-math/scripts/do_math' / name
    if name not in ['contracts.py', 'context_store.py', 'cli_worker.py', 'worker_request.py', 'model_runner.py', 'codex_worker.py', 'claude_worker.py']: continue
    raw = p.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    reuse.append({'file': 'repo:' + p.relative_to(REPO).as_posix(), 'historical_sha256': meta['sha256'], 'current_sha256': digest, 'same': digest == meta['sha256'], 'scope': 'Direct stdin reading-code property only; changed model_runner is reviewed at current source-excerpts, not reused as byte-identical.'})
role_docs = []
for rel, meta in historical['reading_declarations']['internal_roles']['files'].items():
    digest = hashlib.sha256((REPO / '.claude/skills/do-math' / rel).read_bytes()).hexdigest()
    role_docs.append({'path': rel, 'same': digest == meta['sha256'], 'current_sha256': digest, 'historical_sha256': meta['sha256']})
binary_rows = []
for row in json.loads((EVIDENCE / 'host-snapshot.json').read_text(encoding='utf-8'))['binaries']:
    p = Path(row['path']); h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1048576), b''): h.update(chunk)
    binary_rows.append({'path':row['path'], 'before':row['sha256'], 'after':h.hexdigest(), 'same':row['sha256']==h.hexdigest()})
assert all(row['same'] for row in binary_rows)
write('verification.json', {'at_utc':stamp(), 'result':'pass', 'source_observations':len(sources_start)+len(extra_start), 'source_mismatches':changes, 'binary_edition_matches':binary_rows, 'historical_transport_reuse':reuse, 'historical_role_document_reuse':role_docs, 'fixed_input_scope':'Initial 20 hashes plus discovery-time fixed-dependency hashes. Other task writes deliberately excluded; product-wide immutability is not claimed.'})
print(json.dumps({'result':'pass', 'fixtures':rows, 'source_mismatches':len(changes), 'binary_edition_matches':all(r['same'] for r in binary_rows), 'historical_transport_changed':[r['file'] for r in reuse if not r['same']], 'historical_role_docs_changed':[r['path'] for r in role_docs if not r['same']]}, ensure_ascii=False, indent=2))
