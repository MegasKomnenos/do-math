
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$context = Get-Content -LiteralPath 'input/submission/context.json' -Raw | ConvertFrom-Json
$request = Get-Content -LiteralPath 'read-request.json' -Raw | ConvertFrom-Json
$command = @($context.record_map.read_tool.command)
$commandArguments = @($command | Select-Object -Skip 1) + @($request.arguments)
@{version=$PSVersionTable.PSVersion.ToString(); pid=$PID; executable=(Get-Process -Id $PID).Path;
  command=@($command[0]) + $commandArguments; cwd=(Get-Location).Path} |
  ConvertTo-Json -Depth 8 | Set-Content -LiteralPath 'powershell-observed.json' -Encoding UTF8
& $command[0] @commandArguments
exit $LASTEXITCODE
