import hashlib
import json
import mmap
import os
import re
import tomllib
from pathlib import Path
from investigate import EVIDENCE, REPO, stamp, write

def safe_limit(value):
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str) and re.fullmatch(r'[0-9]+', value):
        return value
    return '<non-numeric value redacted>'

paths = [Path('C:/Users/wogud/AppData/Local/Programs/OpenAI/Codex/bin/codex.exe'), Path('C:/Users/wogud/.local/bin/claude.exe')]
rows = []
for p in paths:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''): h.update(chunk)
    rows.append({'path': str(p), 'bytes': p.stat().st_size, 'sha256': h.hexdigest()})

codex_root = Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex')))
config_paths = [codex_root / 'config.toml', REPO / '.codex/config.toml']
selected = []
keys = ['tool_output_token_limit', 'project_doc_max_bytes']
for p in config_paths:
    row = {'path': str(p), 'exists': p.exists(), 'read_scope': keys + ['features.code_mode']}
    if p.exists():
        data = tomllib.loads(p.read_text(encoding='utf-8-sig'))
        row['values'] = {k: {'present': k in data, 'value': safe_limit(data.get(k))} for k in keys}
        row['code_mode'] = {'present': 'code_mode' in data.get('features', {}), 'value': safe_limit(data.get('features', {}).get('code_mode'))}
    selected.append(row)

env_keys = ['CLAUDE_CODE_FILE_READ_MAX_OUTPUT_TOKENS', 'MAX_MCP_OUTPUT_TOKENS', 'BASH_MAX_OUTPUT_LENGTH']
claude_root = Path(os.environ.get('CLAUDE_CONFIG_DIR', str(Path.home() / '.claude')))
claude_configs = []
for p in [claude_root / 'settings.json', REPO / '.claude/settings.json', REPO / '.claude/settings.local.json']:
    row = {'path': str(p), 'exists': p.exists(), 'read_scope': ['env.' + k for k in env_keys]}
    if p.exists():
        data = json.loads(p.read_text(encoding='utf-8-sig'))
        row['values'] = {k: {'present': k in data.get('env', {}), 'value': safe_limit(data.get('env', {}).get(k))} for k in env_keys}
    claude_configs.append(row)

matches = []
patterns = [b'CLAUDE_CODE_FILE_READ_MAX_OUTPUT_TOKENS', b'PARTIAL view', b'File content (', b'2000 characters', b'maxTokens:25000', b'maxBytes:262144', b'maxLines:2000', b'MAX_TOOL_RESULTS_PER_MESSAGE_CHARS', b'MAX_MCP_OUTPUT_TOKENS']
with paths[1].open('rb') as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
    for pattern in patterns:
        offsets = []
        at = 0
        while len(offsets) < 3:
            i = mm.find(pattern, at)
            if i == -1: break
            offsets.append({'offset': i, 'excerpt': mm[max(0, i-100):i+220].decode('utf-8', errors='replace')})
            at = i + len(pattern)
        matches.append({'literal': pattern.decode(), 'first_matches': offsets, 'scope': 'static string evidence, not executed Read contract'})
write('host-snapshot.json', {'at_utc': stamp(), 'binaries': rows, 'codex_config_selected': selected, 'claude_config_selected': claude_configs, 'environment_selected': {k: {'present': k in os.environ, 'value': safe_limit(os.environ.get(k))} for k in env_keys}, 'claude_binary_literals': matches, 'limitations': 'Only selected non-secret keys retained. This process environment is not proof of another operator session environment. No private session, auth, entire config, or credential values copied. Static strings do not establish the branch or effective managed-policy overrides.'})
print(json.dumps({'binaries': rows, 'codex_config_selected': selected, 'claude_config_selected': claude_configs, 'environment_selected': {k: safe_limit(os.environ.get(k)) for k in env_keys}}, ensure_ascii=False, indent=2))

fixtures = []
for label, payload in [('ascii', 'alpha beta gamma 0123456789'), ('unicode', '한글 가나다 café e\u0301 🙂')]:
    lines = [f'{label}:{i:03d}|{payload}|END:{i:03d}' for i in range(1, 81)]
    raw = ('\n'.join(lines) + '\n').encode('utf-8')
    name = f'fixture-{label}.txt'
    (EVIDENCE / name).write_bytes(raw)
    fixtures.append({'name': name, 'lines': 80, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'expected_lines': lines})
write('fixture-manifest.json', {'at_utc': stamp(), 'fixtures': fixtures, 'purpose': 'Finite non-secret exact line sequence; detect missing middle, prefix/suffix truncation and aggregate clipping. Hash is only file identity.'})
