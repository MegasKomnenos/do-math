import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

REPO = Path('C:/math')
RUN = REPO / 'docs/do-math/continuous-development-2026-10-13'
TASK = RUN / 'phases/010/tasks/reading-limits'
EVIDENCE = TASK / 'evidence'

def stamp():
    return datetime.now(timezone.utc).isoformat()

def write(name, data):
    (EVIDENCE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def resolve(ref):
    root, rel = ref.split(':', 1)
    return (REPO if root == 'repo' else RUN) / rel.split('#')[0]

def fingerprint(label):
    phase = json.loads((RUN / 'phases/010/phase.json').read_text(encoding='utf-8-sig'))
    task = next(t for t in phase['tasks'] if t['id'] == 'reading-limits')
    refs = task['inputs'] + ['run:context.md', 'run:plan.md', 'run:seams.md', 'run:phases/010/phase.json', 'run:phases/010/tasks/reading-limits/objective.md', 'repo:services/continuous-development/protocol.md']
    additions = EVIDENCE / 'additional-inputs.json'
    if additions.exists():
        refs += json.loads(additions.read_text(encoding='utf-8'))
    rows = []
    for ref in sorted(set(refs)):
        raw = resolve(ref).read_bytes()
        rows.append({'ref': ref, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    write(f'sources-{label}.json', {'at_utc': stamp(), 'files': rows, 'excluded': [{'ref': p, 'reason': 'Other phase task owns this mutable input; not read or fingerprinted.'} for t in phase['tasks'] if t['id'] != task['id'] for p in t['writes']]})
    print(f'{label}: {len(rows)} fixed inputs fingerprinted')

def extract(ref, start, end):
    p = resolve(ref)
    raw = p.read_bytes()
    lines = raw.decode('utf-8-sig').splitlines()
    row = {'ref': ref, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw), 'lines': len(lines), 'start': start, 'end': min(end, len(lines)), 'text': '\n'.join(f'{n}: {lines[n-1]}' for n in range(start, min(end, len(lines))+1))}
    dest = EVIDENCE / 'source-excerpts.json'
    data = json.loads(dest.read_text(encoding='utf-8')) if dest.exists() else []
    data.append(row)
    write('source-excerpts.json', data)
    print(row['text'])

def command(name, argv):
    started = stamp()
    proc = subprocess.run(argv, cwd=REPO, capture_output=True)
    (EVIDENCE / f'{name}.stdout.txt').write_bytes(proc.stdout)
    (EVIDENCE / f'{name}.stderr.txt').write_bytes(proc.stderr)
    write(f'{name}.command.json', {'started_utc': started, 'ended_utc': stamp(), 'argv': argv, 'cwd': str(REPO), 'exit_code': proc.returncode, 'stdout_bytes': len(proc.stdout), 'stderr_bytes': len(proc.stderr)})
    print(json.dumps({'command': name, 'exit_code': proc.returncode, 'stdout_bytes': len(proc.stdout), 'stderr_bytes': len(proc.stderr)}))

def prior():
    base = RUN / 'phases/001/tasks/document-closeout/evidence'
    packets = json.loads((base / 'followup-packets.json').read_text(encoding='utf-8-sig'))
    packet = next(p for p in packets['packets'] if p['id'] == 'L01')
    inventory = json.loads((base / 'binding-inventory.json').read_text(encoding='utf-8-sig'))
    found = []
    def walk(value, path):
        if isinstance(value, dict):
            for k, v in value.items():
                if k == 'reading_boundary_review': found.append({'json_path': path + [k], 'value': v})
                else: walk(v, path + [k])
        elif isinstance(value, list):
            for i, v in enumerate(value): walk(v, path + [i])
    walk(inventory, [])
    data = {'L01': packet, 'reading_boundary_review': found}
    write('prior-reading-boundary.json', data)
    print(json.dumps(data, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['fingerprint', 'extract', 'command', 'prior'])
    parser.add_argument('args', nargs='*')
    ns = parser.parse_args()
    if ns.mode == 'fingerprint': fingerprint(*ns.args)
    elif ns.mode == 'extract': extract(ns.args[0], int(ns.args[1]), int(ns.args[2]))
    elif ns.mode == 'prior': prior()
    else: command(ns.args[0], ns.args[1:])
