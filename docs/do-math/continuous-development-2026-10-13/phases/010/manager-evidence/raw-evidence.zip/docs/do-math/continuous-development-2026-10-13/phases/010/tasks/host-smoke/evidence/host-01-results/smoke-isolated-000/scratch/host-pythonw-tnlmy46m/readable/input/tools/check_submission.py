import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).with_name('submission-support.zip')))
from do_math.submission_tool import main
raise SystemExit(main())
