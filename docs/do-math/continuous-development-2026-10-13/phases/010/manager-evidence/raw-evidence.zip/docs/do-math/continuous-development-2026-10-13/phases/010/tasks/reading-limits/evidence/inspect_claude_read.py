import json
import mmap
import re
from pathlib import Path
from investigate import write, stamp

p = Path('C:/Users/wogud/.local/bin/claude.exe')
patterns = [b'Zze=262144', b'Lines longer than', b'lines longer than', b'The line number to start reading from', b'The number of lines to read', b'allow_large', b'bashOutputMaxChars', b'maxSelectedBytes:']
rows = []
with p.open('rb') as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
    for pattern in patterns:
        found = []
        start = 195000000
        while len(found) < 3:
            i = mm.find(pattern, start)
            if i < 0: break
            found.append({'offset': i, 'excerpt': mm[max(0, i-160):i+360].decode('utf-8', errors='replace')})
            start = i + len(pattern)
        rows.append({'literal': pattern.decode(), 'matches': found})
write('claude-static-read-details.json', {'at_utc': stamp(), 'binary': str(p), 'scope': 'only static excerpts, no Read call or model session', 'rows': rows})
print(json.dumps(rows, ensure_ascii=False, indent=2))
