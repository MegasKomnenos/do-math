@echo off
"C:\Users\wogud\AppData\Local\Programs\Python\Python312\python.exe" -u -B "C:\math\docs\do-math\continuous-development-2026-10-13\phases\010\tasks\host-smoke\evidence\host-final-results\smoke-isolated-000\scratch\host-job-nonzero-ar4klqrv\local-cli.py" %*
exit /b %errorlevel%
