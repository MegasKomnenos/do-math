import json, os, subprocess, sys, threading
from pathlib import Path
root = Path(__file__).resolve().parent
def atomic(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value), encoding='utf-8')
    os.replace(temporary, path)
if len(sys.argv) == 1:
    child = subprocess.Popen([sys.executable, '-B', __file__, 'grandchild'], creationflags=subprocess.CREATE_NO_WINDOW)
    atomic(root / 'child.json', {'pid':os.getpid(), 'argv':sys.argv, 'cwd':str(Path.cwd()), 'executable':sys.executable})
    try:
        while not (root / 'release').is_file(): threading.Event().wait(.02)
        child.wait()
    finally:
        if child.poll() is None:
            child.terminate()
            child.wait()
else:
    atomic(root / 'grandchild.json', {'pid':os.getpid(), 'argv':sys.argv, 'cwd':str(Path.cwd()), 'executable':sys.executable})
    while not (root / 'release').is_file(): threading.Event().wait(.02)
