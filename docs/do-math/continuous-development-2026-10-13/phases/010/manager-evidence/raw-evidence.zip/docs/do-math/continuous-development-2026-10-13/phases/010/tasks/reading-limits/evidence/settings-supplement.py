import json
import os
import tomllib
from pathlib import Path
from investigate import REPO, write, stamp

def safe_limit(value):
    return value if value is None or isinstance(value, (int, bool)) else '<non-numeric value redacted>'

keys = ['CLAUDE_CODE_FILE_READ_MAX_OUTPUT_TOKENS', 'MAX_MCP_OUTPUT_TOKENS', 'BASH_MAX_OUTPUT_LENGTH']
claude_root = Path(os.environ.get('CLAUDE_CONFIG_DIR', str(Path.home() / '.claude')))
rows = []
for p in [claude_root / 'settings.json', REPO / '.claude/settings.json', REPO / '.claude/settings.local.json', Path('C:/Program Files/ClaudeCode/managed-settings.json')]:
    row = {'path': str(p), 'exists': p.exists(), 'read_scope': ['bashOutputMaxChars'] + ['env.' + k for k in keys]}
    if p.exists():
        d = json.loads(p.read_text(encoding='utf-8-sig'))
        row['bashOutputMaxChars'] = {'present': 'bashOutputMaxChars' in d, 'value': safe_limit(d.get('bashOutputMaxChars'))}
        row['env_limits'] = {k: {'present':k in d.get('env', {}), 'value': safe_limit(d.get('env', {}).get(k))} for k in keys}
    rows.append(row)
codex_root = Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex')))
codex_rows = []
for p in [codex_root / 'config.toml', REPO / '.codex/config.toml']:
    limits = []
    data = tomllib.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else {}
    def walk(d, in_profile=False):
        if isinstance(d, dict):
            for k,v in d.items():
                if k == 'tool_output_token_limit': limits.append({'in_profile':in_profile, 'value': safe_limit(v)})
                else: walk(v, in_profile or k == 'profiles')
    walk(data)
    codex_rows.append({'path': str(p), 'exists': p.exists(), 'selected_limit_occurrences': limits, 'profile_names_retained': False})
write('settings-supplement.json', {'at_utc': stamp(), 'claude': rows, 'codex': codex_rows, 'scope': 'Selected non-secret limit keys only. No config changes. Other operator session, flag, managed service, SDK fileReadingLimits and hook overrides remain unobserved.'})
print(json.dumps({'claude': rows, 'codex': codex_rows}, ensure_ascii=False, indent=2))
