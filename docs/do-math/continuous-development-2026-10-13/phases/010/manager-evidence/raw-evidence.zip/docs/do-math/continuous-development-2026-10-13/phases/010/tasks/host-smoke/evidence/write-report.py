import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
BASE='run:phases/010/tasks/host-smoke/evidence/'
def ref(name): return BASE+name
verification=json.loads((HERE/'verification.json').read_bytes())

details={
    't5-list':('pass','T5 자동 선택은 기존 공급자2건과 새 host3건을 포함한다. 목록 조회만 수행했고 공급자 호출은 없다.'),
    'host-01':('fail','실제3선택 완결:2passed/1failed. 정상 로컬CLI 표본의 turn.started 누락으로 parser가 invalid_lifecycle_order를 반려했다. 원실패를 보존했다.'),
    'host-02':('pass','수정 후 실패한1개 ID만 재실행해1passed/exit0. 다른 두 시험을 이1건 실행에 합치지 않는다.'),
    'host-final':('pass','Python 판본 기록/exit7 정확 오류 단언을 포함한 최종3선택/3고유row/3passed/exit0. 실제 Job·worker·CLI/자손 종료·pythonw 읽기의 원자료4묶음과867개 Python 전후/현재 해시를 대조했다.'),
    'related':('fail','61선택/61고유row/59passed/1failed/1error/exit1. 수정 boundary21개는 전부 passed. 기존 smell 검사4개 unpinned_rejection과 수정하지 않은 call_jobs 오류가 남는다.'),
    'baseline-repro':('fail','첫 독립 사본 구성은 문서의 Git LF/작업본 CRLF 차이 때문에 도중에 중단됐다. 불완전 사본 runner의 exit2/missing test folder는 준비 실패이며 제품 반례가 아니다.'),
    'baseline-repro-02':('pass','시작 해시와 일치하는976파일의 독립 사본에서 정확 두 ID를 실행했다. 기대한 failed1/error1/exit1이 재현됐다. 기존 실패 확인의 통과이며 제품 시험 통과로 세지 않는다.'),
    'mirror-build':('pass','사전 mirror-plan의 허용7경로와 실제 생성2/갱신5/삭제0 변경이 정확히 일치한다. manifest/규칙 변경은 없다.'),
    'mirror-host':('pass','미러의 같은 host3선택/3고유row/3passed/exit0 및867개 Python 소스 불변. 실제 관측4묶음은 정본 실행과 별도로 보존한다.'),
    'cache-sync':('pass','미러 실행 뒤 공식 생성기로 .agents 비용 캐시1파일만 동기화했다. cache-plan/실제 변화가 같고 양쪽 최종 cache 바이트가 같다.'),
    'mirror-check':('pass','공식 --check exit0/1307파일 드리프트 없음. 제품 변화0.'),
    'skill-only':('pass','정본 probe_cli --skill-only exit0/verified. 문서 의미·연구운전·Lean 검증을 대신하지 않는다.'),
    'final-verification':('pass','선택/고유row/counts/실제exit·867개 Python 해시·원OS 판정·정리·21개 기존 test method AST·허용14변경·runtime124/공급자입력3/corpus102 불변을 원파일과 대조했다.')
}
checks=[]
for name,(result,detail) in details.items():
    command=json.loads((HERE/(name+'.command.json')).read_bytes())
    evidence=[ref(name+'.command.json'),ref(name+'.stdout.log'),ref(name+'.stderr.log')]
    if name in verification['suites'] or name in ('baseline-repro','baseline-repro-02'):
        path=HERE/(name+'-results/report.json')
        if path.is_file(): evidence.append(ref(name+'-results/report.json'))
    checks.append({'command':subprocess.list2cmdline(command['argv']),'cwd':'repo:.','result':result,
                   'exit_code':command['exit_code'],'evidence':evidence,'detail':detail})

report={
 'status':'partial',
 'narrative':'''G7의 Windows Job 작업자·pythonw 출력 경계를 공식 T5에 연결했다. 시작 HEAD6a460c15253d46eba33fb36772a0f0910382a28f의 제품/시험2640파일은009 종료본과 전건 동일했고 기존 dirty와 관리 커밋을 구분했다. Job/worker·console_python·지급 command 및 관련 도입 diff/존재하는 원보고를 대조한 유지·공유화·추가 판단은 evidence/review.md에 기록했다. 기존 boundary21개 test method 본문과 단언은 바이트 편집 전후 AST가 같으며, 준비/커널 helper만 support.host_live로 이동했다.

실제 real_ports/ModelRunner/adapter/Codex worker/collector를 실행하고 외부 모델CLI만 자기 scratch의 결정적 로컬프로그램으로 대신했다. 실제 worker의 시작 공개·PID/FILETIME/이름 있는Job과 CLI/child/grandchild 소유를 커널에서 직접 관측했다. 정상 응답·정확exit7/stderr/실행실패 이유, 명시취소 뒤 네 held handle 신호·빈Job/termination barrier를 검사했다. pythonw가 실제 install_tools로 지급한 console_python 명령을 PowerShell5.1.22621.6133에서 소비해 정상JSON/exit0와 권한반려JSON/exit1·읽기로그를 검사했다. 실제 argv/cwd·판본·console0·원출력/파일/파싱/정리 결과는 공식 runner scratch의 smoke.json/call/과 pythonw 작업폴더에 보존한다. 유료 모델 호출과 OS 예약 변경은0건이다.

첫 host3건은2passed/1failed였다. 정상 로컬CLI 사건표본의 turn.started 누락을 실제parser가 반려한 fixture 실패였으며 제품을 바꾸지 않고 표본만 고쳤다. 해당1건 재검사는passed다. 판본 기록과 정확 오류 단언을 보강한 최종 정본과 미러의 각각3선택/3고유row는 모두passed/exit0이고867개Python 전후/현재 해시가 같다. 양쪽 OS원자료 각각4묶음의 실제 판정과 자원정리를 별개 실행으로 검산했다.

관련61선택은59passed/1failed/1error다. 수정범위 밖의 기존 smell4지점 반려와 call_jobs 취소fixture의 clock/environment 누락·오류dict를tuple로읽는KeyError가 남는다. 시작바이트와 일치하는976파일의 독립사본에서 정확 두ID가 같은 failed/error로 재현됐다. 직접 _job_run 호출의 원TypeError도 기록했다. 자기쓰기범위에 없는 파일/런타임을 고치지 않고 후속수리로 반환하므로 A3는fail, task는partial이다. 새host성공으로 이실패나 전체T5/G7을 감추지 않는다. 첫 baseline구성의 개행해시반려와 불완전사본runner exit2는 준비오류로 별도보존했고 두번째 검증된사본의 재현과 구분했다.

변화14개는phase writes와 정확히 같다. 사전계획/실제미러7변경과 최종캐시1변경이 대응하며 --check1307파일/skill-only는exit0/verified다. runtime124·기존공급자smoke입력3·양쪽corpus102경로는불변으로003/006~009의승인된한정재사용조건을 유지한다. 로컬CLI 출력은 실제공급자녹화가아니며 corpus에는넣지않았다. Lean/Mathlib·OS예약등록/발화/해제·학술MCP/L01과G4~G6/G8은미검증/후속책임이다. Git stage/commit/reset/checkout/push와graphify갱신 및 기존연구작업은수행하지않았다.''',
 'acceptance':[
   {'id':'A1','result':'pass','detail':'009 종료2640파일과 시작 전건 같음·HEAD/dirty 분리, 실제 두연쇄의 파일/심볼·기존검사 책임과 새T5 공백을 특정했다. 91d59a80/62b7c220/b484771e 실제diff·현재caller·B117/B118 원보고6개 SHA/row를 대조했다. 없는Temp counts는 새성공에 쓰지 않고 다른PR영역은 닫지 않았다.',
    'evidence':[ref('start.json'),ref('review.md'),ref('history-91d59a80.diff'),ref('history-62b7c220.diff'),ref('history-b484771e.diff'),ref('history-existing-reports.json'),ref('history-original-reports.json')]},
   {'id':'A2','result':'pass','detail':'최종 정본/미러 host3건 전건passed. 실제worker/Job·외부CLI/자손의커널소유와시작식별·정상회수/정확exit7·명시취소와빈Job/held handle 신호, pythonw→PowerShell→제품읽기의정확JSON/exit0/1을검사했다. 각원파일/판본/argv/cwd/파싱/정리는scratch에보존된다. 대역은외부CLI자리뿐이며 모델실호출/실예약은아니다.',
    'evidence':[ref('host-final-results/report.json'),ref('mirror-host-results/report.json'),ref('verification.json'),ref('review.md')]},
   {'id':'A3','result':'fail','detail':'T5목록의공급자2+host3, 최종host3/3와모든원실패·선택/고유row/소스/실제exit는보존했다. 그러나관련61건 중 기존smell1failed/call_jobs1error가남아 지정관련회귀를 전건통과로제출할수없다. 시작사본에서동일두ID를재현했다. 수정21개boundary와포트/기타구조59건은passed지만묶음의successful=false를보존한다. 두쓰기범위밖수리가필요하다.',
    'evidence':[ref('t5-list.stdout.log'),ref('host-01-results/report.json'),ref('host-02-results/report.json'),ref('host-final-results/report.json'),ref('related-results/report.json'),ref('baseline-manifest.json'),ref('baseline-repro-02-results/report.json'),ref('call-jobs-diagnosis.json')]},
   {'id':'A4','result':'pass','detail':'T5호스트 선택/실제자원/원자료/한계·후속책임을시험지침에추가했다. 공식계획과미러생성의7변경은writes안이고미러host3/3passed. 비용캐시만공식재동기화했고 --check1307파일/skill-only가통과했다. runtime124/공급자입력3/corpus102불변과기존실호출재사용조건, 별도G7및최종관문책임을명시했다.',
    'evidence':[ref('mirror-plan.json'),ref('mirror-build.command.json'),ref('mirror-host-results/report.json'),ref('cache-plan.json'),ref('cache-sync.command.json'),ref('mirror-check.stdout.log'),ref('skill-only.stdout.log'),ref('verification.json'),'repo:.claude/skills/do-math/scripts/tests/시험-지침.md']}
 ],
 'changes':[],
 'seams':[],
 'findings':[
  {'id':'F1','kind':'issue','detail':'기존 boundary.test_scheduling_call_jobs의실제취소검사는 _job_run에필수clock/environment를전달하지않는다. ModelCalls가TypeError를failed-result dict로돌려준뒤returned[0][-1]이KeyError를내므로 실제Job취소가실행되지않는다. 관련보고와시작판본정확ID재현이동일error다. call-jobs-diagnosis의직접호출은원TypeError를기록한다. 새T5의실제취소는통과했지만이기존검사의소유자판정/단일수집성질을대신해통과로세지않는다.',
   'evidence':[ref('related-results/report.json'),ref('baseline-repro-02-results/report.json'),ref('call-jobs-diagnosis.json')],
   'affects':['run:context.md#G3','run:context.md#G7','run:phases/010/tasks/host-smoke/objective.md#A3','repo:.claude/skills/do-math/scripts/tests/boundary/test_scheduling_call_jobs.py'],
   'next_action':'별도work에서정본/미러 test_scheduling_call_jobs.py를writes에넣고 실제real_ports의clock/environment를전달한다. 실패dict 원인을 먼저확인하고기존owner callback/collect once/빈Job단언을유지해정확실패ID와영향받는Calls/Job회귀를검사한다. runtime수리는현재근거상필요없다.'},
  {'id':'F2','kind':'issue','detail':'structure.test_test_smells의전건검사에서 unpinned_rejection4건이실패한다: structure/test_doc_code.py의test_deferred_operational_inputs_have_a_document_check_in_the_assigned_method:35와 sim/test_knowledge_currentness.py의test_normal_formal_completion_has_null_checkpoint_and_reports_unrestorable_sources:108 및 test_failed_execution_materials_are_restored_for_its_operational_review:181의두지점이다. 시작판본에서같은실패를재현했다. 새host/수정boundary의smell_issues와support의product_patch는모두빈목록이다. 규칙을약화하거나배정밖시험을수정하지않았다.',
   'evidence':[ref('related-results/report.json'),ref('baseline-repro-02-results/report.json'),ref('verification.json')],
   'affects':['run:context.md#G3','run:context.md#G4','run:phases/010/tasks/host-smoke/objective.md#A3','repo:.claude/skills/do-math/scripts/tests/structure/test_doc_code.py','repo:.claude/skills/do-math/scripts/tests/sim/test_knowledge_currentness.py'],
   'next_action':'별도work에서해당정본/미러두시험파일의음성단언에실제기대오류의고유문구/issue를고정하거나caught.exception을검사한다. 같은입력과정상경로를유지하고 smell_rules는바꾸지않는다. 실패한전건냄새검사와해당음성ID/관련범위만재검사한다.'},
  {'id':'F3','kind':'fact','detail':'현재OS한정T5는정본3/3·미러3/3 통과하며새유료공급자호출은0이다. 종료판본은runtime124·기존공급자smoke입력3·corpus102경로(각18항목51파일223685바이트50명시SHA)와규칙/속성이시작과같다. 기존실호출/원바이트인도증거의승인된재사용조건은유지된다. 로컬CLI녹화는공급자corpus에추가하지않았고다른G7·전체관문은실행하지않았다.',
   'evidence':[ref('verification.json'),ref('review.md'),ref('source-start.json'),ref('source-end.json')],
   'affects':['run:context.md#C11','run:context.md#C12','run:context.md#G7','run:plan.md'],
   'next_action':'manager가이OS성질의새근거를한정승인하고기존공급자재사용조건을유지한다. F1/F2를정확수리한뒤다른G7연쇄와최종G4~G6/G8을배정한다. host성공을전체T5/예약/Lean/학술성공으로올리지않는다.'}
 ],
 'checks':checks
}
for path in verification['changes']:
    if path.endswith('.timings.json'): detail='공식실행비용캐시갱신/최종정본기준공식동기화. 시험결과캐시아님.'
    elif path.endswith('test_host_live.py'): detail='실제worker/Job정상·exit7회수,명시취소/자손종료,pythonw의지급읽기성공/반려를T5자동선택에추가.'
    elif path.endswith('host_live.py'): detail='기존커널wait/held handle·Git snapshot/pythonw준비의공용정본과원자료보존형실제host연쇄. 외부CLI만로컬결정적프로그램.'
    elif path.endswith('시험-지침.md'): detail='T5host선택명령·실제자원/원자료위치·공급자대역한계·별도후속G7책임추가.'
    else: detail='기존시험메서드/단언21건을유지하면서공통준비/관측을support.host_live에서소비하도록이동.'
    if path.startswith('.agents/'): detail='공식생성미러: '+detail
    report['changes'].append({'path':path,'detail':detail})
(HERE.parent/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Wrote partial report; A1/A2/A4 pass, A3 fail.')
