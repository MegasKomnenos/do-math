import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path('C:/math')
RUN = REPO / 'docs/do-math/continuous-development-2026-10-13'
HERE = Path(__file__).resolve().parent

def save(name, value):
    (HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

prior = json.loads((RUN/'phases/001/tasks/closure-map/evidence/prior-review-state.json').read_bytes())
board = json.loads((REPO/'docs/do-math/시험-재편-2026-09-29/단계-전환표-2026-10-03.json').read_bytes())
selected = []
for unit in prior['review_units']:
    for item in unit['review_slices']:
        if item['history_id'] in ('B14','B50','B62'):
            selected.append({'unit':unit['id'], **item})
save('history-slices.json',selected)
for item in selected:
    value=board
    for part in item['board_selector'].strip('/').split('/'):
        value=value[part]
    save('history-'+item['history_id']+'-board.json',value)
    print(item['history_id'], 'keys:', list(value))

paths = ['.claude/skills/do-math/scripts/do_math/windows_job.py',
         '.claude/skills/do-math/scripts/do_math/file_io.py',
         '.claude/skills/do-math/scripts/do_math/submission.py',
         '.claude/skills/do-math/scripts/tests/boundary/test_role_input_snapshot_reach.py',
         '.claude/skills/do-math/scripts/tests/boundary/test_scheduling_windows_job.py',
         '.claude/skills/do-math/scripts/tests/boundary/test_scheduling_owned_job_children.py',
         '.claude/skills/do-math/scripts/operator_schedule.ps1']
for commit in ('62b7c220','91d59a80','3731af18','e65d9b80'):
    result=subprocess.run(['git','show',commit,'--',*paths],cwd=REPO,capture_output=True)
    (HERE/('history-'+commit+'.diff')).write_bytes(result.stdout)
    print(commit,result.returncode,len(result.stdout))
observations=[]
for item in selected:
    for selector in item['original_report_selectors']:
        value=board
        try:
            for part in selector.strip('/').split('/'):
                value=value[int(part)] if isinstance(value,list) else value[part]
        except (KeyError,IndexError):
            observations.append({'selector':selector,'unresolved':True})
            continue
        if not isinstance(value,str):
            observations.append({'selector':selector,'not_string':True})
            continue
        path=Path(value)
        if not path.is_absolute(): path=REPO/path
        row={'selector':selector,'path':str(path),'exists':path.is_file()}
        if path.is_file():
            raw=path.read_bytes()
            row['sha256']=hashlib.sha256(raw).hexdigest()
            try:
                content=json.loads(raw)
                row['keys']=list(content) if isinstance(content,dict) else None
                row['summary']={k:content[k] for k in ('complete','successful','counts','selected','selection','tests_run') if k in content}
            except (ValueError,TypeError): pass
        observations.append(row)
save('history-original-reports.json',observations)
print(json.dumps(observations,ensure_ascii=False,indent=2))
