import hashlib
import json
from pathlib import Path
import subprocess

REPO=Path('C:/math')
HERE=Path(__file__).resolve().parent
original=json.loads((HERE/'source-start.json').read_bytes())
base=HERE/'baseline-tree-02/.claude/skills/do-math/scripts'
assert not base.exists()
base.mkdir(parents=True)
changed=['tests/boundary/test_scheduling_windows_job.py','tests/boundary/test_scheduling_owned_job_children.py',
         'tests/boundary/test_role_input_snapshot_reach.py','tests/시험-지침.md']
added=['tests/smoke/test_host_live.py','tests/support/host_live.py']
prefix='.claude/skills/do-math/scripts/'
manifest={}
for source in (REPO/prefix).rglob('*'):
    if not source.is_file() or '__pycache__' in source.parts or source.suffix=='.pyc': continue
    rel=source.relative_to(REPO/prefix).as_posix()
    if rel in added: continue
    path=prefix+rel
    raw=subprocess.check_output(['git','show','HEAD:'+path],cwd=REPO) if rel in changed else source.read_bytes()
    if rel in changed and hashlib.sha256(raw).hexdigest()!=original[path]:
        candidates=[raw.replace(b'\r\n',b'\n'),raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
        raw=next(candidate for candidate in candidates if hashlib.sha256(candidate).hexdigest()==original[path])
    sha=hashlib.sha256(raw).hexdigest()
    if rel!='tests/.timings.json': assert sha==original[path],path
    dest=base/rel
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(raw)
    manifest[rel]=sha
(HERE/'baseline-manifest.json').write_text(json.dumps({'source_root':str(base),'restored_from_head':changed,
    'omitted_additions':added,'cache_is_nonproduct':True,'hashes':manifest},indent=2),encoding='utf-8')
print('Verified start-edition copy:',len(manifest),'files')
