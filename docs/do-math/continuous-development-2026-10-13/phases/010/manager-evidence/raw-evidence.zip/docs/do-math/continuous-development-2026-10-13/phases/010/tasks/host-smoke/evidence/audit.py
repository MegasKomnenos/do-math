import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

REPO = Path('C:/math')
RUN = REPO / 'docs/do-math/continuous-development-2026-10-13'
HERE = Path(__file__).resolve().parent
PYTHON = sys.executable

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def snapshot():
    old = json.loads((RUN / 'phases/009/tasks/document-callable/evidence/source-final.json').read_bytes())
    paths = set(old)
    for base in ('.claude/skills', '.agents/skills', '.agents/diff', 'services/continuous-development'):
        for p in (REPO / base).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
                paths.add(p.relative_to(REPO).as_posix())
    return {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in sorted(paths) if (REPO / p).is_file()}

def command(name, args):
    before = snapshot()
    write(HERE / (name + '.before.json'), before)
    started = datetime.now(timezone.utc).isoformat()
    with (HERE / (name + '.stdout.log')).open('wb') as out, (HERE / (name + '.stderr.log')).open('wb') as err:
        process = subprocess.Popen(args, cwd=REPO, stdout=out, stderr=err, env={**os.environ, 'PYTHONDONTWRITEBYTECODE':'1'})
        write(HERE / (name + '.process.json'), {'argv':args, 'cwd':str(REPO), 'pid':process.pid, 'started_at':started})
        code = process.wait()
    after = snapshot()
    write(HERE / (name + '.after.json'), after)
    changed = [p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)]
    info = {'argv':args, 'cwd':str(REPO), 'pid':process.pid, 'started_at':started,
            'ended_at':datetime.now(timezone.utc).isoformat(), 'exit_code':code, 'changed_sources':changed}
    write(HERE / (name + '.command.json'), info)
    print(json.dumps(info, ensure_ascii=False), flush=True)
    print((HERE / (name + '.stdout.log')).read_text(encoding='utf-8', errors='replace')[-5500:])
    print((HERE / (name + '.stderr.log')).read_text(encoding='utf-8', errors='replace')[-3500:])
    return code

def mirror_plan(name):
    path = REPO / '.claude/skills/writing-skills/scripts/build_skill_mirrors.py'
    spec = importlib.util.spec_from_file_location('mirror', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rules = module.load_rules(REPO / '.agents/diff')
    sources = module.iter_files(REPO / '.claude/skills')
    overlays = {r:p for r,p in module.iter_files(REPO / '.agents/diff').items() if r not in module.RESERVED}
    expected = {r:module.transform(r,p.read_bytes(),rules) for r,p in sources.items()}
    expected.update({r:p.read_bytes() for r,p in overlays.items()})
    existing = module.iter_files(REPO / '.agents/skills')
    changes = ['.agents/skills/' + r for r in sorted(set(expected)|set(existing))
               if r not in existing or r not in expected or expected[r] != existing[r].read_bytes()]
    phase = json.loads((RUN / 'phases/010/phase.json').read_bytes())
    allowed = next(t['writes'] for t in phase['tasks'] if t['id']=='host-smoke')
    forbidden = [p for p in changes if p not in allowed]
    manifest = json.loads((REPO / '.agents/diff/_manifest.json').read_bytes())
    next_manifest = {'overlays':{r:module.sha1(sources[r].read_bytes()) for r in overlays if r in sources}}
    write(HERE / (name + '.json'), {'changes':changes,'outside_writes':forbidden,'manifest_semantically_unchanged':manifest==next_manifest})
    assert not forbidden and manifest == next_manifest
    print(json.dumps(changes, ensure_ascii=False))

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'start':
        current = snapshot()
        write(HERE / 'source-start.json', current)
        old = json.loads((RUN / 'phases/009/tasks/document-callable/evidence/source-final.json').read_bytes())
        info = {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip(),
                'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO).decode(),
                'prior_count':len(old),'source_count':len(current),
                'prior_mismatches':[p for p,h in old.items() if current.get(p)!=h]}
        write(HERE / 'start.json', info)
        print(json.dumps(info,ensure_ascii=False))
    elif action == 'run':
        raise SystemExit(command(sys.argv[2], [PYTHON,'-u','-B',*sys.argv[3:]]))
    elif action == 'plan':
        mirror_plan(sys.argv[2])
    elif action == 'end':
        write(HERE / 'source-end.json', snapshot())
