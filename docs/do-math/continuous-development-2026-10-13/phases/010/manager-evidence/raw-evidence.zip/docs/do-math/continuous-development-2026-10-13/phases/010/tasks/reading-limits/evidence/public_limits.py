import hashlib
import json
import urllib.request
from investigate import stamp, write

url = 'https://developers.openai.com/codex/config-schema.json'
at = stamp()
try:
    with urllib.request.urlopen(url, timeout=30) as response:
        raw = response.read()
        schema = json.loads(raw)
        selected = {}
        def walk(v, path):
            if isinstance(v, dict):
                for k,x in v.items():
                    if k == 'tool_output_token_limit': selected['/'.join(path+[k])] = x
                    else: walk(x, path+[k])
            elif isinstance(v,list):
                for i,x in enumerate(v): walk(x, path+[str(i)])
        walk(schema, [])
        write('public-codex-schema.json', {'queried_utc': at, 'url': url, 'resolved_url': response.url, 'http_status': response.status, 'document_bytes': len(raw), 'document_sha256': hashlib.sha256(raw).hexdigest(), 'selected_properties': selected, 'version_scope': 'Public current schema, not proof of installed 0.162.1 effective config or current tools.'})
        print(json.dumps({'status': response.status, 'selected_properties': selected}, ensure_ascii=False, indent=2))
except Exception as exc:
    write('public-codex-schema.json', {'queried_utc': at, 'url': url, 'error_type': type(exc).__name__, 'error': str(exc)})
    raise
