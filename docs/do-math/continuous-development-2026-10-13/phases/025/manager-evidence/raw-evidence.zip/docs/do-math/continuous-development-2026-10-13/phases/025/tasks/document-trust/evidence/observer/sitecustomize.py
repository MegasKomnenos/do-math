"""Evidence-only return observer; does not replace a product call or test."""
import inspect
import json
import os
from pathlib import Path
import sys

root = os.environ.get('TRUST_OBSERVER_OUTPUT')
scripts = os.environ.get('TRUST_OBSERVER_SCRIPTS')
if root and scripts:
    sys.path[:0] = [scripts, str(Path(scripts) / 'tests')]
    from do_math import formal, trust_validation
    from do_math.context_store import prepare_role_input
    from support.monitoring_slots import reserve_tool
    output = Path(root)
    output.mkdir(parents=True, exist_ok=True)
    path = output / (str(os.getpid()) + '.jsonl')
    codes = {inspect.unwrap(f).__code__: name for name, f in (
        ('project', formal._project_identity), ('toolchain', formal.inspect_toolchain),
        ('environment_check', trust_validation.check_environment), ('job', formal._job_run),
        ('prepared', prepare_role_input))}
    def write(value):
        with path.open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(value, ensure_ascii=False) + '\n')
    write({'kind': 'process', 'pid': os.getpid(), 'cwd': os.getcwd(), 'argv': sys.argv})
    def returned(code, offset, value):
        frame = sys._getframe(1)
        args = frame.f_locals
        name = codes[code]
        try:
            row = {'kind': name, 'value': value, 'cwd': os.getcwd()}
            if name in ('project', 'toolchain', 'job'):
                row['command'] = args['command']
                row['workspace'] = str(args.get('workspace', args.get('cwd')))
            elif name == 'environment_check':
                row['environment'] = args['environment']
                row['input_binding'] = args['binding']
                row['identity_requested'] = args['identity']
            else:
                context = value['context']
                seat = context.get('role_review')
                if not isinstance(seat, dict) or 'proposal' not in seat:
                    return
                proposal = seat['proposal']
                def count(node):
                    if isinstance(node, dict):
                        return int(node == proposal) + sum(count(v) for v in node.values())
                    if isinstance(node, list):
                        return sum(count(v) for v in node)
                    return 0
                row['proposal_count'] = count(context)
            write(row)
        except Exception as error:
            write({'kind': 'observer_error', 'target': name, 'error': repr(error)})
    tool = reserve_tool('025 actual trust returns')
    sys.monitoring.register_callback(tool, sys.monitoring.events.PY_RETURN, returned)
    for code in codes:
        sys.monitoring.set_local_events(tool, code, sys.monitoring.events.PY_RETURN)

    def audit(event, args):
        if event == 'subprocess.Popen':
            write({'kind': 'popen', 'program': str(args[0]), 'argv': args[1],
                   'cwd': str(args[2]) if args[2] is not None else os.getcwd()})
    sys.addaudithook(audit)
