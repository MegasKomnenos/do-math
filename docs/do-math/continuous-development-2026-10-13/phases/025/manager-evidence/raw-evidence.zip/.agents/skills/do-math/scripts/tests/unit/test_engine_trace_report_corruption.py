"""잘린 JSON과 읽을 수 없는 경로를 완료 증거로 바꾸지 않는다."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from do_math.trace_report import phase_rows, progress, trace_rows
from support.doc_code import documents, field_schemas, scoped_field_issues, unowned_field_references
from support.fakes.clock import FakeClock


class TraceCorruptionTests(unittest.TestCase):
    def test_invalid_rows_and_unreadable_paths_keep_exact_source_and_no_completion(self):
        clock = FakeClock()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'a.jsonl').mkdir()
            raw = b'[]\n{"event":"completed"\n'
            (root / 'b.jsonl').write_bytes(raw)
            start = {'event': 'started', 'operation_id': 'OP-one', 'span_id': 'SP-one',
                     'phase': 'publish', 'observed_at': clock.now()}
            content = (json.dumps(start) + '\n').encode()
            (root / 'c.jsonl').write_bytes(content)
            clock.advance(11)
            rows = trace_rows(root, clock=clock)
            self.assertEqual(rows[:3], [{'event': 'unreadable_trace', 'file': 'a.jsonl'},
                {'event': 'incomplete_trace', 'file': 'b.jsonl'}, {'event': 'incomplete_trace', 'file': 'b.jsonl'}])
            self.assertEqual(rows[3], {**start, '_trace_source': {'path': str(root / 'c.jsonl'),
                'sha256': hashlib.sha256(content).hexdigest(), 'observed_at': clock.now()}})
            phases = phase_rows(root, clock=clock)
            self.assertEqual(len(phases), 1)
            self.assertEqual((phases[0]['created_at_utc'], phases[0]['ended_at_utc'], phases[0]['elapsed_ns']),
                             (start['observed_at'], None, None))
            self.assertNotIn('outcome', phases[0])

    def test_unreadable_error_sidecar_has_bounded_explicit_status(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'errors').mkdir()
            (root / 'live').mkdir()
            for index in range(18):
                (root / 'errors' / f'{index:02}.json').write_bytes(b'{broken')
            clock = FakeClock()
            result = progress(root, clock=clock)
            self.assertEqual(result['telemetry_errors'], [
                {'operation_id': f'{index:02}', 'status': 'unreadable_error_record'} for index in range(2, 18)])
            self.assertEqual(result['rows'], [])
            self.assertEqual(result['observed_at'], clock.now())
            # Reuse this actual file response for the same document population
            # as structure.test_doc_code; status stays at its repository boundary.
            skill = Path(__file__).resolve().parents[3]
            texts = [(document.relative_to(skill).as_posix(), document.read_text(encoding='utf-8'))
                     for document in documents(skill)]
            schemas = field_schemas()

            def field_issues(text, report):
                actual = {**schemas, 'operation_progress': {
                    'type': 'object', 'properties': {name: {} for name in report},
                    'additionalProperties': False}}
                return scoped_field_issues(text, actual, defer_status=True,
                                           defer_query_record=True, defer_query_result=True,
                                           defer_continuations=('result_source', 'rejected_response', 'previous_output_files'),
                                           defer_result_inputs=('source_ref', 'materialized_output_files', 'research_sources', 'results'),
                                           defer_operational_inputs=('operational_evidence', 'recovery_materials'),
                                           defer_role_inputs=('input_manifest', 'prompt', 'documents', 'profile_selection'),
                                           defer_cli_results=('init_result', 'scheduling_result', 'selection_result'), defer_tool_inputs=('execution_window', 'scholarly', 'formal_verifier', 'preview', 'record_map.read_tool', 'submission_contract'), defer_review_inputs=('role_review', 'pending_findings', 'review_research', 'review_sources'), defer_delivery_inputs=('submission_check', 'repair'), defer_governance=('import_payload', 'import_check', 'governance', 'academic_validation'), defer_waits=('change', 'plan_settle_wait'), defer_trust=('project', 'toolchain', 'environment_check'))

            self.assertEqual([(name, *issue) for name, text in texts
                              for issue in field_issues(text, result)], [])
            self.assertEqual([(name, token) for name, text in texts
                              for token in unowned_field_references(text, schemas)], [])
            alias = '`result.telemetry_errors` <!-- do-math fields: result=operation_progress -->'
            self.assertEqual(field_issues(alias, result), [])
            for token in ('operation_progress.budget', 'operation_progress.telemetry_errors.status',
                          'operation_progress.telemetry_errors[].status', 'operation_progress.rows[].event'):
                with self.subTest(token=token):
                    self.assertEqual(field_issues('`' + token + '`', result), [('scoped field', token)])
            for name in result:
                with self.subTest(omitted=name):
                    omitted = dict(result)
                    del omitted[name]
                    token = 'operation_progress.' + name
                    self.assertEqual(field_issues('`' + token + '`', omitted), [('scoped field', token)])
                    if name == 'telemetry_errors':
                        self.assertTrue([(path, *issue) for path, text in texts
                                         for issue in field_issues(text, omitted)])
                        self.assertEqual(field_issues(alias, omitted), [('scoped field', 'result.telemetry_errors')])
